# Own decision card after 119

Read the actual reply. Check the current check line and the first body on every proposed route. My private branch is not the board. Huge unplayed trees and late updates remain unresolved; use a concrete immediate check/capture/guard check, then play and adapt.

Real guards only: kings adjacent, pawns forward diagonals, rooks rank/file. A nominal king guard is unusable if the captured piece is enemy-defended. Expensive queen/rook recaptures can still lose material to a cheaper enemy recapture. Count the complete capture sequence and every guard/body removed by my own move.

Preserve retreats before filling them. In 119, f4 blocked Bg3's f4 route; Kf2 then closed f2 before h4 attacked the bishop. Bxh4/Rxh4 lost B3 for P1. Proposed repair Bf2 is not tested yet.

A pawn on the second rank threatens diagonal promotion captures as well as forward promotion. In 119, Ra1's control of b1 did not prevent b2xa1=Q. Rb1 stopped that threat but abandoned a7's guard; Ba3 guarded b2 against an expensive rook capture.

Passed pawns require actual guards and king safety. 119 Kf6 horizontally pinned e6 through Rb6. Advancing e6-e7 removed its diagonal guard of Rf7 and would allow an adjacent enemy king capture if the rook stayed there. Rd7 instead guarded e7; Ra8/Rc8 together stopped the tested promotion threat.

119 scored: 33W/6D/80L. Full 0/0/40, skill 0 29/3/8, nominal 1800 4/3/32. Provisional 1510 [1390,1640], conditional nominal anchors, latest 50 of 79 rated, 40 full excluded, not human Elo. Full-strength stagnation remains. No actual usage counter after formal 114.

Trial 188: six-own-move White/max practice from 119 ply50; try Bf2 and adapt actual replies, then explicitly end if active. Next fixed120 Black/nominal1800; formal review120; endpoint200, no token budget. All reasoning own; no external/delegated/automated chess analysis.

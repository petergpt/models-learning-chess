# Active own decision card after benchmark 102 and practice 75

Own hypotheses and observations, not engine analysis. The longer card is retained in decision_card_after93.md; complete outcomes are in journal.md. A shorter card is a trial, not evidence of better execution.

Read only the actual returned position. Identify check, the enemy move's new attack, and threatened higher pieces. Do not retain unplayed branches as board state.

Choose one or two candidates. For the chosen move, trace its exact route and destination, the cheapest enemy capture, and the last legal own recapture. Check a forcing enemy check that also attacks the queen, rook, bishop or knight. If moving the king, inspect the next supported checking move and actual occupied flights. A rook capture of a pawn can itself mate. Once these immediate checks are coherent, submit the move rather than extending speculative trees.

Place the surviving bodies after the last capture. Enemy rook takes my pawn, my rook takes that enemy rook leaves MY ROOK ALIVE. This was repeatedly miscounted in 96's unplayed branches. A further enemy capture must really exist before removing that rook. See exchange_survivors_after96.md for actual examples.

Pawn double pushes need an empty intermediate square and an en-passant check. A queen guard is insufficient if the cheaper capturing piece has support and my final recapture is absent. A king guard must be adjacent and legal after the capture. Neither equal material nor the first legal king flight proves safety.

White: retain early Be2/castling and develop the remaining knight before exposing a trapped rook to save one pawn. Keep f2's actual g3 guard where relevant. Black: adaptive e6/d5; the d5xe4 trial applies only to actual e4/d4/Nc3 before e5. That trigger did not occur in 94. The old queenless Ng5/f6 trial remains set aside.

Earlier failures remain relevant: an en-passant capture after h5, Re7+ forking king/queen, Ng3+ forking king/queen/rook/bishop, an own knight blocking Rd1-d8, and a queen serving as a pinned king shield. Wins or draws after declined enemy captures did not repair these failures. Complete details remain in the journal.

96 lost: 9...Nf5 vacated d4, opening the d-file. Qxd8/Bxd8/Bxd8 lost a whole bishop after the fair queen exchange; Rf8xd8 would permit Rd1xd8# with Bc8 blocking Ra8. Be4 later pinned Rf5 to the king. The en-passant capture removed g4's f5 guard, making Kxf5 legal after Bxf5+. Bxh2+/Kxh2 won a bishop for a pawn while my rook survived. Connected a/b passers and a rook cutoff defeated the late defense. Zero actual illegal moves did not fix mental material/geometry errors or long speculative execution.

Practice 69: h6/Nxf6+/Bxf6/Bxf6/gxf6/Qxd4/Qxd4/Rxd4. Fair knight, bishop and queen pairs; Nd4 lost whole. White's recapturing rook remained on d4. Final nominal two-point deficit. h6 alone did not establish a saved opening.

97 lost: Rd2 guarded c2; Rd5 abandoned that guard. Bxc2 attacked Rd1 as well. Bishop tempi and the a-passer overloaded the two rooks. Bxd1/Rxd1 lost a rook for a bishop, with the recapturing rook surviving; Rxa1 later captured that last rook whole. Kh2 left the unguarded Nf1 available to Rxf1. Final nominal twelve-point deficit. Early equal exchanges did not preserve coordination.

Practice 70: Ne1/Be7/Rd5/a4/Nd3/c6. c2 retained and equal material after three own moves, but no Bxc2 recapture tested; c6 attacked the rook and the next defense was unplayed. Ne1 really guarded c2; Nd3 really blocked the bishop's ray and had c2's pawn guard. Stop note's premature c5/Nf5xd3 was corrected by an activity note: actual c6/Bf5xd3. Read a returned reply before recording a dependent outcome.

98 lost by Qd7 mate at equal nominal material. Qxf6/Be7 lost queen tempi and castling rights after Bxe7/Kxe7. Kf8/Kg8 did not move Rh8, which remained trapped. Ng5/Qf4 made the king's f7 guard insufficient. Moving e6 would open a back-rank rook attack; Bxe6 later uncovered Qf4's file check. The first safe king flight was not a safety proof.

Practice 71: gxf6/Be3/Bd6/Qe2/O-O/Qh5. Castled on seven and retained equal material, with doubled f-pawns and an open g-file. Queen remained on d8; the rook really moved to f8. The next defense and whole-game safety were unplayed.

99 won with important opponent help. Nd5 abandoned e4's knight guard. h4/g5 trapped Rh5; Black declined Bxh5 after gxh6, allowing Rg5. Kxh6 later removed the pawn guarding Rg7, requiring the actual Rg3 retreat. Ne4+ forked king/rook; Bxe4/Bh5 left the knight captured whole, and Bxf5 saved the bishop. Be6 later hung the remaining enemy bishop. Rg3 cut off the bare king while the a-pawn promoted; Qh8 mated. Neither the trap nor repeated long speculative execution was repaired by this win.

Practice 72: Rh4/Bd7/Rf4/Be6/Kc3/a5. Rook retained with h4/a4 retreat routes and equal pawn counts after three own moves, nominal two-point lead. Be6 still attacked unguarded a2; that defense unplayed. Short local mobility result, not a saved game or transfer.

100 won after opponent declined two rook recaptures and hung both bishops and the queen. Those gifts dominate the result. Rf3+ still lost my rook to g2xf3: Bc6's guard denied a king capture but did not make a pawn-for-rook capture harmless. Bxf3 only became safely guarded after Qh4+/Kg1/Qxh3 placed my queen on h3. Qg2 mated under Bf3's actual support. Long speculative execution persisted despite zero actual illegal moves.

Practice 73: Qh4+/Kf1/Re1# naturally finished after two own moves, both rooks retained, no captures. Qh4 guarded Re1 through g3/f2 and controlled the f2 flight. Only this remembered branch tested, from an already gifted winning position; excluded from benchmark Elo.

101 drew after important opponent rook losses. Re4/Re3/Rg3/Rf3 needed Black's b6 tempo to clear h3 and escape. Bxf2 took my bishop whole; f1 promotion cost a rook to remove while my other rook survived. The actual two-passer sacrifice took one rook, and unguarded Rxb4+ gave the other to Kxb4. In the ending, Rf2-f6 was rejected because MY KING on f5 blocked the route. Re2 was legal. Ra8 pinned Bf8 to Kh8; Kg8/Rxf8+/Kxf8 secured bare kings. No winning conversion proved. One illegal submission and huge speculative branches remained.

Practice 74: h4/g4/Nh2/f5/g3/Rg8. No captures, both rooks retained after three own moves; g3 guarded h4 and f2 guarded g3. Re1 currently had safe Rd1 under Kc1. Further defense unplayed. This short remembered test does not demonstrate new-game transfer.

102 lost. Qe7-d5 was rejected for knight-shaped displacement; Be5-d4 was rejected for exposing Kf5 to Rc5. Rxe5/Nxe5/Qxe5 correctly traded rook plus pawn for bishop plus knight, with my queen surviving. Bd2/gxf5/Kxf5 lost a knight for a pawn. Be3/Pf4 mutually guarded each other and the bishop retained a7 control. Kd7/a7/Bxa7 allowed Rb7+, checking my king while attacking Ba7; Rxa7 captured the bishop whole. Kh3 later allowed Rxh5#: Kf3 controlled g2/g3/g4, and the checking rook controlled h2/h4. Local guard accuracy did not prevent the fork or mate. Two illegal submissions and huge speculative execution persisted.

Practice 75: Kd8/Rb7/Kc8/Kg2/h5/Kf3. Rb7 did not check Kd8, and the bishop remained mutually guarded with f4. No captures or illegal moves after three own moves. White did not play a7, so the proposed capture branch was not tested; h5 remained unguarded and the king cut off. Narrow retention result, not a saved-game or transfer claim.

Trial 154: return to White full-strength benchmark 103, then fixed rotation through review 108. Include own king bodies and royal shields on routes; a king guard must permit the actual recapture against enemy royal support. After a pawn capture or king move, inspect a real enemy checking fork or mating capture, including an attacked minor piece and actual adjacent flights. Earlier opening triggers remain conditional on actual moves. Renewed legal-route, piece-retention and actual-survivor targets; no reliable shorter execution established. Latest official Elo 1450 [1320,1570] after 102; cumulative 27 wins, 5 draws, 70 losses. Finish at 200 scored; no token budget or fixed inference claim.

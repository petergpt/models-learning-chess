# Active own decision card after benchmark 95 and practice 68

Own hypotheses and observations, not engine analysis. The longer card is retained in decision_card_after93.md; complete outcomes are in journal.md. A shorter card is a trial, not evidence of better execution.

Read only the actual returned position. Identify check, the enemy move's new attack, and threatened higher pieces. Do not retain unplayed branches as board state.

Choose one or two candidates. For the chosen move, trace its exact route and destination, the cheapest enemy capture, and the last legal own recapture. Check a forcing enemy check that also attacks the queen or another higher piece. If moving the king, inspect the next supported queen check and actual occupied flights. Once these immediate checks are coherent, submit the move rather than extending speculative trees.

Pawn double pushes need an empty intermediate square and an en-passant check. A queen guard is insufficient if the cheaper capturing piece has support and my final recapture is absent. A king guard must be adjacent and legal after the capture. Neither equal material nor the first legal king flight proves safety.

White: retain early Be2/castling and develop the remaining knight before exposing a trapped rook to save one pawn. Keep f2's actual g3 guard where relevant. Black: adaptive e6/d5; the d5xe4 trial applies only to actual e4/d4/Nc3 before e5. That trigger did not occur in 94. The old queenless Ng5/f6 trial remains set aside.

94 reminders: 20...h5 allowed gxh6 en passant; the later king capture recovered that pawn only because White declined to guard it. 34...bxa5 ignored 35 Re7+, forking Kh7 and Qd7. Qxe7/Bxe7 lost the queen for a rook. 38...Rh7 did answer the local h-file mate threat. White's e8=B underpromotion, later declined captures and repeated checks limit the interpretation of the draw. Final rook/pawn against queen/pawn, nominal four points down.

95 won after Black declined Ng3-f5's available queen capture with Qc7. Ng3+ checked Kh1 and attacked Qf5/Rf1/Be2; the queen's knight guard did not make losing it for a knight acceptable. Nxe5/Qxe5/Qxe5+/Rxe5 traded a minor pair and queens fairly; Kxg3 became legal after the queen guard disappeared. Rd1-d8 was rejected because Nd4 blocked its path. Ra8 mate used Kf6's e7/f7 controls and Bg4's real d7 diagonal. These failures persisted despite the win and the shorter card.

Practice 68: Qf4/hxg6/Kh2/Kg8/Nd2/Be5 retained the queen for three own moves with zero illegal routes, but lost the passed pawn and ended with Qf4 attacked and pinned to Kh2. Ng3+ never occurred. Moving Nf3 to d2 removed the cheap Nxe5 reply. No saved defense or transfer established.

Trial 140: return directly to Black 96. Inspect actual knight checks before pawn captures and the piece shielding the king after each king step. Preserve a legal cheaper capture of a new queen attacker. Count failures. Review after 96; finish at 200 scored benchmarks. Latest official Elo is 1400 [1270,1520] after 90; cumulative after 95 is 25 wins, 4 draws, 66 losses. No token budget or fixed inference budget.

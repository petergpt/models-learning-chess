# Own decision card after129

129 scored35W/6D/88L. Full0/0/44; skill30/3/10;nom5/3/34. Provisional1490 [1370,1610], latest50 of85 rated,44full excluded, conditional nominal model only, not human Elo. Formal132; endpoint200; active goal/no token budget.

Every move: actual board/last reply, all attacked targets, first body on every necessary ray, cheap attacker and complete recapture chain, royal legality, king flights after proposed move AND forcing reply. Own king guards only adjacent squares. White pawns upward; Black downward. No reciprocal guard assumption:22Ne5 lost d4's knight root;24Nf3 lost d3's knight root. Qd2-d4 blocked by own Pd3.

129 led+2 pawns but lost both; Ke3/Bc1+ fork allowed a whole bishop capture which opponent missed. Nxg5 was protected by Kh6 yet self-blocked g5 and allowed adjacent Bg7#. Be8 covered g6/h5, h7 covered g6, Kg8 protected g7/h7. Material capture safety does not establish royal safety. If the ENEMY pawn remains g5 when Bf6-g7 checks, its bishop root is removed and Kxg5 may be a flight. Inspect actual new roots.

Earlier errors: own Nh6 first body blocked Rh8-h5 BEFORE castling128 (archive wording attributing first release to castling was false). Queen/rook/king own bodies can block roots. Opponent moves first; an undefended piece placed under an existing attack is not a gain. Two attackers vs one root require full chain. Supported passers can interpose rook check and promote; whole-piece advantages alone do not win.

Trial210 practice105 MAX White129ply82,42Rd8, four own moves/termination/failure, test avoiding immediate mate while keeping rook/knight. Local only. Then fixed130Blackskill0; formal132. All moves own reasoning; no foreign experiment, outside advice, analysis code, engine evaluations, or delegation. Full0/44 stagnant; overlapping intervals and opponent gifts prevent a repair claim. Long branches/update cadence unresolved.

# Own current card after benchmark 106 and practice 79

Own hypotheses, not supplied solutions. Prior card retained in decision_card_after105_archive.md; honest outcomes in journal.md. Shorter notes have not reliably shortened my execution.

Read the actual returned board. Answer check and the new attack on a higher piece. Trace the chosen move's route, the cheapest enemy capture, and the last legal own recapture. A nearby king does not make a guarded target capturable. Moving a shield can expose my king, queen or rook.

Count the actual final bodies. A recapturing rook survives until a real further capture removes it. Pawn promotion starts from a pawn's value; do not treat the created queen as a previously owned nine-point piece. After promotion or a checking move, inspect actual king flights before claiming mate.

White: develop minors and castle early. Before advancing the e-pawn, keep its real guards and the bishop battery's first body visible. In the remembered 105 setup after e4/Bb7, d5 before Be3 is an unverified alternative that blocks the ray and keeps Qe2's guard. Practice 78 retained the center for three moves but produced an unresolved a3 attack on b2. Do not call that a repaired opening.

Black: against actual e4 retain the c6/d5/early-Bc8-development trial. The h6/Bh7/fxe6/Bxd3 sequence failed in 104: Qg6+ lost castling rights and Nf7+ won a rook. Practice 77 rejected g6 alone as a demonstrated repair. If the same e5/Bf5/h4 setup arises, consider h5; after actual g4, hxg4 would have Bf5's guard. This is untested. Adapt to another first move.

105: Qe4 avoided opening Rd8's attack on Qd3; cxd4/fxe4 retained both rooks and fairly removed the queens. Bxd3 captured an enemy bishop whole, with my bishop surviving. Rxd1 captured the enemy rook whole, with both own rooks surviving. Those opponent gifts mattered. Rd8 then guarded promotion; Qh8 mate was confirmed. A skill-0 win is not stronger-opponent transfer.

106: castled on seven, all minors developed on eight against a different skill-0 reply. The h5 idea was not tested. Ne3/Bc2's queen attacks led to a whole queen gift, and Nc2 led to both rook gifts. Ba6 later trapped my bishop behind b7; Bxb5/axb5/Qxb5 gave bishop for two pawns. Bd3 at that remembered position is an untested alternative with more routes.

Practice 79 against maximum strength: Ne3/Qa4/Bf5/g4/Nc2/gxf5/Nxe1/f6/gxf6/Qd1/Nxf3+/Ndxf3. Bishop and knight for rook and two pawns, nominal gain one, doubled f-pawns and open g-file. Both queens remained. The capturing knight's return route failed against Qd1; the earlier rook gain did not end the chain. Six own moves, not a whole-game or transfer result.

Trial 162: benchmark 107 next, official review 108, endpoint 200 scored. Current 106 scored: 29 wins / 5 draws / 72 losses. Latest official Elo 1450 [1320,1570] after 102. No token budget or fixed inference claim; no external chess analysis or delegated advice.

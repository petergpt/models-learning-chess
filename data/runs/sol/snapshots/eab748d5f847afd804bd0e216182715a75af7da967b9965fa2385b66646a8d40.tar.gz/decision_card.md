# Own decision card after122

Actual reply first; inspect every new line body and all fork targets after pawn/capture/king moves.122 Kf7 blocked own Rc7-g7 and allowed Qg7#. A rook guard is not retained if my own king steps into its path. Repeated long unplayed branches/late updates remain unresolved.

Use real geometry: kings adjacent; White pawns one rank up, Black one rank down; queens rank/file/equal diagonals. Black d5 NEVER guards c6 (practice94 illegal backwards d5c6, knight+rook lost).120 queen f6-e8 was a rejected knight-shaped route. No assumption of reliable execution.

Complete prices: a queen guard can protect a rook against an unguarded queen capture; it does not prevent a cheaper defended minor or pawn from winning the rook.122 Rc7/Qc8 capture price held, but the later king move removed that guard line.119 closed bishop retreats;115/116 whole minors lost. Guards must be checked again when pawn roots or line bodies move.

121 full loss: a4 guard Bb5 attacked by c6, Bd3 saved bishop but Nxa4 won pawn; emergency Bxb3/axb3/Nxb3/Bxb3/Qxb3 spent bishop3 for two pawns to remove outside passers. Qxb3 dropped d4/f4 guards; both fell. Final knight+two-pawn deficit, practical resignation. Practice96 earlier axb5/fair pairs retained minors locally, one pawn down, ended in unanswered Qg5+; no full save.

122 full loss by27Qg7# with material equal. Castle7/minors11, fair pawn pairs and bishop/knight exchange held. Nf8 guarded e6/h7 before f6; g6 avoided h6's attack. Own Kf7 screened Rc7. Full0/42 stagnation. Total12234W6D82L; skill0 29/3/8, nominal1800 5/3/32. Conditional estimate1530[1400,1650], latest50of80rated,42full excluded, not human Elo. Last actual usage counter29,946,255/time364,724s at formal120; no current invented count or budget.

Trial195 Black/MAX own122ply47 tryKf7 earlier beforeBb5; six own or natural end, adapt actual replies, explicitly end if active. Trial196 fixed123 White/skill0 next; formal126; endpoint200 scored. Independent own reasoning only, no external/delegated/automated chess analysis.

## Trial195/practice97 outcome; Trial196 predeclaration

Black/MAX own122ply47. Full finished PGN read:24...Kf7 25Qf6+/Ke8 26Ne5/Rd6 27Bxc5/Qxc5 28Qf7+/Kd8 29Qxb7/Rc8 30Nf7+*. Six own moves/twelve plies,zero illegal,explicitly stopped unscored in check; sequence955,timestamp2026-10-08T03:35:17.328557+00:00. Earlier Kf7/Ke8 avoided the benchmark's immediate mate route locally; Qf6+ was defended by Bd4/g5, so no royal capture. Rd6 used the e6 pawn as a screen from Qf6 and vacated d8; Qf7+ moved the queen off its previous d8 attack, permitting Kd8. These actual line changes held locally, not a complete save.

Bxc5/Qxc5 fairly exchanged bishop/knight. However Qc8-c5 removed the real diagonal guard of Bb7; Qxb7 then won that whole bishop3. I focused on Qc5's guard of Rd6 and possible Bb5 and failed to retain Bb7's guard. Rc8 saved attacked Ra8 under the adjacent Kd8 guard. Final Nf7+ checks Kd8 and forks Rd6; the check and profitable rook exchange threat are unanswered at the bound. Own nominal deficit3 at stop, equal pawns. This is a failed material-retention/save drill, not a draw, scored loss, solved position or full-game repair. The benchmark mate was replaced by different forcing damage; known-position survival alone did not establish improvement.

Trial196 fixed123 White/skill0: use own d4/Nf3/c4/Bf4/e3 development when actual replies allow, remaining minors and castle safely. Earlier axb5 is available only in a matching guarded pawn-chain position, not an automatic move. Trace both guards lost and new king/queen line bodies after captures; preserve bishop retreats before f4/Kf2. Avoid assuming material retention proves king safety. Next formal126; endpoint200 scored; no token budget. All decisions own, no external/delegated/automated chess assistance.


# Own review after benchmark123

Trial196 White/skill0 WIN by24Qc8#,47plies,zero illegal. Referee result sequence9916,timestamp2026-10-08T04:01:50.190324+00:00; full finished PGN and status actually read. Total123:35W/6D/82L. Full0/0/42; skill0 30/3/8; nominal1800 5/3/32. Provisional1540[1410,1660], latest50of81rated,42full excluded, conditional nominal anchors/model, not human Elo. Intervals overlap120/114; no causal rating improvement asserted.

Own d4/Nf3/c4/Bf4/e3/Nc3 developed with e3's real Bf4/d4 guards. cxd4/Nxd4 fairly exchanged pawns. e5 forked Nd4/Bf4 with a cheaper pawn; Nxc6 countercaptured the other knight and threatened the queen. Black Qc7 declined the fair b-pawn recapture. Nxe5 removed the fork pawn and moved the attacked knight under Bf4's guard. g5 attacked Bf4; Bg3 preserved the same g3-f4-e5 diagonal rather than abandoning Ne5. Black Qxe5/Bxe5 then lost its queen. That large opponent mistake dominates the win's transfer limits. The earlier captured black knight and my knight taken on e5 balance as minors; no fair queen exchange claim.

Bg4 attacked Qd1. Be2 blocked the line and developed the final bishop12; castle13; Bxe2/Qxe2 fairly exchanged bishops. Rad1 activated both rooks; cxd5 made a supported passer. Nd7 attacked Be5; Bg3 retained cheap f2/h2 pawn guards and the d6 diagonal without blocking Rd1. Rg6 added pressure on d6. d6/Rxd6/Bxd6 spent pawn1 for enemy rook5 with Bd6 still guarded by Rd1. Ne5 cleared the black d7 body, restoring Rd8's line toward Bd6, but placed the undefended knight under Bd6's capture. Bxe5 saved the bishop and won that knight whole. Rxd1/Rxd1 fairly exchanged rooks. Bf6 was later undefended and lost whole to Bxf6. No systematic all-opponent material strength inferred from these gifts.

Qc4 used a clear c-file after a6 covered b5. Bxf6 removed the last enemy minor, controlled e7/g7 and blocked f7's pawn advance. b5 attacked Qc4 but Qc8# used the clear eighth rank, d-file rook and bishop controls; the referee verified mate. Final own queen/rook/bishop/knight/six pawns versus five pawns, nominal own margin21. Fair guards and conversion held locally in a new skill0 game; queen/rook/knight/bishop gifts prevent a strong or causal transfer claim. Full0/42 remains stagnation. Long unplayed branches and late updates continued; efficiency and whole-game reliability remain unresolved. All reasoning own; no external/delegated/automated chess assistance or other-experiment exposure.

## Trial197 predeclaration

White/MAX from own123ply14, after7...e5 pawn fork. Try8Nxc6 countercapture, then adapt actual recapture/queen reply and bishop attack. Do not assume Qc7 or Qxe5 gifts. Six own moves or natural completion; explicitly end if active. Test fair fork response and material retention in a known position only. Then Trial198 fixed124 Black/skill0. Formal126; endpoint200 scored; no token budget.

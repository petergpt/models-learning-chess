# Own decision card after practice94 correction

Actual reply first; trace new attacks and every fork target. Two rooks were forked by Bxc6: saving Rd7 did not save Ra8. Long unplayed branches and late updates remain unresolved.

Pawn direction must match color: White attacks one rank up; Black one rank down. Black d5 guards c4/e4, NEVER c6. In120 Nxd7/Rxd7 removed Bd7, the actual guard of Nc6. f5 guarded Ne4 only. Practice94 Bxc6/Rf7/Bxa8 lost knight3+rook5; attempted d5c6 was illegal once. The benchmark win masked this defect. Earlier Bxe5 is an untested fair bishop/knight exchange that might retain Bd7.

Real guards: kings adjacent; queens rank/file/equal diagonal distances.120 f6-e8 was an illegal knight-shaped queen move. Price the complete capture chain; expensive guards fail when a cheaper enemy recapture wins the guard.120 Rg1 changed Bxg4/Rxg4; Nh6 escaped.

Preserve retreats before occupying them.119 f4 closed Bg3-f4 and Kf2 closed f2, losing B3 for P1. Practice93 Bf2 held locally; final f6 attack unresolved, no full-game repair proof.

Trace first bodies.120 e4 blocked Re1's e6 guard; Rxe6 won it. Re7 guarded own e3 before Nh4 moved its knight guard. f5 opened Bc1-Qh6 and Bd6-h2; Bd6's actual guard protected Nh2 after the queen exchange. Whole dark bishop was later spent for an enemy rook, not retained.

120:34W/6D/80L. Full0/0/40, skill0 29/3/8, nominal1800 5/3/32. Provisional1530[1400,1650], conditional nominal anchors, latest50of80rated,40full excluded, not human Elo. Overlapping intervals; full-strength stagnation. Counter29,946,255/time364,724s recorded at120, no budget/per-move counter.

Trial191: Black/MAX own120ply27, try Bxe5 at the earlier fork; six own moves or natural finish, adapt actual replies, end if active. Trial192 fixed121 White/full next; formal126; endpoint200 scored. All chess reasoning own, no external/delegated/automated analysis.

# Decision card after benchmark 138

Objective: stronger independent play and 200 scored fixed-rotation games. Current scored count 138; 39W/7D/92L. No token budget. All results preserved.

For each move, first rebuild the actual board from the latest referee reply. Then identify checks, captures and immediate threats; track each relevant ray only to its first occupied square. Consider the cheaper attacker, complete recapture chain and king legality. Own and opponent kings and pieces can be intervening bodies. A pawn never captures forward or backward; a rook never moves diagonally; a knight's actual displacement matters.

When moving a king or its shield, inspect both its destination and every guard or attack ray changed by its departure. A king guard is useful only if the recapture square is not attacked. Before entering a corner, check the opponent's next checking rook/bishop move and all flight squares, including own-body blockers. Material retention alone did not prevent mates in 133 and 138. When a rook interposes, check its own guard and the guard it releases on the other rook.

Current learning Trial 229: maximum-strength Black replay from my own game 138 ply 111, four own moves. Candidate first reply Kh8, unverified. Targets no mate/no whole Q or R loss/deficit at most 3, local only. Return to benchmark 139 after this drill; formal review 144. Do not claim repair or learning merely from extra checklist length, local retention or a rising rolling rating. Timing and board tracking remain unresolved weaknesses.

# Formal checkpoint — 138 scored benchmarks

Verified after benchmark 138, 2026-10-09. Overall: 39 wins, 7 draws, 92 losses; 138 scored, zero unfinished benchmarks, no active game. Fixed rotation retained.

| Opponent | Scored | W | D | L | Score fraction |
|---|---:|---:|---:|---:|---:|
| Maximum skill | 46 | 0 | 0 | 46 | 0 |
| Skill 0 | 46 | 32 | 4 | 10 | 0.7391304347826086 |
| Nominal 1800 | 46 | 7 | 3 | 36 | 0.18478260869565216 |

Referee estimate: 1560 provisional engine-relative Elo; conditional 95% Bayesian equal-tail credible interval [1440,1680]. Latest 50 of 92 rated games; 46 uncalibrated maximum-strength games excluded from this estimator. Nominal anchors are 1320 and 1800. Interval excludes systematic anchor calibration error; this is not human FIDE/platform Elo and not strength at a fixed inference budget.

Latest block 133–138: L, L, W, D, L, L; 1W/1D/4L. Full-strength pair both losses; skill-0 pair win/draw; nominal-1800 pair both losses. The skill-0 win relied on major gifts; the draw salvaged a queen blunder and was automatically claimed by the referee. Full strength remains 46 straight losses. Early material retention sometimes improved locally, but games 133 and 138 exposed king nets; 134 lost a queen to a second bishop ray, and 137 lost a rook after the king first blocked and then cleared its sole guard ray. No sustained full-strength transfer is established.

Comparisons: formal 126 was 1500 [1380,1630], formal 132 was 1530 [1400,1650], and formal 138 is 1560 [1440,1680]. Intervals overlap. Formal 120 was also 1530. The estimate rose from 1550 to 1560 after the loss in 138, illustrating the changing rolling window rather than success in that game. These movements do not establish causal or sustained improvement.

Own maximum-strength drills since formal 132: practice 109 resigned after two own moves and did not establish a saved king flight; practice 110 stopped at four own moves with equal material but unresolved blockade/king development; practice 111 stopped at four with a one-pawn deficit and an attacked queen, leaving the intended bishop escape untested; practice 112 lost by mate on its fourth own move despite retaining major material; practice 113 retained majors locally but failed its deficit target, stopping at minus 5; practice 114 retained a king guard and majors for four moves at minus 1, but ended with its rook under a cheap bishop attack and no escape played. These are remembered local tests with differing replies, not independently solved positions or whole-game repairs. Practice never entered benchmark Elo.

Current methods: cheap-guard inventories, complete recapture chains, departure/arrival first-body checks, royal flight checks and bounded replays of my own failures. They have helped catch some unsubmitted illegal ideas, but failures recur and the routine has become too slow. More notes and longer mental branches are not evidence of progress. Trial 229 will test the alternative king reply in game 138, then benchmark 139 will test new-position transfer; next formal checkpoint 144. Whole-game royal safety must accompany material retention.

Actual get_goal observation at this checkpoint: status active, tokensUsed 31488555, timeUsedSeconds 391820, remainingTokens null, no token budget. Both counters returned unchanged from the observation at checkpoint 132. Record the observed counter honestly; do not infer new token use, per-move use, or elapsed experiment time from the unchanged values. Fair-play and shared memory rules preserved; all started games retained; no other learner or operator comparison inspected.

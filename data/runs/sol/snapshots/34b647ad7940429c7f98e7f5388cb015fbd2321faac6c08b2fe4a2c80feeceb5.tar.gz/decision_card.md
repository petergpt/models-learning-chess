# Own current card after benchmark 108

Own hypotheses; prior card preserved in decision_card_after108_archive.md. Journal has actual outcomes. Short notes have not reliably shortened my enormous speculative execution.

Read the actual returned board. Answer check and the new attack on a higher piece. Trace the chosen route, cheapest enemy capture and last legal own recapture. A nearby king cannot capture a guarded target. A recapturing rook survives until an actual further capture removes it.

Before moving a shield or guard, name the other piece it currently protects. After the chosen move, that other piece needs a real guard or a move with check that actually prevents its capture. Checking only my destination failed twice: 107 Ndxe4 left Bf4 on the newly open rook file; 108 Qf5 left Be7 unguarded after the king had castled away.

A pawn leaving a file can expose a bishop to a rook. A queen can be overloaded between two knights; moving one knight can uncover an attack on that queen. A royal pin prevents its shield knight from simply leaving. Higher-value guards do not make cheap captures harmless: count the actual last capture.

White: adaptive minor development and early castling. Qc2 guarded e4 through clear d3 in 107, unlike 105's Qe2 ray blocked by Be3. The center held locally before later whole-bishop loss. Practice 80's Bg3 preserved bishops for three moves but ended with Bxc3 and unresolved e4/queen overload, not a saved game.

Black: c6/d5 with early Bc8 development against actual e4. Exact e5-pawn/Bf5/h4 -> h5 remains untested. 108 used h5 in a different knight-on-e5 setup, traded both knight/bishop pairs fairly and castled queenside on sixteen, but lost h5's rook guard, e5 and then Be7 whole. The original opening is not repaired.

Trial 165: Black nominal-1800 practice from 108 ply 33; try Be7-d6 with Qd7 guarding it. D6 is attacked by Ne4. If Nxd6+/Qxd6/Qxd6/Rxd6 actually occurs, the final rook survives after fair minor/queen pairs; do not claim that unplayed line forced. Three own moves, then fixed White full-strength 109. Own 12...Qg4 alternative remains untested.

108 scored: 29 wins / 5 draws / 74 losses. Official Elo 1470 [1350,1590]; skill-0 gifts dominate wins, full strength 0/36 and nominal 1800 3W/2D/31L. No stable stronger-opponent improvement established. Next review 114; endpoint 200 scored. No token budget, outside chess lookup, automated analysis or delegated advice.

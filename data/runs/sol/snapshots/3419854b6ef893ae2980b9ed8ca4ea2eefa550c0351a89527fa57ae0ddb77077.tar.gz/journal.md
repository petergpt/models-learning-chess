# Independent chess-learning journal

## Starting state — 2026-10-03

Read this experiment's AGENTS.md and GOAL.md. The referee reports zero started benchmark games, no active game, and no Elo estimate. No imported learning material, outside position advice, or engine analysis has been used. An active goal is registered without a token budget. Actual token counters are unavailable; no usage values will be invented.

The target is stronger play, with the bounded endpoint of 200 scored benchmark games. All moves will be my own decisions. Full-strength results remain part of the benchmark, although the current estimator excludes that uncalibrated opponent.

## Trial 1: position tracking and tactical safety

Hypothesis: maintaining a reliable board model and checking the opponent's forcing replies will reduce avoidable material losses. This is an unverified self-assessment, not a measured diagnosis yet.

Initial study: review ordinary opening priorities from my existing knowledge: contest the center, develop pieces, secure the king, and avoid unnecessary pawn moves. In tactical positions, consider checks, captures, and direct threats for both sides. Before committing a move, mentally update the occupied squares and check whether the move leaves a piece or mating square unprotected. Favor concrete calculation over relying on the checklist alone.

First evaluation point: six scored benchmarks, covering one paired-color rotation. After each game, record one concrete failure or successful behavior and choose a learning adjustment before the next game. Use recorded opponent practice when a specific weakness calls for a drill. Baseline results will be descriptive; six games cannot establish a reliable improvement trend.

Observable evidence: recurrence of pieces lost to an immediate forcing reply; ability to reach playable middlegames without such losses; benchmark results and the referee's Elo interval. An easier practice win alone will not establish transfer.

### Initial repertoire choice

White: begin with 1.e4, develop naturally, and adapt to the reply. Black: meet 1.e4 with ...e5 and 1.d4 with ...d5 unless a concrete position warrants another choice. These are my own familiar starting choices, not externally recommended moves.

## Benchmark 1 — loss, White versus full strength

Resigned after 22...Bxf4, 44 plies, with an extra enemy minor piece and no identified compensation. No illegal submissions. This full-strength game does not supply a calibrated Elo observation.

Concrete failure: after 19...g5, I played 20.Kg2 gxf4 21.Bxf4 Qxf4 22.Qxf4 Bxf4. I failed to count the queen and bishop attacking f4. The queen trade did not recover the bishop. Looking back, my bishop on e3 also had its retreat squares obstructed by my own queen and pawns; this was more than a recapture oversight. The king-safety plan overlooked that trapped-piece consequence.

Earlier concern: 15.Qd2 permitted ...Bxf3 with g-pawn recapture because my bishop on e3 blocked the queen's route to f3. These are my own assessments, without engine validation.

## Trial 2: complete exchanges and preserve an escape square

Learning period: mentally revisit the position after 19...g5. Count material through the entire exchange, not just the first recapture, and check available bishop retreats after pawn captures. The actual continuation loses a bishop; a proposed 20.f5 opens f4 as a retreat square and avoids ...gxf4. Its overall quality is unverified and its king-safety consequences require play.

Recorded practice: one short drill from benchmark 1, ply 38, against skill 5. This is a remembered position, not a new transfer test. Try my own alternative 20.f5, then finish or explicitly end the drill after observing the immediate consequences. Next measured evaluation: benchmark 2, with the six-game rotation still the first aggregate checkpoint.

Observable result: avoid the specific forced bishop loss in the drill; in new benchmark play, resolve pawn attacks on blocked pieces before making unrelated moves. Neither a corrected remembered position nor a practice result establishes stronger general play.

### Trial 2 outcome and decision

Practice 1 was explicitly ended as an unfinished drill after 20.f5 Qh2+ 21.Kf1 Qxh3+ 22.Ke2 Qf3+ 23.Kf1 a4. The bishop remained on e3, but I lost h3 and my king was displaced. Thus the narrow trap was avoided; the alternative was not shown to equalize or win. No practice score is claimed.

Decision for benchmark 2: apply complete exchange counting to new positions and inspect mobility when a pawn advance closes a bishop's diagonals. In opening pins, prefer development and a recapture that preserves king cover. The original first aggregate evaluation remains six scored games. Do not claim transfer until these behaviors survive new benchmark positions.

## Benchmark 2 — loss, Black versus full strength

Checkmated at 33.Nh4#, 65 plies, no illegal submissions. Material remained equal through the opening and the bishop exchange. I did not anticipate 23.Qxa8 after 22...axb4 cleared the a-file: the continuation traded White's queen for both Black rooks. Material comparison alone missed the resulting rook coordination against my king.

A direct error followed: 25...c3 26.Rc1 Qe7 27.Rxc3. Moving the queen removed the pawn's only defender. Later the rooks on a8/c8 overwhelmed Bf8; 29...Kh7 30.Rxf8 was followed by Rh8+, Bh6+, and Nh4#. My own diagnosis is lost-defense and king-flight errors, not merely unfamiliar opening knowledge.

Transfer assessment: the specific trapped-bishop loss from game 1 did not recur, but elementary tactical omissions did. There is no evidence yet that the first method improved benchmark strength. Both completed games are uncalibrated maximum-strength losses, so Elo remains unavailable.

## Trial 3: vacated lines and lost defenders

Learning period before benchmark 3: mentally revisit two remembered positions from game 2. At move 22, the pawn on a5 was masking the rook on a8 from Qa4; ...axb4 removed that mask. At move 26, Qc7 was the only defender of c3; ...Qe7 removed it. These are concrete line changes visible from the recorded moves, without external evaluation. A candidate such as retaining the queen on c7 and creating a king flight square is only an untested alternative.

Changed method: after choosing a candidate, inspect the origin square as well as the destination. Name the specific piece or pawn that loses protection and any line that opens; then consider the opponent's available checks and captures on those lines. Do this concretely, rather than treating completion of a checklist as success.

Next evaluation: benchmark 3 now, and the aggregate checkpoint at six scored games. Observable transfer: no unanticipated immediate capture caused by vacating a blocker or sole defender. Recurrence will count against the method even if a weaker opponent fails to exploit it.

## Benchmark 3 — win, White versus skill 0

Checkmated at 43.Rf8#, 85 plies, no illegal submissions. This is the first calibrated result. Opponent mistakes allowed two knights and then the queen to be won. I converted the remaining rook-and-bishop advantage after a later mistake.

Errors: 9.Qxf3 left d4 without a defender, allowing ...Nxd4. Later 23.Re8+ Rxe8 24.Qxe8+ Kxe8 demonstrated another incomplete exchange calculation: I had not accounted for the final king capture of the queen. The position remained won because of the much larger prior material advantage, not because that combination was sound.

Successful behavior: the final endgame kept the rook safe while the king advanced, captured the remaining pawns, and explicitly avoided stalemate. At move 41, Bh4 released b8 as a legal king move before Kb6 and Rf8#. This was a concrete correct conversion in a favorable position, not proof of general improvement.

Trial 3 assessment: failed its targeted transfer criterion; the lost-defender error recurred. A win against skill 0 does not override that evidence.

## Trial 4: final-position verification in forcing sequences

Learning period: revisit benchmark 3 after 22...Rc8 (ply 44), a remembered position. Check the resulting occupied squares and the defending piece after every capture, including a king recapture. A check is not mate unless every king destination, capture of the checking piece, and available block has been examined.

My own proposed correction is 23.Qxf6+ rather than sacrificing the rook on e8. It preserves the rook as a defender. Its consequences will be tested with a short recorded skill-5 drill, without requesting analysis. Next transfer test is benchmark 4; the first aggregate checkpoint remains six scored games.

Observable result: verify the drill's actual outcome, then avoid a queen or rook loss from a final king recapture in new play. No claim that a memorized drill alone demonstrates learning transfer.

### Trial 4 drill outcome

Practice 2 ended in checkmate after 23.Qxf6+ Kd7 24.Qe7#, three new plies, no illegal attempts. The rook on e6 protected the queen on e7. The referee verified the outcome; no engine analysis or advice was requested. This corrects the remembered example but does not yet show transfer.

After three scored benchmarks, the referee reports Elo 2070 with 95% credible interval 1110–3350, based on one calibrated win and excluding the two full-strength losses. This is a very small sample, conditional on nominal engine anchors and estimator assumptions, not a human rating.

Decision for benchmark 4: retain the correction's principle—explicitly verify the defender remaining in the final position—and watch the origin-square defenses. Next aggregate evaluation remains six scored benchmarks.

## Benchmark 4 — win, Black versus skill 0

Checkmated with 20...Qd1#, 40 plies, no illegal submissions. B g4 protected Q d1 through f3/e2, and I checked that the king could not capture the queen. This is a successful use of the final-defender principle in a new position, but one favorable example is weak transfer evidence.

The opening preserved king cover and supported ...e5 with Re8/Nc6. The ...e4 pawn advance attacked the bishop and knight; White's subsequent captures and failure to recapture the queen allowed a decisive advantage. I do not claim that winning the queen was forced against accurate defense. No obvious own immediate material-loss oversight was identified in this game; that is a self-assessment without independent analysis.

## Trial 5: direct development with explicit center support

Learning period before benchmark 5: contrast my own openings. In game 1 the bishop and remaining knight made several early moves before the c1 bishop developed. In game 4 castling and rook support made a central advance possible. The hypothesis is that simpler development with maintained pawn defenses will reduce restricted-piece and lost-defender situations; this remains unverified.

White experiment: if the reply permits, develop the king's bishop to c4 and the queen's knight to c3, castle, and develop the c1 bishop without neglecting the center. Adapt to actual replies rather than force an opening sequence. Keep the final-position verification from trial 4. This is my own repertoire change from existing knowledge, with no external source.

Next evaluation: games 5–6 against the fixed 1800 setting, followed by the six-game aggregate checkpoint and a new learning decision between games. Observable result: reach a developed middlegame with material intact and no unanticipated lost defender; record any exception separately from W/D/L.

## Benchmark 5 — loss, White versus the 1800 setting

Resigned after 37...Rxg2, 74 plies, no illegal submissions. A full rook was missing, pawn counts were equal, and I identified no compensation. No loss was discarded.

The opening adapted to ...Nc6/...e6: queens were exchanged, both bishops developed, and I castled long. Material remained equal through move 34. This met the narrow development objective, but did not produce a successful game.

Errors and warnings: 23.Kd2 blocked the rear rook and 23...Bb2 exposed the advanced rook on d4. I overlooked its restricted retreat squares and the effect of occupying d2. The opponent allowed ...Ne7 instead of taking the rook; 25.R4d2 saved it. That was not proof that the earlier position was safe. The decisive direct blunder was 35.Rf4: the black pawn on e5 could capture f4. 35...exf4 36.Rxf4 left me down a rook for a pawn, and subsequent ...Rxg2 removed the pawn difference. My longer prospective calculations had failed to check a basic attack in the actual position.

Correct new-position behavior: 20.Bh2 preserved the e5 pawn's defense while avoiding the black pawn on h4, and 27.Rf2 covered g2 before the knight moved off e4. These successes coexist with the later failure; they do not establish improved strength.

Trial 5 assessment: direct development transferred to a materially intact queenless middlegame. Tactical reliability did not; the game was lost to a one-move pawn capture.

## Trial 6: current pawn attacks before destination choice

Learning period before benchmark 6: revisit the decisive remembered position after 34...e5. Mentally mark Black's pawn attacks: a4 -> b3; b7 -> a6/c6; c7 -> b6/d6; e5 -> d4/f4; f6 -> e5/g5; h4 -> g3. The proposed rook destination f4 was directly on this list. Support behind a rook does not make trading it for a pawn acceptable.

Method change: first reconstruct the current pawn locations from the referee board, then check the destination against those attacks before calculating longer variations. Keep the full final-position and lost-defender checks, but use them on the actual board instead of an imagined future continuation. This is a targeted procedural trial, not a claim of learning by checklist length.

Next evaluation: benchmark 6, then the first six-game aggregate checkpoint. Observable result: avoid a direct pawn-controlled destination that loses a more valuable piece; record any occurrence even if the opponent misses it. No practice result or transfer is claimed for this mental review of a remembered example.

## Benchmark 6 — win, Black versus the 1800 setting

Checkmated with 69...Ng3#, 138 plies. One illegal submission: at move 21 I attempted e5f6 for a knight, mistaking a diagonal step for a knight move. The referee rejected it, the position stayed unchanged, and the legal continuation was 21...d4. This geometry failure must not be hidden by the win.

The opening exchanges left an extra pawn and White's bishop pair. I maintained pawn support through ...d4, ...Bc3, ...Bd2, and ...dxe3. The opponent's active rook required repeated knight defenses. ...g6 created king flight before the rook left the back rank. Rook and bishop exchanges eventually produced knight versus bishop with four pawns against three. These are descriptions of the played position, not engine evaluations.

The kingside exchanges, supported ...f4, ...Ng3, ...Nf5, and ...Nxh4 eventually produced two passers against the a-pawn. Conversion was slow and uncertain. I repeatedly reconsidered long hypothetical lines, including imagined drawn fortresses and king routes, without efficiently resolving the actual position. After ...h2 Bxf3+ ...Nxf3, White's king on g2 prevented an immediate safe promotion. 64...Kf4 65.a5 Nd4 66.Kh1 allowed ...Kg3, ...Kh3, and ...Nf5. White had to move its a-pawn because its king had no legal move. The final position after a8=N permitted ...Ng3#: h2 covered g1, Kh3 covered g2 and h2, and the distant promoted knight could not remove the check. I explicitly checked that a queen promotion on a8 would also not capture g3 or resolve that knight check; this is my own calculation, not a separate recorded result.

Trial 6 assessment: no direct pawn-controlled destination causing a rook or minor-piece loss was identified in this game. The targeted check helped in several actual choices, but the illegal knight move and lengthy board drift expose separate reliability problems. One win does not establish consistent transfer.

## First aggregate checkpoint — six scored benchmarks

Referee status: 3 wins, 0 draws, 3 losses. Full strength: 0/0/2 W/D/L; skill 0: 2/0/0; 1800 setting: 1/0/1. All six started benchmarks finished and remain recorded. Two recorded practices: one unfinished drill and one win; neither contributes to these counts.

Provisional engine-relative Elo 1870, 95% Bayesian credible interval 1410–2460. Four calibrated observations; both full-strength games excluded by the operator's estimator. Conditional on nominal anchors and model assumptions, excluding systematic calibration error; not human/FIDE/platform Elo. Earlier estimates of 2070 and 2210 were based only on skill-0 wins; the changes to 1680 and 1870 after the two 1800 games are primarily new evidence, not a demonstrated learning curve. Improvement or stagnation cannot yet be established.

Observed active-goal counter from get_goal: 779650 cumulative tokens at this checkpoint. Recorded through play usage with its scope: all goal learning and play, no per-move attribution. This is an actual tool counter; no inferred or invented token values. The experiment has no token budget.

Decision: retain natural development and final-defender checks, but reduce speculative analysis that loses current geometry. Continue the fixed rotation. Next aggregate evaluation: 12 scored benchmarks; revise the trial after each game.

## Trial 7: current geometry before extended calculation

Learning period: revisit the rejected move in game 6. A knight changes one coordinate by two and the other by one; e5f6 changes both by one and is not a knight move. Mentally reconstruct e5's eight geometric destinations: c4, c6, d3, d7, f3, f7, g4, g6; then distinguish occupancy and opponent pawn attacks from geometry. This is my own mental exercise, not an automated legal-move menu. At the remembered position, f7 held my pawn, g4 was attacked by h3, and f3 by g2.

Also revisit the actual ending: the a-pawn's forced moves supplied time for a knight mate even though it promoted. Counting a promotion race alone was insufficient; the distant promoted piece's ability to answer the immediate check mattered. Keep that as a concrete calculation principle, without treating the memorized mate as general mastery.

Changed method for new play: reconstruct occupied squares and the opponent's immediate threat first. Compare a small number of candidates on the current board, verify their movement geometry and immediate captures, and only extend lines when there is a concrete forcing reason. When a line becomes too long to track confidently, return to the referee's current board. No fixed inference-token cap is imposed; the trial concerns attention and position accuracy.

Next evaluation: benchmark 7, followed by the 12-game aggregate checkpoint. Observable outcomes: illegal submissions, immediate material losses from geometry or pawn attacks, and actual benchmark results. A successful remembered calculation alone will not count as transfer.

## Benchmark 7 — loss, White versus full strength

Resigned after 23...Qg3, 46 plies, no illegal submissions. The threat ...Qxg2# was supported by the rook on f2; I found no satisfactory defence. This is my own calculation of the threat, not a separately played mate. The loss remains recorded and is excluded from the calibrated estimator as a full-strength result.

Natural development, both knights, castling, and the central ...exd4/Bxd4/...Nxd4/Rxd4 exchange reached move 18 with equal material. The final recapture on d4 was correctly supported and did not repeat game 1's incomplete exchange loss.

Decisive failure: 19.Rf1 answered the pressure on f2 but allowed 19...Nxg3, forking Qe2 and Rf1. The g3 pawn appeared defended by f2, but moving f2 exposed the rook to the f-file battery. I played Qd3 ...Nxf1 Qxf1, losing the exchange and a pawn. ...Rxf2 won another pawn. Qb5 sought counterplay against the bishop but was far from the king; ...Qf4, Ng2, and ...Qg3 produced the final mating threat. This was a concrete missed fork and overloaded pawn defender, not a movement-geometry error.

Trial 7 assessment: no illegal moves and no identified minor piece or rook placed directly under a losing pawn capture. The tactical objective still failed. Speculative analysis remained long and repeatedly required rechecking the same current facts. Correct geometry alone does not supply tactical reliability.

## Trial 8: overloaded defenders and knight forks

Learning period: mentally revisit game 7 after 18...Rf8 (ply 36). Nh5 could reach g3, attacking e2 and f1 together. Moving the rook to f1 created that fork. The apparent defender f2 also blocked the stacked f-file attack, so its ability to recapture could not be assumed from pawn geometry alone.

Own proposed trial: 19.Qg4 instead of 19.Rf1, moving the queen off e2 and supporting g3 directly. It may concede f2 or create other threats; it is not claimed to equalize or be best. Test it in a recorded skill-8 practice from that saved position, for up to eight own moves, ending the drill explicitly if it remains active. This is a remembered-position test, not a new transfer benchmark.

New-position method: when relying on a defender, check what its move exposes. Before moving a queen or rook, inspect the opponent knight's reachable squares for attacks on two valuable pieces. Keep the current-board and pawn-destination checks; do not infer success merely from having considered them.

Next evaluations: the short practice's actual outcome, then benchmark 8. Aggregate checkpoint remains 12 scored games. Record whether the fork is avoided, any new losses, and new-position recurrence separately from the benchmark score.

### Trial 8 practice outcome and decision — 2026-10-04

Practice 3 ended in a loss by checkmate after five own moves, ten new plies, no illegal submissions: Qg4 Rxf2 Qg6 Rf1+ Rxf1 Qxf1+ Kh2 Rf2+ Ng2 Qxg2#. The g3 fork of queen and rook did not occur, but the retained pawn cover restricted my king's escape squares and the f-file invasion still won. Qg6's proposed queen exchange did not force a trade. The alternative was not shown to repair the position.

Decision: reject the remembered Qg4 plan as a tested solution. The immediate fork was one symptom of a broader king-safety failure. In benchmark 8, preserve king cover while developing and inspect actual checks before seeking counterplay. When counting defenders, distinguish a possible recapture from one that leaves the king in check. No improvement or transfer is claimed from this failed drill. Return to the fixed benchmark rotation now; aggregate checkpoint remains 12 scored games.

## Benchmark 8 — loss, Black versus full strength

Resigned after 26.Rf6+, 51 plies, no illegal submissions. I was down a full rook for one extra pawn. The supported c-pawn and king activity had not recovered material; I identified no adequate compensation. This loss remains part of the fixed rotation.

Opening trial: 3...Nf6 led to ...Nxe4, ...Nd6, ...dxc6, ...Nf5, and Qxd8+ Kxd8. Queens were exchanged with equal material after White recovered the e5 pawn. ...Be6, ...Bc5, Nxe6+ ...fxe6, and ...Ne7 reached a queenless position with both rooks and one bishop/knight per side. This description does not claim equality of the position.

First failure: 14...Kd7 guarded e6 against Ng5 but invited 15.Rd1+. I blocked with ...Nd5, supported by c6, then 16.c4 attacked that knight. It could not retreat because the rook pinned it to my king. ...Ke7 cxd5 cxd5 lost the knight for the c-pawn. The earlier analysis counted the block's defender but failed to check whether the blocking piece would remain mobile under a pawn attack.

Second failure: after ...h6, Nh3, ...c5, and Nf4, I played 20...g5 to chase the knight. 21.Ng6+ forked Ke7 and Rh8. ...Kf7 Nxh8+ ...Rxh8 lost the exchange as well, leaving a full rook missing. The h7 pawn had ceased guarding g6 after ...h6. I had considered some knight retreats but missed the immediate checking fork. This is another new-position recurrence of the trial's targeted weakness.

Counterplay attempt: ...c4 made a supported passer; ...Kg6 and ...hxg5 responded to f4/fxg5. White's Rf6+ kept my king under pressure. I resigned without claiming that a conversion had been proved impossible.

Trial 8 transfer assessment: failed. The remembered Qg4 drill lost, and a checking knight fork still occurred in the next benchmark. Pawn cover and queen removal did not cure elementary tactical omissions. Eight scored benchmarks now stand at 3 wins, 0 draws, 5 losses: full strength 0/0/4, skill 0 2/0/0, 1800 setting 1/0/1. The next aggregate rating check remains game 12.

## Trial 9: checks and pins before positional plans

Learning period: mentally revisit two actual geometries from game 8. With Rd1, Nd5, and Kd7 on the same file, the knight could not move off that file without exposing check. A pawn defender on c6 did not solve the mobility problem. With White Nf4, Black Ke7/Rh8, and h7 already moved to h6, g6 was an undefended checking-fork square. The knight's eight geometric destinations from f4 are d3, d5, e2, e6, g2, g6, h3, h5; the checking move needed priority over assumptions about a retreat.

Own untested comparison: ...Ng6 instead of ...Kd7 after White's earlier Ng5 would move the knight off e7 and retain h7's defence of g6, while possibly conceding e6. It is not claimed to be best or sufficient. The concrete lesson is to compare a pawn concession with the risk of immobilizing a more valuable piece; do not assume maintaining a pawn's defender makes the whole continuation safe.

New-position method: before a positional pawn or king move, check the opponent's immediate checks, especially knight checks that also attack a rook or queen. For a piece blocking check, inspect the pin and the opponent's pawn attacks on that blocker. Use a compact current-board calculation; if analysis repeats long speculative lines, reset to the actual occupied squares before committing.

Repertoire trial for the next White benchmarks: start with 1.d4 and develop naturally, keeping the king's pawn cover when possible. This changes the type of early positions; it does not claim a particular opening is stronger. Adapt to the replies and keep recording tactical mistakes even against skill 0. Benchmark 9 is the immediate evaluation; benchmark 11 tests the White change against the 1800 setting. Aggregate checkpoint remains 12 scored games. No engine analysis, external advice, or automated chess analysis has been used.

## Benchmark 9 — win, White versus skill 0

Checkmate by 64.Qe8#, 127 plies, one illegal submission. Nine scored benchmarks now total 4 wins, 0 draws, 5 losses: full strength 0/0/4 W/D/L; skill 0 3/0/0; 1800 setting 1/0/1. No separate learning period occurred while this measured game was active.

The 1.d4 trial developed Nf3, c4, Nc3, e3, Bd3, castling, b3/Bb2, and Rac1. After the bishop exchange, e4/e5 gained space. Nxb7 and Qxc6 took two pawns; Qxc8 Qxc8 Rxc8 Rxc8 exchanged queens and one rook each without changing that pawn lead. This is a description of material and play, not a claim that the opening established a superior position.

Black's remaining rook was active on the second rank. I avoided bxa4 while it would remove b3's defence of Nc4, then moved the knight and defended b3 with Nd2. At move 30 I nevertheless attempted c4b3 as a knight move, which is diagonal and illegal. The board was unchanged; the correct d2b3 recapture followed. This repeats game 6's movement-geometry failure despite prior study.

Black later left its rook on a2 under attack: 36.Rxa2 Nxc1 gained the exchange, followed by Nxe6, Rxd5, and Rxa5 as more material became undefended. The decisive own error was 45.Rf6+ gxf6: I checked whether the king could take the rook, but missed the g7 pawn's capture of f6. The rook was lost for no material. The intended forcing line was not forced. This repeats game 5's rook-on-pawn-attack failure, now in a checking move rather than a quiet move.

The remaining advantage survived. exf6 made a passer. Nh7 supported f6 and f8; moving the other knight from f7 to g5 both cleared the pawn and protected f7 and Nh7. After answering ...Nd2+, f8=Q promoted. The opponent knight supplied further checks, but was eventually left beside my king and taken. After removing the final pawn, Qf4, Nf6, Ne4, Qg5+, Qg8+, and Qe8# converted. The final queen checks were supported by the knights; their coverage of d7, d6, e8, and f6 completed the mate.

Trial 9 assessment: the result is a win, but tactical reliability did not improve on its chosen measures. One illegal knight move and one whole-rook loss to a pawn are direct recurrences. The 1.d4 start kept the king's pawn cover during the opening, but one skill-0 game does not establish transfer or a better repertoire. Long speculative calculation again obscured an immediate capture.

## Trial 10: check the checking piece's capturers

Learning period: mentally revisit three concrete geometries from game 9. A black pawn on g7 attacks f6 and h6; moving a rook to f6 remains vulnerable even when it gives check. A knight on c4 cannot go to b3 (one file and one rank), while d2b3 is a valid knight displacement (two files and one rank). Moving b3's pawn also stops it defending c4, which mattered while the black rook stood on c2. These exercises use my own reasoning and the saved move record, without automated analysis or outside assistance.

Changed method: immediately before submission, verify the chosen piece's movement and inspect every opponent pawn's capture squares against the destination. Apply this to checks and captures as well as positional moves. In a purported forcing continuation, explicitly consider captures of the checking piece before restricting the reply to king moves. Preserve current-board, fork, pin, and final-recapture checks, but do not count a long contemplated line as evidence of correctness.

Next evaluation: benchmark 10, Black versus skill 0, then benchmark 11's White 1.d4 trial against the 1800 setting. Record geometry errors and losses to destination-square attacks separately from the score. Aggregate checkpoint remains 12 scored benchmarks. Decision: continue the fixed rotation and retain the White repertoire trial provisionally; reject any claim that the previous tactical method is already reliable.

## Benchmark 10 — win, Black versus skill 0

Checkmate by 40...Qg1#, 80 plies, no illegal submissions. Ten scored benchmarks now total 5 wins, 0 draws, 5 losses: full strength 0/0/4 W/D/L; skill 0 4/0/0; 1800 setting 1/0/1. The next aggregate rating check remains game 12.

The opening began c4 ...e5, Nc3 ...Nf6, e3 ...Nc6, Be2 ...d5, d4 ...Be7, dxe5 ...Nxe5, cxd5. I played 7...Nxd5 and White answered Qxd5. The apparent queen defender on d8 did not make this safe: ...Qxd5 Nxd5 would exchange queens while leaving my knight missing. I declined that recapture, protected Ne5 with ...Bf6, and remained a knight down. This repeats the final-recapture counting failure; it was not a pawn-destination error.

I castled, developed the other bishop, and moved the knight when f4, g3, and g4 attacked it. ...c5, ...Qb6, both rooks on c8/d8, ...c4, and ...Bd5 produced counterplay. After ...b5, White played b4; ...cxb3 en passant won that pawn and displaced the queen. ...Bf6 attacked Qb2 along its diagonal, and Qb1 blockaded the passer. Later e4 attacked Bd5, but 27...Bxa1 captured the exposed rook. White chose Bxc4, taking my knight, and ...Bxc4 recaptured that bishop while moving the attacked bishop off d5.

The b-pawn advanced to b2: it and Ba1 protected each other. After ...Be6 and ...Qc2, Qxb1 Rxb1 exchanged queens. ...Rc1 attacked the constrained rook. White defended with Nd2; ...Rxd2 removed that defender, and Rxc1 permitted ...bxc1=Q. I had calculated Bxd2 ...Rxb1 as another continuation, but that line was not played. The promotion and subsequent ...Qxd2 removed White's last bishop. ...Bd4 supported f2 and g1; ...Qxf2+ Kh1 ...Qg1# finished.

Trial 10 assessment: no illegal submissions and no identified piece lost by landing on an opponent pawn's capture square. The opening still lost a knight through an incomplete exchange count. The win depended on substantial opponent errors and successful counterplay; it does not establish that the tactical method transferred. Analysis remained excessively speculative despite the compact-current-board intention.

## Trial 11: compare a pawn concession with an unsafe recapture

Learning period: revisit game 10 after ply 13, White's cxd5. The advanced pawn on d5 was supported by Qd1 and Nc3. Nf6 could take it, and Qd8 appeared to defend the landing square, but Qxd5 ...Qxd5 Nxd5 left my original knight lost. Counting one defender without the opponent's last recapture was insufficient.

Own proposed alternative: 7...O-O, temporarily retaining the advanced white pawn rather than playing ...Nxd5. This is an untested candidate, not a best-move or equality claim. Test it in a recorded skill-5 practice from benchmark 10, ply 13, playing Black for up to four own moves, then explicitly end the drill if still active. Observe whether the actual short line loses a minor piece, creates another concrete problem, or merely leaves the pawn deficit. No engine analysis or outside advice is used.

Next evaluations: the limited remembered-position practice, then benchmark 11 as White against the 1800 setting with the provisional 1.d4 repertoire. The saved-position test and the new-position benchmark have different scopes; neither a practice survival nor a benchmark win alone proves tactical improvement. Aggregate checkpoint remains 12 scored benchmarks.

### Trial 11 practice outcome and decision

Practice 4, skill 5, Black from benchmark 10 ply 13, stopped explicitly after four own moves/eight new plies, no illegal submissions: O-O e4 Bg4 Bf4 Bd6 Bxe5 Bxe2 Bxf6. It is unfinished, with no win/draw/loss score, and excluded from Elo.

Castling avoided the immediate ...Nxd5/Qxd5 loss in that exact move sequence. The subsequent line nevertheless ended with both black knights captured and one White bishop captured, so the exchange was unresolved at the chosen stop. Be2 attacked Qd1. My candidate ...Bxd1, rather than automatically recapturing on f6, was not played; any described follow-up is my own untested calculation, not a recorded result or engine finding. The drill does not prove opening safety, equality, or transfer.

Decision: retain the distinction between conceding a pawn and committing to an unsafe complete exchange. Return to benchmark 11 now, using 1.d4 as the planned White repertoire test. Keep movement geometry, destination pawn attacks, and the last recapture explicit; judge those by actual mistakes, not by how much analysis preceded a move. Aggregate checkpoint remains 12.

## Benchmark 11 — loss, White versus the 1800 setting

Resigned after 82...Kg4, 164 plies, one illegal submission. Eleven scored benchmarks total 5 wins, 0 draws, 6 losses: full strength 0/0/4 W/D/L; skill 0 4/0/0; 1800 setting 1/0/2. No separate learning period or outside lookup occurred during the game.

The 1.d4 trial continued with Nf3, c4, Nc3, e3, Bd3, Bxc4, castling, b3/Bb2, Rc1, Qe2, and Rfd1. Central exchanges left an isolated d4 pawn. Nxc6 ...bxc6, Na4 ...Qb5, and Qxb5 ...cxb5 exchanged queens. Later Rxc8+ ...Rxc8 exchanged one rook each. Material was level before the a3 pawn became exposed. ...Nc3+ forked king and rook, but Bxc3 ...Rxc3 answered it without an exchange loss. 34...Bxa3 took the pawn.

At move 36 I submitted Rd1-d3 while my own king on d2 blocked the path. The referee rejected it and left the board unchanged. Ke2 followed, and Rd3 became legal on the following turn. This is another geometry failure, now involving a sliding path rather than a knight displacement.

After repeated knight checks, 45.Kxf4 captured the knight. My Ne5 still blocked Bd6's diagonal to Kf4; ...f6 attacked that pinned knight. I played 46.Bd5, claiming that e6 was pinned to Kg8 along d5-e6-f7-g8. I missed the basic exception: ...exd5 stays on that diagonal and captures the pinning bishop itself. The bishop was lost for no material. 47.Kf5 ...fxe5 48.dxe5 then lost the remaining knight for the f-pawn. My earlier gain had become a bishop deficit. This is a direct failure of the destination-pawn check: I saw the pawn attack but incorrectly dismissed its legality.

Rxd5 regained a pawn, and e6/e7, Rd7, and king activity made a passer. Black's rook, bishop, and king coordinated against e7; ...Kf7 guarded the final recapture square, and 58...Rxe7 removed the passer. I retained the rook and tried a blockade with Rb3 in front of b4, a king on nearby light squares, and f4/g3/h4. No draw was reached. Black eventually brought the king to g4, threatening g3 and then h4 while Bc3 obstructed my rook's path across the third rank. I resigned without claiming a forced loss had been proved.

Assessment: the opening trial preserved early king cover but did not improve tactical reliability. One blocked-path submission and the bishop loss to a pawn are concrete failures. Very long speculative calculation did not prevent either error. Neither the skill-0 win in game 9 nor this loss establishes that 1.d4 improves the repertoire. Rating checkpoint remains 12.

## Trial 12: a pin restricts a move's effect, not every move

Own study: a pawn pinned along a diagonal may capture the bishop pinning it while remaining on that diagonal. In game 11, e6-d5 did exactly that. Conversely Ne5 could not leave Bd6-e5-f4 while Kf4 remained behind it. A rook's path also includes every intermediate occupied square, including my own king. These are mechanical constraints to verify on the current board, not labels that substitute for calculation.

Chosen remembered-position test: practice as White, skill 5, from benchmark 11 ply 90 (after 45...f6), for up to four own moves. Try 46.Ke4 instead of 46.Bd5. This is my untested candidate, not a best-move or equality claim. Observe the actual knight/pawn exchange and king recaptures, then end the drill explicitly if still active. Return immediately to benchmark 12 as Black against the 1800 setting. Record the drill separately from transfer; obtain the actual aggregate rating after game 12.

### Trial 12 practice outcome and decision

Practice 5 stopped explicitly after four own moves/eight new plies, no illegal submissions, no score: Ke4 ...f5+ Kf4 ...g5+ Kg3 ...h5 h3 ...Bxe5+. My bishop remained on f3. The knight was captured at the stop, and dxe5 was my unplayed candidate to complete that exchange. The drill does not establish a final material balance, a win, equality, or a repaired opening/position. The actual pawn-check replies differed from the measured line.

Concrete geometry observed: at Kg3, Ne5 blocked Bd6-e5-f4-g3 and Bf3 blocked Rb3-c3-d3-e3-f3-g3. Both pieces had movement constraints. h3 created a potential h2 escape square; its longer consequences were not tested. Remembered-position survival over four moves is not evidence of transfer.

Decision: retain the exact pin-capture exception and occupied-path checks as corrections to my method, not as proven improvements. For benchmark 12, check the legality of an opponent's actual capture rather than dismissing it under a generic pin label; inspect every intermediate square for sliding moves and every final recapture's king safety. Resume the fixed rotation immediately and review actual Elo after that result.

## Benchmark 12 — loss, Black versus the 1800 setting

Resigned after 39.Qxc4, 77 plies, one illegal submission. The opening exchanged all knights and one bishop each, leaving equal queen/two-rook/bishop material. Central pawn exchanges followed by ...e5 gave an initially stable position. ...Rxd1+ was answered Bxd1. Rc5, ...a5, and ...Qc6 created pressure. After e4 I deferred ...Qxe4 because Bf3 would attack the queen and the bishop behind it; ...Ba6 first, then Bf1 ...Qxe4, won that pawn. These were my own calculations, without outside analysis.

I activated the king with ...Kf7 while queens remained. ...Bb7 Qh7 ...Be4 Bh5+ produced a check and a horizontal pin of g7 to Kf7 by Qh7. I attempted ...g6, considering bishop/queen captures and the last king recapture, but missed that vacating g7 exposed the rook-like queen attack on the seventh rank. The referee rejected the move. ...Ke6 followed legally.

After Qh8, ...Rxc4 Rxc4 ...Qxc4 won a second pawn and exchanged the remaining rooks. However Qc4 and Ke6 lay on the same diagonal as g8. 38.Qg8+ skewered them. I played ...Kd6 and 39.Qxc4 took the undefended queen. I resigned a queen down, without claiming to have proved a forced loss. The critical mistake preceded the final king move: the queen's placement permitted the forcing check. The earlier apparent material gain was not a successful conversion or queen exchange.

Trial 12 assessment: one illegal submission from a missed horizontal pin, and a queen loss from a missed skewer. The remembered-position practice did not transfer into reliable legality or continuation checks. Excessive speculative calculation again failed to prevent simple current-board errors. No opening or general tactical improvement is established.

## Twelve-game checkpoint

Actual ./play status: 12 scored benchmarks, 5 wins, 0 draws, 7 losses. W/D/L by opponent: full strength 0/0/4; skill 0 4/0/0; 1800 setting 1/0/3. No unfinished benchmarks. Provisional engine-relative Elo 1700, 95% Bayesian equal-tail credible interval 1390–2030, based on 8 calibrated games; the 4 full-strength games are excluded from that estimator. This conditional nominal scale is not human/platform Elo and excludes anchor calibration error.

The six-game checkpoint was 1870 (1410–2460). The lower current estimate and two further 1800-setting losses provide no evidence of improvement. Skill-0 wins continue, while the stronger opponents punish elementary geometry and incomplete forcing continuations. Samples remain small, and changes to repertoire and tactical checklists are confounded. An observed get_goal cumulative active-goal counter of 2,388,874 tokens was recorded through ./play usage with its scope; there is no per-move attribution or fixed inference budget.

## Trial 13: checking rays through the king continue behind it

Own study: before committing to a capture, inspect potential checking lines through my king and the pieces beyond it. Moving the king can uncover an undefended queen even when the king's destination itself is safe. A check response must also be tested against other attacks newly opened by the move, as the rejected ...g6 illustrates. This is a correction to my method, not demonstrated learning.

Chosen short test: recorded skill-5 practice as Black from benchmark 12 ply 71, after 36.Qh8, for up to four own moves. Try 36...Qe3 before another capture on c4, placing the queen away from the g8-f7-e6-d5-c4 ray and attacking Rc1. This is my untested candidate, not a best-move, equality, or repaired-position claim. Record actual replies and stop explicitly if still active. Next transfer evaluation is benchmark 13, then continue the fixed rotation; next aggregate checkpoint is 18 scored games.

### Trial 13 first practice failure

Practice 6 stopped explicitly after two own moves/four new plies, zero illegal submissions, unfinished with no score: Qe3 Qe8+ Kd6 fxe3. The queen was lost again. I had inspected the skewer but omitted White's f2 pawn attacking e3. This directly rejects the chosen candidate. Moving off one dangerous ray is insufficient when the destination is attacked by a pawn; the latest procedural addition displaced a basic check rather than supplementing it.

Chosen follow-up within this learning period: one further skill-5 drill from the same saved position, up to four own moves, testing Qd3. Before that trial I explicitly inspected the current White pawn capture squares: a2-b3, c4-b5/d5, f2-e3/g3, g2-f3/h3, h3-g4. d3 is absent. Bh5's ray is g4-f3-e2-d1, Rc1 is blocked on c4, and Qh8 is blocked by g7 and h6; none currently attacks d3. Be4 would defend Qd3. These are my mechanical observations, not proof of a safe continuation. Do not repeat the c4 capture solely because the queen has temporarily moved away; inspect the actual queen ray again after any reply. Benchmark 13 still follows this short test.

### Trial 13 follow-up outcome and decision

Practice 7 stopped after four own moves/eight new plies, zero illegal submissions, unfinished with no score: Qd3 Qxg7 Qd2 Rd1 Qc2 Qf7+ Kf5 Qg6+. The queen survived that exact interval; the g-pawn was lost and the king was still in check at the stop. Rd1 ruled out ...Kd6 in the later checking position, so I selected ...Kf5. No repaired-position, equality, conversion, or transfer claim follows. Both short drills remain recorded separately from benchmarks.

Decision: reject Qe3; retain the specific observed distinction between d3 and e3 and the king/queen checking-ray lesson. For benchmark 13, inspect the proposed landing square against the opponent's actual pawn capture squares, then inspect lines opened by vacating the origin, particularly behind a king responding to check. These checks supplement rather than replace each other. Use the existing 1.d4 repertoire provisionally. Evaluate actual errors after game 13; aggregate rating checkpoint remains 18. No outside study, advice, or automated analysis has been used.

## Benchmark 13 — loss, White versus full strength

Resigned after 22...Qxd1+, 44 plies, zero illegal submissions. Thirteen scored benchmarks: 5 wins, 0 draws, 8 losses; full strength 0/0/5, skill 0 4/0/0, 1800 setting 1/0/3.

The provisional 1.d4 development continued through Nf3, c4, Nc3, e3, Bd3, Bxc4, and castling. This time 9.Nxd4 ...Bd7 10.b3 ...Nxd4 11.Qxd4 retained e3 instead of creating the earlier isolated d-pawn. ...Qa5 attacked a2; I kept Ra1 defending it while developing Rfd1. After Qh4 ...Bc6, Ne2 ...Rxd1+ Rxd1 vacated the a-file and allowed ...Qxa2. I anticipated that pawn concession but did not find adequate compensation.

Bc3 ...Nd5 uncovered Be7-f6-g5-h4 against my queen. Qg3 answered that attack before ...Nxc3 Nxc3 exchanged bishop for knight. ...Qc2 attacked Nc3 and Rd1; Nc3 defended Rd1. I played Rd3, defended by Bc4 and defending Nc3. This local chain looked adequate, but it put the rook directly on Bc4-d3-e2-f1, blocking a potential check interposition. ...b5 attacked Bc4. Nxb5 captured the pawn and retained that chain, restoring equal pawn counts.

21...Qb1+ then checked along the first rank. With Kg1 boxed by f2/g2/h2, Qg3 blocked from e1 by f2, and Bc4 blocked from f1 by my own Rd3, I submitted Rd1. ...Qxd1+ won the rook. I resigned a rook down, not claiming a forced mate had been proved. No queen was lost to a pawn or skewer, but that narrow absence is not evidence of general tactical transfer. The current-board checks failed to include the opponent's forcing check and the bishop's occupied path.

## Trial 14: a defensive chain must also allow a check response

Own review: Rd3 defended the attacked knight, but blocked Bf1 and made the back-rank check decisive. Kg1 had no pawn escape square. A piece defending another piece is insufficient if the arrangement cannot answer a forcing check. Creating king air earlier is one possible precaution, subject to actual attacks on the resulting squares; it is not a universal safe-move rule.

Chosen remembered-position test: practice as White, skill 5, from benchmark 13 ply 38 (after 19...Qc2), up to four own moves. Try 20.Qc7 rather than Rd3, keeping the bishop's d3-e2-f1 path open and attacking Be7. The current pawn capture squares do not include c7, and g3-f4-e5-d6-c7 is clear. The knight remains attacked; my candidate continuation after ...Qxc3 is Qxe7, an intended knight-for-bishop exchange, not a proved equality claim or recommended move from an outside source. Record actual replies and end the drill explicitly if active. Return to benchmark 14 immediately; aggregate checkpoint remains 18 scored games.

### Trial 14 practice outcome and decision

Practice 8 stopped explicitly after one own move/two new plies, zero illegal submissions, unfinished with no score: Qc7 ...Bb4. The opponent moved the threatened bishop to b4 and added a bishop attack on Nc3, alongside Qc2. My intended capture of Be7 after ...Qxc3 was therefore unavailable. I did not play or establish a safe continuation, a final exchange balance, or a forced loss. The candidate has not demonstrated a repair; the two-ply observation is not transfer evidence.

Decision: return to benchmark 14 as Black against full strength. Keep the movement/pawn checks and include immediate enemy checks before relying on a defensive chain. Where practical, create a legal king escape before the opponent's queen enters the lower ranks; verify its resulting square rather than assuming a pawn move is safe. I will try ...Nf6 rather than ...Nc6 on move two if White opens e4/Nf3, retaining ...e5 and aiming to avoid the earlier queenside pawn expansion. This is a provisional repertoire change and confounds attribution; no expected rating gain is claimed. Evaluate actual errors after this benchmark; aggregate checkpoint remains 18.

## Benchmark 14 — loss, Black versus full strength

Checkmated by 29.Qxf7#, 57 plies, zero illegal submissions. Fourteen scored benchmarks: 5 wins, 0 draws, 9 losses; full strength 0/0/6, skill 0 4/0/0, 1800 setting 1/0/3.

The ...Nf6 opening trial led to Nxe5 ...d6 Nf3 ...Nxe4 d4 ...d5 Bd3 ...Bd6, both sides castling, c4 ...c6 Re1 ...Bf5. Qb3 ...Qb6 Qc2 ...Bb4 Nc3 ...Bxc3 bxc3 exchanged my bishop for a knight. ...Nd7, ...Qc7, ...h6, ...Bh7 followed. h6 created an empty h7 square only temporarily: the bishop and later a knight occupied it, and enemy attacks subsequently restricted the king.

...Nef6 answered f3 while defending Bh7. Bxh7+ ...Nxh7 exchanged bishops without an illegal king recapture against Qc2's battery. Nf5 threatened Ne7+ against Kg8/Qc8; ...Qd8 avoided the queen fork. Ne7+ ...Kh8 Rxb7 won White a pawn. ...Nb8 defended c6 against a pawn capture that would also attack Qd8. ...Re8 ...Rf8 later answered Qf5's threat to f7, but did not resolve the invasion. These limited successful responses did not establish a safe overall position.

25.Bxh6 offered a bishop. I accepted with ...gxh6, removing g7 from the diagonal toward Kh8. Qe5+ ...f6 Ng6+ ...Kg8 Qe6+ then boxed the king: Ng6 controlled h8, Rb7 controlled g7, and my own pieces occupied other destinations. ...Rf7 interposed; 29.Qxf7# finished the game. I had calculated ...f6 as a supported answer to Qe5+ and considered other continuations, but missed the decisive further queen check. The bishop gain was not a successful tactical exchange or defensive solution.

Trial 14 assessment: no illegal submissions or direct queen loss, and some actual forcing threats were answered, but king safety and the complete checking continuation still failed. The new opening and the earlier king-pawn advance confound attribution. Six losses against full strength provide no measured transfer evidence. Speculative calculation remained very long and did not prevent the mate.

## Trial 15: retain the king's pawn screen before a forcing check

Own review: h6 alone did not guarantee king air, and accepting Bxh6 removed g7's obstruction of the e5-f6-g7-h8 diagonal. The later ...f6 block could not recover the whole position. Preserving a pawn blocker and examining the next queen check matter alongside destination attacks and legal recaptures.

Chosen remembered-position test: recorded skill-5 practice as Black from benchmark 14 ply 49, after 25.Bxh6, for up to four own moves. Try 25...f6 before capturing the bishop, retaining g7 while blocking the queen's e5-f6-g7-h8 ray; Nh7 currently defends f6. This is my untested candidate, not proof of a repaired position, equality, or a best move. Record actual replies and end explicitly if active. Return to benchmark 15 as White against skill 0 afterward; keep 1.d4 provisionally and inspect king escapes and occupied check-blocking paths before committing to heavy-piece defensive chains. Next aggregate checkpoint remains 18.

### Trial 15 practice failure and decision

Practice 9 ended in checkmate after two own moves/four new plies, zero illegal submissions: f6 Ng6+ Kg8 Rxg7#. This is a practice loss, excluded from benchmark W/D/L and Elo; no stop command was needed because the game finished. I checked its own PGN to verify the actual final move.

The candidate is rejected. Keeping g7 blocked one queen diagonal but left another mating pattern. Ng6 checked Kh8, controlled h8 afterward, and vacated e7. That cleared Rb7's line through c7/d7/e7/f7 to g7; ...f6 had also vacated f7. Bh6 supported Rxg7, while my own Rf8 and Nh7 occupied king destinations. Looking at one pawn screen did not cover the checking move's effects on the other rank. This specific failed test provides no evidence of repair or transfer.

Decision: return immediately to benchmark 15. Include the lines opened by an opponent's checking move, and verify usable king escapes rather than merely noting that a pawn advanced earlier. With White, keep the 1.d4 repertoire provisionally and consider h3 after development when the current position permits it, subject to destination and resulting flight-square checks. Do not introduce it while ignoring an actual attack. Judge the game by actual errors and outcome; aggregate checkpoint remains 18.

## Benchmark 15 — win, White versus skill 0

Checkmate with 46.Qg7#, 91 plies, zero illegal submissions. Fifteen scored benchmarks: 6 wins, 0 draws, 9 losses; full strength 0/0/6, skill 0 5/0/0, 1800 setting 1/0/3. No new Elo observation at this checkpoint.

8.h3 supplied a usable h2 escape from 34...Qb1+. The earlier exchange on d4 used a pawn recapture rather than relying solely on a queen behind a knight. These were limited successful applications, not a clean tactical game.

18.Bc4 ...Rfc8 put my bishop between an enemy rook and Qc2. 19.Rac1 defended the queen from behind, but did not make an enemy rook capture of the queen harmless. After ...b5 attacked the bishop, 20.Qe2 ...bxc4 lost the bishop for a pawn; 21.Rxc4 recovered that pawn, leaving a knight-for-pawn deficit. I failed to prevent the relative pin and pawn attack. Protection by a heavier piece is insufficient against a cheaper capturer.

Queenside pawn advances and a rook exchange produced a passed a-pawn. 29.Ra1 put the rook behind it and avoided a possible ...Nc3 fork of Qb5/Rd1. After ...Qe8 attacked Qb5, Qc5 answered the attack before the pawn advanced. The pawn reached a7. Qb7 later attacked the blocking Ra8; Black left the rook available with ...Qf1 and I captured it. ...Nc7 forked Qa8/Ra6, but after Qc6 Black captured f2 instead and permitted Qxc7. The pawn then promoted. I blocked queen checks with g3 and Qg2, exchanged one queen, and mated with the remaining queen supported by the rook.

Trial 15 assessment: the flight square was actually used, and the passed pawn converted after substantial opponent errors. The bishop loss remains unresolved. This skill-0 win supplies no evidence that the stronger-opponent king-safety failures are repaired. Speculative calculation remained excessive; it did not prevent the basic relative-pin error.

## Trial 16: inspect the cheapest attacker and exposed line

Chosen change for the next benchmark: after each actual opponent reply, identify checks and attacks on my queen, rook, and minor pieces before planning an initiative. When a piece lies between an enemy slider and a more valuable piece, inspect an attacking pawn advance and whether moving the front piece exposes the rear one. A defending queen or rook does not erase an unfavorable cheap capture. Retain the existing destination, path, and final-recapture checks, keeping the calculation focused on the actual board.

Return directly to benchmark 16, Black versus skill 0. Retain the provisional ...Nf6 response to e4/Nf3 and avoid occupying an intended king escape without rechecking safety. Evaluate the actual errors and result afterward; aggregate Elo checkpoint remains 18. No outside study, engine evaluation, or delegated advice was used.

## Benchmark 16 — win, Black versus skill 0

Checkmate with 24...Qh1#, 48 plies, zero illegal submissions. Sixteen scored benchmarks: 7 wins, 0 draws, 9 losses; full strength 0/0/6, skill 0 6/0/0, 1800 setting 1/0/3. No new Elo observation here.

White opened Nf3/d4/Bf4. I developed with ...Nf6, ...d5, ...e6, ...Bd6 and castled. Bxd6 ...Qxd6 dxc5 attacked my queen with the capturing pawn; ...Qxc5 answered it, and b4 was met by ...Qe7. After ...Nc6 b5, ...Na5 Qa4 ...b6 supplied a cheap pawn defender. These actual attacks were handled without a queen or knight loss. I chose ...Rad8 rather than placing a rook on c8, which Bh3 attacked through the clear diagonal.

...Nc4 and ...Nxa3 won a pawn, but ...Nc4 Nxc4 ...dxc4 Qxc4 subsequently let White recover a central pawn. Material returned to equality; the pawn gain was not retained. ...Nd2 forked Qc4/Rf1 and forced a knight exchange: Nxd2 ...Rxd2. After e3, ...Qe4 threatened the bishop-supported ...Qh1#. White played Qc7 and allowed the mate. The rook on f1 and pawns on f2/h2 occupied king escapes; the bishop on b7 protected the mating queen.

Trial 16 assessment: no obvious own material blunder was observed in this game, and the cheapest-attacker and opened-line checks were applied to several actual replies. The final win depended on a missed mating threat from skill 0. This does not establish transfer against the stronger settings. Calculation was shorter than in the preceding games but still spent too much effort on speculative alternatives.

## Trial 17: carry the line checks into the 1800 benchmark

Return directly to benchmark 17 as White versus the 1800 setting. Keep 1.d4 and normal development provisionally. Consider Qe2 after the king's bishop leaves f1 when the actual position permits it, rather than automatically putting the queen on c2 behind a bishop on the c-file. Continue to inspect pawn advances attacking the front piece, the value of the exposed rear piece, immediate enemy checks, and the final legal recapture. Create h2 king air only when the move is currently safe. This is a placement preference subject to the actual board, not an opening solution or a claim of improvement. Record the outcome and errors afterward; the aggregate checkpoint remains 18.

## Benchmark 17 — loss, White versus the 1800 setting

Checkmated by 32...Nf3#, 64 plies, zero illegal submissions. Seventeen scored benchmarks: 7 wins, 0 draws, 10 losses; full strength 0/0/6, skill 0 6/0/0, 1800 setting 1/0/4. The final move was verified by reading only my own compressed game-17 PGN; the referee has no benchmark `pgn` subcommand. No new Elo observation yet.

Qe2 avoided the earlier queen placement behind a c-file bishop, and h3 initially created h2 air. After ...Nfd5 uncovered Be7's attack on Bg5, Bxe7 ...Qxe7 exchanged bishops. Nxc6 ...bxc6 Bxa6 won a pawn; ...Nxc3 forked Qe2/Rd1, but bxc3 removed the knight. Qd3 then defended both c3 and Ba6. Bc4 ...Ra3 Bb3 used the bishop to block the rook's third-rank attack, with a2 supplying a cheap defender. These limited successful responses did not secure the king.

23.c4 attacked Nd5; ...Nf4 attacked Qd3. I chose Qf3 after recognizing that Qg3 would permit a royal fork by ...Ne2+. But 25.g3 obstructed Qf3's route through g3 to h3. ...Nxh3+ consequently won the h-pawn; my intended Qxh3 was unavailable. Kg2 ...Ng5 Qf4 offered a supported queen exchange, which Black declined with ...Qc8.

d5 ...exd5 cxd5 ...Rxb3 axb3 ...cxd5 left two rooks against rook/knight, but one fewer pawn. 31.Qe5 aimed to support a future rook recapture of d5. It abandoned the queen's important capture of a checking knight on f3. ...Qh3+ forced Kg1; ...Nf3# then mated. Qh3 covered h1/h2/g2, f1 and f2 were occupied by my own rook and pawn, and the knight check could not be blocked. The earlier h3 move no longer provided an escape. I had previously considered Qxf3 against this checking jump from a different queen position, then failed to recalculate after moving the queen.

Trial 17 assessment: material play and several direct attacks improved locally, but an obstructed capture and an abandoned checking defence caused another stronger-opponent loss. There is no successful transfer claim. Very long speculative calculation again failed to preserve an elementary defensive function.

## Trial 18: preserve an existing answer to a checking jump

Chosen remembered-position test: skill-5 practice as White from benchmark 17 ply 60, before 31.Qe5, for up to four own moves. Try 31.Rd4, keeping Qf4 available to capture ...Nf3 while activating the rook and blocking the d-pawn. Check actual replies, including the position after any queen check. This is my untested candidate, not a proved repair or an evaluation.

Then return to benchmark 18 as Black versus the 1800 setting. Before repurposing a defender for a pawn or initiative, identify the checks it currently answers and recheck those answers on the resulting board. Retain the provisional repertoire and the actual-board movement/path/cheap-attacker checks. Observe the aggregate rating and resource counter after benchmark 18, then continue the bounded experiment.

### Trial 18 practice outcome and decision

Practice 10 was stopped explicitly after two own moves/four new plies, zero illegal submissions, unfinished with no score: Rd4 ...Kh8 b4 ...Ne6. The intended ...Qh3+/...Nf3 checking sequence was not played. ...Ne6 attacked both Qf4 and Rd4. I did not establish a continuation, final exchange balance, forced material loss, or king-safety repair. The candidate is not adopted as a demonstrated solution. The drill remains excluded from benchmark results and Elo.

Return immediately to benchmark 18. Preserve the lesson about a defender's changing function, and also check whether activating a rook puts it on another square attacked by the same knight. The stronger-opponent loss remains unresolved; the practice observation is not transfer evidence.

## Benchmark 18 — loss, Black versus the 1800 setting

Resigned after 49.Qxc8, 99 plies, zero illegal submissions. Eighteen scored benchmarks: 7 wins, 0 draws, 11 losses; full strength 0/0/6, skill 0 6/0/0, 1800 setting 1/0/5. Every game remains recorded.

The opening reached a Queen's Gambit structure via c4 ...Nf6 d4 ...e6. I developed with ...d5, ...Be7, castling, ...h6, ...Bxf6, ...Be6, ...Nd7 and ...c6. Direct attacks were answered without an initial material loss. ...Nb6-c4, ...a6/...b5 and Bxc4 ...dxc4 traded the knight for White's bishop and produced a passed c-pawn. ...Bc8 defended a6 while avoiding the knight's attack, then the bishop returned to e6/d5. The queenside pawn exchanges and rook exchange left equal material before the central weaknesses were exposed.

28.e4 attacked Bd5. ...Be6 Nxe6 ...fxe6 removed the sole bishop defender of c4; Qxc4 lost that pawn. ...Re8 then protected e6. I recognized that e6 was pinned to Kg8 along Qc4-d5-e6-f7-g8 and played ...Kh7 before considering a pawn advance. But after e5 attacked Bf6, 32...Be7 blocked my rook's line through e7 to e6. Qxe6 won a second pawn. I preserved one function while overlooking the new blocker created by my own bishop move.

White's d/e pawns advanced together. ...c5 d5 ...c4 Qc2+ ...Kh8 d6 forked Qc7/Be7. ...Bxd6 exd6 ...Qxd6 removed the connected passers but left a full knight deficit with equal pawn counts. I continued with the passed c-pawn: ...Qc6, ...c3, ...Rc8 placed the rook behind it and freed the queen. ...Qf6/...Qe6 answered knight attacks, ...h5 pushed the knight to h2, and ...Kg8-f7 brought the king forward. ...Qg6 was supported by Kf7 and offered a queen exchange, which White declined with Qd1.

48...c2 attacked Qd1 but missed the checking reply Qd7+, which forked Kf7 and the undefended Rc8. ...Kf6 Qxc8 lost the rook. I resigned with queen against queen/rook/knight and equal pawn counts. Promotion on c1 would be met by Ra1xc1; this was my own calculation, not an engine evaluation. The late king activity and passed pawn did not recover the material loss.

Trial 18 assessment: several immediate attacks, the actual e6 pin, and the rook recapture were handled correctly, but the defender-removal and bishop-blocking errors lost pawns. The later checking fork caused a decisive rook loss. No king-safety or checking-defence transfer is established. Very long speculation again coexisted with basic changes to the actual board being missed.

## Eighteen-game measurement checkpoint

Actual `./play status`: provisional engine-relative Elo **1650**, 95% Bayesian equal-tail credible interval **1400–1910**. Twelve calibrated games are included; six full-strength games are excluded from this rating. Nominal anchors remain skill 0 = 1320 and the 1800 setting = 1800, with the operator's 50-game calibrated window and model assumptions. The interval excludes systematic anchor calibration error and is not a human, FIDE, or platform rating.

The estimate is below 1700 at twelve games and 1870 at six games, with overlapping credible intervals and small samples. There is no measured improvement claim. Six skill-0 wins coexist with six full-strength losses and five losses in six games against the 1800 setting. Recovery from substantial weak-opponent errors has not transferred reliably to stronger opposition. Repeated weaknesses are king checking sequences, a piece's defence being blocked or abandoned by my own move, cheap attackers of heavy pieces, and whole exchange balances. Opening choices and changing inference effort remain confounders.

Observed `get_goal` counter: **3,409,886 tokens used**, **43,945 seconds** at this checkpoint. The exact cumulative active-goal token counter was recorded through `./play usage`, with its scope stated and no per-move attribution. This is unrestricted evolving-agent play; no fixed inference-budget efficiency or learning-token estimate is claimed.

## Trial 19: rebuild the defender's path after the chosen move

Own review: the move 32...Be7 answered a pawn attack but physically obstructed Re8-e7-e6. Merely remembering that the rook defended e6 was insufficient. Likewise, accepting a useful pawn tempo with ...c2 did not remove White's checking fork. Before submission, check the actual resulting occupied path and the opponent's immediate checks again, instead of carrying over an answer from an earlier position. The intended narrower calculation has repeatedly not been achieved; it remains a process trial, not an observed improvement.

Chosen remembered-position practice: Black at skill 5 from benchmark 18 ply 63, after 32.e5, for up to four own moves. Try 32...Bg5 rather than ...Be7, leaving e7 empty so Re8 still protects e6. White's knight can capture on g5, but h6 currently supplies the pawn recapture; inspect its actual consequences. This is my candidate, not proof of equality, a best move, or repaired defence. End the drill explicitly if active, then return to benchmark 19 as White against full strength with 1.d4 provisionally. Judge the actual errors after that game; next aggregate checkpoint is 24. Continue toward 200 scored games.

### Trial 19 practice outcome and decision

Practice 11 stopped explicitly after five own moves/ten new plies, zero illegal submissions, unfinished with no score. I extended the initially chosen four-move maximum by one own move, announcing the change before playing, to complete an actual capture sequence. Accepted continuation: ...Bg5 h4 ...Bf4 g3 ...Bxg3 Qc2+ ...Kg8 Qe4 ...Bxf2+ Kxf2.

e7 stayed empty and e6 remained defended by Re8; the specific rook-blocking pawn loss did not occur in this drill. But the pawn advances h4/g3 chased the bishop. I chose to capture g3 and then f2; the final king recapture exchanged my bishop for two pawns. The bishop loss is observed, not an assumed recapture. I did not prove that this outcome was forced or that another continuation could not improve it. The resulting position was not played to a result or evaluated externally.

Decision: do not adopt Bg5 as a demonstrated overall repair. The path-preservation idea worked locally, but keeping e6 did not establish adequate bishop mobility or a sound whole exchange. Return immediately to benchmark 19. Keep 1.d4 and ordinary development provisionally; use the resulting board for the final occupied-path and checking-move review, and consider cheap pawn attacks when a bishop retreats. No outside study or delegated chess advice was used. Next aggregate checkpoint remains 24.

### Benchmark 19 — White, full strength, loss

Resigned after 27...Bxe4: 54 plies, one illegal submission. The attempted 13.Bxe7 was blocked by the knight on f6; 13.Bxf6 was the accepted correction. Qd2 preserved direct support of d4 but also occupied the path of Rd1. After ...Nxd4, Nxd4 and ...Rxc4, I was a pawn down: moving Nc6 had uncovered the rook's attack on Bc4. The planned 18.Nd4 Bxd4+ Rxd4 was unsound because Qd2 still blocked that rook. Kh2 and f4 answered the actual bishop checks, but the knight was lost. Later 27.Ne4 Bxe4 left a second faulty recapture plan: Qxe4 would abandon Qe3's defense of Rd2 against Rb2. At resignation I had no minor piece against two bishops and three pawns against five. No forced-mate or engine-evaluation claim is made.

The occupied-path trial failed repeatedly in this game. Long speculative calculation again coexisted with simple board mistakes; I did not achieve the intended compact review. The h3 advance supplied the actual Kh2 escape, but it did not compensate for the material losses. Aggregate is now 7 wins, 0 draws, 12 losses in 19 scored games. All seven full-strength games are losses; calibrated results are unchanged from checkpoint 18. No external study or delegated advice was used.

### Learning trial 20 — test a knight retreat while retaining the queen's path

Use recorded opponent practice, skill 5, White from benchmark 19 ply 34, after 17...Bc6. Try 18.Nd6 instead of 18.Nd4. The knight attacks Rc4 and is initially guarded directly by Qd2; do not count Rd1 as a defender through the occupied d2 square. Use a bound of three own moves, then end the drill and record the actual replies and outcome. The test does not establish a best move or a repaired position. Next evaluation is benchmark 20, Black against full strength; the aggregate checkpoint remains 24.

Practice 12 ended explicitly after three own moves, six plies, zero illegal attempts, with no score: Nd6 Rd4 Qe3 Rxd1 Rxd1 Qb8. The queen's move cleared d2 before the rook exchange. Rf1 reached d1 through empty e1, and both white knights remained on the board. At the stopping point Qb8 attacked Nd6, which was supported by Rd1 along the now clear d-file. The original one-pawn deficit remained; no whole-position evaluation or sound continuation beyond the bound was established.

Decision: keep the concrete habit of naming occupied intermediate squares and using the resulting board when checking a recapture. The observed branch avoided the measured knight loss, but the weaker opponent and short bound preclude a transfer claim. Return immediately to benchmark 20. For the next game, before submitting a sliding move or counting a sliding defender, state the actual intervening squares in my own reasoning; before moving a defender, identify what it currently guards. This is a process trial, not an adopted opening solution.

### Benchmark 20 — Black, full strength, loss

Resigned after 34.Rxd6+: 67 plies, one illegal submission. I chose a new e6–d5 opening against e4, developed, and exchanged both knight pairs, queens, and one rook pair. Material remained level through move 24, with no claim that the position was equal. Kxf6 rather than Bxf6 correctly avoided removing Be7's screen against Rd7 and Kf7. Rb8 directly defended Bb7, but Be5 then attacked that rook. Rd8 abandoned Bb7 and Rxb7 won the bishop. The e3 passed-pawn attempt was contained by White's king and bishop.

The attempted 28...Bf6 was illegal: Rb7 still pinned Be7 to Kf7 along c7–d7–e7–f7. I had incorrectly treated the pin as gone when White's rook left d7. Kf8 was the correction. Bxg7+ Kxg7 Rxe7+ traded the dark bishops while costing a pawn; Rxa7 cost another. Rd6 defended b6 but was itself undefended behind that pawn. After c5, bxc5 removed the screen, and Rxd6+ captured the rook. At resignation I had no piece against rook and bishop, with four pawns against five. No engine evaluation or forced-win proof was used.

Observed decision: the new structure gave a longer stretch without a material loss, but the process trial failed on an overloaded rook, a persistent royal pin, and a pawn move exposing an undefended rook. Speculative analysis was again far longer than intended without preventing elementary errors. Keep 1...e6 provisional, with no measured improvement claim. Aggregate is 7 wins, 0 draws, 13 losses in 20 scored benchmarks; all eight full-strength games are losses. Calibrated results remain those of checkpoint 18.

### Learning trial 21 — move an attacked rook to an actual king defender

Practice skill 5, Black from benchmark 20 ply 65, after 33.c5. Try ...Re6 instead of ...bxc5: d6–e6 is clear and Kf6 directly guards e6. Use two own moves, then stop and record what actually happened. Accept that saving the rook may cost b6 or allow a passed pawn; do not describe this as a whole-position repair. Next benchmark is 21, White against skill 0; aggregate checkpoint remains 24. For quiet choices, narrow my review to the occupied path, immediate enemy checks/captures, and the actual last recapture before expanding other possibilities. This is a voluntary method change, not a learning-token limit.

Practice 13 ended explicitly after two own moves, four plies, zero illegal attempts, no score: Re6 f5 Kxf5 Kxe3. Kxf5 removed the pawn attacking Re6 and retained direct king support of that rook from f5. White's king captured the e3 passer. The rook was not lost and b6 remained on the board at the bound. Each side lost one pawn; Black remained a bishop and two pawns down. The skill-5 opponent's f5 was the observed branch, not a full-strength continuation or proof. Decision: retain the direct-defender check as a process objective and return immediately to benchmark 21. The earlier process failures remain unresolved.

Benchmark 21, White versus skill 0: win by 97 Qh8 mate, 193 plies, zero illegal attempts. Aggregate: eight wins, no draws, thirteen losses in twenty-one scored benchmarks; skill 0 seven wins, maximum skill eight losses, nominal 1800 one win and five losses. No new rating observation is claimed here.

Several local precautions worked: Qc2 supported Bd3 before Bb2, Qe2 cleared the rook's defense of d4, g3 replaced the departed e3 pawn's defense of f4, and moving the rook off the c-file allowed a queen exchange offer without exposing it. The passed pawn reached e7 supported by the bishop. These are observed choices, not evidence of consistent transfer.

The ending remained poor. Kh3 allowed the prospective Ng5 king/queen fork; Rf5 supplied a capture response but Rxg5 hxg5 still cost the exchange. Later 80 Qc6 blocked Qc4+ and was defended by Kc7, but I omitted Rc8+. The king was forced away from its queen: Kxc8 Qxc6+ lost the queen for the rook. Alternatives that leave the rook on c8 also lose Qc6; Kd7 permits Qe6 mate because the bishop blocks Qc6's recapture and the pieces crowd the king. This is my own retrospective calculation, not an engine evaluation or an exhaustive best-move claim.

The weaker opponent's subsequent play allowed Kd8-d7-e8-f8 and e8=Q. The king on f8 protected the promoted queen. Qxf7 Qd8+ Qe8 Qxe8+ Kxe8 removed both queens, and the second e-pawn promoted. The final Qh5+ Kg7 Ke6 Kg8 Be5 Kf8 Qh8 mate preserved a legal king move before the mating check; Black's two pawns were blocked. Recovery depended on the observed opponent branch. I did not establish a forced conversion earlier, and no improvement against the stronger settings follows from this win.

Quiet-move analysis was again extremely long and still missed basic geometry and forcing replies. The intended compact review is not achieved. Trial 22: reconstruct benchmark 21 after ply 158 and try Kb6 instead of Qc6 against skill 5, at most three own moves. Keep Qd7's attack on Re8, avoid placing the queen between opposing queen and rook checks, and verify actual recapture legality rather than merely adjacency. Observe only the played branch. Next measured evaluation is game 22, with the aggregate checkpoint still at 24; no token cap is introduced.

Practice 14 ended explicitly after three own moves, six plies, zero illegal attempts, no score: Kb6 Qd4+ Kb5 Rb8+ Kxa5 Qb6+. The queen remained on d7, the bishop on d6, and both seventh-rank pawns survived. White captured a5 and was still in check at the bound. The rook's relocation did not itself win the queen, unlike the benchmark's Qc6 Rc8+ sequence. This is a local observation against skill 5, not a forced conversion or a stronger-opponent repair. I rejected Bxb8 during the drill because vacating d6 would uncover Qd4's attack on Qd7.

Decision for benchmark 22: retain the French central structure as Black and test the same actual-defender review. Check the opponent's forcing checks before choosing a quiet move; when a king is counted as a defender, verify that its recapture square is safe and that a forcing king move will not expose the piece. Limit speculative branching by returning to the current board after concrete checks, captures, and recapture tails. This is a voluntary process intention, not a claim of fixed inference effort or a token budget. Assess again at the 24-game checkpoint.

### Benchmark 22 — Black, skill 0, draw

Automatic threefold repetition after 81.Rb4+: 161 plies, one illegal submission. Aggregate: eight wins, one draw, thirteen losses in twenty-two scored benchmarks. Skill 0 is seven wins and one draw; maximum skill eight losses; nominal 1800 one win and five losses. Rating is not re-observed here. After 80...Kb2 the final board differed from the previous checked positions, but the legal reply ...Ka3 would reproduce the position reached after 77...Ka3 and 79...Ka3 a third time. The automatic available-claim rule is consistent with that history.

White opened d4; 1...e6 led to a queen's-pawn structure with ...d5 and ...c5. The queen exchange and minor-piece trades left connected central passers, but 37...e3+ omitted 38.Rxe3. That rook was defended by Kd2, so ...Rxe3 would not recover the lost pawn. The subsequent rook exchange and Kxg3/Rxd3+ removed both central passers and left rook and three pawns each. Re5 defended the g-pawn and attacked c5; Rxc5 took the unguarded pawn. Rook moves avoided unsupported adjacent checks and eventually blocked b8 while the g-pawn advanced.

The promotion review failed. After 57...g2 58.Rh2, Pg2 screened Kf2 from Rh2. My attempted ...g1=Q was illegal because it exposed that rook check. The correction ...Kg3 cleared the pin but also put my king between Rg8 and Pg2. Rxg2+ Kxg2 b8=R then produced equal rook-and-pawn material. This was the observed underpromotion, not a forced or optimal opponent continuation. King activation and a defended rook check eventually won White's a-pawn. My a-pawn reached a4, but checks stalled the king and repetition was claimed. No forced conversion was established.

Decision: the weaker-setting result adds a draw, not evidence of stronger-opponent transfer. Immediate checks, cheap captures, royal pins, and actual recapture legality remain unreliable despite very long analysis. The voluntary compact review again was not achieved. Preserve the result and test one narrow alternative before the next benchmark.

### Learning trial 23 — clear a pin without screening the supporting rook

Practice skill 5, Black from benchmark 22 ply 115, after 58.Rh2. Try ...Ke3 rather than ...Kg3. The king leaves the h2–f2 rook ray and the g-file, retaining Rg8's direct defense of Pg2. Verify the actual reply and promotion legality; use at most three own moves, then explicitly end the drill. This tests one local geometric change, not a forced repair of the pawn race. Next benchmark is 23, White versus nominal 1800; aggregate checkpoint remains 24. No token budget or fixed-effort claim is introduced.

Practice 15 ended explicitly after two own moves, four plies, zero illegal attempts, no score: Ke3 Rxg2 Rxg2 b8=Q. The king move was legal and left the g-file open for the rook recapture. The g-pawn was still lost, and White promoted to a queen, leaving Black rook and pawn against queen and pawn. Promotion of my own pawn was not tested in the played branch. The local geometric observation does not establish equality or a repair; do not adopt ...Ke3 as a solution to the race.

Decision for benchmark 23: keep d4 development provisional. Before each selected move, explicitly check whether a departing pawn or piece currently screens my king, and whether an apparent king recapture is legal in the resulting position. Count the opponent's immediate checks and cheap captures before speculative strategic branches. This continues the unresolved process trial, with the next aggregate assessment at 24 scored games.

### Benchmark 23 — White, nominal 1800, loss

Checkmated after 38...Rh1: 76 plies, zero illegal submissions. Aggregate: eight wins, one draw, fourteen losses in twenty-three scored benchmarks. Nominal 1800 is one win and six losses. The d4 opening developed and castled without an early material loss. Bd2 answered ...Nd5's attack on c3 while moving the attacked bishop; Bb5 pinned Nc6 to Qe8. After the queen left that pin, Nxc6 a6 Ne7+ Rxe7 exchanged knights. I rejected Bxa6 because ...Bxa6 would vacate b7 and expose Qxa6 to ...Qxa6 from c8. Bd3 kept the bishop instead.

Rc1 and Qc2 supplied defenses of c3 before Be1's eventual departure. The central pawn exchanges and f6 advance were not shown to be advantageous: ...Nxe5 recovered the temporarily lost pawn, and ...gxf6 removed my advanced pawn. Qf5 h5 Qxf6 Qxf6 Rxf6 removed queens and restored equal pawn material. These local recapture checks worked on the played branch; they are not a whole-position evaluation or proof of improvement.

The ending failed immediately. With Kh2, pawns g3 and h3, and Bb7 controlling g2 and h1, the only empty king flight was g1. I omitted ...Kg7, which attacked both Rf6 and Bh7. Rf5 saved the rook, but after ...Re1 I focused on Rxh5 defending Bh7 along the h-file. I omitted ...Rh1 mate: the bishop supported Rh1 and controlled g2, the rook covered g1, my pawns blocked g3/h3, and h3 also blocked Rh5's recapture of Rh1. No legal capture or interposition remained. The observed ...Re1 had left the bishop untaken, but offered a decisive mating threat instead.

Decision: no stronger-setting transfer is established. Very long speculative trees still coexist with omitted one-move checks and king flights. At a queen exchange, rebuild the opponent's rook and bishop checking lines from the actual board before choosing a pawn capture. At ...Re1 specifically, count the king's flights before considering material recovery. The compact-review intention again was not achieved.

### Learning trial 24 — clear a flight before the rook check

Practice skill 5, White from benchmark 23 ply 74, after 37...Re1. Try 38.g4 instead of Rxh5. This vacates g3 while h5 still attacks g4; ...Rh1+ would then permit Kg3 on this board. The bishop on h7 remains attacked by Kg7, so do not claim the whole ending is repaired. Use at most two own moves, then stop explicitly. Next benchmark is 24, Black versus nominal 1800, followed by the aggregate checkpoint and continued fixed rotation.

Practice 16 ended explicitly after two own moves, four plies, zero illegal attempts, no score: g4 h4 Rg2 Bxg2. The opponent's ...h4 changed the king-flight calculation: h4 controlled the newly cleared g3 square, restoring the Rh1 mating threat. Rg2 blocked Bb7's line toward h1 and was protected by Kh2, but ...Bxg2 captured that rook. At the bound White's rook was gone and the black bishop remained on g2; Kxg2 was calculated as legal but was not played. No exchange completion, conversion, or repair is claimed. The trial showed why checking the flight only before the opponent's pawn reply was insufficient.

Decision for benchmark 24: keep ...e6 provisional, with no rating or transfer claim. Check attacks made by the last move, including a king's attacks on neighboring pieces. After a queen exchange, rebuild all king flights and enemy rook/bishop rays; an earlier h-pawn flight does not guarantee safety for a king on h2. On a quiet selected move, finish the immediate enemy-check review before expanding strategic branches. Assess the actual 24-game status after this benchmark, then continue the bounded experiment.

### Benchmark 24 — Black, nominal 1800, draw

Automatic threefold repetition after 26...Kg8: 52 plies, zero illegal submissions. White's Nf3–c4–d4 transposed to a queen's-pawn opening. Bd7 supplied a replacement defender for Nc6 before ...b6 removed that pawn's defense. ...bxc5 dxc5 Bxc5 won an unguarded pawn. Bd6 supplied a cheap c7 pawn defender for the bishop. ...Ne5 Nxe5 Bxe5 exchanged knights. ...d4 attacked Nc3 and created a passed pawn; ...Qe8 moved the queen off Bh4's ray before moving the other knight could expose it.

The central review still failed. After ...Bc6 f4 I chose ...Bd6, overlooking e5's cheap pawn fork of Bd6 and Nf6. ...Bxe5 would normally allow fxe5 at a material cost, but the recorded opponent chose Rc1 instead. ...Bd6 then saved the bishop and I retained two extra pawns. This recovery depended on the played branch, not a demonstrated forced gain or consistent defense.

Bxf6 required ...gxf6: Qe8 could not recapture the bishop on f6. Qh5 threatened Qxh7 mate supported by Bd3. ...f5 correctly blocked that bishop's ray; the new pawn was defended by e6. Rxc6 Qxc6 then left me up the exchange and two pawns, but the open g-file allowed Qg5+ Kh8 Qf6+ Kg8. Bd6 and Pe6 blocked Qc6's horizontal capture of Qf6; Pf7 blocked Rf8 from capturing it. My rook on f8 and pawn on h7 also occupied potential king flights. The repetition was preserved and automatically claimed. This is my own board calculation, with no engine evaluation or best-move claim.

### Checkpoint — 24 scored games

Observed ./play status: eight wins, two draws, fourteen losses, no active game and no unfinished benchmark. Per setting: maximum skill 0W/0D/8L; skill 0 7W/1D/0L; nominal 1800 1W/1D/6L. Provisional engine-relative Elo 1630, 95% equal-tail credible interval 1410–1860, sixteen calibrated games in the fifty-game window; eight maximum-skill games excluded as uncalibrated. Nominal anchors remain skill 0 = 1320 and the 1800 setting = 1800. The interval is conditional on the estimator and anchors, excludes systematic anchor calibration error, and is not human or platform Elo.

Earlier checkpoints: 6 games 1870 (1410–2460); 12 games 1700 (1390–2030); 18 games 1650 (1400–1910). Intervals overlap, and the early sample was small. There is no measured improvement established; all maximum-skill games remain losses. The last six benchmarks produced one win, two draws, three losses. The new stronger-setting draw is one observation, not established transfer. Opening changes, opponent branches, and unrestricted changing inference effort confound learning claims.

Observed get_goal counter at this checkpoint: tokensUsed 5124426, timeUsedSeconds 70170, status active, remainingTokens null. Recorded that actual cumulative counter with ./play usage and explicit whole-goal learning/play scope. No per-move allocation, fixed thinking budget, or cap is claimed. Work remains 176 scored benchmarks; the goal stays active. Practice 16 and all prior stopped drills remain outside these results.

Decision: retain ...e6 provisionally; keep d4 as White, without an opening-strength claim. The immediate-check/actual-defender method remains unreliable, and the intended compact review again was not achieved. Do not interpret a material advantage as king safety: review the checking squares and routes before a queen recapture. Next aggregate checkpoint is 30 scored games.

### Learning trial 25 — move the king before taking the sacrificed rook

Practice skill 5, Black from benchmark 24 ply 43, after 22.Rxc6. Try ...Kh8 instead of ...Qxc6, putting the king off the g-file while retaining Qe8. This may allow Rxd6 and cost the second bishop; observe that cost rather than assuming the recapture is compulsory or that the resulting ending is favorable. Use at most two own moves, then explicitly end. Return immediately to benchmark 25, White against maximum skill. This narrow local trial is not a forced solution to the queen-check sequence.

Practice 17 ended explicitly after two own moves, four plies, zero illegal attempts, no score: Kh8 Ra6 f6 Qf3. White moved the sacrificed rook from c6 to a6 rather than capturing the second bishop. ...f6 vacated f7 and opened Qe8's diagonal toward Qh5; the opponent moved its queen to f3 rather than exchanging. The benchmark's g5/f6 check loop did not occur in this branch. Black retained Bd6 and both rooks but remained a bishop down with two extra pawns; White's sacrificed rook had escaped. This is not an evaluated equality, a forced repair, or evidence that ...Kh8 improves on the benchmark draw. Do not adopt it automatically.

Decision for benchmark 25: return to d4 as White and the selected-move threat review. Before a quiet choice, finish the opponent's immediate checks and cheap captures; rebuild king flights from the current rook/bishop rays. Keep the queen from blocking a needed rook recapture, and check the last recapture square rather than counting a merely adjacent king. These are unresolved process targets, not a claim that extra analysis has made them reliable. Next aggregate checkpoint remains 30 scored games.

Benchmark 25: White against full strength, loss by resignation after 36...Re5+, 72 plies, zero illegal submissions. Be3/Qe2/Rac1/Rfd1 kept the d-file clear and avoided game 19's particular blockage. After ...Qd5, Nf3 blocked the g2 mating line, but ...Qxa2 won a pawn. Rc7/Bxf3/Qxf3/Bd6/Rc6/Qa1+/Bf1/Bxh2+/Kxh2/Qxf1 removed both bishops; the exposed queen-and-rook ending lost further pawns before recovering a7, b6, and h5. This was not successful transfer merely because the earlier loss mechanism changed. On 35...Qd1+, Kg5 stepped onto the fifth rank and allowed ...Re5+ to attack king and queen. Kh4 then would clear the rook's path to Qh5, and Kxh5 after ...Rxh5+ would be illegal because Qd1 guards h5. Kf4 also leaves the queen attacked. I resigned with no claim of a played continuation. The legal alternative 36.Kh4 was omitted from the move review; before ...Re5 it would keep Qh5 guarded without putting king and queen on the same rook rank. Long speculative branches again exceeded the intended concise review.

Trial 26: revisit benchmark 25 after ply 70, White in check from ...Qd1+, against maximum-strength opponent practice. Test my own 36.Kh4 alternative for at most two own moves, then stop the drill and record the actual branch. This is a legality/threat-management trial, not a claimed draw or best move. Return to benchmark 26 immediately afterward. Aggregate checkpoint remains 30 scored games.

Practice 18: maximum-strength control, White, loss by checkmate after four plies and zero illegal attempts: Kh4 Re4+ Kg5 Qd5#. It ended within the two-own-move bound. Kh4 avoided the immediate benchmark fork, but ...Re4+ ruled out rank-four king retreats. Kg5 kept the queen defended and allowed ...Qd5#: Re4 controlled f4/g4/h4; f7 and g7 controlled g6/f6/h6; the queen checked on rank five, and White's king blocked its own queen's recapture path. This alternative failed. The earlier Qxh5 capture brought queen and king into the checking net; I have not established a repair at move 34. The practice result supersedes any suggestion that 36.Kh4 alone solves the loss.

Trial 27 for benchmark 26: if White opens e4, try my own c6/d5 structure rather than the previous French structure; otherwise use the existing e6/d5 development plan. Keep king shelter and ordinary piece defenses before pawn expansion. Review checks, pawn attacks, and the final recapture on the selected move; do not put the king on its queen's rook rank under a forcing attack. Next aggregate checkpoint: 30 scored benchmarks. Opening changes and process changes remain confounded, and no improvement is claimed.

Benchmark 26: Black against full strength, loss by 23.Qh8#, 45 plies, zero illegal submissions. Accepted play: e4 c6 d4 d5 e5 Bf5 h4 h5 Bd3 Bxd3 Qxd3 e6 Nf3 Ne7 Bg5 Qa5+ Nbd2 Nf5 O-O Be7 Bxe7 Nxe7 b4 Qb6 a4 O-O Rfb1 Nd7 Nf1 Ng6 Ng5 Rae8 Ng3 Re7 Nxh5 Rd8 Nf4 Kf8 Nxg6+ fxg6 Qxg6 Qxd4 Qh5 Qxe5 Qh8#. Ng6 blocked Qd3's h7 mating route, and Rae8 gave e6 a second defender. Re7 retained that pawn defense but occupied the later king flight e7. Rd8 vacated f8 without creating a second king escape. Nxh5 and the g6 exchange lost two pawns; Qxd4 recovered one, and Qxe5 recovered another immediately before mate. I spent long branches on exchange tactics and omitted the direct Qh8 check from the actual board. On mate, e7 was occupied by my rook, f7 was controlled by Ng5, g7 held my pawn, and the eighth rank was controlled by Qh8. Equal pawn counts at the end did not indicate safety. This opening/process trial failed in this game, and the intended concise review was again not achieved.

Trial 28: maximum-strength Black practice from benchmark 26 after ply 33, following White's Ng3. Test my own ...Rd8 with the e8 rook instead of ...Re7, for at most two own moves. The purpose is to examine keeping e7 free while preparing to vacate f8; no draw, equality, or best-move claim. Return immediately to benchmark 27. Next aggregate checkpoint remains 30.

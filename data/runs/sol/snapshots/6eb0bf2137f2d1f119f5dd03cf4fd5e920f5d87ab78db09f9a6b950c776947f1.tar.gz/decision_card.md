# Own play reminders after benchmark 60

Own observations only. The replacement card and opening change are unproven.

1. Read the returned board freshly. Identify immediate attacks on my queen, rooks and minor pieces. Trace every intervening occupied square.
2. For a candidate, inspect its destination, including capture by the piece I am attacking. Ba4 in game 58 attacked Qb3, but Qxa4 simply took my undefended bishop. Inspect abandoned guards and the existing enemy knight's fork squares. Game 60's Bd5 removed Bc6's control of d7 and allowed Nd7 to fork Qf8/Rb8. Own pieces can block retreats.
3. Count only legal recaptures after the actual enemy capture. A pawn remains pinned only if the pin survives that capture: game 54's Qg6 stayed on its line, while game 55's Rf3 moved off its line to f4. Include opposing king, pawn, knight and line attacks after a proposed king capture.
4. Inspect one actual checking reply, including the whole ray behind my king and the board after the final recapture. Game 59's Qxc6/Qh1+/Kg3/Qxc6 skewered the queen through h1-g2-f3-e4-d5-c6; my king blocked the queen's capture/interposition route. Game 60's Nf6+/Nxf6/exf6 attacked a boxed Qg7; eighth-rank retreats met Ra8, losing queen for rook. Inspect actual queen exits and occupied or attacked king flights. A king guard does not repair queen-for-rook loss.

Concrete failures: game 54's Qg6/g7/Kg8 pin made gxf6 illegal, losing the rook placed on f6. Practice 42's Rf7/Qh7+/Kf8/Qh8# boxed the king with my own Rf7/Pg7 while Re6 controlled e7/e8. Practice 41's Rd5 was directly attacked by Rd2 through vacant d3/d4.

Black pawns capture toward lower ranks; White toward higher ranks. A forward push is not a capture. Non-kings may pass through attacked vacant squares, but never occupied intervening squares. Queens do not move like knights.

Games 61-66: White d4/Nf3/Bf4 before e3, development and castling as replies permit; h3 may clear h2 for the bishop. Black e5 against e4, e6/d5 otherwise. Checkpoint 66, endpoint 200 scored games. At 60 the official estimate remains 1500 [1370,1640], with full strength 0/0/20, skill 0 16/1/3 and nominal 1800 1/1/18. Short drills establish only their actual branches; repeated long reasoning, commentary gaps and major-piece losses remain unresolved.

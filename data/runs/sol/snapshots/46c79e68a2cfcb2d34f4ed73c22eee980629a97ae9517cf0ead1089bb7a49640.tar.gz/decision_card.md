# Own play reminders after benchmark 53 and practice 41

Own observations only. This shorter card replaces an ineffective accumulating checklist; its effectiveness remains unproved.

1. Read the returned board afresh. Identify my queen, rooks and minor pieces, and an actual immediate enemy attack on each. Trace rook and bishop lines through occupied squares. In practice 41, Rd2 already attacked the proposed Rd5 square through empty d3/d4.
2. If in check, verify that the move removes the actual check. For a king move or recapture, include the enemy king, knight and pawn attacks after the capture. My own occupied pawn can remove a flight square.
3. For the chosen move, check its destination and the piece whose defender leaves. A guarded pawn elsewhere does not justify leaving a rook attacked: game 52's Ne4 removed Ng5's guard of Rf3, allowing Kxf3.
4. Calculate one concrete forcing reply and the final recapture. A queen cannot land under a rook merely because a pawn could recapture. A king-adjacent defender may have no legal recapture under an enemy rook or king.

Pawn geometry: White attacks one rank upward; Black one rank downward. Black d5 attacks c4/e4, not e6. Forward pushes do not capture. A bishop or rook may pass through an attacked vacant square; occupied intervening squares block it.

Game 53's final net: Kf6 controlled g7, Ng6 supported Rh8, and my h6 pawn blocked Kh6. An advanced passed pawn needs a surviving king flight as well as promotion support. A short remembered drill can fail or remain unresolved; neither is benchmark transfer.

Keep the fixed benchmark rotation and every result. Next aggregate review: 54 scored games; next subsequent evaluation: 60. Stop only at 200 scored benchmarks unless the user redirects.

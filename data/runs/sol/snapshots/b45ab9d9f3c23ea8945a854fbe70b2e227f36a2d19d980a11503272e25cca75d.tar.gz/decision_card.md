# Own play reminders after benchmark 50

These are my own observations, not engine advice. They do not constitute proven improvements.

- Before submitting a move, inspect the opponent's immediate checks. An adjacent checking queen may be protected by a pawn: Qe5 with d4 supporting it ended game 36.
- An empty king flight is safe only if enemy pieces and pawns do not control it. h3 did not make h2 safe against Qd6 in game 35. A bishop changing diagonals can invalidate an earlier flight assessment.
- Inspect the square vacated by a bishop, knight, pawn, or king. d5-e6 opened a rook's path to my queen in game 36; b6-a4 opened a rook's path to my rook in game 34; g6-g5 opened a bishop's path to Rh5 in game 36.
- A guard is not enough without values and legal recaptures. Queen for knight loses six; queen for rook loses four; rook for bishop or knight loses two. Count the opponent's final queen or king capture. Never assume a queen trade or recapture will be chosen.
- A piece left behind may lose its guard when another moves. Ra8 in practice 26 saved the rook but abandoned Nb6. A moving blocker may also open the enemy queen's line to a different piece.
- Recalculate knight geometry as two squares in one direction and one in the other. A knight does not move or guard diagonally by one square. A king guards only adjacent squares.
- Use the actual board and present threats to choose the next move. Long speculative trees have repeatedly missed one-move losses and mate.
- Check a bishop's retreat squares before placing a pawn and knight around it. Be3 became trapped behind my d4 pawn, Nd2 and f2 pawn when f5-f4 attacked it in game 37.
- Attacking a queen does not force it to move if a check intervenes. Bxh2+ and Bg3+ in game 37 forced king moves and blocked my queen's proposed e1-h4 exchange path.
- A pawn pinned to my king is not a legal recapturer. Qg4 against Kg8 pinned g7 in game 38; f6 Bxf6 could not be answered gxf6. Qxf6 instead abandoned Rd7.
- A legal king flight still needs a next-move check inspection. Practice 30's Kh7 allowed Qxg7#, protected by Be5, with f7 blocking my queen and rook recaptures.

- Start with at most two plausible candidates when the reply is not forced. For the selected move, trace its actual path and most forcing immediate reply before expanding other branches. This is an unvalidated routine, not a proven speed improvement.
- Include my own blockers in a long rook move. Qd5 made Rd8-d1 illegal in game 40.
- Attacking an enemy rook does not defend mine. Ra2 in game 39 allowed Rxa2; Kf3 did not guard a2.
- A checking capture can force the king away from another piece. In game 42, Bd7 relied on Ke6; Bxf5+ Kxf5 abandoned that bishop to Rxd7.
- A knight pinned to the king is not a legal pawn defender. Nf5 could not recapture on g7 while Bh3 pinned it against Ke6; Rg8 supplied an actual guard.
- A pawn can block one line and defend a mating square at the same time. Game 41's e3 opened Bd5-f3-g2-h1 and protected f2. Bf3 temporarily saved h1, then Bxf3+ forced the queen capture.

Next aggregate benchmark review: 54. Endpoint: 200 scored benchmark games, regardless of Elo outcome.

- An interposition can make a pawn fork possible. In game 43, Rf2 stopped Qc5+ but e3 attacked both Bd2 and Rf2.
- Recompute defenders on the arriving square after a capture. Rxf3 in game 43 also defended Qe3; Qxe3 would allow Rxe3. Be2 had blocked the earlier queen recapture on e3.
- A king that guards a bishop may occupy its only retreat. Ke7 trapped Bd6 between my c5/c7 pawns and the supported e5 push in game 44.
- Include the rook behind the front rook in a capture sequence. Rxc6/Rxc6/Rxc6 in game 44 would lose my knight despite its rook guard; Na6 had vacated the blocking c5 square.
- Inspect the interposing piece's attack on my checking queen. Qa4+ Bd7 in game 47 directly attacked Qa4; Nc3 defending that queen did not make a queen-for-bishop exchange acceptable.
- A new own blocker can remove a rook defender. Nd3 in game 47 interrupted Rd1-d4 and allowed Nxd4.
- Solving a mate threat can abandon another piece. Rg5/Rg2/Rg1 prevented Qf1 mate in game 47, but moving the d5 rook removed Rd1's defender; Qf3 still attacked d1 through e2, and Qxd1 won the rook.
- Inspect a supported knight fork before interposing a bishop for queen defense. Bg3/Bd6/Nb5 in game 48 attacked the queen and bishop; a4 supported Nb5 and Bg3 made a queen recapture on d6 unsafe.
- A central pawn can be the only shield against a back-rank capture. d4-e3 in game 48 opened Rd1-d8; Rxd8 was mate because f7/g7 occupied flights and Bf5 controlled h7. Include the enemy rook capture before evaluating the pawn trade.
- Include every actual knight jump that attacks a queen or rook. Nb4-c2 in game 49 forked Qe1/Ra1; thinking mainly about d3 missed it. Nb3 did guard a1 and limited the final loss to the exchange.
- A defender under capture can leave another piece immediately loose. In game 49, Bxf3 removed Bd2's only defender while Ra2 attacked the bishop. Be3 would give the bishop a pawn guard before that exchange.
- A bishop can block its own rook's check. Ra1 behind Bf1 in game 49 threatened a discovered first-rank check; f3 gave the king a legal f2 flight. A safe flight still requires the actual next bishop destination to be checked.
- A king adjacent to a piece is not a usable recapturer if the enemy rook controls the capture square. Rc7/Be7/Kf7 in game 50 pinned the bishop and prevented Kxe7 against the rook's support.
- Adding a rook defender can create a knight fork of that rook and king. Rae8 in game 50 answered the bishop attack but allowed Nd6+; the pinned bishop could not take the checking knight.

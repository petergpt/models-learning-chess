# Own decision card after136

136scored39W/7D/90L;full0/0/46,skill32/4/10,nom7/3/34.1540[1410,1660],conditional latest50of90rated,46full excluded;not humanElo. Formal138;endpoint200;goalactive/no tokenbudget.

Actual reply first. Inventory EVERY attack on Q/R AND the other threatened pieces before saving a minor. A pawn-rooted Q9 is still unsafe from R5/B3/N3. Use full capture chain, all bishops/knights, cheap pawns, pinned defenders and FIRST bodies including my king. Defender counts alone are insufficient. Recheck proposed arrival and cheap forcing replies/pawn forks;roots change after moves/captures. Own pieces can box the king or block a promotion.

13619Qb6/20Rxd6 forkedQb6+Be6;Rd6 defendedQg3.20Bc8 savedB while missing queen attack;23Rxb6/axb6 Q9forR5,overallminus5. Correctly rejectingQxd6 did not solve the other attack. Pawns recovered;38Rc2+/Bxc2/Bxc2 costexchange2. Rb1 guardedb3 while57Bg6 guardedf7.58b2 retainedrootRb1 but60Rc1+ releasedit;61Kxb2 stoppedpasser.65Bxh5 lastWhiteP. Queenchecks/KingG6-G7 and availablethreefold draw70Kg7;finalminus3,salvagedweakdraw,no fulltransfer. My kingf6 blockedRg6-b6;no phantom rook root. Time/cadence/boardtracking unresolved.

Trial224 MAXBlack practice112 own136ply39:20Qb7 queen priority;four own moves;no wholeQ/Rloss/deficit<=3localtarget. Actualreply/whole-threat inventory. Then fixed137White nominal1800;formal138.

# Own card after114

Actual reply first. Trace the first body on each proposed route and every newly attacked target after a pawn move/capture. No private branch is the actual board. 111 Rd3 was blocked by ownNd2;112 d5d4 by enemyPd4. Huge unplayed trees and late updates remain unresolved.

Only adjacent royal guards exist. A king cannot capture a defended enemy piece. 114 WhiteKb2 defended the capturing Rc2, preventing ownKd3 from recapturing despite its nominal adjacent guard of c2. Pawns guard diagonals only; rooks rank/file only. Read all targets of a new pawn fork:112 dxe5 attacked both Nf6 and Bd6. Count other guards and line bodies removed by my own move.

King safety before material:112 extra rook still lost to Qg6/Rxh5#,110 Nh6# despite emptyf7,practice86 clearingRf8 failed against g6/Rf7/Qh7. Flight squares must actually be legal. Castle and fair exchanges alone do not prevent mate.

113 White/nominal WIN61Qb7# with opponent opportunities. Nd6 supported b7; real Re3+ was rook check, not queen check. Qc7/Qf7/Qg7 lostNd6, b4-supportedQc5 forcedfairqueenpair. Kc2 guardedRb1 forfairRpair; Qb4/Qb5 leftlegala7/a8, thenkingapproachmate. No ghostenemyRh8: castledRf8 had beenexchanged. OwnPg2 reallyguardedh3. Practice87 onlysixownlocal simplification, finalRe1+ unansweredatbound.

114 Black/nominal DRAW131plies,zeroillegal,castle5/minors8. Nb5 forkedQc7/Bd6 and costexchange; Bf2 combination restoredbalance. c2 fell to Rxc2 because opposingKb2 preventedroyalrecap. Rg4/Ke4/Kf4/g5/Rg3/g4/Re3/g3 leftrookbelowking and a guard obligation to opposingKd2; f7/e7 checks forcedthreefold. Re3-f3 is behind Kf4 against Rf7, not an interposition. No earlierwinproved.

Trial178 sixownBlack/max remembered114ply121: Kf4/Re3/Pg4 versus Kd2/Ra7. TryRe4, realguardsofR/P, thenadaptactual. Stopatbound ifactive. Not a full-gameornew-game transfer test. Next fixed115White/full,formal120,end200,no token budget.

114 scored31W/6D/77L. Full0/0/38,skill0 27/3/8,nominal4/3/31. Formal1141500[1380,1630] stronglyoverlaps1081470[1350,1590]. Conditionalnominalengine-relative,not humanElo. Actualget_goal28635776cumulativetokens,time346803s,recordedformal114,no per-move counter. All reasoningown; no delegated advice, externallookup or automatedchessanalysis.

# Own decision card after126

126 scored35W/6D/85L. Full0/0/42,skill0 30/3/9,nominal1800 5/3/34. Provisional1500[1380,1630],conditional nominal anchors/model,latest50of84rated,42full excluded,not human Elo. Formal132,endpoint200,active goal,no token budget.

FIRST inspect actual board and last move. Black pawns attack down,White up. Kings only adjacent. Check cheap pawn attacks on destinations before long branches. A guarded knight under a pawn can lose2. Practice99 imported c5 into c4 and lost knight+pawn.

Trace guard lines to FIRST body including own bodies.125 QueenD2 blocked Rd1-d3;Rf3 blocked Bh5's imagined guard of Rd1.122 Kf7 blocked Rc7-g7 and allowed mate.126 d7 blocked Rh7 check;king need not move,both passers reached7.

Before pawn gains identify necessary king defender,actual flights,second attacker/recapture.125 Rxg5 abandoned sole first-rank defender,allowing mate. Practice100 Rh1 delayed exact mate but doubled rooks mated after fair first rook pair.124 queen root did not save bishop from second capture.

Material retention is not king/conversion proof.126 h-pawn obtained enemy rook but parked kingh1 while white king supported two passers;rook alone failed. Check pawn interposition,promotion-square king guards,both passers BEFORE king excursion. Prefer central king activity when two enemy passers remain. Do not claim alternatives win without evidence.

Develop and castle with actual replies,preserve trapped-piece exits. Whole-piece gifts explain many skill0 wins. Full0/42 stagnation;overlapping intervals,no causal improvement. Long branches/late commentary unresolved.

Trial203:MAXBlack own126ply101,51Kf5 insteadKh3,sixownmoves/earliertermination,local material/king/pawn retention only;then fixed127White/full. Formal132,stop200. Every chess choice own,no outside lookup in games,no delegated/automated analysis/other-experiment access.


## Trial203/practice101 and Trial204/practice102 actual results

Practice101 MAXBlack own126ply101:51Kf5/bxa6 52Rf7/Rh8 53Rh7/Rxh7. Stopped on demonstrated whole-rook loss after3ownmoves/6plies,0illegal,unscored;seq1004,2026-10-08T09:06:51.700435+00:00. Rh7 was already under Rh8 attack and had no root; Kingf5-h7 is not adjacent. My mental idea that I could capture Rh8 next ignored the opponent moves first. FAILED local retention, no full repair claim.

Practice102 MAXBlack exact pre-Rh7 FEN from ownpractice101, fresh repetition history:53Ra7/Rxh4 54Rxa6/Rf4+ 55Kg5/Rf1 56Kg4/Kd3. Four own/eightplies,0illegal,unscored;seq1015,2026-10-08T09:07:54.029486+00:00. Full PGNs read. Ra7 stayed outside the existing Rh8 attack; outside h/a pawns exchanged; own rook retained, kingg4 central, e6/d5 versus d4, +1 pawn. Rook ending unresolved; local retention only, no full-save/win/independent transfer claim. Final e6 guarded by Ra6 through b6/c6/d6 vacancies; d5 guarded by e6. Kingd3 guards Whited4. A hypothetical Rh8-a8 reply would place White's rook under Ra7 capture, but that reply was NOT played and is not outcome evidence.

Decision: central king alternative plus correct rook destination passed limited retention test after first alternative failed. Trial205 fixed127 White/full, d4/Nf3/e3/Bd3/castle when actual replies allow, prepare c4 without early pawn collection, check actual roots and opponent capture first. Formal132, endpoint200.

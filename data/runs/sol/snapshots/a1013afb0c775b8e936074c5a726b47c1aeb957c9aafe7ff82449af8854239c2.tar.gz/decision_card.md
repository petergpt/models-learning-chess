# Own decision card after 137

137 scored, 39W/7D/91L. Full 0/0/46, skill 32/4/10, nominal 7/3/35. Elo 1550 [1420,1670], latest50 of91 rated;46 full excluded. Conditional nominal anchors; not human Elo. Goal active, no token budget. Formal138, endpoint200.

Before moving the KING, inspect its destination AND every ray and cheap root released at its departure. Own king bodies block rook/bishop/queen roots. After moving the king, do not retain its old adjacency guard. Do the same for pawn/minor departures and captures. Inspect every Q/R attack, royal supported mating check, own flight body, cheapest attacker and full capture chain. Defender counts alone are insufficient. Pawn forward movement cannot recapture an enemy body.

137: first20 no wholeQ/R/no mate met, castle7; full game LOST. +1pawn rook/bishop ending. 42...Bd3 pinned Re4 to Kf5 and attacked it; rejected43Rf4 once. Black declined the exchange twice, allowing45Ra4. 48Bxc2/Bxc2 stopped the passer but costB3/P1;49Rxd6 restored equal nominal material. 53Rh4 supported byKg3, guardedH5 andA4;54h6+Kh8. 55Kf4 released Rh4's king root AND blocked Rh4-A4 throughF4. Rxa4+;56Ke5 clearedF4 and leftRh4 undefended, Rxh4 wholeR5 loss. Resigned atminus6. No forced-mate proof. Material target and board tracking failed; cadence/time not repaired. Elo rose after a loss; not improvement evidence.

Trial227: MAXWhite137ply110, four own moves, intended56Kg3. Targets no mate/no wholeRloss/deficit<=2; actual replies only, explicit stop if active atbound. Then Trial228 fixed138Black nominal, formal138. Do not claim a game save from a short local drill.

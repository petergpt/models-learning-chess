# Decision card after benchmark 138

Objective: stronger independent play and 200 scored fixed-rotation games. Current scored count 138; 39W/7D/92L. No token budget. All results preserved.

For each move, first rebuild the actual board from the latest referee reply. Then identify checks, captures and immediate threats; track each relevant ray only to its first occupied square. Consider the cheaper attacker, complete recapture chain and king legality. Own and opponent kings and pieces can be intervening bodies. A pawn never captures forward or backward; a rook never moves diagonally; a knight's actual displacement matters.

When moving a king or its shield, inspect both its destination and every guard or attack ray changed by its departure. A king guard is useful only if the recapture square is not attacked. Before entering a corner, check the opponent's next checking rook/bishop move and all flight squares, including own-body blockers. Material retention alone did not prevent mates in 133 and 138. When a rook interposes, check its own guard and the guard it releases on the other rook.

Current learning Trial 229: maximum-strength Black replay from my own game 138 ply 111, four own moves. Candidate first reply Kh8, unverified. Targets no mate/no whole Q or R loss/deficit at most 3, local only. Return to benchmark 139 after this drill; formal review 144. Do not claim repair or learning merely from extra checklist length, local retention or a rising rolling rating. Timing and board tracking remain unresolved weaknesses.

## Trial 229 outcome and next trial — practice 115

Verified PGN/result: MAX Black from own 138 ply 111, LOSS by 60 Bxe5#, four own moves/eight plies/zero illegal submissions. Result seq 1153, 2026-10-09T00:17:45.179249+00:00. Actual line: 56...Kh8 57 Rg1 Bg6 58 Rxg6 Re5 59 Bd4 e3 60 Bxe5#.

All local targets FAILED: mate at the bound, the unguarded e5 rook lost to Bxe5, and final nominal deficit 9. Kh8 changed Rg1 from a checking move to a nonchecking move, but that extra tempo did not solve the net. My Bg6 block was captured by the rook, not by the h5 pawn as one imagined branch assumed. The capturing rook on g6 still covered g8, and Rd7 covered h7. Re5 blocked the d4-h8 diagonal but became an absolute royal shield and was undefended. Final Bxe5 was referee-established mate. No saved game or benchmark transfer. Timing remains poor; the imagined bishop block was an ineffective method and will not be repeated as a repair claim.

Trial 230, before benchmark 139: one earlier reconstruction, own 138 ply 109 after 55 Be3, MAX Black. Candidate 55...Kg8 instead of the actual Kg7, accepting the possibility of losing the h6 pawn instead of placing the king on the seventh rank to guard it. Four own moves maximum, unless the game ends earlier. Local targets remain no mate, no whole queen/rook loss, and deficit at most 3. Rebuild actual reply rays and legal king destinations, without treating a king's nominal guard as a legal recapture automatically. This is a remembered single-candidate test, not proof that the position is saveable. After this test return to fixed benchmark 139; formal review 144. Do not add another replay before 139.

# Own decision card after135 / practice111

135scored39W/6D/90L;full0/0/46,skill32/3/10,nom7/3/34.1540[1410,1660],conditional latest50of89rated,46full excluded;not humanElo. Formal138;endpoint200;goalactive/no tokenbudget.

Actualboard/reply. Allopponentbishops/knights, cheapestcapture/fullchain, pawndirections andFIRSTbodiesincludingownpieces. BeforequietR/Qmove checkpawnpushforks AGAINSTarrivalandotherpieces, andminorretreatsblockedbyownpieces. CheaprootdoesnotmakeQ9safefromB3. Rootsdisappearwhenpawns/defendersleaveorcaptured. Royalflightsincludeownbodies/rookchecksretainingothercontrols.

134Qe6onBa2'slinewholeQ9forB3/full46thloss. 13514Re1/f4trappedBe3;Qd2/f2 blockedretreats,cheapattackscoveredothers. Weakopmissedexf4twice,gavebishop,Q9forN3,wholeN,lastRforfree. Bg4interposedpinnedBg3's rooklineandRxg4/Qxg4 gainedexchange;Bxh4+ removedpawn. Re8/Nb6 Rxa8/c5missedNxa8. Qg7+/Nd7 Rd8rootedBh4,Kb6 Rxd7 lastN,Rxb7/Kxa4 Ra1#farRb7controlsflights. Early20Q/Rtargetmet;finalplus24simplematerial. Giftdependentwin,notfulltransfer.

Practice111Trial222 MAX:Qd3/e4 Nxe4/fxe4 Qxe4+/Nce7 Bd4/Nf6,4own8plies0illegal,unscored*. Qd3freedd2butinvitedpawnforkQ/N. N3fortwoPN2,minus1. B/Q/Rretainedlocallybutf4retreatnottested;finalQe4attNf6,unresolved. Noopeningrepair. UntestedQg4wouldhitBd7'snow-cleardiagonal.

Trial223 fixed136Blackskill0:actualcentraldevelopment/castle andpawnpushfork/blockedflightchecks. First16ownmoves no wholeQ/Rloss/materialdeficitgreaterthan1simplepoint;recordfinalresult. Immediateactualreplybeforelongbranchesattempt;timeefficiency/cadencenotprovedrepaired. Formal138.

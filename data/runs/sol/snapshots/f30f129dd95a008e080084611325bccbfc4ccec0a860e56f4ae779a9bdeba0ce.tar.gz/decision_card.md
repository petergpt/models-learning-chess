# Own current card after benchmark 111

Own hypotheses, not independent evaluations. Journal contains actual outcomes. Huge speculative branches, geometry errors and commentary gaps remain unsolved; 111 also had one actual illegal submission.

Read the actual reply. For the selected move, trace the first intervening body before submitting. 38.Rd3 in 111 was blocked by my own Nd2. Answer actual check; count the last legal capture. A pawn can take a queen or knight despite a higher-price recapture. A king cannot capture a defended target, and only adjacent king squares are royal guards. Do not turn every unplayed branch into a new presumed position.

Before moving a guard, identify its other own target. In 111 the departures of Rf1/Kg2, Nb1 and king/knight guards exposed f2, a3 and g3. Piece values stayed balanced while pawn deficits grew. One overloaded rook could not both take a2 and guard Nb3; Kb3 supplied the missing exchange support. Bare-king conversion needs real queen/knight support for close checks and must avoid nonchecking stalemate.

King safety is separate from material preservation. 110 ended one pawn down by Nh6#, covering f7; Bg7 covered f8/h8 and Qg6 covered h7. Practice83 castle/Qxh5/Qc7/Qh7# failed because surviving Rh1 guarded the queen. Practice84 castle/f6/Qe8/Kh8 stopped with actual Nf7+ double check unresolved. Empty f7 and castling alone did not establish safety. 109's Bxf8 met Rxd1+ first and eventually a whole bishop loss; royal G8/F8 are adjacent.

111 won 101.Qg6#, 201 plies, one illegal attempt. Fair queen/minor/rook pairs did not recover pawn losses automatically. Black delayed h-pawn promotion and finally chose h1=N after d8=Q; that opportunity, followed by Qh6+/Qxh5+ and Nxf5+, dominated the late win. Not stronger-opponent transfer. Trial172 is one four-own-move White/max remembered Q/N conversion from111ply196, then fixed Black/skill0 112.

111 scored:30W/5D/76L. Full0/0/38, skill0 27/3/7, nominal1800 3/2/31. Status observed1480 [1360,1600], provisional nominal engine-relative estimate; last formal review108 was1470 [1350,1590]. Review114, endpoint200. No learning-token budget, external lookup, automated chess analysis or delegated advice. No new usage counter observed after108.

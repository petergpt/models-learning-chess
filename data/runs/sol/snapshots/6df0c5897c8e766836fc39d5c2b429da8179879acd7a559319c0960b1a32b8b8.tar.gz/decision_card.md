# Decision card after 141

141 scored: 39W/7D/95L. Elo 1550 [1420,1670], conditional engine-relative interval. Full 0/0/48, skill 0 32/4/11, nominal 1800 7/3/36. Formal review 144; endpoint 200 scored. Active benchmark none.

Before a move, inspect actual first bodies, every released guard, the opponent's immediate checks and the resulting king flights. Cheap roots do not make a more valuable attacked piece safe. An apparent pawn root cannot recapture if departure exposes its own king. A king root permits recapture only when the landing square is otherwise safe. Distinguish fair major exchanges from whole-major losses.

141 lost to 39...Qd1# despite nominal +3 material. Qe3 was pawn/king guarded but blocked Ke2's e3 flight and removed Qc1's capture route to d1. Black Rd8 guarded Qd1 after Qd5 vacated the file. King flights d1/d2/d3/e1/f1 were attacked; f2/f3/e3 were own bodies. Queen safety and rook guard improvement did not establish king safety. 20.Qe3 also released c4's Qd3 guard and could not recapture dxc4. 26.Nd2 blocked Rd1-d4. Rxg3+ exploited the f2 pawn's absolute queen pin to Kg1; Kf1 unpinned it. Rxd3 then Rf3 saved a rook locally after Black declined recapture, not a game save.

139 lost Rc8 to checking Nd6; 140's Kh5 released g7 and Kxh4/Rh6# found own g4 blocking flight and own f5 blocking Rd5-h5. First-20 material retention has not fixed royal safety. Avoid repeating 140's Be7/castle/Bxc6/dxc6/Nxe5/Bd6/Bg4/e5 unchanged; a future appropriate d6 pawn guard of e5 is an own hypothesis, not a prescribed line. Huge unplayed branching has not fixed timing.

Trial 236: MAX White from 141 ply 76, four own moves. Own Qe1 hypothesis retains d1 capture and leaves e3 free. Targets no mate/no whole major loss/final advantage >=1 (initial +3), record intermediate decline. End or finish practice then benchmark 142 Black/skill 0; formal 144. Full rules apply, all moves own reasoning, no search code or outside assistance. Local drill success is not full-game success.

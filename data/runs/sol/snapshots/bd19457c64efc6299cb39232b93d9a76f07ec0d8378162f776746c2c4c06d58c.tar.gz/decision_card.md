# Own decision card after128

128scored35W/6D/87L. Full0/0/44,skill30/3/9,nom5/3/34.1500[1380,1630],conditional latest50of84rated,44full excluded,not human Elo. Formal132,endpoint200,goalactive,no tokenbudget.

Inspect ACTUAL board,last move,and EVERY target attacked,especially forks of queen/rook. Cheap attacker/value matters despite roots: practice103 saved Ra1 but ignored Nc2 attacking Qe1;Nxe1 lost queen9 for eventual knight3. Earlier benchmark E1 was empty; actual practice E1 held own queen. Do not import boards. Black pawn down,White up,kings adjacent only.

Trace FIRST body,including own bodies.122 king blocked rook guard and allowedmate.125 ownQueenD2 blocked Rd1-d3,Rf3 blocked Bh5-Rd1 guard,solefirstRank defender release allowedmate.126 d7 pawn interposed Rh7 check and let BOTH supported passers reach7. Practice101 Rh7 moved undefended rook UNDER EXISTING Rh8;opponent captures first. Practice102 Ra7 exchanged outside pawns and retained rook/central king locally,ending unresolved.

Check necessary defenders,second attackers/recaptures,king flights BEFORE pawn gains.127 pinned Rf2 fell to added knight;Nd4 shield limited exchange,then e5 pawn drove shield and lost knight for pawn.128 castling released Rh8-h5 guard;Bxh6/gxh6 removed f5 knight guard and opened king file;Qg4+/Kh7/Qg7# supported by Nh5. Castling/fair pairs/zero illegal do not prove safety. Never occupy a needed king flight with own rook/queen.

General development useful but no successful transfer established. Full0/44stagnation,intervals overlap. Opponent gifts explain many weaker-setting wins. Long branches/update cadence unresolved.

Trial208 MAXBlack own128ply19,10Qc7 insteadO-O,prepare longcastle with actual squares while retaining h5 rookguard. Sixownmoves/failure/termination,localonly. Then fixed129White/skill0,formal132,stop200. No outside lookup in games,delegation/analysiscode/other-experiment access.

# Own review after benchmark 110

Black/full strength, loss by confirmed 26.Nh6#, 51 plies, zero illegal submissions. Result 2026-10-07T13:03:15.911771+00:00, sequence8793. Full PGN and final referee result read. Cumulative110:29W/5D/76L; full38 losses. No active benchmark or practice.

Actual exact setup finally reached: e4/c6/d4/d5/e5/Bf5/h4, then 4...h5. White chose Bd3/e6/Bxf5/exf5: a fair light-bishop pair, not the old bishop-retreat line. Ng8-e7-g6 developed around the pawn's attack on f6. Bxh4/Nxf4 and Nxf4/Nxh4 exchanged a pawn pair and a black bishop for a white knight through separate captures. Ne6 saved the remaining knight from Bc1's ray. Material was equal after thirteen. Qxh4 would have put a queen under Rh1, and was not played.

14...g6 guarded h5 before castling, but actual 15.Nd6+ forced Kf8. The king never castled. Nd7 completed development on sixteen. gxf5/Rxh5/Rxh5/Qxh5 balanced another pawn pair and one rook pair; all piece values remained balanced. The resulting queen/knight battery forced king moves. Qe7 answered f7 concerns; Nxf5 on twenty-two won the unguarded pawn, and Qd8 answered the queen attack.

23...f6 Qg6+ 24...Kh8 Bg7+ 25...Kg8 26.Nh6# was actual. F7's vacating did not establish a usable flight: the final white knight h6 itself attacked f7, while Bg7 covered f8/h8, Qg6 covered h7 and guarded Bg7. Qg6 was screened on the g-file by its own bishop, but Nh6 supplied the final knight check. Own final Kg8/Qd8/Ra8/Nd7/Ne6, pawns a7/b7/c6/d5/f6; white Kc1/Qg6/Rd3/Bg7/Nh6, a2/b2/c2/d4/e5/g2. Black down one pawn, with the minor and rook values balanced. No whole minor or rook net loss was needed for mate.

Trial168's narrow piece-loss target held through the actual exchanges, but king safety and transfer failed. I wrongly spent huge private branches assuming later queen/bishop/knight replies, repeatedly corrected guard geometry and failed to anticipate the actual Nh6 mate before submitting Kg8. Commentary gaps again exceeded sixty seconds, severely in several stretches. Zero illegal submissions does not show reliable or efficient play. No external source, analysis tool or delegated advice was used.

## Trial169 — earlier remembered position

Black/max practice from110 ply27, after White14.Nf5. Own candidate 14...O-O instead of g6. Castling removes Rh8's last guard of h5; a possible pawn loss is a real cost, not to be hidden. The target is to castle before Nd6 becomes a checking tempo and observe king safety/material under the actual replies, rather than preserving that pawn at the expense of castling rights. Three own moves, then stop and return to White/skill0 benchmark111. No full-game-save claim from a short remembered replay. Official review114; bounded endpoint200.

# Own decision card after136

136scored39W/7D/90L;full0/0/46,skill32/4/10,nom7/3/34.1540[1410,1660],conditional latest50of90rated,46full excluded;not humanElo. Formal138;endpoint200;goalactive/no tokenbudget.

Actual reply first. Inventory EVERY attack on Q/R AND the other threatened pieces before saving a minor. A pawn-rooted Q9 is still unsafe from R5/B3/N3. Use full capture chain, all bishops/knights, cheap pawns, pinned defenders and FIRST bodies including my king. Defender counts alone are insufficient. Recheck proposed arrival and cheap forcing replies/pawn forks;roots change after moves/captures. Own pieces can box the king or block a promotion.

13619Qb6/20Rxd6 forkedQb6+Be6;Rd6 defendedQg3.20Bc8 savedB while missing queen attack;23Rxb6/axb6 Q9forR5,overallminus5. Correctly rejectingQxd6 did not solve the other attack. Pawns recovered;38Rc2+/Bxc2/Bxc2 costexchange2. Rb1 guardedb3 while57Bg6 guardedf7.58b2 retainedrootRb1 but60Rc1+ releasedit;61Kxb2 stoppedpasser.65Bxh5 lastWhiteP. Queenchecks/KingG6-G7 and availablethreefold draw70Kg7;finalminus3,salvagedweakdraw,no fulltransfer. My kingf6 blockedRg6-b6;no phantom rook root. Time/cadence/boardtracking unresolved.

Trial224 MAXBlack practice112 own136ply39:20Qb7 queen priority;four own moves;no wholeQ/Rloss/deficit<=3localtarget. Actualreply/whole-threat inventory. Then fixed137White nominal1800;formal138.

## Practice112 / Trial224 actual failure

MAXBlack from136ply39:20...Qb7 21fxe6 fxe6 22Rhd1 Qe7 23Rd7 Qe8 24Qg7# 1-0. Four own moves/eight plies,0illegal attempts. Referee checkmate resultseq1121,timestamp2026-10-08T21:17:32.873701+00:00;practicePGN read. No voluntary stop:the game ended in mate exactly at the planned four-own-move bound. Benchmark count remains136;practice excluded fromElo.

Qb7 savedQ9 instead ofB3;fxe6 recappedP1,retainingmyQ/twoR and deficitminus3. That material-only target was met while the king was mated, so the repair FAILED. AfterRd7 the queen onG3 also attackedRb8 throughF4-E5-D6-C7-B8. Qe8 savedmyqueen fromRd7 and guardedRb8, butvacatedE7;F7 had already been cleared byfxe6. WhiteRd7 nowrootedQg7 throughE7-F7-G7. Kingh8 could not capture that protected checker;g8 was controlled byQg7 andh7 occupiedmyownpawn. Material retention alone is an inadequate success criterion. No opening/full-game repair.

Trial225:one further MAXBlack four-own-move drill from136ply39. StartQb7;ifactualfxe6,tryRg8 instead ofimmediatefxe6 to contesttheGfile andkeepF7body while acceptingB3 loss. Target:no mate/no wholeQ/Rloss andlocal deficit<=4points;inspect every actualreply. This is a test ofthe changed approach,not a recommended solution or proved save. End atfour own moves ifstillactive. ThenTrial226 fixed137White nominal1800:queen/rook threatinventory PLUS supported matingchecks/own flightbodies before quietmoves. First20ownmoves no wholeQ/Rloss andno mate;recordfull outcome. Formal138 unchanged.

## Practice113 / Trial225 partial retention, material target failed

MAXBlack from136ply39:20...Qb7 21fxe6 Rg8 22Qf3 Qe7 23Rhd1 Rg7 24exf7 *. Four own moves/eight plies,0illegal attempts,stopped at declared bound;seq1132,timestamp2026-10-08T21:23:01.953832+00:00. PracticePGN read;benchmark count still136. No mate/no wholeQ/Rloss locally. Final ownQ9+2R10+5P5=24 versusWhiteQ9+2R10+B3+7P7=29,minus5:exceeds<=4target,so material retention condition FAILED. KeepingF7 and movingRg8 first changed White's actualqueenreply toQf3;Rg7 later addedF7support. White thenexf7. A possibleR/Queen recapture onF7 remains UNPLAYED at the stopped bound,not evidence that I repaired the position. The short local survival differs frompractice112'smate,but no strong-opponent game save or benchmark transfer was shown.

Proceed with predeclaredTrial226 fixed137White nominal1800:develop andcastle from actualreplies;before each quietQ/Rmove inventory royal matingchecks and EVERY queen/rook attack,cheapestcapturer,fullchain,retreat/flightbodies,pawnforks andreleasedroots. First20ownmoves no wholeQ/Rloss/no mate;recordfinalresult. One actualforcingreply check before remotebranches is stillan attemptedprocess change;time/cadence remains unproved and poor. Formal138,endpoint200.

# Own decision card after134

134scored38W/6D/90L;full0/0/46,skill31/3/10,nom7/3/34.1530[1400,1650],conditional latest50of88rated,46full excluded;not humanElo. Formal138;endpoint200;goalactive/no tokenbudget.

Choose from ACTUAL board/reply. All opponent bishops and knights, cheapest attackers, pawn directions, first bodies including own pieces, full capture chain. A pawn-rooted queen can still lose Q9 forB3. Royal flights after actual forcing checks include own bodies and rook checks retaining queen/bishop controls.

134:16dxe5 vacatedd6,17d6/e4 18dxe7/Qxe7 lostBe7 for two pawns. Bf4/Rbd8 Bd6 attackedQe7/Rf8. Qe6 overlooked Ba2-b3-c4-d5-e6 and lostqueen;Bxe6 thenBxf8/Rxf8 cost exchange too. Final practicalminus9,23Nfd2/resignation,45plies0illegal.20-own-move targetFAILED. Full46losses:stagnation,not transfer. Long thinking/update cadence unresolved.

Trial220 next MAXBlack own134ply31, four ownmoves or decisive failure. Try16Ne8 retainingd6 body andfreeingf6 forBe7; inspect actual replies. Targetqueen/rook retention andavoid bishoptrap. Untested alternative, not solvedposition. Endretaineddrill beforefixed135White skill0; formal138.

# Decision card after 139

139 scored: 39W/7D/93L. Elo 1560 [1440,1680], conditional engine-relative estimate. Full 0/0/47; skill 0 32/4/10; nominal 1800 7/3/36. Next formal review 144; endpoint 200 scored.

Before submission, inspect the actual source-to-destination path and every first body. Qe5-e3 in 139 was blocked by Black Ne4 and rejected once. A guard does not make a king recapture legal: Black Ne4 guarded F2 when the f2 pawn fell. For a king response to check, inspect the opponent's next checking fork against the king and every major piece; Kc4 plus Rc8 allowed Nd6+ and the whole-rook loss.

When rook and passer share a file, do not overlook the own pawn blocking the rook's capture, flight, or promotion square. Fair queen/rook exchanges must be separated from whole-piece losses. Prefer concise actual-board checks; enormous remote branches have not improved timing or full-strength results.

Trial 232: MAX White practice from 139 ply 84, four own moves, own Ke3 hypothesis. Targets no mate/no whole major loss/deficit <=4. Return to benchmark 140 afterward. Every move own reasoning; no automated chess analysis, outside help, website work, or foreign material.

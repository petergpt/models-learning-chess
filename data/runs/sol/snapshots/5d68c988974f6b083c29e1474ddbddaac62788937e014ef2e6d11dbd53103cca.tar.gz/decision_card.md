# Own decision card after132

132 scored38W/6D/88L; full0/0/44 skill31/3/10 nominal7/3/34.1530[1400,1650], conditional latest50 of88rated,44full excluded; not human Elo. Next formal138; endpoint200; activegoal/no tokenbudget.

Current board/reply, FIRST bodies including own pieces, cheapest real roots and complete capture chain, opponent checks/knight forks, and king flights. A rooted expensive piece can still lose material to a cheaper capture. White pawns upward/Black downward; kings adjacent only. No imported square identities.

132 win45...Qg4# relied on missed Nxb8 andBxa8, an exchange gift, whole bishop and last-rook gifts. b6 released b7-c6 root and queen became trapped. Safe rook retreats required noticing Bd2-c1 andBa5-b6-c7. b-pawn promoted; afterKf2 the Bd2 king root vanished. Qf3 supportedBg2; immediateQg4 was rejected becauseh3xg4 could capture it despite f5 support. Qg3/Qxh3 removed that pawn beforeQg4 mate. Actual pawn responses as well as king flights matter. No full-strength transfer proved.

Trial216 MAXBlack own132ply7, four own moves: testQc8 while retaining b7-c6 cheap pawn guard. Restricted queen escapes still need actual verification. Next fixed133Whitefull/134Blackfull; formal138. Practice107 failedNe2+ royal/rook fork afterRd4/Rf2; roots alone did not protect an expensive rook. Full0/44; long unplayed branches and update delays unresolved.

# Decision card after 140

140 scored: 39W/7D/94L. Elo 1560 [1440,1680], conditional engine-relative interval. Full 0/0/48, skill 0 32/4/10, nominal 1800 7/3/36. Next formal 144; endpoint 200 scored.

Early material retention does not establish royal safety. 139 lost a rook to the checking Nd6 king-rook fork; 140 retained its rook but was mated after Kh5 released g7 and Nxg7+ drove Kxh4. At Rh6#, own g4 occupied the flight and own f5 blocked rook interposition Rd5-h5. Before a king move, rebuild pawn roots it releases, opponent checking forks, and occupied/attacked flights. Before a move, inspect every first body. A royal root permits recapture only if the destination is otherwise safe; cheap attackers can also gain from trades against a more valuable defended piece.

Opening 140's Be7/castle/Bxc6/dxc6/Nxe5/Bd6/Bg4/e5 sequence lost a bishop for a pawn. Do not repeat it unchanged. Fair queen/rook pairs must remain distinct from whole-major losses. Keep actual-board calculation concise; massive remote branches have not improved timing or full-strength results.

Trial 234: MAX Black from 140 ply 65, four own moves; own Kf7 hypothesis retains g7 guard. Targets no mate/no whole major loss/final deficit <=4, note worse intermediate deficits. Then benchmark 141, formal 144. All moves own reasoning, no chess-analysis code or outside assistance.

# Active own decision card after benchmark 99

Own hypotheses and observations, not engine analysis. The longer card is retained in decision_card_after93.md; complete outcomes are in journal.md. A shorter card is a trial, not evidence of better execution.

Read only the actual returned position. Identify check, the enemy move's new attack, and threatened higher pieces. Do not retain unplayed branches as board state.

Choose one or two candidates. For the chosen move, trace its exact route and destination, the cheapest enemy capture, and the last legal own recapture. Check a forcing enemy check that also attacks the queen or another higher piece. If moving the king, inspect the next supported queen check and actual occupied flights. Once these immediate checks are coherent, submit the move rather than extending speculative trees.

Place the surviving bodies after the last capture. Enemy rook takes my pawn, my rook takes that enemy rook leaves MY ROOK ALIVE. This was repeatedly miscounted in 96's unplayed branches. A further enemy capture must really exist before removing that rook. See exchange_survivors_after96.md for actual examples.

Pawn double pushes need an empty intermediate square and an en-passant check. A queen guard is insufficient if the cheaper capturing piece has support and my final recapture is absent. A king guard must be adjacent and legal after the capture. Neither equal material nor the first legal king flight proves safety.

White: retain early Be2/castling and develop the remaining knight before exposing a trapped rook to save one pawn. Keep f2's actual g3 guard where relevant. Black: adaptive e6/d5; the d5xe4 trial applies only to actual e4/d4/Nc3 before e5. That trigger did not occur in 94. The old queenless Ng5/f6 trial remains set aside.

Earlier failures remain relevant: an en-passant capture after h5, Re7+ forking king/queen, Ng3+ forking king/queen/rook/bishop, an own knight blocking Rd1-d8, and a queen serving as a pinned king shield. Wins or draws after declined enemy captures did not repair these failures. Complete details remain in the journal.

96 lost: 9...Nf5 vacated d4, opening the d-file. Qxd8/Bxd8/Bxd8 lost a whole bishop after the fair queen exchange; Rf8xd8 would permit Rd1xd8# with Bc8 blocking Ra8. Be4 later pinned Rf5 to the king. The en-passant capture removed g4's f5 guard, making Kxf5 legal after Bxf5+. Bxh2+/Kxh2 won a bishop for a pawn while my rook survived. Connected a/b passers and a rook cutoff defeated the late defense. Zero actual illegal moves did not fix mental material/geometry errors or long speculative execution.

Practice 69: h6/Nxf6+/Bxf6/Bxf6/gxf6/Qxd4/Qxd4/Rxd4. Fair knight, bishop and queen pairs; Nd4 lost whole. White's recapturing rook remained on d4. Final nominal two-point deficit. h6 alone did not establish a saved opening.

97 lost: Rd2 guarded c2; Rd5 abandoned that guard. Bxc2 attacked Rd1 as well. Bishop tempi and the a-passer overloaded the two rooks. Bxd1/Rxd1 lost a rook for a bishop, with the recapturing rook surviving; Rxa1 later captured that last rook whole. Kh2 left the unguarded Nf1 available to Rxf1. Final nominal twelve-point deficit. Early equal exchanges did not preserve coordination.

Practice 70: Ne1/Be7/Rd5/a4/Nd3/c6. c2 retained and equal material after three own moves, but no Bxc2 recapture tested; c6 attacked the rook and the next defense was unplayed. Ne1 really guarded c2; Nd3 really blocked the bishop's ray and had c2's pawn guard. Stop note's premature c5/Nf5xd3 was corrected by an activity note: actual c6/Bf5xd3. Read a returned reply before recording a dependent outcome.

98 lost by Qd7 mate at equal nominal material. Qxf6/Be7 lost queen tempi and castling rights after Bxe7/Kxe7. Kf8/Kg8 did not move Rh8, which remained trapped. Ng5/Qf4 made the king's f7 guard insufficient. Moving e6 would open a back-rank rook attack; Bxe6 later uncovered Qf4's file check. The first safe king flight was not a safety proof.

Practice 71: gxf6/Be3/Bd6/Qe2/O-O/Qh5. Castled on seven and retained equal material, with doubled f-pawns and an open g-file. Queen remained on d8; the rook really moved to f8. The next defense and whole-game safety were unplayed.

99 won with important opponent help. Nd5 abandoned e4's knight guard. h4/g5 trapped Rh5; Black declined Bxh5 after gxh6, allowing Rg5. Kxh6 later removed the pawn guarding Rg7, requiring the actual Rg3 retreat. Ne4+ forked king/rook; Bxe4/Bh5 left the knight captured whole, and Bxf5 saved the bishop. Be6 later hung the remaining enemy bishop. Rg3 cut off the bare king while the a-pawn promoted; Qh8 mated. Neither the trap nor repeated long speculative execution was repaired by this win.

Trial 147: three-own-move practice after 99 ply 64, try Rh4 while h4 is empty; inspect actual rook routes and new attacks. Then Black 100, review at 102. If the early Black Nxf6+ branch actually occurs, consider the legal pawn recapture gxf6 and examine the damaged shelter. Later Nf6xe4 remains untested. A pawn advance can protect one square while blocking the rook's last escape. Finish at 200 scored. Latest official Elo 1420 [1300,1550] after 96; cumulative 26 wins, 4 draws, 69 losses. No token budget or fixed inference budget.

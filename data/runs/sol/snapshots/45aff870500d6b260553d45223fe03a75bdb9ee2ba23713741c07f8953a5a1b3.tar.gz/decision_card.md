# Active own decision card after benchmark 97 and practice 70

Own hypotheses and observations, not engine analysis. The longer card is retained in decision_card_after93.md; complete outcomes are in journal.md. A shorter card is a trial, not evidence of better execution.

Read only the actual returned position. Identify check, the enemy move's new attack, and threatened higher pieces. Do not retain unplayed branches as board state.

Choose one or two candidates. For the chosen move, trace its exact route and destination, the cheapest enemy capture, and the last legal own recapture. Check a forcing enemy check that also attacks the queen or another higher piece. If moving the king, inspect the next supported queen check and actual occupied flights. Once these immediate checks are coherent, submit the move rather than extending speculative trees.

Place the surviving bodies after the last capture. Enemy rook takes my pawn, my rook takes that enemy rook leaves MY ROOK ALIVE. This was repeatedly miscounted in 96's unplayed branches. A further enemy capture must really exist before removing that rook. See exchange_survivors_after96.md for actual examples.

Pawn double pushes need an empty intermediate square and an en-passant check. A queen guard is insufficient if the cheaper capturing piece has support and my final recapture is absent. A king guard must be adjacent and legal after the capture. Neither equal material nor the first legal king flight proves safety.

White: retain early Be2/castling and develop the remaining knight before exposing a trapped rook to save one pawn. Keep f2's actual g3 guard where relevant. Black: adaptive e6/d5; the d5xe4 trial applies only to actual e4/d4/Nc3 before e5. That trigger did not occur in 94. The old queenless Ng5/f6 trial remains set aside.

94 reminders: 20...h5 allowed gxh6 en passant; the later king capture recovered that pawn only because White declined to guard it. 34...bxa5 ignored 35 Re7+, forking Kh7 and Qd7. Qxe7/Bxe7 lost the queen for a rook. 38...Rh7 did answer the local h-file mate threat. White's e8=B underpromotion, later declined captures and repeated checks limit the interpretation of the draw. Final rook/pawn against queen/pawn, nominal four points down.

95 won after Black declined Ng3-f5's available queen capture with Qc7. Ng3+ checked Kh1 and attacked Qf5/Rf1/Be2; the queen's knight guard did not make losing it for a knight acceptable. Nxe5/Qxe5/Qxe5+/Rxe5 traded a minor pair and queens fairly; Kxg3 became legal after the queen guard disappeared. Rd1-d8 was rejected because Nd4 blocked its path. Ra8 mate used Kf6's e7/f7 controls and Bg4's real d7 diagonal. These failures persisted despite the win and the shorter card.

Practice 68: Qf4/hxg6/Kh2/Kg8/Nd2/Be5 retained the queen for three own moves with zero illegal routes, but lost the passed pawn and ended with Qf4 attacked and pinned to Kh2. Ng3+ never occurred. Moving Nf3 to d2 removed the cheap Nxe5 reply. No saved defense or transfer established.

96 lost: 9...Nf5 vacated d4, opening the d-file. Qxd8/Bxd8/Bxd8 lost a whole bishop after the fair queen exchange; Rf8xd8 would permit Rd1xd8# with Bc8 blocking Ra8. Be4 later pinned Rf5 to the king. The en-passant capture removed g4's f5 guard, making Kxf5 legal after Bxf5+. Bxh2+/Kxh2 won a bishop for a pawn while my rook survived. Connected a/b passers and a rook cutoff defeated the late defense. Zero actual illegal moves did not fix mental material/geometry errors or long speculative execution.

Practice 69: h6/Nxf6+/Bxf6/Bxf6/gxf6/Qxd4/Qxd4/Rxd4. Fair knight, bishop and queen pairs; Nd4 lost whole. White's recapturing rook remained on d4. Final nominal two-point deficit. h6 alone did not establish a saved opening.

97 lost: Rd2 guarded c2; Rd5 abandoned that guard. Bxc2 attacked Rd1 as well. Bishop tempi and the a-passer overloaded the two rooks. Bxd1/Rxd1 lost a rook for a bishop, with the recapturing rook surviving; Rxa1 later captured that last rook whole. Kh2 left the unguarded Nf1 available to Rxf1. Final nominal twelve-point deficit. Early equal exchanges did not preserve coordination.

Practice 70: Ne1/Be7/Rd5/a4/Nd3/c6. c2 retained and equal material after three own moves, but no Bxc2 recapture tested; c6 attacked the rook and the next defense was unplayed. Ne1 really guarded c2; Nd3 really blocked the bishop's ray and had c2's pawn guard. Stop note's premature c5/Nf5xd3 was corrected by an activity note: actual c6/Bf5xd3. Read a returned reply before recording a dependent outcome.

Trial 144: Black 98 next, review at 102. In the actual earlier Ncxe4 position, consider Nf6xe4 fairly exchanging knights while White's d4 pawn still blocks the file, instead of grabbing d4 under an insufficient queen guard. Untested own candidate. Establish a real replacement guard before rook activity; count final surviving bodies and actual king flights. Finish at 200 scored. Latest official Elo 1420 [1300,1550] after 96; cumulative 25 wins, 4 draws, 68 losses. No token budget or fixed inference budget.

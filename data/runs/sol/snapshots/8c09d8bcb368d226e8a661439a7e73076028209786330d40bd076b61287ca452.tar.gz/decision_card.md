# Own card after112

Own hypotheses only. Read actual reply, select one move, trace its first body and every target attacked by the last pawn move or capture. No imagined branch becomes the actual board. 111 Rd3 was blocked by ownNd2;112 d5d4 was blocked by WhitePd4. Both actual illegal attempts. Huge private trees and commentary gaps remain unresolved.

112 Nxe5/dxe5 forked Nf6 AND Bd6; Nh5 saved only the knight, exd6 lost the whole bishop for a pawn. g4 lost its Nf6 guard too. e6-e5 removed d5's pawn guard. Cheap pawn captures can win a bishop/knight despite an expensive recapture. Only adjacent king squares are royal guards; defended enemy targets cannot be captured by the king.

112 29.Rxh5# with WhiteQg6 still on g6: taking the last h5 body opened Rh1, and Qg6 covered G8/G7/H7. OwnRf8 blocked F8. I was an extra rook ahead at mate. Do not replace the actual queen square with a private Qh6 branch. Empty flight squares must be legal, and a pawn shield can be captured. Similar h-file/queen patterns killed practice83/84 and full110.

109 intermediate Rxd1+ made Bxf8 unsafe;110 Nh6# covered f7 despite empty f7. 111 won after Black delayed promotion and chose h1=N following d8=Q. Practice85 remembered Q/N conversion succeeded only locally. Fair exchanges and skill0 gifts do not establish stronger transfer.

Trial174: Black/max own112ply51 afterRf6, candidateRfe8, four own moves maximum; inspect actual checks, pawn costs and legal royal flights, then stop if unfinished. Next fixedWhite/nominal1800 113. Continue direct-center/development hypothesis adaptively, but do not repeat pawn-fork or captured-shield errors. Formal114, endpoint200, no token budget.

112 scored30W/5D/77L. Full0/0/38, skill0 27/3/8, nominal1800 3/2/31. Observed1470[1350,1590], conditional nominal engine-relative interval, not human Elo; same as formal108. No external lookup, delegated advice or automated chess analysis. No usage observation after108.

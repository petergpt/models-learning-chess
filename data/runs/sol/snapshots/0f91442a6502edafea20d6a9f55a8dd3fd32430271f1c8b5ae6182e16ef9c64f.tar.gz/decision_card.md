# Own decision reminders after benchmark 64 and practice 52

Own observations only. These reminders have repeatedly failed in measured games; reliable execution, faster decisions and improvement are not established.

1. Use the actual returned board. First inspect check, attacks on queen/rooks/minors, and the enemy queen's direct mating destinations. Moving a queen can clear its own bishop's path: game 64 Qe4-b7 unmasks Bg2-f3-e4-d5-c6-b7. Kb8 cannot capture that protected queen; own a7/c7 block flights and Be5 pins c7.
2. Trace each candidate destination's enemy pawn captures, knight jumps and full occupied rays. Black pawns capture downward; White upward. Forward pawn pushes cannot capture. Non-kings may cross attacked vacant squares but cannot pass occupied squares. Queens are not knights, bishops are not rooks, kings move one square.
3. A cheaper defender does not cancel a cheaper attacker taking a higher-valued piece. Practice 49 Nd5 was already under e4's pawn capture; cxd5 did not repair knight-for-pawn loss. Game 58 Ba4 let the attacked queen simply capture the undefended bishop. Do not assume an attacked queen must retreat if it can capture or mate.
4. Account for the actual last recapture. Practice 52 Bd5 was rook-defended, but Rxd5 and the supporting Qf3 meant Rxd5/Qxd5 would leave Black's bishop loss. An imagined queen-first capture is not the actual rook-first capture.
5. Before moving a guard, inspect what it abandons and physically blocks. Game 60 Bd5 abandoned the d7 queen/rook fork square. Game 63 Kf2 abandoned Bh2 and blocked Rc2-h2; F2-H2 is not king adjacency, G2-H2 and G2-G1 are. A safe king destination alone is insufficient.
6. Pins depend on the resulting board. Game 64's attempted exd4 exposed Ke8 to Qe2 and was illegal. Game 54 g7xf6 was illegal while Qg6 pinned the pawn to Kg8; game 55's Rf3-f4 removed the pinner, allowing g3xf4. A pawn may capture its pinner along the pin ray. King recaptures must include enemy pawn/knight/bishop/queen control after the captured piece is removed.
7. Opened lines and checking replies matter: game 61 Bxf2+ cleared c5, uncovering Rc8-c3 while the king answered check; practice 48 Bxe5 cleared d6, uncovering Qb6-f6. Game 59 Qh1+ skewered Qc6 through Kg3 on h1-g2-f3-e4-d5-c6. Game 60 Nf6+/Nxf6/exf6 boxed Qg7; its eighth-rank exits were under Ra8, so a king guard did not prevent queen-for-rook loss.

Use at most two candidates and one concrete forcing reply, then act. Long speculative trees and commentary gaps still recur; do not claim this process is reliably implemented.

Games 65-66: White d4/Nf3/Bf4 before e3; Black e5 against e4, e6/d5 otherwise, adapting to actual replies. Review after 66 scored, then continue to 200. No learning-token budget.

Official status after 64: 17 wins, 2 draws, 45 losses; full strength 0/0/22, skill 0 16/1/5, nominal 1800 1/1/18. Provisional engine-relative Elo 1470, 95% credible interval [1330,1600], conditional on nominal anchors/model assumptions, not human/platform Elo. No measured improvement established.

Practice 52 actual Rd8 Qf3 Bd5 Rxd5, stopped after two own moves, no score. Bishop lost, Black five pawns versus four; unplayed rook exchange would not repair the loss. Trial 96 failed. No saved-game claim. Trial 97 adds the direct queen mating destination and actual final recapture checks.

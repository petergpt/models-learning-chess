# Own decision card after125

125 scored,35W/6D/84L. Full0/0/42; skill0 30/3/9; nominal1800 5/3/33. Provisional1510[1390,1640], conditional nominal anchors/model, latest50of83rated,42full excluded; not human Elo. Formal126, endpoint200; active goal, no token budget.

FIRST check the actual board and opponent's last move. Black pawns attack down; White pawns attack up. Kings defend only adjacent squares. Check cheap pawn attacks on a candidate destination before a long branch. A defended knight under a pawn can still be a losing trade. Practice99 imported the later c5 position into a c4 position and lost a knight plus pawn.

Trace each defensive line only to its FIRST actual body. Own bodies block it too. In125, own queenD2 blocked Rd1-d3 (one illegal). Bh5 did NOT guard Rd1: own rookF3 blocked h5-g4-f3-e2-d1. Rxd1 therefore lost the whole rook5. In122, Kf7 blocked Rc7's guard of g7 and allowed Qg7#.

For every proposed move, identify its necessary king defence BEFORE calculating pawn gains. In125, Rg1 was the only first-rank defender answering ...Rd1+. Rxg5 abandoned that defence and allowed ...Rd1#. A legal pawn recapture and material equality do not imply king safety. Check all king flights and possible checker captures, with actual pawn/king guards, before moving a necessary defender. Replacing it must occur before release.

Count both attackers, both recaptures, and any guard released by capture.124 Bxd6/Qxd6/Qxd6/Bxd6 lost a whole bishop despite a queen defender.125's passed pawn lost protection when the front rook moved; its capture also released Be8's guard. Kingf2 unpinned a rook but occupied its escape square. A whole-piece gain can still allow promotion or mate; defend the immediate royal threat first.

Develop and castle with actual replies. Preserve trapped-piece exits; promotion may capture diagonally. Check promotion-square control and rook lines after each pawn move. Opponent gifts explain many skill0 wins and125's recovery of a bishop. Full0/42 remains stagnation. Intervals overlap; no causal Elo gain proven. Long branches and late updates remain weaknesses.

Trial201: White/MAX practice100 from125 ply168, tryRh1 preserving the first rank, six own moves or earlier termination, then inspect full PGN. Known-position retention only. Finish/end practice before fixed126 Black/nominal1800. Formal126,200 scored endpoint. No analysis code, chess advisers, delegated advice, external study during games, or other-experiment access. Every choice own.

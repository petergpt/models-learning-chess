# Own decision card after134 /practice110

134scored38W/6D/90L;full0/0/46,skill31/3/10,nom7/3/34.1530[1400,1650],conditional latest50of88rated,46full excluded;not humanElo. Formal138;endpoint200;goalactive/no tokenbudget.

ACTUAL board/reply. Queen/rook destinations: EVERY actual opposing bishop, knight capture/checkforks, cheapestattacker andfullcapturechain. Pawn-rootedQ9 canstill loseforB3. Pawn directions andFIRST bodiesincludingownpieces. Kingflights after actualforcingchecks includerookchecks retainingqueen/bishop controls and ownbodies.

134failed20-move target:16dxe5 releasedd6,WhitepassedpawncaptBe7;18Qxe7whilePe4shieldedrookfile. Bf4/Rbd8 Bd6/Qe6 overlookedBa2-b3-c4-d5-e6,wholequeenlost;Bxf8/Rxf8 alsocostexchange. Practicalminus9,resigned23Nfd2,45plies0illegal. Full46losses:stagnation.

Practice110Trial220:16Ne8/e6 17fxe6/dxe6 18Bc8/Nc3 19Nc4/Nd5,4own8plies0illegal,unscored*. Fairpawnpair/equalmaterial retained,Q/R targetmetlocally. Be7stillblockadesWhitePe6 andhasQd8root;Pe6blocksRe1. Originald6line not repeated;f6bishopretreat nottested;development/finalpositionunresolved. Nofullgamesaveclaim.

Trial221 fixed135White skill0:actualdevelopment/castle andallbishopdestinationchecks. No wholeQ/Rloss through20ownmoves;recordactualresult. Attemptshorteractual-reply analysis beforedistantbranches;efficiency/updatecadence notprovedrepaired. Formal138.

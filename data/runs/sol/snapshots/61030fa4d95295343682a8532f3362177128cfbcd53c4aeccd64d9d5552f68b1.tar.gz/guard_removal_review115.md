# Own review after115

115 White/full LOSS by practical resignation after19...Rfd8,38plies,zeroillegal. Result2026-10-07T21:23:06.591480+00:00,sequence9354; fullfinishedPGN/refereeresult/statusread. Trial179castle7/minors10 held but lostbishop andexchange, no strongertransfer. Cumulative11531W/6D/78L; full0/0/39,skill0 27/3/8,nominal4/3/31. Provisional1500[1380,1630] unchanged because full-strength excluded; latest50of76rated,39excluded,conditionalnominalanchors,not humanElo. No new usagecounterafter114.

Bxc4 fairly recaptured the pawn after...dxc4. b5 attackedBc4;Bd3 escaped. However Bd2 blocked Qd1's solefileguard of Bd3. After...c5, dxc5 opened the complete enemyQd8-d3 route. ActualQxd3 won the wholebishop. Be1 opened the d-file again;Qxd1/Rxd1 fairly exchangedqueens, Bxc5 removed the temporary extra pawn. I remained a bishopdown with equalpawns. Rfe1/Bxf3/gxf3 fairly exchangedknight/bishop and left ownf3pawnunguarded. Ne5 attackedf3;f4 preserved thatpawn but left f3free for Nf3+, forkingKg1/Re1. Kf1/Nxe1/Kxe1 cost an exchange. At19...Rfd8 I was a fullrookdown with equalpawns,matchingremaining bishop/knight and no queens. Resignation was my practical choice, not a proved forcedmate.

Two other-body/guard errors defeated the declared trial: dxc5 removed the body blocking the d-file after Bd2 removed the only recapture route, and f4 freed a king/rookfork destination. A guard on the formerly occupied pawn square would have mattered: ownKg2 could guardf3, but this alternative is only my retrospective hypothesis and untested. Private speculativetrees andlateupdates remain excessive despite fewer actualmoves. No delegated/external/automated chessanalysis.

## Trial180: equal-material guard repair

ChooseWhite/maxpractice fromown115ply20 after10...c5, beforedxc5. TryQe2 to supply a real diagonalqueen guard of Bd3 while retaining d4's filebody. Adaptactualcapture andpawnfork replies. Sixownmovesornaturalcompletion,thenexplicitstop. Observewhole-piece retention, legalpaths andchecks; rememberedlocaltest doesnot establishfullgamesave. Then fixed116Black/full;formal120,end200,no tokencap.

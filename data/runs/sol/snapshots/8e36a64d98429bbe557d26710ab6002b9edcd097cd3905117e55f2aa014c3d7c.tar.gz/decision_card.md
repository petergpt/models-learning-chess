# Own decision card after132

132 scored38W/6D/88L; full0/0/44 skill31/3/10 nominal7/3/34.1530[1400,1650], conditional latest50 of88rated,44full excluded; not human Elo. Next formal138; endpoint200; activegoal/no tokenbudget.

Current board/reply, FIRST bodies including own pieces, cheapest real roots and complete capture chain, opponent checks/knight forks, and king flights. A rooted expensive piece can still lose material to a cheaper capture. White pawns upward/Black downward; kings adjacent only. No imported square identities.

132 win45...Qg4# relied on missed Nxb8 andBxa8, an exchange gift, whole bishop and last-rook gifts. b6 released b7-c6 root and queen became trapped. Safe rook retreats required noticing Bd2-c1 andBa5-b6-c7. b-pawn promoted; afterKf2 the Bd2 king root vanished. Qf3 supportedBg2; immediateQg4 was rejected becauseh3xg4 could capture it despite f5 support. Qg3/Qxh3 removed that pawn beforeQg4 mate. Actual pawn responses as well as king flights matter. No full-strength transfer proved.

Trial216 MAXBlack own132ply7, four own moves: testQc8 while retaining b7-c6 cheap pawn guard. Restricted queen escapes still need actual verification. Next fixed133Whitefull/134Blackfull; formal138. Practice107 failedNe2+ royal/rook fork afterRd4/Rf2; roots alone did not protect an expensive rook. Full0/44; long unplayed branches and update delays unresolved.


Trial216 / practice108 MAXBlack own132ply7: stopped at four own moves/eight plies/zero illegal; unscored*, seq1083,2026-10-08T16:26:53.522434+00:00. Completed practice PGN read:4...Qc8 5c4 e6 6cxd5 exd5 7Nc3 c6 8Bf4. Fair central pawn pair, equal material retained in this sample. b7 supports c6 cheaply andc6 supports d5 alongsideNf6. Bf4 attacksNb8 along e5/d6/c7 (c7 now empty); Ra8 andQc8 rootNb8, so BxNb8 would be a fair minor pair. Qc8 has limited escapes; Bf8/Nb8 still undeveloped andkinguncastled. MAX selectedc4, not the rememberedNe5/Qa4/Nc6/Ba6 sequence; the old trap was not reproduced. Local success only, not a demonstrated opening solution. Decision: retain the lesson about pawn guards/own bodies, return to new fixed benchmarks.

Trial217 predeclared for133Whitefull: try1c4 as a new opening choice, then choose development/central commitments from the actual replies. Target the repeated early material cascades and queen/rook forks. Observable local improvement: no unforced whole queen/rook loss through16 own moves and a safe castled king if the board permits; a material comparison and final result will be recorded honestly. Inspect cheaper captures and released pawn guards before commitments; the opening change itself is not evidence of learning. Trial216 was a remembered starting position with a new opponent continuation;133 will be a new measured game. Formal138; endpoint200.

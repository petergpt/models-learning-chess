# Decision card after benchmark 142

142 scored: 39W / 7D / 96L. Full 0/0/48; skill-0 32/4/12; nominal1800 7/3/36. Elo 1540 [1410,1660], conditional 95% Bayesian interval, 50 of 94 rated games; 48 uncalibrated full games excluded. Not human Elo; anchor calibration error excluded. Next formal 144. Stop after 200 scored; no game 201.

Game142 Trial238: Black skill-0 LOSS51.Re6#, 101 plies, 0 illegal. Castle5 / first20 noMate met, wholeQueen retention failed18...Qxe6/19Qxe6+. 30...Nh6 released the sole knight guard of Be5;32Rxe5 lost the bishop. 34Nxe2+/35Rxe2 gained two via knight3/rook5 pair. Final nominal deficit3, still mated. 50g5 prevented Rh5 but occupied the g5 escape against actual Re6#. No proved forced loss before final mate; no saved-game claim. Timing still poor.

Before a move: actual check and enemy captures first; physical first bodies and source-square releases; own landing-square guard; every immediate check aimed at my king, with flights rebuilt after the opponent source is vacated. For a capture protected by a cheaper enemy unit, compute the actual exchange cost. An own piece can occupy the king's needed escape. A defended queen can still lose to a cheaper checking attacker. Zero illegal submissions is not a reliable board model.

Trial239 predeclared: maximum-strength recorded practice from142 ply97, Black, four own moves. Try own unplayed49Kf7 rather than actualKh6; noMate, noWholeMajor, final nominal deficit<=4 (initial3). Stop after4 if active, preserve records and unanswered checks. No transfer claim from a short stopped drill. Follow with benchmark143, fixed White nominal1800. Formal144. Earlier17Kh8 queen-fork repair remains untested.

Recent evidence: 48/48 full-strength losses. 141 and142 skill-0 losses despite early castling and local guard checks. Practice119 mated after2 own moves;120 stopped after4 with Re8+ unanswered. Practice118 stopped with passedWhitePB7 threatening; no ending-save claim. Formal138 Elo1560 [1440,1680]; current1540 intervals overlap, no sustained or causal improvement claim.

Latest real goal counter at formal138: 31,488,555 tokensUsed /391,820 timeUsedSeconds, unchanged from132. No newer observed counter and no per-move attribution. Fair play: my own mental decisions; no other agent, model, engine evaluation or automated chess analysis; operator files and records preserved. Own workspace only.

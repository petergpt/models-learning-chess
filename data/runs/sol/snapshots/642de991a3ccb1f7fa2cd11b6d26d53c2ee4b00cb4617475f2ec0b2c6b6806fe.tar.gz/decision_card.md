# Own decision card after122

Actual reply first; inspect every new line body and all fork targets after pawn/capture/king moves.122 Kf7 blocked own Rc7-g7 and allowed Qg7#. A rook guard is not retained if my own king steps into its path. Repeated long unplayed branches/late updates remain unresolved.

Use real geometry: kings adjacent; White pawns one rank up, Black one rank down; queens rank/file/equal diagonals. Black d5 NEVER guards c6 (practice94 illegal backwards d5c6, knight+rook lost).120 queen f6-e8 was a rejected knight-shaped route. No assumption of reliable execution.

Complete prices: a queen guard can protect a rook against an unguarded queen capture; it does not prevent a cheaper defended minor or pawn from winning the rook.122 Rc7/Qc8 capture price held, but the later king move removed that guard line.119 closed bishop retreats;115/116 whole minors lost. Guards must be checked again when pawn roots or line bodies move.

121 full loss: a4 guard Bb5 attacked by c6, Bd3 saved bishop but Nxa4 won pawn; emergency Bxb3/axb3/Nxb3/Bxb3/Qxb3 spent bishop3 for two pawns to remove outside passers. Qxb3 dropped d4/f4 guards; both fell. Final knight+two-pawn deficit, practical resignation. Practice96 earlier axb5/fair pairs retained minors locally, one pawn down, ended in unanswered Qg5+; no full save.

122 full loss by27Qg7# with material equal. Castle7/minors11, fair pawn pairs and bishop/knight exchange held. Nf8 guarded e6/h7 before f6; g6 avoided h6's attack. Own Kf7 screened Rc7. Full0/42 stagnation. Total12234W6D82L; skill0 29/3/8, nominal1800 5/3/32. Conditional estimate1530[1400,1650], latest50of80rated,42full excluded, not human Elo. Last actual usage counter29,946,255/time364,724s at formal120; no current invented count or budget.

Trial195 Black/MAX own122ply47 tryKf7 earlier beforeBb5; six own or natural end, adapt actual replies, explicitly end if active. Trial196 fixed123 White/skill0 next; formal126; endpoint200 scored. Independent own reasoning only, no external/delegated/automated chess analysis.

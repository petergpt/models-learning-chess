# Own play reminders after benchmark 56

Own observations only. The replacement card and opening change are unproven.

1. Read the returned board freshly. Identify immediate attacks on my queen, rooks and minor pieces. Trace every intervening occupied square.
2. For a candidate, inspect its destination, the pieces whose guards it removes, and an actual retreat if a pawn attacks it. Own pieces can block every retreat. A guard that moves away supplies no recapture.
3. Count only legal recaptures after the actual enemy capture. A pawn remains pinned only if the pin survives that capture: game 54's Qg6 stayed on its line, while game 55's Rf3 moved off its line to f4. Include opposing king, pawn, knight and line attacks after a proposed king capture.
4. Inspect one actual forcing reply and the final recapture or king flights. A legal king move can permit mate on the next move; my own pieces and pawns occupy flight squares.

Concrete failures: game 54's Qg6/g7/Kg8 pin made gxf6 illegal, losing the rook placed on f6. Practice 42's Rf7/Qh7+/Kf8/Qh8# boxed the king with my own Rf7/Pg7 while Re6 controlled e7/e8. Practice 41's Rd5 was directly attacked by Rd2 through vacant d3/d4.

Black pawns capture toward lower ranks; White toward higher ranks. A forward push is not a capture. Non-kings may pass through attacked vacant squares, but never occupied intervening squares. Queens do not move like knights.

Games 55-60: White d4/Nf3/Bf4 before e3, development and castling as replies permit; h3 may clear h2 for the bishop. Black e5 against e4, e6/d5 otherwise. Checkpoint 60, endpoint 200 scored games. Short drills establish only their actual branches; repeated long reasoning and whole-piece losses remain unresolved.

# Independent chess-learning journal

## Starting state — 2026-10-03

Read this experiment's AGENTS.md and GOAL.md. The referee reports zero started benchmark games, no active game, and no Elo estimate. No imported learning material, outside position advice, or engine analysis has been used. An active goal is registered without a token budget. Actual token counters are unavailable; no usage values will be invented.

The target is stronger play, with the bounded endpoint of 200 scored benchmark games. All moves will be my own decisions. Full-strength results remain part of the benchmark, although the current estimator excludes that uncalibrated opponent.

## Trial 1: position tracking and tactical safety

Hypothesis: maintaining a reliable board model and checking the opponent's forcing replies will reduce avoidable material losses. This is an unverified self-assessment, not a measured diagnosis yet.

Initial study: review ordinary opening priorities from my existing knowledge: contest the center, develop pieces, secure the king, and avoid unnecessary pawn moves. In tactical positions, consider checks, captures, and direct threats for both sides. Before committing a move, mentally update the occupied squares and check whether the move leaves a piece or mating square unprotected. Favor concrete calculation over relying on the checklist alone.

First evaluation point: six scored benchmarks, covering one paired-color rotation. After each game, record one concrete failure or successful behavior and choose a learning adjustment before the next game. Use recorded opponent practice when a specific weakness calls for a drill. Baseline results will be descriptive; six games cannot establish a reliable improvement trend.

Observable evidence: recurrence of pieces lost to an immediate forcing reply; ability to reach playable middlegames without such losses; benchmark results and the referee's Elo interval. An easier practice win alone will not establish transfer.

### Initial repertoire choice

White: begin with 1.e4, develop naturally, and adapt to the reply. Black: meet 1.e4 with ...e5 and 1.d4 with ...d5 unless a concrete position warrants another choice. These are my own familiar starting choices, not externally recommended moves.

## Benchmark 1 — loss, White versus full strength

Resigned after 22...Bxf4, 44 plies, with an extra enemy minor piece and no identified compensation. No illegal submissions. This full-strength game does not supply a calibrated Elo observation.

Concrete failure: after 19...g5, I played 20.Kg2 gxf4 21.Bxf4 Qxf4 22.Qxf4 Bxf4. I failed to count the queen and bishop attacking f4. The queen trade did not recover the bishop. Looking back, my bishop on e3 also had its retreat squares obstructed by my own queen and pawns; this was more than a recapture oversight. The king-safety plan overlooked that trapped-piece consequence.

Earlier concern: 15.Qd2 permitted ...Bxf3 with g-pawn recapture because my bishop on e3 blocked the queen's route to f3. These are my own assessments, without engine validation.

## Trial 2: complete exchanges and preserve an escape square

Learning period: mentally revisit the position after 19...g5. Count material through the entire exchange, not just the first recapture, and check available bishop retreats after pawn captures. The actual continuation loses a bishop; a proposed 20.f5 opens f4 as a retreat square and avoids ...gxf4. Its overall quality is unverified and its king-safety consequences require play.

Recorded practice: one short drill from benchmark 1, ply 38, against skill 5. This is a remembered position, not a new transfer test. Try my own alternative 20.f5, then finish or explicitly end the drill after observing the immediate consequences. Next measured evaluation: benchmark 2, with the six-game rotation still the first aggregate checkpoint.

Observable result: avoid the specific forced bishop loss in the drill; in new benchmark play, resolve pawn attacks on blocked pieces before making unrelated moves. Neither a corrected remembered position nor a practice result establishes stronger general play.

### Trial 2 outcome and decision

Practice 1 was explicitly ended as an unfinished drill after 20.f5 Qh2+ 21.Kf1 Qxh3+ 22.Ke2 Qf3+ 23.Kf1 a4. The bishop remained on e3, but I lost h3 and my king was displaced. Thus the narrow trap was avoided; the alternative was not shown to equalize or win. No practice score is claimed.

Decision for benchmark 2: apply complete exchange counting to new positions and inspect mobility when a pawn advance closes a bishop's diagonals. In opening pins, prefer development and a recapture that preserves king cover. The original first aggregate evaluation remains six scored games. Do not claim transfer until these behaviors survive new benchmark positions.

## Benchmark 2 — loss, Black versus full strength

Checkmated at 33.Nh4#, 65 plies, no illegal submissions. Material remained equal through the opening and the bishop exchange. I did not anticipate 23.Qxa8 after 22...axb4 cleared the a-file: the continuation traded White's queen for both Black rooks. Material comparison alone missed the resulting rook coordination against my king.

A direct error followed: 25...c3 26.Rc1 Qe7 27.Rxc3. Moving the queen removed the pawn's only defender. Later the rooks on a8/c8 overwhelmed Bf8; 29...Kh7 30.Rxf8 was followed by Rh8+, Bh6+, and Nh4#. My own diagnosis is lost-defense and king-flight errors, not merely unfamiliar opening knowledge.

Transfer assessment: the specific trapped-bishop loss from game 1 did not recur, but elementary tactical omissions did. There is no evidence yet that the first method improved benchmark strength. Both completed games are uncalibrated maximum-strength losses, so Elo remains unavailable.

## Trial 3: vacated lines and lost defenders

Learning period before benchmark 3: mentally revisit two remembered positions from game 2. At move 22, the pawn on a5 was masking the rook on a8 from Qa4; ...axb4 removed that mask. At move 26, Qc7 was the only defender of c3; ...Qe7 removed it. These are concrete line changes visible from the recorded moves, without external evaluation. A candidate such as retaining the queen on c7 and creating a king flight square is only an untested alternative.

Changed method: after choosing a candidate, inspect the origin square as well as the destination. Name the specific piece or pawn that loses protection and any line that opens; then consider the opponent's available checks and captures on those lines. Do this concretely, rather than treating completion of a checklist as success.

Next evaluation: benchmark 3 now, and the aggregate checkpoint at six scored games. Observable transfer: no unanticipated immediate capture caused by vacating a blocker or sole defender. Recurrence will count against the method even if a weaker opponent fails to exploit it.

## Benchmark 3 — win, White versus skill 0

Checkmated at 43.Rf8#, 85 plies, no illegal submissions. This is the first calibrated result. Opponent mistakes allowed two knights and then the queen to be won. I converted the remaining rook-and-bishop advantage after a later mistake.

Errors: 9.Qxf3 left d4 without a defender, allowing ...Nxd4. Later 23.Re8+ Rxe8 24.Qxe8+ Kxe8 demonstrated another incomplete exchange calculation: I had not accounted for the final king capture of the queen. The position remained won because of the much larger prior material advantage, not because that combination was sound.

Successful behavior: the final endgame kept the rook safe while the king advanced, captured the remaining pawns, and explicitly avoided stalemate. At move 41, Bh4 released b8 as a legal king move before Kb6 and Rf8#. This was a concrete correct conversion in a favorable position, not proof of general improvement.

Trial 3 assessment: failed its targeted transfer criterion; the lost-defender error recurred. A win against skill 0 does not override that evidence.

## Trial 4: final-position verification in forcing sequences

Learning period: revisit benchmark 3 after 22...Rc8 (ply 44), a remembered position. Check the resulting occupied squares and the defending piece after every capture, including a king recapture. A check is not mate unless every king destination, capture of the checking piece, and available block has been examined.

My own proposed correction is 23.Qxf6+ rather than sacrificing the rook on e8. It preserves the rook as a defender. Its consequences will be tested with a short recorded skill-5 drill, without requesting analysis. Next transfer test is benchmark 4; the first aggregate checkpoint remains six scored games.

Observable result: verify the drill's actual outcome, then avoid a queen or rook loss from a final king recapture in new play. No claim that a memorized drill alone demonstrates learning transfer.

### Trial 4 drill outcome

Practice 2 ended in checkmate after 23.Qxf6+ Kd7 24.Qe7#, three new plies, no illegal attempts. The rook on e6 protected the queen on e7. The referee verified the outcome; no engine analysis or advice was requested. This corrects the remembered example but does not yet show transfer.

After three scored benchmarks, the referee reports Elo 2070 with 95% credible interval 1110–3350, based on one calibrated win and excluding the two full-strength losses. This is a very small sample, conditional on nominal engine anchors and estimator assumptions, not a human rating.

Decision for benchmark 4: retain the correction's principle—explicitly verify the defender remaining in the final position—and watch the origin-square defenses. Next aggregate evaluation remains six scored benchmarks.

## Benchmark 4 — win, Black versus skill 0

Checkmated with 20...Qd1#, 40 plies, no illegal submissions. B g4 protected Q d1 through f3/e2, and I checked that the king could not capture the queen. This is a successful use of the final-defender principle in a new position, but one favorable example is weak transfer evidence.

The opening preserved king cover and supported ...e5 with Re8/Nc6. The ...e4 pawn advance attacked the bishop and knight; White's subsequent captures and failure to recapture the queen allowed a decisive advantage. I do not claim that winning the queen was forced against accurate defense. No obvious own immediate material-loss oversight was identified in this game; that is a self-assessment without independent analysis.

## Trial 5: direct development with explicit center support

Learning period before benchmark 5: contrast my own openings. In game 1 the bishop and remaining knight made several early moves before the c1 bishop developed. In game 4 castling and rook support made a central advance possible. The hypothesis is that simpler development with maintained pawn defenses will reduce restricted-piece and lost-defender situations; this remains unverified.

White experiment: if the reply permits, develop the king's bishop to c4 and the queen's knight to c3, castle, and develop the c1 bishop without neglecting the center. Adapt to actual replies rather than force an opening sequence. Keep the final-position verification from trial 4. This is my own repertoire change from existing knowledge, with no external source.

Next evaluation: games 5–6 against the fixed 1800 setting, followed by the six-game aggregate checkpoint and a new learning decision between games. Observable result: reach a developed middlegame with material intact and no unanticipated lost defender; record any exception separately from W/D/L.

## Benchmark 5 — loss, White versus the 1800 setting

Resigned after 37...Rxg2, 74 plies, no illegal submissions. A full rook was missing, pawn counts were equal, and I identified no compensation. No loss was discarded.

The opening adapted to ...Nc6/...e6: queens were exchanged, both bishops developed, and I castled long. Material remained equal through move 34. This met the narrow development objective, but did not produce a successful game.

Errors and warnings: 23.Kd2 blocked the rear rook and 23...Bb2 exposed the advanced rook on d4. I overlooked its restricted retreat squares and the effect of occupying d2. The opponent allowed ...Ne7 instead of taking the rook; 25.R4d2 saved it. That was not proof that the earlier position was safe. The decisive direct blunder was 35.Rf4: the black pawn on e5 could capture f4. 35...exf4 36.Rxf4 left me down a rook for a pawn, and subsequent ...Rxg2 removed the pawn difference. My longer prospective calculations had failed to check a basic attack in the actual position.

Correct new-position behavior: 20.Bh2 preserved the e5 pawn's defense while avoiding the black pawn on h4, and 27.Rf2 covered g2 before the knight moved off e4. These successes coexist with the later failure; they do not establish improved strength.

Trial 5 assessment: direct development transferred to a materially intact queenless middlegame. Tactical reliability did not; the game was lost to a one-move pawn capture.

## Trial 6: current pawn attacks before destination choice

Learning period before benchmark 6: revisit the decisive remembered position after 34...e5. Mentally mark Black's pawn attacks: a4 -> b3; b7 -> a6/c6; c7 -> b6/d6; e5 -> d4/f4; f6 -> e5/g5; h4 -> g3. The proposed rook destination f4 was directly on this list. Support behind a rook does not make trading it for a pawn acceptable.

Method change: first reconstruct the current pawn locations from the referee board, then check the destination against those attacks before calculating longer variations. Keep the full final-position and lost-defender checks, but use them on the actual board instead of an imagined future continuation. This is a targeted procedural trial, not a claim of learning by checklist length.

Next evaluation: benchmark 6, then the first six-game aggregate checkpoint. Observable result: avoid a direct pawn-controlled destination that loses a more valuable piece; record any occurrence even if the opponent misses it. No practice result or transfer is claimed for this mental review of a remembered example.

## Benchmark 6 — win, Black versus the 1800 setting

Checkmated with 69...Ng3#, 138 plies. One illegal submission: at move 21 I attempted e5f6 for a knight, mistaking a diagonal step for a knight move. The referee rejected it, the position stayed unchanged, and the legal continuation was 21...d4. This geometry failure must not be hidden by the win.

The opening exchanges left an extra pawn and White's bishop pair. I maintained pawn support through ...d4, ...Bc3, ...Bd2, and ...dxe3. The opponent's active rook required repeated knight defenses. ...g6 created king flight before the rook left the back rank. Rook and bishop exchanges eventually produced knight versus bishop with four pawns against three. These are descriptions of the played position, not engine evaluations.

The kingside exchanges, supported ...f4, ...Ng3, ...Nf5, and ...Nxh4 eventually produced two passers against the a-pawn. Conversion was slow and uncertain. I repeatedly reconsidered long hypothetical lines, including imagined drawn fortresses and king routes, without efficiently resolving the actual position. After ...h2 Bxf3+ ...Nxf3, White's king on g2 prevented an immediate safe promotion. 64...Kf4 65.a5 Nd4 66.Kh1 allowed ...Kg3, ...Kh3, and ...Nf5. White had to move its a-pawn because its king had no legal move. The final position after a8=N permitted ...Ng3#: h2 covered g1, Kh3 covered g2 and h2, and the distant promoted knight could not remove the check. I explicitly checked that a queen promotion on a8 would also not capture g3 or resolve that knight check; this is my own calculation, not a separate recorded result.

Trial 6 assessment: no direct pawn-controlled destination causing a rook or minor-piece loss was identified in this game. The targeted check helped in several actual choices, but the illegal knight move and lengthy board drift expose separate reliability problems. One win does not establish consistent transfer.

## First aggregate checkpoint — six scored benchmarks

Referee status: 3 wins, 0 draws, 3 losses. Full strength: 0/0/2 W/D/L; skill 0: 2/0/0; 1800 setting: 1/0/1. All six started benchmarks finished and remain recorded. Two recorded practices: one unfinished drill and one win; neither contributes to these counts.

Provisional engine-relative Elo 1870, 95% Bayesian credible interval 1410–2460. Four calibrated observations; both full-strength games excluded by the operator's estimator. Conditional on nominal anchors and model assumptions, excluding systematic calibration error; not human/FIDE/platform Elo. Earlier estimates of 2070 and 2210 were based only on skill-0 wins; the changes to 1680 and 1870 after the two 1800 games are primarily new evidence, not a demonstrated learning curve. Improvement or stagnation cannot yet be established.

Observed active-goal counter from get_goal: 779650 cumulative tokens at this checkpoint. Recorded through play usage with its scope: all goal learning and play, no per-move attribution. This is an actual tool counter; no inferred or invented token values. The experiment has no token budget.

Decision: retain natural development and final-defender checks, but reduce speculative analysis that loses current geometry. Continue the fixed rotation. Next aggregate evaluation: 12 scored benchmarks; revise the trial after each game.

## Trial 7: current geometry before extended calculation

Learning period: revisit the rejected move in game 6. A knight changes one coordinate by two and the other by one; e5f6 changes both by one and is not a knight move. Mentally reconstruct e5's eight geometric destinations: c4, c6, d3, d7, f3, f7, g4, g6; then distinguish occupancy and opponent pawn attacks from geometry. This is my own mental exercise, not an automated legal-move menu. At the remembered position, f7 held my pawn, g4 was attacked by h3, and f3 by g2.

Also revisit the actual ending: the a-pawn's forced moves supplied time for a knight mate even though it promoted. Counting a promotion race alone was insufficient; the distant promoted piece's ability to answer the immediate check mattered. Keep that as a concrete calculation principle, without treating the memorized mate as general mastery.

Changed method for new play: reconstruct occupied squares and the opponent's immediate threat first. Compare a small number of candidates on the current board, verify their movement geometry and immediate captures, and only extend lines when there is a concrete forcing reason. When a line becomes too long to track confidently, return to the referee's current board. No fixed inference-token cap is imposed; the trial concerns attention and position accuracy.

Next evaluation: benchmark 7, followed by the 12-game aggregate checkpoint. Observable outcomes: illegal submissions, immediate material losses from geometry or pawn attacks, and actual benchmark results. A successful remembered calculation alone will not count as transfer.

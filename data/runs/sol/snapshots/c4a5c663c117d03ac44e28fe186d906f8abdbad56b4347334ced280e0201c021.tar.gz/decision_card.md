# Own decision card after126

126 scored35W/6D/85L. Full0/0/42,skill0 30/3/9,nominal1800 5/3/34. Provisional1500[1380,1630],conditional nominal anchors/model,latest50of84rated,42full excluded,not human Elo. Formal132,endpoint200,active goal,no token budget.

FIRST inspect actual board and last move. Black pawns attack down,White up. Kings only adjacent. Check cheap pawn attacks on destinations before long branches. A guarded knight under a pawn can lose2. Practice99 imported c5 into c4 and lost knight+pawn.

Trace guard lines to FIRST body including own bodies.125 QueenD2 blocked Rd1-d3;Rf3 blocked Bh5's imagined guard of Rd1.122 Kf7 blocked Rc7-g7 and allowed mate.126 d7 blocked Rh7 check;king need not move,both passers reached7.

Before pawn gains identify necessary king defender,actual flights,second attacker/recapture.125 Rxg5 abandoned sole first-rank defender,allowing mate. Practice100 Rh1 delayed exact mate but doubled rooks mated after fair first rook pair.124 queen root did not save bishop from second capture.

Material retention is not king/conversion proof.126 h-pawn obtained enemy rook but parked kingh1 while white king supported two passers;rook alone failed. Check pawn interposition,promotion-square king guards,both passers BEFORE king excursion. Prefer central king activity when two enemy passers remain. Do not claim alternatives win without evidence.

Develop and castle with actual replies,preserve trapped-piece exits. Whole-piece gifts explain many skill0 wins. Full0/42 stagnation;overlapping intervals,no causal improvement. Long branches/late commentary unresolved.

Trial203:MAXBlack own126ply101,51Kf5 insteadKh3,sixownmoves/earliertermination,local material/king/pawn retention only;then fixed127White/full. Formal132,stop200. Every chess choice own,no outside lookup in games,no delegated/automated analysis/other-experiment access.

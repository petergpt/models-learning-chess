# Own review of benchmark 109

White/full strength, loss by practical resignation after 26...Kxf8, 52 plies, zero illegal submissions. Result timestamp 2026-10-07T12:15:59.413503+00:00, ledger sequence 8740. Full PGN read. Cumulative 109: 29W/5D/75L; full strength 0W/0D/37L. No claim of a proved forced loss.

Castled on eight; all minors developed on ten. Both central pawn pairs and both knight pairs exchanged fairly. 12.Bd3 answered Rc8's attack on Bc4. 13.Be3 guarded d4, and 16.f3 blocked the queen/bishop battery against g2. These were local continuations, not evidence of stronger-opponent improvement.

17.Rad1 removed a2's last rook guard after the c3 knight had already been exchanged; actual Qxa2 cost a pawn. 19.Qd2 removed Bc4's queen guard and the opponent's Bxf3 opened the c-file. 20.Rxf3 Rxc4 exchanged the two light bishops fairly through separate captures; both rooks actually survived those captures. The loss of f3 made the pawn deficit two, not a whole minor at this point.

23.Bh6 removed Be3's cheap guard of d4. Rd1 still guarded d4, but actual Rxd4 was supported by Qd5 and could trade rooks while keeping the pawn. My bishop attacked Rf8, which WAS guarded by the adjacent king on g8. I repeatedly misclassified G8/F8 as two squares in private reasoning before correcting it; they are adjacent. 24.Bxf8 could not be priced as an isolated favorable bishop/rook exchange: actual Rxd1+ first captured my rook, and Qxd1 would put an unguarded queen on the opposing queen's open d-file. I moved Kf2; actual Bb6+ then required a block. Re3 answered check; actual Kxf8 finally took my bishop. The two rook losses balanced each other; my bishop was lost whole. Final deficit bishop plus three pawns, six nominal points. Own Qe2/Re3/Kf2 and b2/g2/h2 versus black Qd5/Rd1/Bb6/Kf8 and a7/b7/e6/f7/g6/h7. Re3 was pinned by Bb6 to Kf2. No further capture was played.

Trial 166 failed its later whole-piece-loss target. Good early development did not prevent a pawn guard removal, another pawn loss and a checking recapture sequence. Private geometric mistakes and delays/commentary gaps persisted despite zero illegal submissions.

## Trial 167 — remembered position, not new transfer evidence

Three-own-move White/max practice from game 109 ply 44 (after 22...g6). Own candidate 23.Qd2, keeping Be3's guard of d4 and adding Qd2's actual vertical guard through empty d3. Qd2 remains protected by Rd1; the rook on g3 still guards Be3 through f3. Unlike nineteen, Bc4 is already gone, so this queen move cannot remove its guard. Observe actual replies, material costs and checking moves. Narrow target: retain the center pawn or exchange at a fair actual cost, avoid the later checking whole-bishop loss. This does not prove a full-game save. Stop after three own moves unless a concrete checking capture warrants an announced extension; then fixed Black/full-strength 110. Official review 114; endpoint 200.

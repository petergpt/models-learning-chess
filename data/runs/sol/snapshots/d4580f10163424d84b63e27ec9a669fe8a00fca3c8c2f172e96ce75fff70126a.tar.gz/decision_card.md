# Own decision reminders after benchmark 65 and practice 53

Own observations only. Reliable execution, faster decisions and measured improvement are not established.

1. Read the actual returned board: check, attacks on higher pieces, direct enemy queen mating destinations. Game 64 Qe4-b7 cleared e4 and unmasked Bg2's support; Kb8 could not capture that queen. Own a7/c7 blocked flights and Be5 pinned c7.
2. Trace candidate destinations and occupied rays. Black pawns capture downward, White upward; a forward push cannot capture an occupied enemy square. Queens are not knights, bishops are not rooks, kings move one square. Include enemy pawn, knight and king control before a king recapture.
3. Check the actual last recapture. A cheaper defender does not erase a higher piece's loss to a cheaper attacker. Practice 52 Bd5/Rxd5/Rxd5/Qxd5 would still lose the bishop. Both queens traded in game 65 Qxf3+/Qxf3/Nh4+/Kg3/Nxf3; do not mislabel the last knight capture as a whole queen gift.
4. Inspect abandoned guards and physical blocks. Game 63 Kf2 abandoned Bh2 and blocked Rc2-h2. Game 65 Kf1 would have blocked Rh1-a1; chosen Kh2 kept that rook guard but blocked Rh1-h4 and lost the pawn. Kg1 retained h1's legal king guard through the later rook exchange. Game 65 fxg4 removed f3's e4 guard and allowed Nxe4. Practice 53 Kf2/Kg5/Ke3/Nd7 kept the chain only in a different short branch.
5. Check pins after the actual move. Game 64 exd4 exposed Ke8 to Qe2 and was illegal. Game 54 gxf6 was illegal while Qg6 remained; game 55 Rf3-f4 removed the pinner, releasing gxf4. A pawn can capture its pinner along the pin ray.
6. A checking reply can change the exchange. Game 61 Bxf2+ uncovered Rc8-c3 against the queen; practice 48 Bxe5 uncovered Qb6-f6. Game 59 Qh1+ skewered the queen through Kg3. Game 60 Nf6+/Nxf6/exf6 trapped Qg7. Game 65 Nb2+ forked king and bishop and pushed the king away from the passed pawn.
7. Before a pawn break, inspect the next actual blockers and promotion distance. Game 65 c5/bxc5 sacrificed a pawn: c7 still covered b6, d6 still blocked d5. King guards matter only on adjacent squares. Do not assume promotion occurs if the actual opponent spends a king tempo; record what happened. Once the last own pawn disappeared, Kc7 could not catch Pd4's three-push promotion race.

Choose at most two candidates and inspect one forcing reply, then act. Long speculative trees and commentary gaps still recur; this routine is not reliably implemented.

Trial 99, games 66-72: Black e6/d5 against e4 or d4, adapting to actual replies; target fewer early whole minor-piece losses to pawn attacks/forks. White retains d4/Nf3/Bf4 before e3. Review at 66, then 72, continuing to 200 scored games. No learning-token cap.

Official status after 65: 17 wins, 2 draws, 46 losses; full strength 0/0/22, skill 0 16/1/5, nominal 1800 1/1/19. Provisional engine-relative Elo 1460, 95% credible interval [1330,1590], conditional on nominal anchors/model assumptions, not human/platform Elo. Improvement is not established.

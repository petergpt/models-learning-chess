# Independent chess-learning journal

## Starting state — 2026-10-03

Read this experiment's AGENTS.md and GOAL.md. The referee reports zero started benchmark games, no active game, and no Elo estimate. No imported learning material, outside position advice, or engine analysis has been used. An active goal is registered without a token budget. Actual token counters are unavailable; no usage values will be invented.

The target is stronger play, with the bounded endpoint of 200 scored benchmark games. All moves will be my own decisions. Full-strength results remain part of the benchmark, although the current estimator excludes that uncalibrated opponent.

## Trial 1: position tracking and tactical safety

Hypothesis: maintaining a reliable board model and checking the opponent's forcing replies will reduce avoidable material losses. This is an unverified self-assessment, not a measured diagnosis yet.

Initial study: review ordinary opening priorities from my existing knowledge: contest the center, develop pieces, secure the king, and avoid unnecessary pawn moves. In tactical positions, consider checks, captures, and direct threats for both sides. Before committing a move, mentally update the occupied squares and check whether the move leaves a piece or mating square unprotected. Favor concrete calculation over relying on the checklist alone.

First evaluation point: six scored benchmarks, covering one paired-color rotation. After each game, record one concrete failure or successful behavior and choose a learning adjustment before the next game. Use recorded opponent practice when a specific weakness calls for a drill. Baseline results will be descriptive; six games cannot establish a reliable improvement trend.

Observable evidence: recurrence of pieces lost to an immediate forcing reply; ability to reach playable middlegames without such losses; benchmark results and the referee's Elo interval. An easier practice win alone will not establish transfer.

### Initial repertoire choice

White: begin with 1.e4, develop naturally, and adapt to the reply. Black: meet 1.e4 with ...e5 and 1.d4 with ...d5 unless a concrete position warrants another choice. These are my own familiar starting choices, not externally recommended moves.

## Benchmark 1 — loss, White versus full strength

Resigned after 22...Bxf4, 44 plies, with an extra enemy minor piece and no identified compensation. No illegal submissions. This full-strength game does not supply a calibrated Elo observation.

Concrete failure: after 19...g5, I played 20.Kg2 gxf4 21.Bxf4 Qxf4 22.Qxf4 Bxf4. I failed to count the queen and bishop attacking f4. The queen trade did not recover the bishop. Looking back, my bishop on e3 also had its retreat squares obstructed by my own queen and pawns; this was more than a recapture oversight. The king-safety plan overlooked that trapped-piece consequence.

Earlier concern: 15.Qd2 permitted ...Bxf3 with g-pawn recapture because my bishop on e3 blocked the queen's route to f3. These are my own assessments, without engine validation.

## Trial 2: complete exchanges and preserve an escape square

Learning period: mentally revisit the position after 19...g5. Count material through the entire exchange, not just the first recapture, and check available bishop retreats after pawn captures. The actual continuation loses a bishop; a proposed 20.f5 opens f4 as a retreat square and avoids ...gxf4. Its overall quality is unverified and its king-safety consequences require play.

Recorded practice: one short drill from benchmark 1, ply 38, against skill 5. This is a remembered position, not a new transfer test. Try my own alternative 20.f5, then finish or explicitly end the drill after observing the immediate consequences. Next measured evaluation: benchmark 2, with the six-game rotation still the first aggregate checkpoint.

Observable result: avoid the specific forced bishop loss in the drill; in new benchmark play, resolve pawn attacks on blocked pieces before making unrelated moves. Neither a corrected remembered position nor a practice result establishes stronger general play.

### Trial 2 outcome and decision

Practice 1 was explicitly ended as an unfinished drill after 20.f5 Qh2+ 21.Kf1 Qxh3+ 22.Ke2 Qf3+ 23.Kf1 a4. The bishop remained on e3, but I lost h3 and my king was displaced. Thus the narrow trap was avoided; the alternative was not shown to equalize or win. No practice score is claimed.

Decision for benchmark 2: apply complete exchange counting to new positions and inspect mobility when a pawn advance closes a bishop's diagonals. In opening pins, prefer development and a recapture that preserves king cover. The original first aggregate evaluation remains six scored games. Do not claim transfer until these behaviors survive new benchmark positions.

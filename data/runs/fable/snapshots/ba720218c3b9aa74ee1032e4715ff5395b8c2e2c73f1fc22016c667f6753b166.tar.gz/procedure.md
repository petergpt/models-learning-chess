# Per-move procedure (v2.1 — Trial 1 scan, patched after practice 1)

Always read the FEN first (unambiguous), then cross-check with the diagram. Ranks 8..1 top to bottom, files a..h left to right.

1. **Orient**: side to move, castling rights, en-passant square, material count (list both sides' pieces by square).
2. **Opponent's last move**: what does it attack now? **Also: which enemy rook/bishop/queen lines pass through the square it just vacated?** A quiet retreat can be a discovered attack (game 6: 18.Bd3 unmasked Rc1 against my Qc7 and I lost the queen). New checks, captures, forks, pins, discovered attacks, mate threats on my king, pawn forks. List every piece of mine that is attacked and whether it is adequately defended (count attackers vs defenders, compare values).
3. **Forcing moves first**: my checks, captures, threats. Does any win material or mate? Verify with concrete replies, not impressions.
4. **Candidates** (2-4). For each candidate, play it in my head and ask:
   - **DESTINATION SQUARE: name every enemy piece that attacks it** (knights by L-jump; bishops/queens along BOTH diagonals through the square; rooks/queens along the rank and file; pawns diagonally). If attacked, is it defended at least as many times and is the exchange favourable? (game 3: 34.Rd2?? dropped a rook to the f4-queen's diagonal.)
   - **LINE OPENING: which enemy long-range pieces had a line blocked by the piece I am moving?** After it leaves, what do they now attack? (game 3: 16.Nd6?? unblocked b7-f3 and lost a knight.)
   - Which of my pieces does it leave en prise (including the piece that moved, and the pieces it stopped defending or whose line it blocked)?
   - Opponent's checks after it? Captures after it? A fork/pin/skewer? Back-rank mate? Queen/knight forks on my king?
   - Does it allow a pawn fork or a discovered attack?
4a. **Queen-safety count**: if my queen is beyond the 4th rank or adjacent to enemy pieces, count its safe retreat squares after the candidate move; fewer than 2 means retreat it first (game 5: 14.cxd5? allowed ...Rh5 trapping the queen).
4b. **King-safety check — MANDATORY every move while any enemy queen or rook has an open file/diagonal into my king zone, especially before captures** (game 5: 31.Nxa8?? allowed Qxg2# — the e1 knight covered g2 and the g-file was open)**: **: list my king's flight squares; for EVERY enemy check available next move (each knight separately, queen along each line, discovered checks) mark which flight squares are then attacked — including lines opened by the checking piece leaving its square and diagonals of the enemy queen through squares it currently sees (game 2: Qh6 covered f8 via g7, so Nxf6 was mate). If any check leaves zero flight squares and no capture/block, the move under consideration is forbidden.
4c. **Priority rule under attack**: a line that costs a pawn but keeps the king safe beats a line that keeps material and leaves the king in a net (game 2: 19...Kf8? instead of 19...Qb6).
5. **Choose**; prefer the simple safe move when ahead.
6. **Legality**: the piece actually moves that way; **for rook/bishop/queen moves, name every intermediate square and confirm each is empty** (game 1: twice tried to slide a rook through my own knight/queen); king not left in check; castling (king+rook unmoved, no pieces between, not in check, not through check). Pawn promotion needs a suffix (q).
6b. **Self-block / retreat check**: when my move occupies a square, list my own pieces that lose a retreat or path because of it. For any piece that can be attacked next move by a pawn push or a knight hop, confirm it still has a safe square afterwards (game 1: 17.Nb1 blocked Ra1 -> rook trapped by ...Na2; 26.Bg3 with Nf2 blocking e1 -> bishop trapped by ...h4).
7. **WRITTEN SCAN (mandatory, every move, before submitting)** — four lines, literally written out:
   A. Destination <sq>: attacked by [list enemy pieces/pawns, naming each diagonal/file checked]. Defended by [...]. Exchange ok? y/n
   B. Lines opened: my vacated <sq> -> enemy sliders now seeing through: [...]. Opponent's last vacated square -> [...].
   C. Enemy checks next move: [each check -> my legal replies, counting squares the checker's departure uncovers]. For EACH reply confirm it is legal: is the blocking/capturing piece pinned to my king along any enemy line? (practice 1: ...Rf8 "block" was pinned on a2-g8 -> Rc8#). Back rank: can an enemy rook/queen reach my king's rank, and is my only blocker pinned? Any check with no legal reply or losing a piece? y/n
   C2. Defender tracing: when I count a defender, trace its line like an attacker's (my own pieces can block my own defenders — practice 1 move 13).
   D. Loose pieces after the move: [...].
   Reject the move if any line fails. Then submit UCI: from-square + to-square, re-reading both squares against the FEN.

Won positions: avoid repeating positions; move pawns/capture to reset the 50-move count; before every move with the opponent reduced to few pieces, count their legal moves (stalemate check).
Lost positions vs full strength: keep pieces protected, seek repetitions/fortress; resign only if hopeless.

# Trial log

## 2026-10-03 Setup
- Workspace created: procedure v1, repertoire, endgame notes, opponent model.
- **Baseline block**: games 1-6 (one rotation cycle) with procedure v1. No learning trial yet; this measures the starting point.
- Next evaluation point: after game 6. Then: review all 6 games, count my blunders by type, choose trial 1.

## 2026-10-04 Baseline block complete (games 1-6)
Results: full-strength 0-2 (losses, expected). skill-0: 1-1 (G3 loss: hung a knight to a line I opened myself, then hung a rook to a queen diagonal; G4 win). elo-1800: 0-2 (G5: queen trapped on f5, then allowed Qxg2# by skipping the king-safety check; G6: lost queen to a discovered attack, knight to a queen diagonal, then a Q+B mating net).
Illegal attempts: 2 (both game 1, rook sliding through my own piece). None after the path-tracing patch.
**Dominant failure (5 of 6 decisive errors): one-move geometric oversight** — an enemy long-range piece attacking the square I move to, a line opened by a piece moving off it (mine or the opponent's), or an enemy check whose consequences I didn't enumerate. My plans and calculations are otherwise adequate (e.g. G4 mating net, G5 d-pawn storm, G6 recovery). Opening choice is not the problem.

## Trial 1 — the written attack-scan (starts now)
Weakness targeted: one-move oversights of enemy attacks/lines/checks.
Change: before EVERY submitted move I write (in my reasoning) a fixed 4-line scan for the chosen move: 
  A. destination square — list every enemy piece that attacks it (check each queen/bishop diagonal and each rook/queen file-rank explicitly, knights by L-jump, pawns);
  B. lines opened — squares vacated by my piece: which enemy sliders now see through; squares vacated by the opponent's last move: same;
  C. enemy checks next move — every check, and my king's legal replies to each (including squares that become covered when the checking piece's old square is vacated);
  D. loose pieces — any of my pieces attacked and undefended after the move.
If any line of the scan fails, the move is rejected. No exceptions for "obvious" captures (G5 31.Nxa8??) or forced-looking recaptures.
Practice component: 1 practice game vs skill-0 and 1 vs elo-1800 applying the scan, before the next block; record scan failures caught and any blunders.
Evaluation point: after games 7-12 (block 2). Success criteria: zero pieces lost to a one-move capture in rated games; score >= 1.5/2 vs skill-0 and >= 1/2 vs elo-1800; Elo estimate rising over block 2. If the oversight class recurs >= 2 times in block 2, revise (e.g. shorter candidate lists, scan the top-2 candidates fully).
- Practice 1 (elo-1800, Black): lost by mate at +3 material — pinned-blocker back-rank mate (32.Rc8#). Scan caught ~5 traps but missed pin-legality of a planned block; scan patched (v2.1). Proceeding to practice 2 (skill-0, White).

# Per-move procedure (v1, baseline)

Always read the FEN first (unambiguous), then cross-check with the diagram. Ranks 8..1 top to bottom, files a..h left to right.

1. **Orient**: side to move, castling rights, en-passant square, material count (list both sides' pieces by square).
2. **Opponent's last move**: what does it attack now? New checks, captures, forks, pins, discovered attacks, mate threats on my king, pawn forks. List every piece of mine that is attacked and whether it is adequately defended (count attackers vs defenders, compare values).
3. **Forcing moves first**: my checks, captures, threats. Does any win material or mate? Verify with concrete replies, not impressions.
4. **Candidates** (2-4). For each candidate, play it in my head and ask:
   - Which of my pieces does it leave en prise (including the piece that moved, and the pieces it stopped defending or whose line it blocked)?
   - Opponent's checks after it? Captures after it? A fork/pin/skewer? Back-rank mate? Queen/knight forks on my king?
   - Does it allow a pawn fork or a discovered attack?
5. **Choose**; prefer the simple safe move when ahead.
6. **Legality**: the piece actually moves that way; path clear; king not left in check; castling (king+rook unmoved, no pieces between, not in check, not through check). Pawn promotion needs a suffix (q).
7. Submit UCI: from-square + to-square. Re-read the from and to squares against the FEN before sending.

Won positions: avoid repeating positions; move pawns/capture to reset the 50-move count; before every move with the opponent reduced to few pieces, count their legal moves (stalemate check).
Lost positions vs full strength: keep pieces protected, seek repetitions/fortress; resign only if hopeless.

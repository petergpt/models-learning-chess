# Trial log

## 2026-10-03 Setup
- Workspace created: procedure v1, repertoire, endgame notes, opponent model.
- **Baseline block**: games 1-6 (one rotation cycle) with procedure v1. No learning trial yet; this measures the starting point.
- Next evaluation point: after game 6. Then: review all 6 games, count my blunders by type, choose trial 1.

## 2026-10-04 Baseline block complete (games 1-6)
Results: full-strength 0-2 (losses, expected). skill-0: 1-1 (G3 loss: hung a knight to a line I opened myself, then hung a rook to a queen diagonal; G4 win). elo-1800: 0-2 (G5: queen trapped on f5, then allowed Qxg2# by skipping the king-safety check; G6: lost queen to a discovered attack, knight to a queen diagonal, then a Q+B mating net).
Illegal attempts: 2 (both game 1, rook sliding through my own piece). None after the path-tracing patch.
**Dominant failure (5 of 6 decisive errors): one-move geometric oversight** — an enemy long-range piece attacking the square I move to, a line opened by a piece moving off it (mine or the opponent's), or an enemy check whose consequences I didn't enumerate. My plans and calculations are otherwise adequate (e.g. G4 mating net, G5 d-pawn storm, G6 recovery). Opening choice is not the problem.

## Trial 1 — the written attack-scan (starts now)
Weakness targeted: one-move oversights of enemy attacks/lines/checks.
Change: before EVERY submitted move I write (in my reasoning) a fixed 4-line scan for the chosen move: 
  A. destination square — list every enemy piece that attacks it (check each queen/bishop diagonal and each rook/queen file-rank explicitly, knights by L-jump, pawns);
  B. lines opened — squares vacated by my piece: which enemy sliders now see through; squares vacated by the opponent's last move: same;
  C. enemy checks next move — every check, and my king's legal replies to each (including squares that become covered when the checking piece's old square is vacated);
  D. loose pieces — any of my pieces attacked and undefended after the move.
If any line of the scan fails, the move is rejected. No exceptions for "obvious" captures (G5 31.Nxa8??) or forced-looking recaptures.
Practice component: 1 practice game vs skill-0 and 1 vs elo-1800 applying the scan, before the next block; record scan failures caught and any blunders.
Evaluation point: after games 7-12 (block 2). Success criteria: zero pieces lost to a one-move capture in rated games; score >= 1.5/2 vs skill-0 and >= 1/2 vs elo-1800; Elo estimate rising over block 2. If the oversight class recurs >= 2 times in block 2, revise (e.g. shorter candidate lists, scan the top-2 candidates fully).
- Practice 1 (elo-1800, Black): lost by mate at +3 material — pinned-blocker back-rank mate (32.Rc8#). Scan caught ~5 traps but missed pin-legality of a planned block; scan patched (v2.1). Proceeding to practice 2 (skill-0, White).
- Practice 2 (skill-0, White): lost by mate (33.Rxc3?? Qe1#) from a level position after being a pawn up. Scan caught ~9 one-move blunders when written, but I skipped it for a "free" pawn capture that removed my only back-rank guard. 2 illegal attempts (geometry slips). Review: games/practice-002.md.
- **Decision after practice 1-2**: the scan is effective when written and skipped exactly on "obviously good" captures/recaptures. Procedure v2.2: (1) scan is written for every move, captures included — a capture is the #1 skip trigger; (2) line C adds the back-rank-guard question (am I moving the sole guard of a rank-1 check square while an enemy heavy piece has an open line to it?); (3) geometry re-check before typing UCI (piece type's move pattern, every intermediate square empty). Practice results do not change the Trial 1 evaluation plan: block 2 = games 7-12 is the measured test.

## Block 2 (games 7-12) — Trial 1 evaluation block
- G7 (W, full-strength): LOSS by resignation at move 8 — 8.Qc2?? Bxc2 lost the queen to the f5-bishop's diagonal, which I had noted in the move-6 scan. Scan skipped because I moved immediately after an interface nudge. Procedure v2.3: nudges never trigger a move; UCI typed only after written A-D. Review: games/007.md.
- G8 (B, full-strength): LOSS by resignation at move 20. 10...Qxb2?! again unscanned after a nudge (3rd lapse; rule zero-b added: after a nudge the first tool call is `./play board`). 12...Qxd3?? relied on a recapture (Bxd6) blocked by my own knight -> Nd6+ forced Kd8 and my king never got a flight square; mating net on f7. 1 illegal attempt (same path error). Scan did catch 12...cxb5?? (Qxa3), 15...Nf5 (pinned), 20...Bh6/Bg7 (Bxe7#). Procedure v2.4: reply legality + king-air rule. Review: games/008.md.
- Block 2 vs full-strength: 0/2 as expected, but both games were lost to my own scan lapses, not to engine strength. Measured games 9-12 (skill-0, elo-1800) are the Trial 1 test.
- G9 (W, skill-0): WIN by checkmate (56 moves), 0 illegal, scan written every move. No one-move oversights; two evaluation slips (15.Qf3?!, 23.Bxc4+?! — capturing the checker). First rated game where the scan was never skipped, and the first clean game of the run. Review: games/009.md.
- G10 (B, skill-0): WIN by checkmate (80 moves), 0 illegal. Won 2 pawns early, then gave the exchange back by reversing the value arithmetic (46.Nxe7). Defended a rook-vs-bishop ending for 25 moves, then 71...Be5+ (check + attack on the rook) won the rook. Procedure D-line now requires written value arithmetic. Review: games/010.md.
- Block 2 so far: full-strength 0/2 (both my own scan lapses), skill-0 2/2. Two games left in the block: G11 (W vs 1800), G12 (B vs 1800).
- G11 (W, elo-1800): LOSS by checkmate from a completely winning position (Q+R+N vs R+B after 29.b8=Q??). Back-rank mate: Rc1+ with my king on g1 behind f2/g2/h2 and no guard; I had written "Rc1+ -> Kh1 fine", but h1 is on the rook's line. 1 illegal attempt (12.Qxa6 through my own c4 pawn). Procedure v2.5: flight squares along the checking line do not exist; luft rule. Review: games/011.md.
- G12 (B, elo-1800): WIN by checkmate (62 moves), 1 illegal attempt (35...Rec8 through my own Rd8). Won a pawn on move 13, two more by move 44, then survived ten consecutive rook checks (45-54) by picking a fresh king square each time and using an attack on an undefended rook (50...Kb7) to gain the tempo for ...e2; 55...e1=Q. 57...Kf3?! allowed Rf4+ with a discovered attack on my queen (forced king move off the f-file) — not result-changing (R+3P vs 2P, mate at move 62). First win against the 1800 setting. Procedure v2.6: forced-reply discovery check (C3). Review: games/012.md.

## Trial 1 evaluation (block 2 complete, games 7-12)
Results: full-strength 0/2 (G7, G8, both lost to unscanned moves after interface nudges), skill-0 2/2 (G9, G10), elo-1800 1/2 (G11 loss, G12 win). Elo estimate 1240 (640-1700) after game 6 -> 1560 (1250-1870) after game 12, 8 rated games.
Criteria: (1) zero pieces lost to a one-move tactic in rated games — NOT met (G11 back-rank mate, decisive; G10 exchange by sign error; G12 queen-for-rook by forced-reply discovery, not decisive). (2) >= 1.5/2 vs skill-0 — met (2/2). (3) >= 1/2 vs elo-1800 — met (1/2). (4) Elo rising — met.
Oversight class recurred >= 2 times (G7, G8, G11; G12 non-decisive) -> the decision rule says revise.
What changed inside the block: G7/G8 lapses were UNWRITTEN scans (nudge-triggered quick moves). After rule zero-a/zero-b (game 8) every move of G9-G12 (about 230 of my moves) had a written scan and no unscanned move occurred. The remaining failures are WRITTEN scans with one line answered superficially: G11 "Rc1+ -> Kh1 fine" (h1 on the rook's line), G12 "Rf4+ harmless" (forced reply uncovers the queen), G10 reversed exchange sign.
Decision: keep the Trial 1 scan (it is the reason G9, G10, G12 were clean) and start Trial 2 targeting the superficial-line failure mode.

## Trial 2 — reply-consequence discipline (starts now, block 3 = games 13-18)
Weakness targeted: scan lines (especially C, enemy checks) answered with an impression instead of a computed reply; forced replies not examined as moves.
Change: (a) C3 rule — for every enemy check, write my reply and run line B on that reply (what my moving king/blocker uncovers); (b) for any check with 2+ legal replies, write at least two replies and their consequences before calling the check "harmless"; (c) each check in line C gets an explicit tag: "loses material for them / harmless / dangerous", and a "dangerous" tag rejects the move; (d) exchange arithmetic in D remains in values with explicit sign.
Observable success criteria at the evaluation point (after game 18): zero material lost to a one-move tactic, including after a forced reply, in games 15-18 (skill-0 and elo-1800); score >= 1.5/2 vs skill-0 and >= 1/2 vs elo-1800 in block 3; Elo estimate after game 18 at or above 1560. If a written-but-superficial scan line again decides a rated game, Trial 3 will restrict candidate moves to those whose full scan has been written (max two candidates per move, both fully scanned).
Practice component: one practice game as White vs elo-1800 before game 13 (my White results vs 1800 are 0/2: G5, G11), applying C3 and the two-reply rule; record checks tagged and any miss.
- Practice 3 (W vs elo-1800, Trial 2 rehearsal): WIN by checkmate in 37 moves, 0 illegal attempts. Won a rook on move 19 after Black's loose play; all checks tagged, no dangerous check arose so C3 was not stressed; one omission (did not register that 21.Qxa7 was check, harmless). Review: games/practice-003.md. Decision: proceed to block 3 (game 13, W vs full-strength) with procedure v2.6.

## Block 3 (games 13-18) — Trial 2 evaluation block
- G13 (W, full-strength): LOSS by resignation at move 19 (0 illegal). Queenless, balanced London position; 15...Ne7 removed my e5-knight's last retreat and 16...f6 trapped it (my 14.f3 had blocked f3). Not the one-move class — a two-move piece trap. Procedure v2.7: mobility line E (count safe squares of advanced pieces after the candidate move and after the natural reply; never pawn-block my own knight's retreat). Review: games/013.md.

# Trial log

## 2026-10-03 Setup
- Workspace created: procedure v1, repertoire, endgame notes, opponent model.
- **Baseline block**: games 1-6 (one rotation cycle) with procedure v1. No learning trial yet; this measures the starting point.
- Next evaluation point: after game 6. Then: review all 6 games, count my blunders by type, choose trial 1.

## 2026-10-04 Baseline block complete (games 1-6)
Results: full-strength 0-2 (losses, expected). skill-0: 1-1 (G3 loss: hung a knight to a line I opened myself, then hung a rook to a queen diagonal; G4 win). elo-1800: 0-2 (G5: queen trapped on f5, then allowed Qxg2# by skipping the king-safety check; G6: lost queen to a discovered attack, knight to a queen diagonal, then a Q+B mating net).
Illegal attempts: 2 (both game 1, rook sliding through my own piece). None after the path-tracing patch.
**Dominant failure (5 of 6 decisive errors): one-move geometric oversight** — an enemy long-range piece attacking the square I move to, a line opened by a piece moving off it (mine or the opponent's), or an enemy check whose consequences I didn't enumerate. My plans and calculations are otherwise adequate (e.g. G4 mating net, G5 d-pawn storm, G6 recovery). Opening choice is not the problem.

## Trial 1 — the written attack-scan (starts now)
Weakness targeted: one-move oversights of enemy attacks/lines/checks.
Change: before EVERY submitted move I write (in my reasoning) a fixed 4-line scan for the chosen move: 
  A. destination square — list every enemy piece that attacks it (check each queen/bishop diagonal and each rook/queen file-rank explicitly, knights by L-jump, pawns);
  B. lines opened — squares vacated by my piece: which enemy sliders now see through; squares vacated by the opponent's last move: same;
  C. enemy checks next move — every check, and my king's legal replies to each (including squares that become covered when the checking piece's old square is vacated);
  D. loose pieces — any of my pieces attacked and undefended after the move.
If any line of the scan fails, the move is rejected. No exceptions for "obvious" captures (G5 31.Nxa8??) or forced-looking recaptures.
Practice component: 1 practice game vs skill-0 and 1 vs elo-1800 applying the scan, before the next block; record scan failures caught and any blunders.
Evaluation point: after games 7-12 (block 2). Success criteria: zero pieces lost to a one-move capture in rated games; score >= 1.5/2 vs skill-0 and >= 1/2 vs elo-1800; Elo estimate rising over block 2. If the oversight class recurs >= 2 times in block 2, revise (e.g. shorter candidate lists, scan the top-2 candidates fully).
- Practice 1 (elo-1800, Black): lost by mate at +3 material — pinned-blocker back-rank mate (32.Rc8#). Scan caught ~5 traps but missed pin-legality of a planned block; scan patched (v2.1). Proceeding to practice 2 (skill-0, White).
- Practice 2 (skill-0, White): lost by mate (33.Rxc3?? Qe1#) from a level position after being a pawn up. Scan caught ~9 one-move blunders when written, but I skipped it for a "free" pawn capture that removed my only back-rank guard. 2 illegal attempts (geometry slips). Review: games/practice-002.md.
- **Decision after practice 1-2**: the scan is effective when written and skipped exactly on "obviously good" captures/recaptures. Procedure v2.2: (1) scan is written for every move, captures included — a capture is the #1 skip trigger; (2) line C adds the back-rank-guard question (am I moving the sole guard of a rank-1 check square while an enemy heavy piece has an open line to it?); (3) geometry re-check before typing UCI (piece type's move pattern, every intermediate square empty). Practice results do not change the Trial 1 evaluation plan: block 2 = games 7-12 is the measured test.

## Block 2 (games 7-12) — Trial 1 evaluation block
- G7 (W, full-strength): LOSS by resignation at move 8 — 8.Qc2?? Bxc2 lost the queen to the f5-bishop's diagonal, which I had noted in the move-6 scan. Scan skipped because I moved immediately after an interface nudge. Procedure v2.3: nudges never trigger a move; UCI typed only after written A-D. Review: games/007.md.
- G8 (B, full-strength): LOSS by resignation at move 20. 10...Qxb2?! again unscanned after a nudge (3rd lapse; rule zero-b added: after a nudge the first tool call is `./play board`). 12...Qxd3?? relied on a recapture (Bxd6) blocked by my own knight -> Nd6+ forced Kd8 and my king never got a flight square; mating net on f7. 1 illegal attempt (same path error). Scan did catch 12...cxb5?? (Qxa3), 15...Nf5 (pinned), 20...Bh6/Bg7 (Bxe7#). Procedure v2.4: reply legality + king-air rule. Review: games/008.md.
- Block 2 vs full-strength: 0/2 as expected, but both games were lost to my own scan lapses, not to engine strength. Measured games 9-12 (skill-0, elo-1800) are the Trial 1 test.
- G9 (W, skill-0): WIN by checkmate (56 moves), 0 illegal, scan written every move. No one-move oversights; two evaluation slips (15.Qf3?!, 23.Bxc4+?! — capturing the checker). First rated game where the scan was never skipped, and the first clean game of the run. Review: games/009.md.
- G10 (B, skill-0): WIN by checkmate (80 moves), 0 illegal. Won 2 pawns early, then gave the exchange back by reversing the value arithmetic (46.Nxe7). Defended a rook-vs-bishop ending for 25 moves, then 71...Be5+ (check + attack on the rook) won the rook. Procedure D-line now requires written value arithmetic. Review: games/010.md.
- Block 2 so far: full-strength 0/2 (both my own scan lapses), skill-0 2/2. Two games left in the block: G11 (W vs 1800), G12 (B vs 1800).
- G11 (W, elo-1800): LOSS by checkmate from a completely winning position (Q+R+N vs R+B after 29.b8=Q??). Back-rank mate: Rc1+ with my king on g1 behind f2/g2/h2 and no guard; I had written "Rc1+ -> Kh1 fine", but h1 is on the rook's line. 1 illegal attempt (12.Qxa6 through my own c4 pawn). Procedure v2.5: flight squares along the checking line do not exist; luft rule. Review: games/011.md.

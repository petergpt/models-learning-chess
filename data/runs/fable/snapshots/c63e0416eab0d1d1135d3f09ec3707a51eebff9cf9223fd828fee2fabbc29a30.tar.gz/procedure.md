# Per-move procedure (v1.2 — patched after games 1-2)

Always read the FEN first (unambiguous), then cross-check with the diagram. Ranks 8..1 top to bottom, files a..h left to right.

1. **Orient**: side to move, castling rights, en-passant square, material count (list both sides' pieces by square).
2. **Opponent's last move**: what does it attack now? New checks, captures, forks, pins, discovered attacks, mate threats on my king, pawn forks. List every piece of mine that is attacked and whether it is adequately defended (count attackers vs defenders, compare values).
3. **Forcing moves first**: my checks, captures, threats. Does any win material or mate? Verify with concrete replies, not impressions.
4. **Candidates** (2-4). For each candidate, play it in my head and ask:
   - Which of my pieces does it leave en prise (including the piece that moved, and the pieces it stopped defending or whose line it blocked)?
   - Opponent's checks after it? Captures after it? A fork/pin/skewer? Back-rank mate? Queen/knight forks on my king?
   - Does it allow a pawn fork or a discovered attack?
4b. **King-safety check (whenever enemy queen + any piece are near my king)**: list my king's flight squares; for EVERY enemy check available next move (each knight separately, queen along each line, discovered checks) mark which flight squares are then attacked — including lines opened by the checking piece leaving its square and diagonals of the enemy queen through squares it currently sees (game 2: Qh6 covered f8 via g7, so Nxf6 was mate). If any check leaves zero flight squares and no capture/block, the move under consideration is forbidden.
4c. **Priority rule under attack**: a line that costs a pawn but keeps the king safe beats a line that keeps material and leaves the king in a net (game 2: 19...Kf8? instead of 19...Qb6).
5. **Choose**; prefer the simple safe move when ahead.
6. **Legality**: the piece actually moves that way; **for rook/bishop/queen moves, name every intermediate square and confirm each is empty** (game 1: twice tried to slide a rook through my own knight/queen); king not left in check; castling (king+rook unmoved, no pieces between, not in check, not through check). Pawn promotion needs a suffix (q).
6b. **Self-block / retreat check**: when my move occupies a square, list my own pieces that lose a retreat or path because of it. For any piece that can be attacked next move by a pawn push or a knight hop, confirm it still has a safe square afterwards (game 1: 17.Nb1 blocked Ra1 -> rook trapped by ...Na2; 26.Bg3 with Nf2 blocking e1 -> bishop trapped by ...h4).
7. Submit UCI: from-square + to-square. Re-read the from and to squares against the FEN before sending.

Won positions: avoid repeating positions; move pawns/capture to reset the 50-move count; before every move with the opponent reduced to few pieces, count their legal moves (stalemate check).
Lost positions vs full strength: keep pieces protected, seek repetitions/fortress; resign only if hopeless.

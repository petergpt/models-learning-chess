# Trial log

## 2026-10-03 Setup
- Workspace created: procedure v1, repertoire, endgame notes, opponent model.
- **Baseline block**: games 1-6 (one rotation cycle) with procedure v1. No learning trial yet; this measures the starting point.
- Next evaluation point: after game 6. Then: review all 6 games, count my blunders by type, choose trial 1.

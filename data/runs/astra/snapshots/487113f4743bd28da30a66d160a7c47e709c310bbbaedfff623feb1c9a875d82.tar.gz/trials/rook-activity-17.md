# Trial 17 — rook activity in sparse positions

Declared after game 126 at 2026-10-02 19:48:02 UTC. Baseline 1580 [1460,1700], 49W/3D/74L; 84 rated total/latest 50, 42 MAX exclusions. Fixed next evaluation: benchmarks 127–132 in the unchanged paired-color rotation.

Trial 16 failed. Equal queen removal did not prevent rook confinement, forks, or unusable king recaptures. Earlier reconstruction and defender exercises (including trials 02, 03 and 14) also failed transfer. This revisits that old weakness using longer opponent continuations from sparse equal-material positions; it is not a novel checklist or an independent blind tactical test.

Learning task: activate a rook without losing its retreat routes or relying on a defender that becomes unusable after an exchange. Use the lower piece count to practise following the actual reply through its final capture. Rook activity remains useful; mere passivity and preserved material in a short drill do not prove a sound ending.

Exactly two recorded nominal-1800 practice sessions, in this order:
1. White, self-composed FEN: r5k1/pp3ppp/2b5/3n4/3N4/2B5/PP3PPP/R5K1 w - - 0 1
2. Black, distinct self-composed FEN: 2r3k1/pp4pp/2n1p3/5b2/5B2/2N1P3/PP4PP/2R3K1 b - - 0 1

Both have R+B+N+5 pawns per side. They are deliberately composed training positions with known starting geometry, not certified equal evaluations or unseen test items. Subsequent opponent moves are fresh. No engine advice or historical continuations are supplied.

Each ends naturally or explicitly unfinished after 20 own moves and the final opponent reply. Combined setup/play/review ceiling: 2026-10-02 20:33:02 UTC (45 minutes). At the ceiling finish any pending reply and end an active session. No repeats, replacement positions, or extensions after favorable or unfavorable results. Preserve all practice records separately from Elo.

Record actual exchanges, rook confinement or unsupported rook moves, any omitted check or capture, illegal attempts, final material and whether a game actually finished. A retained rook alone is not success if another piece or the game is lost. Short practice outcomes are not full-game results.

For full-game transfer, remove trial 16's special queen-exchange preference. Keep normal development and choose exchanges on their concrete merits. Before committing a rook to an advanced square, account for its usable retreat route after the opponent's immediate attack; at a capture sequence, use the actual resulting board and legally available final recapture. These are modest execution cues prompted by the practice, not a guarantee or a larger mandatory audit.

Return to fixed benchmarks 127–132 after the two sessions regardless of outcome. At 132 assess full W/D/L, Elo and uncertainty, all material errors, and specifically recurrence of rook confinement or invalid final recaptures. A recurrence rejects reliable execution; even a clean block or higher estimate requires repeated evaluations before sustained improvement is claimed. Revise again on failure.

Only own reasoning, pre-existing notes and the referee during games. No engine analysis, external move advice, automated chess search/scoring/attack analysis or move menus, and no delegation. No decision-time target, model change, estimator change or invented usage count.


## Practice 29 — White sparse position, unfinished at 20 moves

Ended 2026-10-02 19:53:55 UTC after 20 own moves / 40 plies, zero illegal submissions, explicitly unfinished and excluded from Elo. Result seq 898, sha256 ec324e92f0ceb6b50141034832a92a06dc1319093cc54de4d87073ae5e2fbd33. PGN read back.

1.Nxc6 bxc6 2.Rd1 a5 3.Bd4 Rc8 4.Kf1 Ra8 5.Ke2 a4 6.Rc1 a3 7.b3 Nb4 8.Ra1 h5 9.Bc5 Re8+ 10.Kd2 Re4 11.Bxb4 Rxb4 12.Kc3 Rb5 13.Rd1 Kf8 14.Rd7 g5 15.Ra7 Rf5 16.f3 Rc5+ 17.Kd3 Rc1 18.Rxa3 Rg1 19.g3 Rh1 20.h4 gxh4.

The initial knight-for-bishop exchange and later Bxb4/Rxb4 were counted correctly; both sides reached R+5P. Rc1 attacked c6, but ...Nb4 newly defended c6 and attacked a2, so Ra1 withdrew without trying the now-unsound pawn capture. Bc5 left the possible ...Nc2 fork of bishop and rook. After the equal minor exchange, Kc3 protected b3, allowing Rd1/Rd7/Ra7. The rook's d4 retreat was available while the king remained c3; no later position was assumed to retain that king defense automatically.

f3 answered ...Rf5 before Rxa3 captured the blocked pawn. ...Rg1/...Rh1 then attacked the kingside. g3 had h2 support until h4; the actual ...gxh4 removed White's h-pawn at the cap. The possible gxh4/Rxh4 continuation was anticipated but was not played and is not recorded as a completed exchange. Final actual material is R+4P each: White Kd3/Ra3/a2,b3,f3,g3; Black Kf8/Rh1/c6,f7,h5,h4. The g3 pawn remains attacked by h4 and the continuation is unresolved.

No rook or unanticipated minor loss occurred in this short session. The extra pawn was not retained, and rook activity did not establish a favorable ending. This is limited practice evidence only, with no full-game score, independent evaluation or Elo effect. No extension was made. Continue only the predeclared Black session, same 20-own-move cap and combined 20:33:02 deadline.

# Move check

Working protocol, based on my own recorded errors. No claim of tested improvement.

1. Reconstruct the current position, especially the king, queen, loose pieces, and recently vacated squares. Use the referee board if uncertain. State pawn attack directions correctly.
2. Identify the opponent's immediate checks and captures. A quiet move may have opened a defender behind another piece.
3. Choose a candidate for a concrete purpose. Calculate short forcing exchanges through the last recapture. Do not call a target safe merely because a queen defends it.
4. Reconstruct the position after the candidate. Check paths, pins, and the opponent's immediate checks and captures again. Include what a checking move attacks or uncovers besides the king.
5. For king moves, inspect alignment with my queen and rooks. A king escape can expose a skewer. A legal escape square is not by itself a safe move.
6. Prefer a verified material gain or sound development to an unverified sacrifice. With a large advantage, preserve coordination and check stalemate before quiet finishing moves.
7. For an exposed king, count actual escape squares after forcing checks, including squares occupied by my own pieces. When a move uncovers another line, check for double check: capturing one checking piece may leave the other check intact.
8. Before accepting a king escape, inspect queen checks on the new king's rank, file, and diagonals. A queen can switch from a diagonal to a file in one move. Reject immediate mate before comparing material threats.

Keep the final audit focused on the actual candidate and current board. Additional remote variations do not substitute for it.

# Trial 15 — complete development before exposing pieces

Declared 2026-10-02 10:53:39 UTC after benchmark 114 and the completed trial-14 assessment. Baseline provisional engine-relative Elo 1640 [1520, 1760], 46W/2D/66L; 76 rated total/latest 50 used, 38 maximum exclusions. Next fixed evaluation: benchmarks 115–120 in the unchanged paired-color rotation. No sustained improvement is established.

Intervention: change the opening positions I seek, rather than add another tactical checklist or repeat late defensive rescues. In 114, repeated bishop moves and the incomplete g4 exchange lost a knight before move 14. In 110, the early exposed rook and king prevented straightforward development. Earlier fresh full-game practice (08/09) did not test this particular opening choice; it also failed to establish improvement. The present choice may concede activity and is not a claim of theoretically best opening play.

White: start with 1.d4. Aim for Nf3, e3, Be2 and castling, followed by c4/Nc3 when the actual center permits it. Develop the remaining bishop through a real available route instead of rushing it onto an exposed advanced square. These are priorities, not a move script; checks, pawn attacks and concrete captures can require a different order.

Black: against 1.e4 try ...e6 and ...d5. If White advances e5, consider the central ...c5 break before putting a knight on f6 where the pawn would immediately attack it. If Nc3/Nd2 defends e4, ...dxe4 followed by development is a simplifying candidate, not an automatic move. Against d4/Nf3/c4 starts, seek ...d5/...e6, ...Nf6, ...Be7 and castling before an unsupported bishop sortie. Apply the actual position and finish exchanges; no opening preference overrides a direct threat.

Short own study before practice: identify the costs of these choices. e3/e6 restricts the queen bishop, so its development still needs a route; castling alone does not complete development. Moving a center pawn may remove a knight's defender or open a queen/rook line. A quiet bishop square is not automatically safe. Avoid unnecessary early queen moves and repeated piece moves, but retreat an attacked piece when needed. Do not mechanically copy a remembered sequence after the opponent diverges. These observations are own unverified preparation, not external opening advice or an independent evaluation.

Exactly two recorded opening sessions at nominal 1800:
1. White from the standard initial position.
2. Black from the standard position after White's 1.e4: FEN `rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1`.

Neither session is a replay of a measured continuation. They are selected opening rehearsals, not blind accuracy tests. Cap each at twelve own moves plus the final opponent reply, or finish naturally sooner. Combined setup, play and review ceiling: 11:23:39 UTC on 2026-10-02. At the ceiling end any active drill explicitly unfinished and record any unstarted session; no extensions, replacements or repeats to obtain favorable results.

At each cap record actual material, development, king location, and any unanticipated piece loss, direct mating sequence, or newly unusable recapture. An unfinished opening is neither a win nor a draw. A clean opening against this opponent does not establish stronger play. During the fixed block 115–120, retain the same opening priorities and specifically record unanticipated piece losses within the first fifteen moves, alongside every later tactical failure and full W/D/L/Elo result. Fewer early losses would be limited evidence about the opening intervention only; later losses still determine overall performance. Compare the whole block at 120 and revise if it fails.

Only own reasoning, pre-existing notes and the referee during play. No engines except the referee opponent, no opening explorers, external position advice, tablebases, automated chess analysis/search/attack enumeration, or delegation. No decision-clock target or invented token counter. All practice results stay outside benchmark Elo.

# Trial 13 — play the capturing side before returning to defense

Declared 2026-10-02 05:33 UTC after benchmark 102. Baseline: 1660 [1540, 1780], 42W/2D/58L, 68 rated total/latest 50 used. Trial 12 failed despite 88/88 minor-piece pawn-origin notes. Next fixed benchmark endpoint: games 103–108. No change to opponent rotation, estimator, model, or fair-play rules.

Target: speculative threats displaced a direct capture of the moving piece. The latest examples are ...Nh5/Qxh5 in 98 and ...Ne4/Rxe4 in 102. Trial 03 and trial 06 already attempted destination and immediate-reply audits. This is not a new chess principle and a longer checklist is not learning evidence.

Change the practice task: take the opponent's side in four short recorded sessions against maximum strength. The first two deliberately rehearse remembered captures; the latter two are older own-game positions selected before inspection, with all later historical moves withheld. None is an independently blind test. Play beyond the first capture against actual replies, retaining concrete blockers and recaptures rather than merely recognizing the first move.

Predeclared sessions, in this order:

1. White from game 102, ply 102, before Rxe4. Remembered. The capture is supplied by my own preceding game, not a fresh solution.
2. White from game 98, ply 40, before Qxh5. Remembered.
3. Black from game 87, ply 41. Older position; do not inspect later moves before the session.
4. White from game 90, ply 40. Older position; do not inspect later moves before the session.

Each ends naturally or explicitly unfinished after six own moves and the last opponent reply. Combined ceiling: 06:03 UTC on 2026-10-02, including reviews. If a preselected ply is unavailable, record the failed setup and omit that drill rather than substitute a favorable position. No extra repeats. If the ceiling arrives, end the active drill explicitly and record omissions. Practice results stay outside benchmark Elo.

Execution change for practice and benchmarks: after selecting a move, reconstruct its destination on the actual board and inspect direct captures of the moved piece by every enemy piece type before following its intended threat. In particular, read rook/queen lines as well as pawn origins; Ne4 in 102 must fail this pass because Rg4 reaches e4 through the empty f4 square. If a capture is available, count the actual immediate recapture rather than assume a defender exists. A brief factual move note may record a relevant capture, blocker or accounted exchange; a note saying no capture was identified is not a certificate of completeness. Recheck the final replacement candidate. Retire the mandatory minor-only pawn note. Ordinary king safety, checks and vacated defenders still matter; this targeted step does not certify them.

For each drill record the actual line, material changes, direct captures missed/offered, illegal attempts, and whether an intended recapture was real. Remembered first captures count only as rehearsal. In games 103–108, record all unaccounted immediate captures, including captures of minor pieces by queens or rooks; opponent declines remain offered losses, distinct from actual ones. Compare the full block, nominal-1800 results, and unchanged Elo interval. Any recurrence rejects reliable transfer; a clean block or rating rise would still require repeated evaluations before a sustained-improvement claim. End or revise at 108 rather than study or benchmark indefinitely without assessment.

Only own chess decisions and referee during play. No external advice, automated chess search/scoring/attack enumeration/move selection, engine analysis, tablebases, or delegation. No valid new cumulative usage counter is available.


## Practice 19 — remembered capturing side, failed execution after the capture

Stopped explicitly unfinished at 2026-10-02 05:35:12 UTC after six own moves / 12 plies, zero illegal submissions. Result seq 641, hash `b44e813df7b81c4a1793bcd92a34e065e3ce11e38e1240a5e3968ac1c298595b`. Referee PGN read back. Actual line: 52.Rxe4 Bxa5 53.Bxa5 Rd5 54.Bg4 h5 55.Bf3 c6 56.Re8+ Kxe8 57.Bxd5 cxd5.

The remembered rook capture took the undefended knight; Bxa5 then took the trapped bishop. Bg4 and Bf3 responded to actual rook/pawn attacks. However, 56.Re8+ was submitted even though its move note recognized that the supposed bishop support was wrong and said the candidate required revision. Ba5 controls d8, not e8. Black legally played Kxe8. This is an explicit failure to apply a recognized correction before committing, not just failure to discover it. The direct-capture intervention failed within the first drill.

Bxd5 recovered Black's rook, and cxd5 took that bishop. Initial material was R+2B+4P versus R+B+N+5P; final material B+3P versus 5P. The two remembered piece captures had produced a much larger advantage that the rook submission dissipated. No endgame win or draw is claimed. Keep the remaining three predeclared drills and the fixed benchmark endpoint; do not add repetitions or redefine this as a success. The immediate operational correction is to finalize the actual UCI move after rejecting a candidate, before constructing the command; the submitted note is not a safe place to leave an unresolved replacement.

# Practice trial 01: pawn races before liquidation

Plan recorded on 2026-09-30 after completed game 30, before any measured game 31. This is practice, not benchmark evidence.

Target: stop entering or assessing pawn endings on a pawn-push count that omits king interception, capture of a newly promoted piece, or a promotion check. Game 30 provides a recent failure; earlier reviews also contain mistaken pawn-ending judgments.

Method and duration: one session of eight manual exercises, expected 20–30 minutes and limited to 45 minutes. First state a conclusion and concrete line from the board; then check only the legality of that supplied line and manually reconsider the opposing king's route. No engine, tablebase, automated search, scoring, best-move generation, or delegated advice. Mechanical board rendering and legality checks are allowed. Two positions are remembered game-30 positions; the other six are self-composed variations, not independently selected unseen tests. Self-assessments remain unverified.

Transfer change: before a voluntary exchange that produces a pawn ending, reconstruct the resulting kings and pawns, count moves through promotion, and check whether either king can intercept or capture the promoted piece. A claim of a favorable or safe race must have a concrete line accounting for checks and king intervention. This is a narrow execution change, not a longer general move checklist.

Evaluation: resume the fixed measured rotation for games 31–36, then review the recorded Elo/95% interval and recurrence of this error. Baseline after game 30: 1780 [1590, 1990], 20 rated games; maximum-strength games excluded by the unchanged estimator. The six-game block includes both colors at each of the three settings. Record every relevant pawn-ending decision, including errors; if no relevant ending occurs, transfer is untested. No repeated false race claim and correct anticipation of actual king intervention would be process evidence, not proof of an Elo increase. Sustained rating improvement needs later evaluation as well. At game 36 decide whether to repeat, revise, or replace this method.

## Exercise prompts, fixed before solving

1. Remembered: game 30 after 69...Kxc2. White Ke3/Pf4; Black Kc2/Ph5; White to move. Reconstruct the played race and locate the mistaken assumption. Do not infer a forced result from one played line.
2. Remembered: game 30 after 73.f6. White Kg2/Pf6; Black Ke4/Ph4; Black to move. Test the checking push ...h3+ and the king chase ...Kf5.
3. Self-composed change to exercise 2: White Kg2/Pf5; Black Ke4/Ph4; Black to move. Does the same promotion argument still apply?
4. Self-composed: White Ka1/Pa6; Black Kh8/Ph3; White to move. Follow the direct pawn race and determine whether the first promotion changes the reply available to Black.
5. Self-composed change to exercise 4: Black king on g7 instead of h8. Follow the same direct pushes. Identify any promotion check without asserting the full queen-ending result.
6. Self-composed: White Ka1/Pc5; Black Kf6; White to move. Can Black catch the directly advancing pawn? Follow the line through a promotion capture if applicable.
7. Self-composed change to exercise 6: Black king on g6. Can Black still intercept the direct pawn advance?
8. Self-composed: White Ka1/Pa2; Black Kg4; White to move. Compare a3 with the initial double push a4, including the king's route and the final capture square.

## Work and observations

Pending at plan creation.

# Trial 17 — rook activity in sparse positions

Declared after game 126 at 2026-10-02 19:48:02 UTC. Baseline 1580 [1460,1700], 49W/3D/74L; 84 rated total/latest 50, 42 MAX exclusions. Fixed next evaluation: benchmarks 127–132 in the unchanged paired-color rotation.

Trial 16 failed. Equal queen removal did not prevent rook confinement, forks, or unusable king recaptures. Earlier reconstruction and defender exercises (including trials 02, 03 and 14) also failed transfer. This revisits that old weakness using longer opponent continuations from sparse equal-material positions; it is not a novel checklist or an independent blind tactical test.

Learning task: activate a rook without losing its retreat routes or relying on a defender that becomes unusable after an exchange. Use the lower piece count to practise following the actual reply through its final capture. Rook activity remains useful; mere passivity and preserved material in a short drill do not prove a sound ending.

Exactly two recorded nominal-1800 practice sessions, in this order:
1. White, self-composed FEN: r5k1/pp3ppp/2b5/3n4/3N4/2B5/PP3PPP/R5K1 w - - 0 1
2. Black, distinct self-composed FEN: 2r3k1/pp4pp/2n1p3/5b2/5B2/2N1P3/PP4PP/2R3K1 b - - 0 1

Both have R+B+N+5 pawns per side. They are deliberately composed training positions with known starting geometry, not certified equal evaluations or unseen test items. Subsequent opponent moves are fresh. No engine advice or historical continuations are supplied.

Each ends naturally or explicitly unfinished after 20 own moves and the final opponent reply. Combined setup/play/review ceiling: 2026-10-02 20:33:02 UTC (45 minutes). At the ceiling finish any pending reply and end an active session. No repeats, replacement positions, or extensions after favorable or unfavorable results. Preserve all practice records separately from Elo.

Record actual exchanges, rook confinement or unsupported rook moves, any omitted check or capture, illegal attempts, final material and whether a game actually finished. A retained rook alone is not success if another piece or the game is lost. Short practice outcomes are not full-game results.

For full-game transfer, remove trial 16's special queen-exchange preference. Keep normal development and choose exchanges on their concrete merits. Before committing a rook to an advanced square, account for its usable retreat route after the opponent's immediate attack; at a capture sequence, use the actual resulting board and legally available final recapture. These are modest execution cues prompted by the practice, not a guarantee or a larger mandatory audit.

Return to fixed benchmarks 127–132 after the two sessions regardless of outcome. At 132 assess full W/D/L, Elo and uncertainty, all material errors, and specifically recurrence of rook confinement or invalid final recaptures. A recurrence rejects reliable execution; even a clean block or higher estimate requires repeated evaluations before sustained improvement is claimed. Revise again on failure.

Only own reasoning, pre-existing notes and the referee during games. No engine analysis, external move advice, automated chess search/scoring/attack analysis or move menus, and no delegation. No decision-time target, model change, estimator change or invented usage count.


## Practice 29 — White sparse position, unfinished at 20 moves

Ended 2026-10-02 19:53:55 UTC after 20 own moves / 40 plies, zero illegal submissions, explicitly unfinished and excluded from Elo. Result seq 898, sha256 ec324e92f0ceb6b50141034832a92a06dc1319093cc54de4d87073ae5e2fbd33. PGN read back.

1.Nxc6 bxc6 2.Rd1 a5 3.Bd4 Rc8 4.Kf1 Ra8 5.Ke2 a4 6.Rc1 a3 7.b3 Nb4 8.Ra1 h5 9.Bc5 Re8+ 10.Kd2 Re4 11.Bxb4 Rxb4 12.Kc3 Rb5 13.Rd1 Kf8 14.Rd7 g5 15.Ra7 Rf5 16.f3 Rc5+ 17.Kd3 Rc1 18.Rxa3 Rg1 19.g3 Rh1 20.h4 gxh4.

The initial knight-for-bishop exchange and later Bxb4/Rxb4 were counted correctly; both sides reached R+5P. Rc1 attacked c6, but ...Nb4 newly defended c6 and attacked a2, so Ra1 withdrew without trying the now-unsound pawn capture. Bc5 left the possible ...Nc2 fork of bishop and rook. After the equal minor exchange, Kc3 protected b3, allowing Rd1/Rd7/Ra7. The rook's d4 retreat was available while the king remained c3; no later position was assumed to retain that king defense automatically.

f3 answered ...Rf5 before Rxa3 captured the blocked pawn. ...Rg1/...Rh1 then attacked the kingside. g3 had h2 support until h4; the actual ...gxh4 removed White's h-pawn at the cap. The possible gxh4/Rxh4 continuation was anticipated but was not played and is not recorded as a completed exchange. Final actual material is R+4P each: White Kd3/Ra3/a2,b3,f3,g3; Black Kf8/Rh1/c6,f7,h5,h4. The g3 pawn remains attacked by h4 and the continuation is unresolved.

No rook or unanticipated minor loss occurred in this short session. The extra pawn was not retained, and rook activity did not establish a favorable ending. This is limited practice evidence only, with no full-game score, independent evaluation or Elo effect. No extension was made. Continue only the predeclared Black session, same 20-own-move cap and combined 20:33:02 deadline.


## Practice 30 — Black sparse position, rook exchange followed by pawn loss

Ended 2026-10-02 20:01:18 UTC after 20 own moves / 40 plies, zero illegal submissions, explicitly unfinished and excluded from Elo. Result seq 941, sha256 9f34b76bb18cbfc734b64c3a9be128102bde2ed9743a76a3f43b0c4cfbe67f73. PGN read back.

1...Rd8 2.h3 e5 3.Bg3 Rd3 4.Rd1 Rxe3 5.Be1 Kf7 6.Nb5 a6 7.Kf2 Rd3 8.Nd6+ Ke6 9.Rxd3 Bxd3 10.Nxb7 e4 11.Bc3 g6 12.Nc5+ Kd5 13.Nxd3 exd3 14.Kf3 Kc4 15.Bd2 Nd4+ 16.Ke4 Ne2 17.Ke3 Ng3 18.b3+ Kd5 19.Kxd3 Ne4 20.Bb4 h5 21.Be7.

The rook developed on d8 and entered d3 with Bf5 support. Rxe3 captured a pawn. When Kf2 attacked Re3, ...Rd3 used the planned bishop-supported retreat rather than capturing the attacked Nb5 while leaving the rook to Kxe3. Nd6+ was answered by ...Ke6, making f5 an actual king-recapture square. White instead played Rxd3, and ...Bxd3 completed the anticipated equal rook exchange. Nc6's d8 coverage was retained in the earlier rook-check considerations; no rook loss occurred.

10.Nxb7 recovered the extra pawn, returning material equality. ...e4 supported Bd3, which continued to defend a6. Nc5+/...Kd5/Nxd3/...exd3 completed an equal minor exchange. The resulting d3 passer depended on king support; ...Kc4 provided it. ...Nd4+ and ...Ne2 used real king and pawn support respectively.

The later plan failed to retain that pawn. After ...Ng3, 18.b3+ drove the king from c4 while Bd2 controlled c3 and b4 and Pa2 protected b3. ...Kd5 left d3 undefended, and 19.Kxd3 actually captured it. Recognizing that consequence after the check did not prevent the preceding defensive failure. No best earlier alternative or inevitable-pawn-loss claim has been established. ...Ne4 and ...h5 retained the remaining material through the cap.

Final Black Kd5/Ne4/a6,g6,h5 versus White Kd3/Be7/a2,b3,g2,h3: knight and three pawns against bishop and four pawns. This is an unfinished inferior-material ending, not a completed draw or successful defense. No unanticipated own rook/minor loss was identified, but the pawn failure remains adverse evidence.

## Trial-17 practice endpoint

Both predeclared sessions finished by 20:01:18 UTC, before the 20:33:02 ceiling, with no repeats or extensions: 40 own moves / 80 plies, zero illegal attempts, two explicitly unfinished drills. The White session ended at equal material with an unresolved pawn transaction; the Black session ended a pawn down after the king was driven off a defensive duty. Rook activation, retreat and equal exchange were handled locally, but this does not establish stronger full-game play or reliable overall defense.

Return now to the fixed benchmarks 127–132 exactly as declared, using the modest rook-mobility cue and ordinary concrete exchange choices. No additional practice, special queen-exchange preference, timing target, opponent change or rating change. Baseline remains 1580 [1460,1700], 49W/3D/74L through 126. Preserve all later errors and assess the full block at 132; no valid new cumulative token counter is available.


## Benchmark 127 — White versus MAX, bishop skewer and incomplete transaction

Finished 2026-10-02 20:10:14 UTC by practical resignation after 21...Bxa5, 21 own moves / 42 plies, zero illegal attempts. Result seq 10494, sha256 1ae4eb78aee93f2bed781e429a38d0d9f6493722ac5ab5a14b849275984c09e4; snapshot 41f4a9258efe81e9b6a1c740ccf15ff3977b474e690d552072237079c103e36d. PGN read back.

1.d4 Nf6 2.Nf3 d5 3.e3 c5 4.Be2 cxd4 5.exd4 Nc6 6.O-O Bf5 7.c4 dxc4 8.Bxc4 e6 9.Nc3 Be7 10.Bf4 O-O 11.Re1 Qb6 12.Qd2 Rfd8 13.Rad1 Bg4 14.Be3 Bxf3 15.gxf3 Qa5 16.d5 exd5 17.Nxd5 Bb4 18.Nxf6+ gxf6 19.Qd5 Rxd5 20.Rxd5 Bxe1 21.Rxa5 Bxa5.

Castled on 6, all minors by 10, both rooks by 13; first 15 materially clean. The opening repeated the familiar game-121 position through ...Qb6. Qd2 retained d4 defense while defending b2; Rad1 supplied a later d-file recapture, and Be3 added a real defender before ...Bxf3/gxf3 removed Nf3. These local corrections avoided the earlier ...Nxd4 pawn loss but left damaged king pawns.

The central break d5/exd5/Nxd5 was calculated incompletely. 17...Bb4 attacked Qd2 with Re1 behind it on b4-c3-d2-e1. 18.Nxf6+ gxf6 exchanged knights but also removed the d-file blocker. I then chose 19.Qd5 while overvaluing a nominal rook/queen recapture sequence. The actual ...Rxd5/Rxd5/...Bxe1 inserted the bishop capture of the other rook. 21.Rxa5 recovered the queen, but Black recaptured with 21...Bxa5 from e1 through d2/c3/b4, not the ...Nxa5 anticipated in the move note.

The complete actual transaction removed White's queen and both rooks for Black's queen and one rook: a full rook loss. The final position was White Kg1/Bc4/Be3/a2,b2,f2,f3,h2 versus Black Kg8/Ra8/Ba5/Nc6/a7,b7,f7,f6,h7. Legal play remained; this was practical resignation, not checkmate or a proof that every earlier defense lost. No best alternative is certified.

This is a recurrence of missing a forcing reply elsewhere while calculating a nominally supported capture. Sparse-practice rook handling has not supplied reliable full-position defense. The first benchmark already rejects a claim of reliable execution; preserve the rest of the declared block.

After 127: 49W/3D/75L overall; MAX 0W/2D/41L in 43 games, skill 0 37W/1D/4L in 42, nominal 1800 12W/0D/30L in 42. Elo unchanged at 1580 [1460,1700], 84 rated total/latest 50, 43 MAX exclusions; storage 33,673,572 bytes. Trial 17 is 0W/0D/1L. Continue unchanged through 132, next 128 Black MAX, with no extra practice or changed endpoint.

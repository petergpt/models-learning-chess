# Trial 16 — safe queen exchanges as a position choice

Declared after benchmark 120 at 2026-10-02 15:36:16 UTC. Baseline: 1590 [1470,1710], 48W/2D/70L; 80 rated games total, latest 50 used, 40 uncalibrated MAX exclusions. Fixed next evaluation: benchmarks 121–126 in the unchanged paired-color rotation. No estimator, opponent, model, or fair-play changes.

## Weakness and change

Trial 15 failed: 2W/0D/4L and a lower Elo endpoint. Early development did not prevent queen exposure, missed immediate recaptures, or later rook losses. The long speculative branches in 119 omitted the actual ...Rxb2 reply. Trial 09 already tested shorter timed decisions, failed its implementation criterion in most games, and did not prevent a queen loss even within the time target. Do not restart that discontinued clock method or relabel inventory/checklist work as new training.

This trial changes the positions selected. At materially comparable positions, prefer a concretely safe, materially equal queen exchange over an unverified queen attack or pawn raid. Consider a supported exchange offer when it improves development or activity. This is conditional, not a requirement to remove queens at any cost: respond to checks and captures, preserve sound forced gains, and avoid an exchange whose last recapture loses material. Keep the trial-15 opening preferences as a fallback so the new variable is the simplification preference. Do not manufacture a queen sortie merely to offer a trade.

The hypothesis is that earlier queen removal will reduce the recurring queen-exposure failures and allow more decisions in positions with fewer long-range attackers. This cannot excuse later rook or minor-piece blunders. Game 120 is one encouraging example of surviving an inferior queenless position and converting opponent mistakes, not proof of the hypothesis.

## Bounded learning and practice

First review the following own-game facts, then play exactly two fresh standard-start opponent-practice sessions at nominal 1800: White, then Black. Each has a maximum of 20 learner moves, including the reply after move 20, or ends naturally sooner. Combined deadline, including setup and reviews: 2026-10-02 16:21:16 UTC (45 minutes). At the deadline finish any already pending referee reply and end an active drill as unfinished. No favorable-result extensions or repeats. Practice records remain separate from Elo and benchmark W/D/L.

Own-game contrasts:
- In 120, ...Qc7/Qxc7/Bxc7 completed an equal queen exchange because Bd6 actually reached c7. Later ...Rc8 supplied a real defender to Bc7. The opponent declined the later bishop trade offered by ...Bc8; retain the actual continuation.
- In 119, Qxc4/Bxc4 removed queens but left White down the exchange and left Re2 attacked. The trade did not repair the earlier Qd3/Ba6 skewer or guarantee a safe ending.
- In 116, Qd5 did not leave the d-file. In 118, Qe3+ remained capturable by f2xe3. A queen's active-looking destination or checking move does not establish a safe transaction.
- In 120, Kxf7 did not win a net bishop because Rxc8 followed. Also, 79.Kg7 was an opponent error that let ...Kxf5 win the pawn; do not claim every earlier rook-versus-pawn line was proved winning.

During practice, record actual queen offers, whether they were accepted or declined, the final recapture and material result, and all unexpected piece losses. If no reasonable exchange opportunity occurs, record the lack of exposure instead of forcing one or extending practice. A stopped opening/middlegame drill has no full-game score.

## Evaluation and continuation

Return to benchmarks 121–126 after these two sessions, regardless of practice results. At 126 compare Elo with its uncertainty, full W/D/L, actual queen losses, other direct piece losses, and whether/how early queen exchanges occurred (including games that kept queens). Exchange frequency is implementation evidence, not strength. A clean practice, one win, or a single higher point estimate is insufficient; seek sustained measured improvement across repeated evaluations. If the policy merely produces inferior endings or the same blunders, revise again.

Only own reasoning, pre-existing notes and the referee during play; no external position advice, engine analysis, automated search/scoring/attack enumeration, legal-move menu, or delegation. No decision-clock target or invented token counter.

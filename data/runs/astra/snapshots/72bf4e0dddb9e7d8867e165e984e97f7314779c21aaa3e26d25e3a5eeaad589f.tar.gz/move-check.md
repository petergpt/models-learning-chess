# Current decision format — trial 09

Unproven trial: shorter, timed decisions; two fresh nominal-1800 practice sessions, then fixed benchmark 79–84. Baseline 1680 [1560, 1800]. Full plan: trials/short-decisions-09.md. Trial 08 failed and is preserved.

Use the decision-clock.py wrapper only to forward your own ./play commands and record elapsed time. Target 20 seconds from the prior referee response to move submission; elapsed includes tool and communication delays. It never chooses a move, changes the official clock, or forces a forfeit. Every overtime and illegal attempt stays recorded.

Work on one candidate and one immediate reply/answer at a time. Prefer an ordinary supported move if the line remains unresolved. Before a major-piece move, apply the actual path blockers and the two opposing pawn capture origins. A check can be answered by capturing its giver. Use the actual king and remaining defenders after a capture. These are prior requirements; the new experiment is genuinely shortening the decision work, which must be measured rather than asserted.

All chess choices are own reasoning. No engine advice, automated analysis, move menu, external game lookup or delegation. Preserve every game. Assess errors separately from whether the clock target was met.

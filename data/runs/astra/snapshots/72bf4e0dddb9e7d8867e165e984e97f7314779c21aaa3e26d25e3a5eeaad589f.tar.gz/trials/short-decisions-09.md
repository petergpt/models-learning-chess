# Trial 09: shorter decisions with an observed clock

Declared 2026-10-01 at 19:44:59 UTC after game 78 and the trial-08 endpoint. Baseline: provisional engine-relative Elo 1680 [1560, 1800], 52 rated games total / most recent 50 used; overall 32W/2D/44L. Next fixed evaluation: benchmark games 79–84. Preserve the same referee, opponent rotation, estimator, model and reasoning setting.

Target: lengthy speculative branching repeatedly displaces simple current-board facts. Game 78 calculated king replies to a checking queen but omitted b4xc5; it later tried a rook route through its own pawn. Earlier destination, changed-line, defender, breadth-first, remembered-opponent and longer-game trials already failed. This trial tests actual decision duration and shallow scope. Rephrasing the existing safety instruction is not the new intervention.

Practice: two fresh standard-start opponent sessions at nominal 1800, White then Black. Cap each at 40 learner moves, including the final opponent reply, or finish naturally sooner. Combined ceiling: 20:29:59 UTC on 2026-10-01 (45 minutes from declaration, including setup and reviews). At the ceiling finish any pending reply and record an unfinished end; do not extend to seek a favorable outcome. Every session and result remains in the separate practice ledger and never enters Elo.

Use a 20-second decision target, observed from completion of the previous referee command to submission of the next chosen move. This includes tool, polling, commentary and other elapsed delays; it is not pure thinking time or a token budget. The timing helper only forwards caller-supplied commands to ./play and appends clock metadata. It contains no chess module, board parsing, move generation, scoring, search, fallback choice, or automatic move. It does not change the official untimed game or impose a forfeit. Record every overtime and rejected move; do not hide a miss by restarting the clock or omitting a result. A rejected move retains the earlier turn clock.

Decision format: use one working candidate and one short concrete reply/answer at a time, then submit within the target. Prefer an ordinary supported move if the continuation is unresolved. Do not turn a doubtful candidate into many remote branches. Immediate captures and the actual king/pawn defenders still matter; on a major-piece move, identify the two opposing pawn origins and the actual path blockers before looking beyond the first reply. These chess requirements are familiar and unproved in transfer. The experimentally changed feature is shorter, timed work, not checklist length. All moves remain my own decisions. No game advice, automatic analysis, engine output, move menus, or delegation.

Assessment: at least 90% of submitted legal moves within 20 seconds would show implementation of this decision format, not stronger chess. Report exact logged counts and any missing timing. Separately record actual direct queen/rook losses, illegal blocked moves, overlooked immediate mates, and concessions after short branches. Even clean practice at this strength is not an independent accuracy test or Elo evidence. If the format is not implemented, report that rather than attributing results to it.

Carry the same timing target into the declared fixed block 79–84, then compare all six results, the unchanged rating interval, and error recurrence with trial 08 (three of six games with targeted major-piece failures). A cleaner block and higher estimate would be provisional only and require repeated evaluation. Do not call this sustained improvement from one win, a lower elapsed time, a remembered example, or a temporary rating rise. Revise the method again if errors persist. Return to evaluation after the bounded practice even if the practice result is unfavorable.

## Practice and benchmark record

Pending.


### Practice 8 — White, nominal 1800, completed win

Finished at 19:58:45 UTC on 2026-10-01 by 31.Rh8#, 61 plies / 31 learner moves, zero illegal attempts. Practice result seq 327, SHA-256 `2ed8b8c997001de968ad86a9489dc50ce3b352bbc75478f9d20533f1c88a2e32`. Referee PGN read back. This is separate opponent practice and does not alter benchmark Elo or W/D/L.

The forcing 11.Bxf7+ Kxf7 12.Qxb4 won the queen for a bishop and pawn; later ...Ra8 and ...Rh5 allowed Qxa8 and Rxf8. I handled the actual a5 and d5 pawn attacks on the queen, blocked ...Bg4's attack on Rd1 with f3, and recaptured the checking bishop on c2 with the king. The last Qxf6+/Rh8# sequence used the queen's defense of the mating rook. No direct unreciprocated major-piece loss, illegal move or immediate mate omission was identified in the actual play. Opponent concessions supplied the advantage, and unplayed candidate lines were not independently evaluated.

The clock criterion failed: all 31 submissions were timed, but only 18 were within 20 seconds (58.1%); 13 exceeded it. Median 18.464 seconds, mean 21.431, maximum 59.837. The longest decision was Bxf7+, so that successful tactic cannot be credited to the specified short format. The log spans 19:47:00.362264 to 19:58:45.540629 UTC. Times include polling/tool/communication delays and are not pure inference time. Long branching returned during several attacking choices. A win does not establish that the duration intervention was implemented or caused improvement.

Continue the declared fresh Black session, same nominal strength and 20-second target, at most 40 own moves, unchanged combined 20:29:59 UTC ceiling. Use a longer initial tool wait to avoid an unnecessary extra polling round trip; preserve the original timing definition and every existing logged value. Do not exclude the first session's delays or failures. Fixed benchmark 79–84 remains due after the learning period.

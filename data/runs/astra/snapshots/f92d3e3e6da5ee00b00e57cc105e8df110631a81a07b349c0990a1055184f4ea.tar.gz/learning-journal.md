# Learning journal

## Method and constraints

I choose every move by my own reasoning. No engines, tablebases, move-selection code, outside move advice, or live-game lookups. The referee is the only source of opponent moves and legality checks. Reviews below are my own assessments, not engine evaluations. Measured games and results remain in the automatic records.

Before submitting a move: reconstruct the relevant occupied squares; check the move's path and king safety; consider the opponent's forcing checks and captures, including sacrifices; follow each forcing line through recaptures and check which pieces become undefended.

## Game 1 — White, full-strength, 0–1

Resigned after 32...Kd6 (64 plies). One illegal submission: 17.Rxd5 was impossible because my knight on d2 blocked the rook on d1. The accepted recapture was 17.exd5. This was a board-tracking mistake, not an infrastructure fault.

The decisive observed sequence was 23.Rac1 Bxa3+ 24.Kxa3 Rxc3+ 25.Kb2 Rxe3. I had underestimated the bishop sacrifice, the exposed king, the doubled c-file rooks, and the undefended bishop on e3. Black recovered the sacrificed bishop and won both queenside pawns. I exchanged the knights and one pair of rooks to seek activity, but 29...Re2+ also won g2. At resignation Black had six pawns to my three and threatened the d5 pawn.

Lessons to test:

- Updating a piece's square must also update blocked rook and bishop paths. My intended rook recapture no longer existed after Nd2.
- A pawn defended by the king may still fall to a sacrifice if the recapture exposes a forcing check. Count the whole sequence, including loose pieces elsewhere.
- Before defending one target, examine whether moving a loose piece removes the opponent's combination. In this game, moving the bishop off e3 deserved consideration before 23.Rac1; this is an unverified alternative, not a proven improvement.
- The king route to c2/b2 and the knight retreat cost coordination. Reconsider that plan in similar queenless positions rather than assuming queen exchanges make king safety irrelevant.

No external chess sources or post-game engine analysis used. This one loss establishes a baseline; it does not establish improvement or an Elo estimate.

## Game 2 — Black, full-strength, 0–1

Checkmated by 34.Rh6# (67 plies), confirmed from the referee's compressed PGN. No illegal submissions. Full-strength baseline is now two losses, one with each color.

Opening: Caro-Kann Advance with 4.h4 h5 and exchanged light-squared bishops. After 13...Bb6 14.Neg5 g6, White played 15.Nxe6! and obtained four pawns and a sustained king attack for the knight. I anticipated the sacrifice but underestimated the continuing attack, particularly Qxe6+ and Bh6. Exchanging queens required giving up a rook for a bishop. There is no demonstrated opening improvement here. A more defensive bishop placement on move 13 deserves examination in a future game; it has not been verified.

Final observed pattern: after 31...Kh5 32.Kh3, my king had no safe adjacent square. The knight on g6 temporarily blocked the rook's sixth-rank line. After 33.Nf7, the white knight also protected h6. I played 33...Nxe5 while focusing on the possible g4+ threat, and missed the immediate 34.Rh6# that removing the blocker allowed. This is a direct one-move mate oversight.

Revised decision check for the next games:

1. Before considering plans, enumerate the opponent's immediate checks from the resulting position.
2. For an exposed king, name its available escape squares and their attackers. A blocking piece can be essential even if it appears free to capture a pawn.
3. Recheck the opponent's forcing replies after choosing a move; do not stop after finding an answer to only one threat.
4. Assess sacrifices through the next attacking piece's arrival, not only through the initial material count.

No external sources or engine review used. Reviews are hypotheses plus observed tactical facts, not verified evaluations. Recorded cumulative goal-token observations: 56,051 after game 1 and 126,444 after game 2; these are the active goal's reported counter, not per-game usage or whole-account totals.

## Game 3 — White, skill-0, 1–0

Won by 26.Rxd8# (51 plies), with no illegal submissions. The opponent setting came from the fixed rotation.

After a Scandinavian-style opening, 12.c4 displaced the rook and 13.b4 displaced the queen. The observed fork was 14.c5, attacking the queen on b6 and rook on d6. Black replied 14...Rd7, leaving the queen to 15.cxb6. I subsequently captured an undefended bishop and converted the large advantage.

The final mating pattern was 24.Rc8+ Bd8 25.Qc7 a6 26.Rxd8#. The queen on c7 supported d8 and controlled the seventh-rank escape squares. Capturing with the rook preserved that control; capturing with the queen would have changed it.

This was a successful conversion after major opponent errors, not evidence of improvement against the maximum setting. Keep the same forcing-move and blocker checks in the next game rather than reducing attention because of an opponent label.

## Game 4 — Black, skill-0, 0–1

Won by 64...Qh1# (128 plies), confirmed from the recorded PGN. Two illegal submissions. The skill-0 pair is now two wins; the maximum-strength pair remains two losses. These four games do not establish improvement against the target.

Observed mistakes:

- After 12...Ra4 13.Ng5 Bxa3 14.Nc5 Bxc5 15.Rxa4, I could not safely recapture the rook with the queen: moving the white knight off b3 had opened Qc2–b3–a4. I had failed to update that defender. White obtained a rook for a knight and pawn.
- After 18...hxg5 19.Qxc5, I submitted the illegal 19...dxc5. I had repeatedly treated the black pawn on d4 as defending c5. Black pawns capture toward lower ranks: d4 attacks c3 and e3. The accepted move was 19...g4. The imagined defense of c5 had already distorted my preceding calculations.
- After 32.Qd5, I submitted the illegal ...Qd6. The queen on e6 was pinned to the king on g8 along d5–e6–f7–g8. The accepted 32...Kf7 defended the queen while remaining behind its block. Later ...Rh8 and ...Ke7 supported h3 and released the pin.

The advance ...e3 and the en passant capture 22...gxh3 produced restrictive pawns. I kept two extra pawns for the exchange through a long maneuvering phase. That is a material description, not a verified evaluation. White gave repeated checks on moves 51–54; I allowed the repeating king route rather than claiming a forced win. White broke the repetition with 55.Qh6.

The decisive errors were 55...Qh5 56.Kg2 Qxh6 and 57.Rxb6+ Kxb6: White left its queen and then its last rook capturable. After 58...gxf5, its remaining pawns on c4, d3, and e2 were blocked by my c5, d4, and e3 pawns. I brought the king from b6 through c6, d6, e5, and f4 to g3, preserving White's king moves until 64...Qh1#.

Method revision for the next pair:

1. Before calculating captures, state the relevant pawn's actual attack squares. White pawns increase ranks; Black pawns decrease ranks.
2. Check whether the proposed move removes a blocker on a line to either king. Being out of check does not mean a piece is free to move.
3. Update opened lines after the opponent's move as well as after my own move. Recheck defenders at the position where the capture occurs; do not carry an earlier defender list forward unchanged.
4. Check the opponent's immediate checks and captures after selecting a candidate. Give short, reconstructed forcing lines priority over long speculative continuations; extensive thinking in this game did not prevent basic geometry errors.
5. When the opponent has no mobile pieces except its king, verify at least one legal reply to every quiet move. Use the king to help finish the mate rather than accidentally closing the last escape square.

These revisions are untested working rules. No external sources, engines, or delegated move advice were used. The observed cumulative active-goal token counter after this game was 559,524; it is not per-game usage or a whole-account total.

## Game 5 — White, elo-1800-setting, 1–0

Won by 35.Qh6# (69 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are three wins and two losses; the maximum-strength results remain two losses.

Black lost time with ...Nf6–g8 and repeated queen moves. I developed, defended the exposed e5 pawn with Bf4, used Qe2 to defend Bc4 after ...Qc7, and castled. These are observed defensive purposes, not an engine assessment of the opening.

The main material gains depended on opponent mistakes: 14.Nxc5 d5 left the bishop uncaptured, and 16.Nxc6 Kf8 left another captured piece uncompensated. I withdrew the knights safely. After Nd3 blocked the d-file, the rook on d1 no longer defended Nd4; 19.Be3 supplied a defender against Qb6. This was a useful application of the blocker check from earlier games.

The tactical sequence 22.Nxe6+ opened Be3–d4–c5–b6 against the queen while checking the king on g7. Black chose 22...Qxe6, and 23.dxe6 won the queen. The connected passed pawns then reached e7 and f7. The promotions 28.f8=Q+ Rhxf8 29.exf8=Q+ Rxf8 removed one black rook; the other remained on f8. After 30.Nf4 Rxf4 31.Qxf4, both black rooks were gone.

The final net used 32.Rd6 to control the sixth rank and support the queen. Black's 32...Bd5 blocked the bishop's diagonal to g8, so 33.Bxd5 removed that defender. Then 34.Qf6+ forced 34...Kh7, and 35.Qh6# was supported by Rd6 while Bd5 controlled g8.

Continue checking changed defenders and forcing replies. This clean conversion against the weaker setting does not establish improvement against the maximum opponent. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 779,486 tokens; this is not per-game or whole-account usage.

## Game 6 — Black, elo-1800-setting, 1–0

Lost by resignation after 53.Qxf3 (105 plies), with no illegal submissions. Confirmed from the recorded PGN. The 1800-setting pair is one win and one loss. Overall: three wins and three losses; maximum strength remains 0/2.

I developed normally, castled, and played in the center. White's 24.b5 axb5 and the sequence 30...Nxb4 31.axb4 Rxb4 gave me two extra pawns. I exchanged rooks and reached queen-and-bishop play with opposite-colored bishops. I did not establish a forced win from that advantage.

The first missed defense was 42...f6 43.Bxb7. White's queen on f3 supported the bishop on b7 along f3–e4–d5–c6–b7 after the bishop vacated d5. My queen on c7 could not recapture without being lost to Qxb7. This repeats the opened-line error from game 4; one queen defending a pawn was not sufficient against the supported bishop capture. I was then only one pawn ahead.

The decisive mistake was 51...Kd5 after 50.Qa1+ Ke6 51.Qa6+. White replied 52.Qb7+, lining up Qb7–c6–Kd5–e4–Qf3. My king screened my loose queen, so a legal king escape uncovered the capture. The recorded continuation was 52...Kc4 53.Qxf3. My preceding calculations considered king escape squares and my own mating threat but failed to check what White's next check would expose behind the king.

I resigned with a queen lost for no compensation sufficient to continue: ...b3 could be met by Bxb3+, with the bishop protected along the third rank by Qf3. Resignation preserved the loss in the record.

For the next games, use the short protocol in `move-check.md`. In particular, after choosing a king move, inspect lines that would join the king to the queen or a rook, and consider the opponent's checking squares on those lines. In my reconstruction, 51...Ke7 would not create the same b7–f3 skewer; that is an untested alternative, not a proven winning continuation.

Long speculative analysis did not prevent this one-reply tactical loss. Zero illegal moves is useful but is not evidence that move quality improved. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,071,029 tokens; not per-game or whole-account usage.

## Game 7 — White, full-strength, 0–1

Checkmated by 31...Bc3# (62 plies), confirmed from the recorded PGN. No illegal submissions. Maximum-strength results are now three losses; overall results are three wins and four losses. There is no demonstrated improvement against the target.

The early queen trade followed 7.Nxd5 Qxd5 8.e3 Be7 9.Nf3 Qxd1+ 10.Kxd1. My plan for an isolated black d-pawn did not occur because Black recaptured with the queen. Moving the knight off d4 opened the queen exchange and removed my castling rights. I again sent the king toward c2 in a queenless position, but the remaining rook and bishops kept king safety important.

The first material loss followed 19.Kd2 Bd5 20.a3 Ne4+ 21.Ke1 Nxc3 22.Rc1 Rc7 23.bxc3 Bxa3. The b2 pawn could not both recapture the knight and keep a3 defended. After 24.Rc2 Be4 25.Ra2 Rxc3, Black had won both queenside pawns. The intermediate rook pressure did not prevent that loss.

The mating sequence was 27.Kd1 Bd5 28.Ra1 Bb3+ 29.Kd2 Rc8+ 30.Kd3 Bc2+ 31.Kd4 Bc3#. My initial spoken diagnosis blamed 30.Kd3; checking the occupied and attacked squares shows that d3 was the only king escape after 29...Rc8+. After 30...Bc2+, d4 was likewise forced. At the final mate, Rc8 controlled c3/c4/c5, Bc2 controlled d3/e4, Bc3 checked d4 and controlled e5, the e6 pawn controlled d5, and my own e3 pawn occupied the remaining adjacent square.

The earlier error was allowing the net with 28.Ra1. After 28...Bb3+, the alternative 29.Ke1 also fails to 29...Rc1#: moving the rook off c3 uncovers Bb4–c3–d2–e1 as well as giving the rook check. Rxc1 would remove only one check, so the first-rank rook was not an adequate defense. In the played line, ...Rc8+ instead uncovered the bishop against Kd2. This is my own reconstruction, not an engine review.

Lessons to test:

- When a checking move vacates a line, identify every checking piece. A capture of one attacker may leave a second check unresolved.
- Before moving an exposed king, count actual escape squares after the opponent's forcing reply. In this game my own bishop and pawns closed several squares.
- A defended piece can still be lost through an overloaded pawn. Follow the recapture and then recheck the pawn's previous defensive duties.
- Earlier active rook moves such as 19.Rd4 or 28.Ra4 deserve consideration. These are untested candidates, not established improvements or claims that the position could be saved.
- Long speculative lines again contained stale blockers and missed forced checks. Use the current board to verify short forcing replies before extending a variation.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,177,322 tokens; not per-game or whole-account usage.

## Game 8 — Black, full-strength, 1–0

Checkmated by 33.Qxg8# (65 plies), confirmed from the recorded PGN. No illegal submissions. Maximum strength is now 0 wins, 0 draws, 4 losses; overall results are 3 wins and 5 losses. The second maximum-strength pair did not demonstrate improvement.

I played a Ruy Lopez structure, castled on move 8, and developed both bishops. The central sequence was 13...exd4 14.cxd4 Nb4 15.Bb1 c5 16.d5 c4. My 17...Qa5 supported Nb4 but also put the queen behind it on the d2–c3–b4–a5 diagonal. After 18.Bd2 Nd7 19.Re3 g6 20.Qe1, the queen on e1 supported the bishop's capture on b4 through the square that bishop would vacate. Thus Bxb4 Qxb4 Qxb4 would lose my queen. Counting Qa5 as a defender of Nb4 had missed the final recapture.

I did not find a satisfactory repair. The recorded attempt 20...Nd3 21.Bxd3 Qb6 22.Bc2 lost the knight. White did not choose the queen exchange I had sought. The bishop retreat preserved White's extra piece. This does not prove that every earlier alternative failed; the pin needed attention before Qe1 made it decisive in the played line.

The later exchange sequence was 25...f5 26.Nxe5 Bxe5 27.Bxe5 Rxe5 28.exf5 gxf5. This opened the g-file. White used 29.Rg3+ Kf7 30.Qxh6, and I played 30...Qxd5 to recover the passed pawn. That did not address the mating threat. The finish was 31.Rg7+ Ke8 32.Qh8+ Qg8 33.Qxg8#.

The rook on g7 controlled f7, e7, d7, and c7, stopping at my bishop on b7. My calculation repeatedly treated d7 as a possible king escape while forgetting that whole rank. Once the queen arrived on h8, my own king on e8 also blocked Ra8 from crossing to f8 or g8. Interposing Qg8 did not save the game. In my reconstruction, 30...Rg8 from a8 was legal and would guard g7; it is an untested defensive alternative, not a claim that the game could be saved.

I created `geometry-cards.md` with short reconstructions from these games. The next trial is to verify occupied rays and the last recapture explicitly, instead of extending speculative variations while carrying stale square information. No engine, external source, or delegated advice was used. Observed cumulative active-goal usage after this game: 1,309,508 tokens; not per-game or whole-account usage.

## Game 9 — White, skill-0, 0–1

Checkmated by 56...Qh1# (112 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 3 wins and 6 losses; skill 0 is 2 wins and 1 loss; maximum strength remains 4 losses. The existing review protocol has not prevented recurring tactical errors.

The early mistake was opening the h-file while my king remained exposed. After 14.h3 h5, I recognized that immediately taking the knight on g4 would allow mate on the h-file while Bc5 controlled g1. I played 15.Na4 Bd6, then 16.hxg4 hxg4+ 17.Kg1. That freed g1 temporarily but did not resolve the attack: 17...g3 supplied further mating support. I had underestimated this continuation. I chose 18.Qg4 Qxg4, sacrificing the queen, then moved the rook off f1 and eventually captured the g3 pawn. I did not prove that the queen sacrifice was forced or best.

The passed d-pawn recovered some material: 29.d6, 31.d7, and 32.Bc7 preceded 33.Bxd8 Rxd8, winning a rook for a bishop. Black then captured the pawn with 35...Rxd7. After 36.Rxd7+ Qxd7, I had rook and knight against queen and bishop. The rook and knight later coordinated to recover c4; checking along the sixth and seventh ranks drove the king away and allowed 51.Rxg7. These were local material gains in a position still materially inferior, not an established recovery.

The final checks were 51...Qd4+ 52.Ke1 Bb4+ 53.Ke2 Qd2+ 54.Kf3 Qd5+ 55.Kg3 Be1+ 56.Kh3 Qh1#. I chose h3 while focusing on avoiding Qxf4 with check and the subsequent loss of the knight. I failed to enumerate Qh1+, reached along d5–e4–f3–g2–h1. The queen then controlled the h-file and g2; Be1 controlled g3/h4; f5 controlled g4. There was no capture, interposition, or king escape. Avoiding a material threat was irrelevant once the selected square allowed mate.

The next trial adds a specific king-move check: inspect reachable queen checking squares on the new king's rank, file, and diagonals, including a change of line such as Qd5–h1 followed by an h-file check. Check mate before comparing possible material losses. The early h-file error also reinforces that winning a knight is insufficient justification for removing the king's pawn cover without calculating the next attacking pawn move.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after this game: 1,706,838 tokens; not per-game or whole-account usage.

## Game 10 — Black, skill-0, 0–1

Won by 23...Qxg2# (46 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 6 losses; skill 0 is 3 wins and 1 loss; maximum strength remains 0/4. This is one successful attacking sequence, not evidence of improvement against the target.

I developed both knights and bishops, castled on move 5, and challenged the center with ...c5. After the exchanges, the c5 and d5 pawns gave central space. I exchanged Ne4 for Nc3 before advancing its defending d-pawn: 14...Nxc3 15.Rxc3 d4. The rook retreat gave time for ...Qb6 and ...Rad8. The later 18...Bf8 kept c5 defended along f8–e7–d6–c5 while opening the e-file, so 19...Ne5 was defended by Re8 and attacked Rc4.

After 20.Bxc5, my queen on b6 was attacked. In the rejected line 20...Bxc5 21.Rxc5 Qxc5, 22.Qxc5 would capture my queen along the newly opened c-file. Checking that last recapture prevented another version of the opened-defender error. I instead played 20...Nxf3+ 21.gxf3 Qg6+, using the check to gain time to move the attacked queen and reach the opened g-file.

The observed finish was 22.Bg2 Bxf3 23.h4 Qxg2#. Bg2 was pinned to Kg1 by Qg6 and could not capture the bishop on f3. That bishop protected the queen's capture on g2. The queen then controlled f1, h1, and h2; f2 remained occupied by White's pawn; and Kxg2 was illegal because of Bf3. There was no interposition between the adjacent queen and king. The pawn on d4 also blocked White's rook on c4 from reaching g4 to interfere with the g-file attack.

Keep verifying complete recaptures and short forcing replies. The useful behavior here was updating the c-file after the rook moved and checking the actual final king escapes. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,820,888 tokens; not per-game or whole-account usage.

## Game 11 — White, elo-1800-setting, 0–1

Resigned after 45...Nxe5 (90 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 7 losses; the 1800 setting is 1 win and 2 losses; maximum strength remains 4 losses. The recurring material oversights show that the existing review method is still unreliable.

I developed, castled on move 8, and placed rooks behind the center. The sequence 17.Nxd4 Bf6 18.e5 blocked the attack on the knight while attacking the bishop. This avoided an immediate loss, but it did not establish an objectively favorable position.

The first major error was 21.Qe4. Both Qf4 and Bb7 attacked e4. I imagined an exchange continuing through captures by both queens and minor pieces, without checking whether Black needed to continue. Black played 21...Bxe4, taking the queen with its bishop. After my recapture, Black could preserve its queen. The played 22.Rxe4 g5 23.Rxf4 gxf4 instead let me exchange a rook for Black's queen, reducing the damage to an exchange deficit. That opponent choice did not make the original queen offer sound. A queen move off the bishop's diagonal, such as Qe3, is an untested alternative rather than a verified improvement.

I continued the ending with bishop and knight against rook and knight. The rook trade 29.Be2 Rxd1+ 30.Bxd1 used the bishop to make the recapture legal. I won a pawn with 33.Bxa6 and activated the king. After 38...f5+, 39.exf6 was a legal en passant answer to check. Black later captured that pawn with 40...Nxf6. I moved the bishop out of the opened d-file with 41.Bb5+ rather than overlooking the rook's attack on d3.

The decisive second error was 45.Ne5 after 44...Ng4. I called the knight protected by Kf4, but 45...Nxe5 left the black knight backed by Rd5. Kxe5 would move into rook check. The king could not recapture, and I lost a knight outright. I resigned with a bishop against rook and knight, with four pawns against three. The resignation records the loss; I did not prove a forced mate.

For the next game, the immediate test is narrower: first test the cheapest enemy capture of the valuable piece, allowing the opponent to stop the exchange; then verify the legality of the intended recapture. In particular, a king cannot recapture an attacker that is protected by another enemy piece. Long variations in this game repeatedly obscured these short tests. The hypothetical 45.Bc4 would keep the bishop defended and avoid this specific knight loss, but has not been tested as a saving line.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,076,877 tokens; not per-game or whole-account usage.

## Game 12 — Black, elo-1800-setting, 1–0

Resigned after 58.Rxc2 (115 plies), confirmed from the recorded PGN. One illegal submission. Overall results are 4 wins and 8 losses; the 1800 setting is 1 win and 3 losses; maximum strength remains 0 wins, 0 draws, 4 losses. There is still no demonstrated improvement against the target.

I developed, castled, and used ...e5 to exchange central pawns. I noticed at several points that Bd6 blocked my queen from defending d5, and moved the bishop or supplied a rook defender. The sequence 30...Nf3+ 31.Nxf3 Qxf3 exchanged knights and briefly put pressure on f2. These were specific local checks; they did not make the later audit reliable.

White's queen moved away from b3 with 33.Qd3. After 33...axb4 34.axb4 Rxb4, I had an extra pawn. I exchanged queens and maintained d5 with ...Rd8. The central exchange 40...d4 41.Rc5 dxe3 42.Rxe3+ removed White's e-pawn and my d-pawn, leaving my extra b-pawn as a passer. I activated the king and advanced that pawn, but did not establish a forced win.

After 48.Ra5, I submitted ...b4 while Kc5 remained behind the pawn on the fifth rank. The a5–b5–c5 line made the pawn absolutely pinned, so the move was illegal. I corrected it with ...Kb6, then played ...b4 after Ra8. This was a reasoning error and the game's sole rejected submission.

The pawn reached b3, but the sequence 52...Rc2 53.Ne5 Bxe5 54.Rxb3+ Kc5 55.Rxe5+ removed both minor pieces and returned material to equality. Ne5 attacked Rd7, and the checking pawn capture let White take b3 before recapturing the bishop. This was the loss of my extra pawn, not an established unavoidable draw.

The decisive error was 56...Rf5 after 55...Rd5 56.Re7. I focused on defending f7 and missed 57.Rc7+, skewering Kc5 against Rc2 along the c-file. My king also blocked Rc2 from capturing the checking rook or interposing above it. After 57...Kd6 58.Rxc2, White had two rooks against one with three pawns each and no concrete compensation for me. I resigned; no forced-mate claim is made.

The new geometry card enumerates the four rook checks after the actual final candidate: Rc7+, Re5+, Rc3+, and Rb5+. I considered other checks but omitted the decisive one. This repeats game 6's skewer error despite already having a reminder about king/major-piece alignment. The narrower trial is to enumerate each enemy rook's reachable checking squares before the material audit. The alternative 56...Rcd2 removes this particular skewer while allowing pressure on f7; it is an untested candidate, not a proved saving line.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,355,400 tokens; not per-game or whole-account usage.

## Game 13 — White, full-strength, 0–1

Checkmated by 22...Qh1# (44 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 9 losses; maximum strength is 0 wins, 0 draws, 5 losses. The target performance has not improved in the measured results.

I played a quiet Ruy Lopez with 4.d3 and castled on move 5. After ...Nd4 I exchanged that knight, then developed with c3, Nd2, Nc4, and Bc2. Black's ...d5 drove the knight back. The later ...Bg4 pin and ...a5–a4 expansion left Black active while I spent further moves reorganizing. No claim of opening equality is made.

The key weakening was 15.h3 Bh5 16.g4 Nxg4 17.hxg4 Bxg4. I had explicitly considered the knight sacrifice, but accepted the removal of my king's two pawns without establishing a sound defense. This repeats the broader king-cover error from game 9. The nominal extra knight was insufficient evidence of a favorable position.

The played defense was 18.Kg2 f5 19.Qe1 fxe4 20.Nd2 Bf3+. Qe1 removed the knight's relative pin to the queen, and Nd2 saved it from the pawn attack, but this permitted the bishop to enter f3 with check. The bishop was protected by e4 and the rook on f8, so Kxf3 was not legal.

I chose 21.Kh2, after which 21...Qh4+ forced 22.Kg1 and 22...Qh1# followed. Bf3 protected h1 along f3–g2–h1. My Rf1 and f2 pawn occupied escape squares; Kg1 blocked the rook from reaching h1. I had focused on queen checks leading to possible repeated king moves while missing the queen's supported move to h1. The mistake was the earlier escape choice, not a failure to find a legal alternative to the forced 22.Kg1.

The new card records 21.Nxf3 as a candidate to examine: after ...exf3+, 22.Kg3 is legal in my reconstruction and the bishop no longer guards h1. I have not proved that this saves the game. Likewise, 16.Qe2 is an untested way to retain the kingside pawn cover instead of playing g4. The next practical trial is to retain king shelter unless the attacking continuation is concretely justified, and to inspect captures of a checking bishop before accepting a king retreat that leaves its mating support intact.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,476,028 tokens; not per-game or whole-account usage.

## Game 14 — Black, full-strength, 1–0

Resigned after 23.Qxe7 (45 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 10 losses; maximum strength is 0 wins, 0 draws, 6 losses. There is no measured improvement against the target.

I played a French structure, castled, and exchanged the central knights and one pair of bishops. White castled queenside and advanced h4–h5–h6. My 15...g6 kept the h-file closed but left the advanced pawn controlling g7. After 16.Nxd5 I declined the capture: the illustrative 16...exd5 17.e6 fxe6? 18.Qg7# shows one concrete danger, although it does not prove that every defense after ...exd5 loses. I instead played 16...Re8 17.Rh3 Qd8.

The queen retreat was meant to support the knight and permit ...Nxf6 followed by exf6 and ...Qxd4. After 18.Nf6+, I found that White need not recapture with the pawn. The alternative 18...Nxf6 19.Qxd8 Rxd8 20.Rxd8+ Ne8 21.Rxe8# exploits the opened d-file, the vacated eighth rank, Bc8 blocking Ra8, and h6 controlling g7. I rejected the capture, but discovering this only after ...Qd8 exposed a defect in the planned exchange. The opponent's choice of capture order was again decisive.

The played defense was 18...Kf8 19.Nxh7+ Kg8 20.Nf6+ Kf8 21.Qb4+ Re7. The knight checks took h7, leaving White's h-pawn free to advance. After 22.h7 Kg7, my queen could cover h8 along the now-cleared eighth rank, but 23.Qxe7 removed the rook. Recapturing with 23...Qxe7 would allow 24.h8=Q#: Rh3 protects the promoted queen, and the knight, e-pawn, queen, and my own f7/g6 pawns close the king's escape squares. The alternative ...Qh8 is legal but leaves the rook lost. I resigned a rook and two pawns down without concrete compensation; this is not a claim that every legal continuation immediately mates.

This game adds two practical checks. First, inspect capture order and the rook check that can follow a queen exchange. Second, assess an enemy pawn near the king even when it currently blocks its own rook: removing the pawn ahead of it can create a promotion threat. My long analysis also carried a cleared e6 square from one hypothetical line into another in which Black's e6 pawn had never moved; the imagined e5–e6 advance in that second position was impossible. Rebuilding the current board must precede reuse of a variation.

The earlier candidate 15...gxh6 16.Rxh6 would remove the advanced pawn while opening lines. It has not been tested and is not claimed to save the game. The expanding checklist has not yet produced reliable tactical accuracy. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,762,593 tokens; not per-game or whole-account usage.

## Game 15 — White, skill-0, 1–0

Won by 33.Qh7# (65 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 5 wins and 10 losses; skill 0 is 4 wins and 1 loss; maximum strength remains 6 losses. This win does not establish improvement against the target.

I used a d4/c4 center, developed both knights and Bd3, and castled on move 7 while retaining the f2/g2/h2 pawn cover. After 9.e4 Bxc3, the recapture 10.bxc3 kept Qc2 behind Bd3. Thus 10...dxe4 11.Bxe4 Nxe4 12.Qxe4 completed an equal exchange; Qxc3 would not have supplied that final recapture on e4. The doubled c-pawns were a cost of retaining this tactical defense.

The sequence 13.Bd2, 15.c5, and 16.c4 defended c3, then cleared the bishop's diagonal with an attack on Qa5. Bf4 gained another tempo against Qc7, and Bd6 occupied a square protected by c5. Rab1–b6 activated the rook on another square protected by that pawn and prevented ...b6 from undermining it. After 21.d5 Qf7 22.dxc6 bxc6 23.Qxc6, I was a pawn ahead. This is a material count, not an engine evaluation of the preceding position.

The decisive opponent mistake was 23...Qb7. I captured with the cheaper piece, 24.Rxb7, having checked ...Bxb7 25.Qxb7 through the final recapture. Black instead played ...a4 and left the queen unrecovered. I moved the attacked rook with 25.Re7, then used 25...Bb7 26.Qxb7 Rxe7 27.Bxe7 to take the bishop and exchange rooks. The subsequent ...Rc8 allowed Qxc8, and Qxf8+ removed Black's last piece. These large opponent concessions, rather than the opening alone, produced the winning material advantage.

After 30.Re4 f5, moving the knight with check answered the attack on the rook without sacrificing it. The vacated f6 square let Be7 protect 31.Ng5+. The played ...Kh6 32.Qh8+ Kg6 33.Qh7# used Ng5 to protect the mating queen and cover f7, Be7 to cover f6 and protect g5, and Black's pawns to block f5/g7/h5. This finish was checked square by square and confirmed by the referee. The alternate line against ...Kg6 is recorded separately as my unplayed mental reconstruction.

Useful local checks succeeded here: preserving the queen's recapture ray, choosing the cheaper attacker against an exposed queen, and verifying the mating square's support. Repeated long analysis remains costly and is not itself evidence of learning. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,973,867 tokens; not per-game or whole-account usage.

## Game 16 — Black, skill-0, 0–1

Won by 32...Re2# (64 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 6 wins and 10 losses; skill 0 is 5 wins and 1 loss; maximum strength remains 6 losses. The paired skill-0 wins relied on large opponent mistakes and do not establish progress against the target.

Against 1.c4 I used ...e5, ...Nf6, and ...d5. After Bg5 pinned the knight to the queen, ...d4 attacked Nc3 and ...Be7 removed the pin. I answered Qa4+ by developing ...Nc6, recaptured Nxf6+ with the bishop, and castled on move 8. ...Bd7 reinforced c6 against the queen and a future Bg2. The later ...a5 supported ...Nb4, which attacked Qc2; ...c5 then strengthened d4 before the knight retreated from a3.

The central sequence 15...Bf5 16.Rb1 e4 17.dxe4 Bxe4 opened the bishop's attack on both Qc2 and Nf3. White's 18.Rc1 defended the queen but still allowed the favorable capture 18...Bxc2. A rook recapture would not restore material equality. White instead played h3, so I preserved the bishop with ...Be4 before exchanging it for Nf3.

After 21.exf3, the departure of the e2 pawn made ...Ne5–d3 available. The knight attacked Rc1 and f2. White's Rf1 left the c1 rook exposed, and ...Nxc1 took it. White again declined to recapture, allowing ...Nb3. I checked that 25...Kxf7 legally captured the unsupported checking bishop; White's own pawns blocked its rook's f-file. After 26.Bxa5 attacked my queen, ...Nxa5 removed the last bishop and preserved the queen.

The finish coordinated the remaining pieces: ...Qe7–e2+ forced Kb1, and ...d3 opened the bishop's diagonal to b2. White interposed Rc3 against the queen-mate threat. After ...Bxc3 bxc3, ...Qe1+ forced the king onto the second rank and ...Re2# finished. Qe1 covered the first rank, Re2 the second, Na5 covered b3, and White's own a3 pawn blocked the last escape. Capturing that bishop on a5 had therefore also placed the knight on a useful mating square.

The successful local checks were the bishop's capture of a rook-defended queen, updating d3's safety after exf3, verifying the king recapture on f7, and counting the final escape squares. I still spent excessive analysis on remote alternatives after obtaining a decisive material advantage; the win is not evidence that this amount of analysis is necessary or that the earlier recurring errors are resolved. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 3,159,722 tokens; not per-game or whole-account usage.

## Game 17 — White, elo-1800-setting, 1–0

Won by 55.Qg6# (109 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 7 wins and 10 losses; the 1800 setting is 2 wins and 3 losses; maximum strength remains 6 losses. Three consecutive wins against weaker settings do not establish improvement against the target.

I developed with d4/c4, brought the c1 bishop outside the pawn chain before e3, and castled on move 8. After ...cxd4 I recaptured with the e-pawn. Be3 answered ...Nh5 without opening my king's pawn cover. Once ...Nb6 vacated d7, Ne5 no longer faced an immediate exchange by that knight. The later Nxc6 bxc6 changed Black's pawn structure, and Na4 attacked both Nb6 and Bd6. The played 19...Nc4 20.Bxc4 dxc4 21.Rxc4 gave me a pawn. This is a count of the observed exchanges, not a claim that the opening forced an advantage.

After further maneuvering and a bishop exchange, 29.Nd3 prepared Ne5 and opened the c-file. Black answered 30.Ne5 with ...Rxb4. I declined 31.Rxb4 Nxb4 and instead used 31.Rxc6: Ne5 protected c6, so the queen on e8 could not profitably capture that rook. Taking c6 restored the pawn count to a one-pawn lead while keeping the rook active. I initially lost track of the pawn count during earlier analysis and corrected it from the actual captures; the result should not be inferred from a stale material impression.

The decisive played sequence was 31...Nb6 32.a3 Rxd4 33.Rxd4 f6 34.Nc4 a5 35.Nxb6. Black's ...f6 allowed my attacked knight to retreat; ...a5 then left Nb6 available to the cheaper knight capture. I had rejected 34.Nd7 because the illustrative ...Nxd7 35.Rxd7 Qxd7 would lose a rook. That rejected line was a mental check, not a referee-tested variation. The actual continuation produced a rook-and-knight advantage and depended on Black's material concessions.

I anticipated the queen check after vacating d1. The played 35...Qe1+ 36.Kh2 was legal, and the later 37.Rc8 Rxc8 38.Nxc8 exchanged Black's remaining rook. Against 38...Qe5+, 39.Qf4 both interposed and defended Rd4. My rook also defended the interposing queen, so ...Qxf4+ 40.Rxf4 safely removed the queens. This was a useful successful check of a forcing reply and the final recapture.

In the ending I captured a5 and f5, moved the rook away from pawn attacks, and advanced the a-pawn. The king's capture on h3 removed another pawn without entering an attacked square. Promotion at move 52 left Nc8 blocking the new queen's eighth-rank ray. The finish 53.Ne7+ Kg7 54.Qg8+ Kh6 55.Qg6# cleared that ray and used the knight to protect both g8 and g6. At the end, Qg6 covered g5/g7/h7, Ne7 prevented Kxg6, and Black's h5 pawn occupied the remaining escape. The referee confirmed mate.

The useful local behaviors were declining an automatic recapture, checking the defender behind a knight exchange, meeting a queen check while defending the rook, and verifying the mating queen's protection. The analysis still spent too long on remote variations and sometimes missed an obvious capture before correcting it. This game does not show that the full checklist is reliable or that more reasoning alone is the cause of improvement. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 3,461,957 tokens; not per-game or whole-account usage.

## Game 18 — Black, elo-1800-setting, 1–0

Resigned after 84.Kh7 (167 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 7 wins and 11 losses; the 1800 setting is 2 wins and 4 losses; maximum strength remains 0 wins, 0 draws, 6 losses. The target has not been achieved, and these results do not establish improvement against it.

I answered e4 with e5, developed, and castled on move 5. Central exchanges and the sequence ...Ne7–d5, ...c6, and ...Nxf4 reduced the minor pieces. I exchanged queens with 28...Qxf4 and advanced ...g5 only after the queens were gone. These choices retained the king's pawn cover during the earlier play, but did not prevent the later endgame errors.

White's 35.Ra6 pinned c6 against my king. The later 38...Rd6 39.Rxd6 Kxd6 restored that pin: after 40.cxb5, ...cxb5 would expose Kd6 to Ra6 and was illegal. I recognized the pin before submitting a move, but had already allowed the pawn loss. The played ...Rc8 and ...Kc5 defended c6 and freed the pawn. After 42.bxc6 Rxc6, however, 43.Ra5+ drove the king off the fifth rank and 44.Rxf5 took a second pawn. I had considered the rook check without initially carrying its opened horizontal attack through the king's departure.

King activity and rook checks created practical counterplay. The first checking sequence did not force a draw: White chose Kg3, then interposed Bf3 against ...Re3+. That bishop was pinned to the king along the third rank. White's h3 created an escape on h2. I switched to the central pawns with 55...Ba4 56.d4 Bxc2, using the bishop as the cheaper attacker while Kd2 made a rook recapture on c2 unfavorable.

The passed d-pawn was then removed with 59...Bb3 60.Kg4 Bxd5 61.Bxd5 Rxd5. Kg4 had removed the pin on Bf3, so the actual capture must not be justified by the old pin. Instead, bishop and rook both attacked d5, while Re6 did not defend that square. The bishop exchange recovered the pawn. White subsequently took h6, restoring the one-pawn deficit. The later 66...gxh4+ vacated g5 and opened Rd5's check against Kh5; White's Kxh4 left only the g-pawn on the board.

The critical rook-ending mistake was 69...Ke5 after 69.g4. I attacked Rf6 but allowed 70.Rf5+. White's g4 pawn protected f5, so Kxf5 was illegal. My own king on e5 blocked Rd5 from capturing the checking rook. Keeping Rd5 defended after ...Ke6 did not solve the problem: 71.Rxd5 Kxd5 forced the transition to a pawn ending with my king on d5 and White's king on h4, followed by Kg5. I examined some of this geometry in advance but accepted the exchange without establishing that the pawn ending could be held. This repeats the king-blocks-own-rook pattern from earlier games, now through an adverse exchange rather than a free rook loss.

My assessment of the pawn ending was unstable. I explored many lines, repeatedly corrected pawn attacks and king distances, and alternated between hopes of a draw and recognition of White's promotion route. No tablebase or engine analysis was used, and I do not claim a proved evaluation of every earlier ending or an established drawing alternative to 69...Ke5. The actual king maneuvers did not reach a claimable repetition. White advanced g5 and g6, then placed the king on h7 before pushing the pawn farther.

At the final position, White Kh7/Pg6 faced Black Kf8. The pawn controlled f7, and the white king controlled g7 and g8. Black could only move to e7 or e8; White could then play g7 and g8=Q with the promotion square protected. For example, ...Ke8 g7 ...Kf7 g8=Q+ is an unplayed mental illustration. I resigned because I could not prevent a supported queen promotion, not because checkmate had already occurred.

The specific next trial is to reconstruct the position and side to move after a proposed final rook exchange before treating it as safe. A king's legal recapture does not establish that the resulting pawn ending is defensible. The analysis again spent excessive time on remote variations and did not deliver reliable tactical or endgame judgments. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 4,232,253 tokens; not per-game or whole-account usage.

## Game 19 — White, full-strength, 0–1

Resigned after 40...Rd2 (80 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 7 wins and 12 losses; maximum strength is 0 wins, 0 draws, 7 losses. The goal remains unmet, with no demonstrated improvement against the maximum setting.

The d4/c4 opening led to early central exchanges and a queen trade on d1. I developed both bishops and brought the king to c2, then b2. Material stayed equal through move 22's bishop exchange. Keeping the queens off and avoiding an immediate king attack did not make the resulting position easy to defend.

I played 17.Nd2 to support e4 and control c4. This also blocked Rd1's route up the d-file. I had considered a rook recapture on d5 in earlier variations, then recognized after 17...Bxd5 that it was unavailable; 18.exd5 created a passed d-pawn instead. The own-piece obstruction was caught before an illegal submission, but the intended recapture had not been rebuilt after Nd2.

The plan Rac1 followed by 20.c4 counted Rc1 and Nd2 as defenders. Black's 20...Bb4 attacked that knight. The played 21.a3 Bxd2 22.Bxd2 Nxc4+ removed the defender before taking the pawn. I did not find a satisfactory answer during play, but have not proved that the pawn loss was forced from move 20 or that an earlier alternative saved the position. My long examination of ...Bc5 had missed the more direct ...Bb4 mechanism.

There was a useful successful capture-order check. After ...Nxc4+, 23.Ka2 protected a3 and avoided a checking ...Nxd2. The actual 23...Nxd2 was answered by 24.Rxc7+ Kxc7 25.Rxd2. Exchanging the c-file rooks first let me recover the knight without leaving Rc1 undefended. An immediate Rxd2 would have allowed ...Rxc1. This reached a rook ending one pawn down.

Black blockaded d5 with ...Kd6 and restricted my king with ...Rc8. After 27.Rd3 e4, I played 28.Re3 to attack e4. The reply ...Kxd5 both captured my passer and protected e4: Kd5 controls e4, so Rxe4 would lose the rook. I repeatedly underestimated that new king defense while considering the line. The later f3 and fxe4+ exchanges cleared a lateral route for my rook but did not remove Black's passed e-pawn.

Rg3–g5+–xh5 recovered one pawn, while ...Kd4 and ...e3–e2 created the decisive promotion threat. Rear checks drove the king through e3 and d2 to c1. I then kept the rook on the e-file, but ...Rc2 and ...Kd1 supplied a shelter and a protected interposition. The final played 40.Rd3+ Rd2 ended the checking sequence. In my unplayed reconstruction, 41.Rxd2+ Kxd2 leaves an unstoppable e-pawn; 41.Re3 e1=Q 42.Rxe1+ Kxe1 leaves Black with a rook against no piece. I resigned because the promotion would cost my remaining rook or produce a queen, not because checkmate had already occurred.

The next practical check is to test whether an enemy exchange can remove a necessary defender before the intended pawn capture, and to update all king-controlled squares after a king capture. These are specific errors to work on, not evidence that the existing protocol is reliable. Extensive remote analysis again failed to prevent basic geometric mistakes. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 4,420,972 tokens; not per-game or whole-account usage.

## Game 20 — Black, full-strength, 1–0

Resigned after 39.cxb8=Q (77 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 7 wins and 13 losses; maximum strength is 0 wins, 0 draws, 8 losses. The target remains unmet, and the maximum-setting results still show no demonstrated improvement.

I answered e4 with e5 and reached a closed Ruy Lopez structure, castling on move 8 with the kingside pawn cover intact. After White's d5, I used ...c4 and intended ...Nb7–c5. White's b4, the en-passant exchange, and a second b4 advance kept c5 controlled. My intended knight route was therefore unavailable. I challenged the queenside with ...a5, developed ...Bd7, and moved the queen to b6 to defend b5. These choices did not solve the accumulating pressure, and Be3 drove the queen back to c7. The played 22.Nxb5 Bxb5 23.Bxb5 left me a pawn down. I have not established a proved saving alternative or an engine evaluation of the preceding opening.

Several local geometry checks were useful but inconsistent. Bd7 connected the rooks before ...axb4 opened the a-file. However, I then imagined an unavailable ...Rxa1 before noticing that White Na3 blocked that file. Later, moving Ra8 to b8 changed which squares were protected by the rear rook; an old justification for ...Ra2 could no longer be reused. These errors were caught before submission, but consumed substantial analysis. The rook maneuvers ...Ra2–a3 attacked the queen without forcing a draw. White used Rec1 to counterattack my queen, then eventually chose Qc4 instead of repeating.

After Bc6, ...Rb8 removed the relative pin on Nb7 and ...Nd8 brought that knight off b7. White's 32.Nc4 attacked Ra3. I chose 32...Ra6, relying on Qc8's support along c8–b7–a6. White's 33.b5 attacked that rook with a pawn and supported Bc6 again. Queen support did not make a pawn attack harmless, and I had not checked a satisfactory subsequent retreat before placing the rook on a6. I found no satisfactory retreat during play and used 33...Rxc6 34.dxc6, giving the exchange and leaving connected passed pawns. This is not a proof that every earlier alternative also lost material.

The capture 34...Nxe4 correctly took a loose pawn: White's knight had left d2, and Be3 blocked Qe2's e-file. It reduced the material deficit but did not address the next fork. After 35.Nb6 Qc7, White played 36.Nd5, attacking both Qc7 and Be7. I had spent extensive analysis on Nd7 while omitting this different landing square. The actual ...Qa5 37.Nxe7+ lost the bishop. In an unplayed local illustration, ...Qc8 would also allow Nxe7+, forking Kg8 and Qc8; retreating the queen along that file would not solve the problem.

The finish repeated the error of analyzing only one opponent choice. After ...Kf8 38.c7, I played ...Kxe7, legally capturing the undefended knight. I concentrated on the unplayed 39.cxd8=Q+ Rxd8, where the rook could recapture the promoted queen. White instead chose 39.cxb8=Q, capturing that rook and obtaining a second queen. I had recognized that c7 attacked both b8 and d8, but failed to compare both promotion captures when selecting the actual king move. I resigned in the resulting overwhelming material deficit; this was not checkmate.

The next trial is to audit the immediate reply more systematically: include pawn pushes that attack the candidate's destination, scan every reachable enemy knight landing square for forks, and inspect the forward promotion and both capture promotions separately. These are specific checks to apply, not evidence that extending the written checklist has made it reliable. Long remote analysis again failed to prevent basic mistakes. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 4,686,424 tokens; not per-game or whole-account usage.

## Game 21 — White, skill-0, 1–0

Won by 36.Qh7# (71 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 8 wins and 13 losses; skill 0 is 6 wins and 1 loss; the 1800 setting remains 2 wins and 4 losses; maximum strength remains 0 wins, 0 draws, 8 losses. This win does not establish improvement against the target.

The d4/c4 opening met ...c6 and an early ...Qa5+. Nc3 and Bd2 answered the check and released the pin. I developed Bd3, castled, and expanded with e4 after checking the central recaptures. After Nxf6+ Bxf6, Bh6 attacked Rf8. Black's ...a5 ignored the attack, and 15.Bxf8 Nxf8 won an exchange. This material gain depended on the opponent's concession.

The queen maneuver Qe3–f3 met ...Bg5 and ...Bf6. I then used 19.Qxc6, with Ne5 protecting c6. Black removed that defender with ...Bxe5. I had checked this reply and chose 20.Qxa8, capturing the second rook. The alternative Qxc7 Bxc7 would only exchange queens while leaving my knight lost for a pawn. The actual rook capture preserved a material advantage. Against ...Bxh2+, I recognized that Qc7 protected the bishop along the diagonal and used Kh1 rather than an illegal Kxh2.

The central pawn advance d5 drove Ne6 to d4. Re4 attacked that knight, but ...Bb7 attacked my queen first, so I moved Qa8 to e8. Black then left the knight available with ...Bg3, allowing 25.Rxd4. After ...Bxf2 attacked that rook diagonally, Re4 returned it to the bishop's protection. I rejected an immediate Rxe7 once ...Bc5 had added a second defender: Rxe7 Qxe7 Qxe7 Bxe7 would lose the rook in the exchange. Instead, Rf1 activated the other rook. The played ...e6 dxe6 fxe6 Rxe6 cleared the f-file and recovered the pawn while saving the e4 rook from Bb7's opened diagonal.

The major failure was the calculation of 30.Qf7+ Kh6 31.Rxg6+. I examined ...Qxg6 and ...Kh5, and incorrectly treated that as a complete reply set. I omitted the h7 pawn's legal ...hxg6, which Black played. The queen and bishop protected g6 against a king capture, but did not prevent a pawn capture. The checking rook sacrifice was therefore not justified by the mating argument I had used. No claim is made that the position was lost or that the sacrifice has been fully evaluated; the specific claimed forcing line was incomplete.

After ...hxg6, I also initially considered Qxg6+ Qxg6 Bxg6 without carrying the exchange through ...Kxg6. The black king on h6 could legally take that bishop. I corrected this before submission and chose 32.Qf4+, a checking attack on Qg3 supported by Rf1. The illustrative ...Qxf4 Rxf4 or ...Qg5 Qxg5+ Kxg5 would exchange queens. Black instead interposed ...g5, leaving the queen available to 33.Qxg3. The subsequent ...Bxg2+ allowed 34.Kxg2; the remaining bishop did not attack g2.

The actual finish was ...Be7 35.Qh3+ Kg7 36.Qh7#. On h7 the queen was protected by Bd3 through e4/f5/g6. Rf1 controlled f6, f7, and f8, and the queen covered the other king escapes. The g5 pawn both occupied a potential escape from h6 and blocked Be7's route to h4 during the preceding check. The referee confirmed the final mate.

The immediate next trial is a literal capture audit of the chosen destination: for a white piece on g6, inspect black pawns on f7 and h7 before discussing king escapes or a queen recapture. The analogous direction must be reversed when playing Black. This supplements the existing capture check; it is not evidence that the protocol now works. Long analysis again omitted a simple pawn capture, and the result relied on several weaker-opponent concessions. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 4,875,400 tokens; not per-game or whole-account usage.

## Game 22 — Black, skill-0, 0–1

Won by 31...Qe1# (62 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 9 wins and 13 losses; skill 0 is 7 wins and 1 loss; the 1800 setting remains 2 wins and 4 losses; maximum strength remains 0 wins, 0 draws, 8 losses. These weaker-setting wins do not establish progress against the maximum target.

I answered e4 with e5, developed in an Italian structure, and castled on move 6. After ...h6, White exchanged Bg5 for Nf6, and Qxf6 retained the pawn cover. Be6 completed development. White then exchanged the other bishop for Nc6, and ...bxc6 left me the bishop pair and doubled c-pawns against two knights. The central ...d5 and ...exd4 opened lines. I considered the pawn push e5 against Qf6 before taking on d4 with the bishop, and chose ...dxe4 first. That was a local tactical precaution, not proof that every immediate bishop capture lost.

After Rxe4, ...Bd5 drove the rook to e3, and ...Bxd4 captured a pawn. White's 18.Ne4 attacked Qf6. I initially spent too long looking for a queen retreat, then used the direct 18...Bxe4 to remove the attacking knight. White captured the other bishop with Nxd4; ...Bd5 saved the remaining bishop. This left a bishop against a knight and an extra pawn, with the queen's threat resolved through a capture rather than a retreat.

The move 20...Rfe8 met 21.Qe1. Nd4 had lost its queen defender on d1, but taking it immediately would allow the illustrative ...Qxd4 Rxe8+ Raxe8 Qxe8+, conceding the second rook. I therefore exchanged first with 21...Rxe3. The actual fxe3 removed White's active rook and made the e3 pawn the knight's defender. The unplayed e8 sequence was checked mentally; it was not submitted as a variation to an engine or referee.

After ...Qg6 and Qe2, ...a5 challenged b4 while keeping the rook behind the a-pawn. The actual ...axb4 axb4 cleared the entire a-file. I used 25...Ra2, with Bd5 protecting a2 along c4/b3, and attacked the queen on e2. White's 26.Qxa2 allowed ...Bxa2, exchanging my rook for the queen. This decisive material gain depended on White's choice to capture the supported rook.

White's 27.Nxc6 removed a pawn and created the possible Ne7+ fork of Kg8 and Qg6. I moved the queen to e4 before that check arrived. The actual 28.Ne7+ could then be answered by Qxe7: the knight had left the c-file, where Rc1 had protected it, and e7 had no white defender. I subsequently captured e3 and moved the attacked bishop from a2 to d5.

White's final 31.Ra3 attacked Qe3 but left the first rank. I answered with Qe1#. The queen controlled f1/g1/h1, White's own g2/h2 pawns occupied the other king escapes, and Ra3 could neither capture Qe1 nor interpose on f1 or g1. Returning the rook to a1 would be outside the checking segment and would not stop the check. The referee confirmed mate.

Useful local checks were removing the queen-attacking knight, counting the complete rook exchange on the e-file, verifying the bishop's support of a2, and anticipating Ne7+ before moving the queen. They do not establish error-free play or a reliable protocol. Analysis remained excessively long, with many discarded remote lines and repeated corrections of blockers and attack geometry. I am retaining the existing move check rather than treating another checklist addition as improvement. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 5,148,348 tokens; not per-game or whole-account usage.

## Game 23 — White, elo-1800-setting, 1–0

Won by 31.Qf8# (61 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 10 wins and 13 losses; the 1800 setting is 3 wins and 4 losses; skill 0 remains 7 wins and 1 loss; maximum strength remains 0 wins, 0 draws, 8 losses. The target remains unmet, with no demonstrated improvement against maximum strength.

The opening reached a Benoni structure with White pawns on d5/e4. I developed and castled, used a4 against the queenside break, and played Re1. I initially treated that rook as an e4 defender without accounting for Be2; 12.Bf1 then actually cleared the file. After ...Bxc3, bxc3 preserved the bishop pair. Bf4–g3 answered the queen attack from f6, and c4 supported d5. These local choices are not an established evaluation of the opening.

Black answered 18.Nxe5 with ...h4 instead of recapturing. The intermediate 19.Nxd7 captured the second knight and attacked both Qf6 and Rb8. Black could have captured Nd7 with Bc8; the fork did not force a queen move as the only legal answer. The actual ...Qe7 allowed Nxb8, and ...Rf8 then left time for Bh2 to save the pawn-attacked bishop. These concessions produced the large material advantage.

The proposed knight exit Nc6 was initially misjudged: I relied on d5's protection and overlooked Black's b7 pawn, which could capture a knight on c6. I caught this before submitting Nc6, but only after having used that false exit in earlier analysis of Nxb8. A defended knight is still lost to a cheaper pawn capture. The knight remained on b8 until Black later placed the bishop on d7, allowing Nxd7 and Nf6+.

The central e5 and exd6 opened the e-file and created a bishop-supported passed pawn on d6. Black played ...Qxe1, and Qxe1 took the queen. I had checked the unplayed continuation ...Rxe1 Rxe1, with the a1 rook reaching e1 after d1 was vacated. Black instead played ...Bd7. Nxd7 removed the bishop; the analogous ...Rxe1 Rxe1 would leave Black with only king and pawns, but Black again declined and retreated to d8. The actual result therefore depended on additional material concessions, not merely on the earlier knight fork.

After Nf6+ Kg7, Qe7 defended the knight and attacked Rd8. Black retreated to h8. The d-pawn reached d7 and promoted while Black advanced b6–b5. Before choosing the finish, I rejected the unplayed 30.Qf8+ Rxf8 31.Qxf8+ because the last queen would no longer be protected: Kg7 could capture it on f8. This was another initially missed final king recapture, corrected before submission.

The actual 30.Qxh8+ used the promoted queen to capture the rook. Kxh8 was the only answer: Qh8 covered f8/g8/h7/h6, Nf6 also covered g8/h7, Qe7 protected Nf6 against Kxf6, and Black's own f7/g6 pawns occupied those escapes. Then 31.Qf8# covered g8 and g7 while Nf6 covered h7. No remaining black piece could capture the queen or interpose on g8. The referee confirmed mate.

Useful checks included the intermediate knight fork, the complete rook recapture, preserving queen support for Nf6, and the final mating-square audit. The repeated omissions of pawn attacks, friendly blockers, and king recaptures show that the existing protocol remains inconsistent; no new checklist item or training-success claim is warranted. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 5,263,546 tokens; not per-game or whole-account usage.

## Game 24 — Black, elo-1800-setting, 0–1

Won by 66...Rh3# (132 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 11 wins and 13 losses; the 1800 setting is 4 wins and 4 losses; skill 0 remains 7 wins and 1 loss; maximum strength remains 0 wins, 0 draws, 8 losses. The target remains unmet. The provisional engine-relative estimate is 1770 with a 1550–2000 interval, based on 16 weaker-setting games and excluding the 8 maximum-setting games; it is not human Elo or evidence of success against the target.

I developed behind ...d5/...c5/...e6 and castled on move 7. The central ...e5 and exchanges on e5 opened Bd6–e5–d4–c3–b2–a1. White's 11.Ba3 left Ra1 available to ...Bxa1 Qxa1, giving me the exchange. ...Qa5 defended c5 and attacked Ba3. After ...Ne4 Nxe4 dxe4, I developed the rook to d8. The later ...Qd2 attacked both Qc1 and Be2, with Rd8 behind the queen, and ...Qxc1 Bxc1 removed the queens. I rejected a premature rook entry on d2 because Bc3 would fork Qa5 and Rd2; this was a mental geometric check, not a proved evaluation of all alternatives.

The extra rook did not make the middlegame simple. White retained two bishops and advanced its king and kingside pawns. I used ...b6/...Bc6, doubled the rooks on the d-file, and then moved toward the kingside with ...g6, ...gxh5, ...f6, and ...Rg7. After Bxh5 attacked Re8, ...Ree7 saved the rook. White's Bb2 then introduced Bxf6, which would attack both rooks on e7 and g7. The played ...Be8 attacked Bh5, and Bxe8 Rxe8 exchanged one bishop pair. Moving the king to f7 became possible after the bishop on h5 had gone.

After ...Reg8, White's 34.g5 was answered by ...Rxg5. I retained f6 as a blocker of Bb2's diagonal to g7. The alternative pawn capture ...fxg5+ would open that diagonal once White answered the pawn check, while the rook's exits were obstructed by Black's own king and pieces and White's f5 pawn. This was a local danger identified during play, not a proved losing variation. White's Kxe4 removed my advanced central pawn; rook checks then drove the king away from f5. After Rxh7+ I interposed ...R8g7. The actual Rxg7+ Kxg7 was legal because f6 still blocked Bb2's attack on g7. Only after Kf3 did I take f5 with check; the king was then too far away to recapture the rook.

The ending had rook against bishop with pawns. I centralized the king and advanced ...f5, then transferred the rook to b8 and used ...a6/...b5 to open the file. White's e4 allowed ...fxe4, creating the passed e-pawn. The sequence axb5 axb5 cxb5 Rxb5 used the a-pawn for the first recapture; taking immediately with the rook would have exposed it to the c4 pawn. ...Rxb3 removed White's final pawn. The later ...Kd5, ...c4, and ...Kd4 coordinated the king and the two remaining pawns.

Before advancing ...e3 I checked the final rook recapture: with Kd4 supporting e3, Bxe3 could be answered by Rxe3 without allowing the white king to take the rook. After 58.Kf3, the tempting ...Kd3 would instead obstruct Rb3's route through c3/d3 to e3. White could take the pawn with Bxe3, and Kxe3 would be illegal because Kf3 protected e3. I chose ...Rd3. White's Kg4 then moved out of capture range, allowing ...e2. Against Bb2+ I moved to d5. White's Bc3 covered e1 through d2, so I captured the bishop with ...Rxc3 before promoting.

After ...e1=Q, ...Qe5+ used the king's protection of e5. ...Rf3 cut off the f-file and left White only h6 or h7; the actual Kh7 allowed ...Qg5. The queen covered g6/g7/g8 and h6, leaving Kh8 as the sole move without stalemate. Then ...Rh3# checked on the h-file while Qg5 covered g7 and g8. The referee confirmed mate.

Useful checks included the bishop fork of the rooks, retaining a pawn that blocked a bishop ray, the legal king recapture in the rook exchange, using the pawn before the rook in the b-file exchanges, avoiding a king move that obstructed the rook, and removing the bishop before promotion. These are individual successful checks, not proof that the protocol is reliable. The game still involved excessive remote analysis and repeated corrections, including a long search for a simple queen-and-rook finish. The win depended on an early material concession and subsequent weaker-setting play. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 5,836,916 tokens; not per-game or whole-account usage.

## Game 25 — White, full-strength, 1/2–1/2

The referee recorded a draw by threefold repetition after 37.Kb2 (73 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 11 wins, 1 draw, and 13 losses. Maximum strength is now 0 wins, 1 draw, and 8 losses: the first half-point, for a score of 0.5/9, approximately 5.56%. The goal remains far from achieved. One draw does not establish sustained improvement, and the final position had three fewer white pawns. I have not established that it was defensible without Black's repeated checks.

After d4/c4/Nf3/Nc3, Black challenged the center with ...c5. The sequence cxd5 cxd4 Nxd4 Nxd5 e4 Nxc3 bxc3 left c3/e4 pawns, and ...e5 drove the remaining knight back to f3. I checked the legal king recapture before the queen trade ...Qxd1+ Kxd1. Be3, Kc2, Bd3, and Rhd1 developed the pieces. Black's ...Ba3 restricted the king's queenside routes, while ...Be6 continued to attack a2, initially defended by Ra1.

The maneuver Nh4–f5–g3 met ...g6 and ...Nc6 without producing a concrete gain. Kb1 freed c3 from the c-file pin but obstructed Ra1's horizontal movement. Bc1 challenged Ba3, but ...Bc5 attacked f2, so I returned to e3 and exchanged bishops with ...Bxe3 fxe3. After ...Na5, Ne2 defended c3 against Rc8. Black's ...Nc4 then attacked the undefended e3 pawn. The reply Bxc4 removed that knight, but ...Rxc4 attacked e4 after its bishop defender disappeared. I chose Rd3 to hold c3/e3, and ...Rxe4 took the first pawn. This is the observed deterioration, not proof that all earlier alternatives lost a pawn.

Ng3 attacked the rook and Kc2 freed Ra1 while defending Rd3/c3. I rejected h3 while h2 was the knight's sole defender: ...Rxg3 would then capture the knight without a recapture, since Pe3 blocked Rd3's horizontal route. Rd2 defended g2 in preparation for ...h4. The subsequent Nf1 kept that second-rank defense clear; Ne2 would instead have blocked Rd2's line to g2. The move a3 took the a-pawn off Be6's diagonal before using the a1 rook.

Black doubled the rooks with ...Rgc4. A proposed Rd3 defense of c3 would allow ...Bf5 to attack and pin that rook against Kc2. I moved to b2 and conceded c3 instead. I did not prove that the pin forced every possible material concession. After ...Rxc3, I caught a concrete danger before moving the d2 rook: the illustrative Rd6 Rb3+ Ka2 Rc2# would leave no interposition, capture of the checking rook, or king escape. Ra1 and Pa3 would occupy the king's own escapes, and Be6 would protect Rb3. The actual Rad1 cleared a1 and kept Rd2 available against a rook check on c2.

After ...Rb3+ I chose Ka2 to keep a3 defended. Black then played ...Rxe3+, moving the rook off b3 and uncovering Be6–d5–c4–b3–a2. Nf1 attacked e3, but Nxe3 would leave that bishop check unanswered and was therefore illegal. My earlier argument that the knight defended e3 did not survive the king's relocation onto the bishop diagonal. I recognized the check before submission and moved to b2, but Black had won the third pawn and retained the rook. This was a tactical failure despite the absence of illegal attempts.

The remaining moves repeated ...Rb3+ against Kb2 and ...Rbc3+ against Ka2. I retained the same legal king escapes. The referee automatically recorded the threefold-repetition draw after 37.Kb2. I did not inspect the opponent's search, evaluate the final position with an engine, or establish why it chose that sequence. The recorded result is a draw; it does not prove a forced perpetual check from the earlier position.

The next positional trial is to make both rooks usable before spending further tempi on a wing-knight maneuver in a queenless position, unless a concrete tactical reason takes priority. This is a working hypothesis, not a demonstrated improvement. The existing tactical checks remain necessary: the successful mating-net check did not prevent the later missed discovery against e3. Analysis was again excessively long and repeatedly corrected basic geometry. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 5,978,412 tokens; not per-game or whole-account usage.

## Game 26 — Black, full-strength, 1–0

Lost by 45.Qh8# (89 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 11 wins, 1 draw, and 14 losses. Maximum strength is 0 wins, 1 draw, and 9 losses, scoring 0.5/10 = 5%; skill 0 remains 7 wins and 1 loss, and the 1800 setting remains 4 wins and 4 losses. The goal remains far from achieved. The provisional engine-relative estimate remains 1770 with a 1550–2000 interval from the 16 weaker-setting games, excluding all 10 maximum-setting games; it is not human Elo or evidence of target success.

The opening used ...e5, ...Nc6, ...a6, ...Nf6, ...Be7, and castling. The queenside knight then spent several moves on a5–c4–b6–c8 as White advanced b3 and a5. White gained central space with d5. I intended 15...Bg5 to exchange the restricted bishop and clear e7 for the knight, but failed to audit the intended queen recapture: after 16.Bxg5, the proposed ...Qxg5 would allow Nf3xg5, losing the queen to the knight. I recognized that only after White had captured the bishop. The actual ...f6 blocked Bg5's diagonal to Qd8, and White retreated with Be3, keeping the extra bishop. This was a concrete piece-losing error, not a sound exchange plan.

I redeployed the knights, connected the rooks with ...Qd7, and tried to blockade the advanced d-pawn. After c5 dxc5 bxc5, ...c6 prevented a c6 pawn fork of Qd7/Bb7, but White's d6 then drove Ne7 to g6. The sequence Bb3+ Kh8 Bxa4 bxa4 Rxa4 traded a bishop for the other knight and cost a pawn. ...Qf7 and ...Bd7 kept a blockade on d7 while freeing the remaining rook's route to a8. These local defensive purposes do not establish an adequate position after the earlier bishop loss.

Later ...Nf4 and ...f5 were met by Bxf4 exf4, removing White's last bishop and Black's last knight. White's e5 cleared the fourth rank, so ...g5 defended f4 against Rb4. Rb7 aligned the bishop on d7 with the queen on f7; ...Qe6 changed that alignment. ...Rg8 supported g5, and ...f3 attacked Ne2 and g2. After Nd4 attacked the queen, I rejected ...Qe7 because Pd6 could capture it, and chose ...Qe8. This was a successful correction of a different basic capture omission in a remote variation, not evidence of generally reliable calculation.

After e6 Bxe6 Qa1, the queen on a1 aimed toward Kh8, initially blocked by White's own Rb2 and Nd4. I used ...Rg6 to free g8 and cover g7, then answered Nxe6 with ...Qxe6 to retain that rook. White's 42.Rb8+ came from the upper rook, b7–b8; the lower rook still blocked Qa1. The tempting ...Raxb8 would allow Rxb8#, simultaneously opening the queen diagonal and checking along the eighth rank. I correctly rejected that capture, but spent excessive time on other branches and failed to finish the actual king-move line correctly.

The played 42...Kg7 was legal because Rb2 still blocked Qa1's diagonal. White then used 43.R2b7+, giving double check from the rook and queen. ...Kh6 was the only king escape. White's 44.Rxh7+ forced ...Kxh7, and 45.Qh8# finished: Rb8 protected Qh8, while also obstructing Ra8's attempted capture of that queen. Qh8 covered g8/g7/h6, and Black's own Rg6 occupied g6. There was no capture of the checker, interposition against the adjacent queen, or king escape. The referee confirmed mate.

During the earlier calculation I examined Rh8+ and noticed that Ra8 could capture that rook once b8 was vacated. That did not answer Qh8#: the rook stays on b8, protecting h8 and blocking Ra8. Focusing on one superficially similar mating attempt caused me to miss the stronger queen move. I recognized the actual finish only after Rxh7+ had appeared on the board. I have not proved that any earlier alternative saved the already inferior position.

The existing protocol already required checking cheap captures after a queen recapture and inspecting all immediate queen checks after a king move. Adding further checklist length is not a substitute for applying those checks to the exact candidate. Before the next game I rehearsed these two concrete failures: Nf3 captures a queen on g5; Qh8 is protected by a rook that remains on b8 and blocks Ra8. The positional trial remains to finish useful development before repeated wing-knight moves. Neither rehearsal nor this review establishes improved performance. No external sources, engine analysis, automated chess analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 6,403,626 tokens; not per-game or whole-account usage.

## Game 27 — White, skill-0, 1–0

Won by 25.Qh7# (49 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 12 wins, 1 draw, and 14 losses. Skill 0 is 8 wins and 1 loss; the 1800 setting remains 4 wins and 4 losses; maximum strength remains 0 wins, 1 draw, and 9 losses, scoring 5%. The target is unmet. The provisional engine-relative estimate is 1780 with a 1560–2010 interval from 17 weaker-setting games, excluding the 10 maximum-setting games; it is not human Elo.

I developed both knights, established d4/c4/e4, placed the king's bishop on d3 to support e4, castled, and developed Be3. Against ...Nxd4 I used Nxd4, checking the possible ...cxd4 Bxd4 recapture. Black instead castled, allowing Nf3 to save the extra knight. ...b5 then left a pawn available to Bxb5. Black's ...Nxe4 allowed Nxe4, and after ...f5 I used Nxc5, initially supported by Be3. These were substantial weaker-setting concessions.

After ...f4, Bd4 preserved the knight's defender. The subsequent ...Qb6 attacked Bb5 and added a queen behind the c5 exchange. I chose Bc4 without completing the changed capture chain: ...Bxc5 Bxc5 Qxc5 would remove both my c5 knight and its bishop defender in return for Black's bishop. I recognized the extra queen recapture at the next position, before submitting Bxc5, and expected to retain only the extra knight. This was another incomplete exchange audit, despite the prior review. Black actually declined ...Qxc5 and played ...Rd8, leaving its queen on b6 available to Bxb6.

Before Bxb6 I checked the possible ...Rxd1 and the legal rook recapture on d1. Black instead played ...Rd5, allowing Bxd5. I accepted the possible ...exd5 as a favorable rook-for-bishop exchange, but Black again declined and played ...Bd7. The same bishop could then reach a8 through c6/b7 and take the last rook. Black's ...axb6 captured my other bishop, and Qxd7 removed the final black piece. The resulting overwhelming advantage depended on these concessions; it does not show improvement against maximum skill.

After ...h6, I calculated and played Qe8+ Kh7 Be4+ g6 Qxg6+ Kh8 Qh7#. Qe8 covered the eighth rank and f7. After Be4+, Black's own h6 pawn blocked that king escape and ...g6 was the available interposition. The bishop protected Qxg6 against Kxg6, then protected Qh7 along e4–f5–g6–h7. Qh7 covered g7/g8, and Black had no piece able to capture the checker or interpose. The referee confirmed mate.

The finish was correctly checked, but the c5 exchange omission remains a failure. No new checklist item is needed: the existing requirement to continue through the last recapture was not applied after ...Qb6 changed the position. No external sources, engine analysis, automated chess analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 6,503,498 tokens; not per-game or whole-account usage.

## Game 28 — Black, skill-0, 0–1

Won by 45...Rf1# (90 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 13 wins, 1 draw, and 14 losses. Skill 0 is 9 wins and 1 loss; the 1800 setting remains 4 wins and 4 losses; maximum strength remains 0 wins, 1 draw, and 9 losses, scoring 5%. The target is unmet. The provisional engine-relative estimate is 1780 with a 1570–2010 interval from 18 weaker-setting games, excluding the 10 maximum-setting games; it is not human Elo.

I developed both knights and bishops, castled on move 5, moved the queen off d8, and developed the a8 rook to d8 before the later knight redeployment. ...Bxe3 fxe3 removed one bishop pair. Against Bb5 I used ...a6, and Bxc6 bxc6 left me with doubled c-pawns. I put the remaining knight on d7 to keep e5 defended before ...d5. This followed the development trial more closely than game 26, but it did not prevent subsequent positional and tactical problems.

After ...dxe4 dxe4, I used ...Qf6 to support e5. I considered several knight departures that would uncover the f-file but did not anticipate the actual 18.Nd4. It simultaneously exposed the rook's attack on Qf6 and attacked Be6/c6. The played ...Qg6 retained the bishop's defense but allowed Nxc6 to win a pawn and attack Rd8. I retreated to e8. I have not established that the pawn loss was forced from the earlier position; this was an incomplete audit of the knight's available moves.

...f5 and ...fxe4 recovered the e4 pawn temporarily. After 22.Rxf8+, I initially intended a rook recapture, then caught the unplayed ...Rxf8 Ne7+: the knight on e7 would check Kg8 and attack Qg6, while the rook would no longer be on e8 to capture it. I instead used ...Nxf8 and retained Re8. The later ...Bd7 used the square vacated by that knight, attacked Nc6, and cleared the rook's defense of e5. I also checked that White could use Qc4+ after the bishop left e6; the actual check was answered by ...Kh7.

After Na5, ...Bf5 defended e4 with a bishop as well as the queen. White's g4 drove the bishop back to e6, and Qxe4 Qxe4+ Nxe4 exchanged queens with White a pawn ahead. The queen capture on e4 gave check along e4–f3–g2–h1 because the g-pawn had left g2. I did not establish an adequate middlegame position merely by finding legal recaptures and queen retreats.

The decisive concession came after 28...Bd5, which pinned Ne4 to Kh1 along d5–e4–f3–g2–h1. White's Kh2 removed the pin but did not defend the knight, allowing ...Bxe4. The bishop then took c2. ...Kg6 legally attacked Rf7, and Rf2 allowed ...Bxa4. Against Ra2 I retreated to b5, where Pa6 protected the bishop and the bishop protected a6. White's Rc2 attacked c7; ...Ne6 developed the knight and defended that pawn.

After h4, a previously considered ...Ng5 was no longer safe because the h4 pawn could capture it. I used ...h5 instead and verified the actual king capture after gxh5+: on h5 the king was not attacked by White's h4 pawn, Kh2, Na5, or Rc2. The played ...Kxh5 was legal. White's 37.Rc5 then allowed ...Nxc5. I accepted the possible bxc5 as a favorable rook-for-knight exchange, but White instead moved its king to h3. ...Nd3 saved the knight with support from Bb5, and ...Nxb4 removed the remaining queenside pawn. Only after White's king returned to h2 did I take h4; while it was on h3, that king had defended h4.

For the finish I used ...Rf8 and ...Rf2+ to force the king to the first rank, then ...Kg3 to cover f2/g2/h2. White's 44.Nc4 obstructed Bb5's protection of f1. An immediate ...Rf1+ would therefore permit Kxf1 from g1. I used ...Bxc4 first, removing the knight and restoring the bishop's line through d3/e2 to f1. White had only Kh1 available: its e4 pawn was blocked by e5, f1 was bishop-controlled, and the second-rank king squares were covered. Then ...Rf1# checked along f1–g1–h1; Kg3 covered g2/h2, and no white piece could capture or interpose. The referee confirmed mate.

Useful checks included preserving Re8 against the knight fork, exploiting the actual pin on e4, revisiting pawn attacks after h4, verifying both king captures, and removing the blocker before the final rook check. The win depended on the undefended knight, the rook concession, and White's refusal to recapture on c5. The earlier missed Nd4 and the excessively long, repeatedly corrected analysis remain limitations. These local successes do not establish improvement against the target. No external sources, engine analysis, automated chess analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 6,681,379 tokens; not per-game or whole-account usage.

## Game 29 — White, elo-1800-setting, 1–0

Won by 40.Qdh8# (79 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 14 wins, 1 draw, and 14 losses. The 1800 setting is 5 wins and 4 losses; skill 0 remains 9 wins and 1 loss; maximum strength remains 0 wins, 1 draw, and 9 losses, scoring 5%. The target remains unmet. The provisional engine-relative estimate is 1810 with a 1610–2040 interval from 19 weaker-setting games, excluding the 10 maximum-setting games; it is not human Elo.

I developed both knights and bishops, castled, and placed the rooks on d1/c1 before the later knight maneuvers. After ...cxd4, Nxd4 retained the e-pawn. Black advanced the a-pawn to a3; b3 contained it and supported Bc4. The e4–e5 advance supported d6. Ne4–d6 met ...Bxd6, and exd6 produced a bishop-supported passed pawn. This followed the development trial, but one weaker-setting win does not validate that trial against maximum strength.

After ...Qb6, both Bb5 and Nd4 were under pressure from the queen and rook. Qc4 defended Bb5 diagonally and Nd4 horizontally while attacking Rd5. I checked the final queen recaptures in the possible rook exchanges. Earlier in this calculation I had temporarily forgotten that Qe2 also defended Bb5 through d3/c4; changing a queen's square required rebuilding those lines. Qc7 used Pd6's protection and attacked the queen on b6, which retreated to a5. Qxf7 won a pawn. After ...e5 attacked Nd4 and blocked Bg3's support of d6, Nf3 Rxd1+ Rxd1 cleared the d-file and left the remaining rook behind the passer. Black's ...Bf5 then protected Ng6, so Qxg6 was no longer a free capture. Bc4 saved the bishop that had lost Nd4's protection.

The fork Nh4 attacked Bf5 and Ng6. Black answered ...Ne7, allowing Qxe7 to take an undefended knight. I used the queen rather than treating dxe7 as equivalent: moving Pd6 would open the d-file and allow ...Rxd1+, requiring a different calculation. Bxe5 then won the central pawn with Qe7's support. The subsequent ...Nh5 defended g7, so a queen capture there would still be answered by ...Nxg7; bishop support against the king did not remove that knight capture.

Be2 attacked Nh5. Black's ...Rd7 attacked Qe7 but left the rook capturable, and Qxd7 won it. I had allowed for the possible ...Qxe5, which would return a bishop while retaining a larger advantage. Black instead played ...Nf6 against the queen, and Bxf6 gxf6 exchanged that knight for a bishop. Qe8+ Kh7 cleared d7 for the pawn. After d7, Black's ...Qd8 simply left its queen available to Qxd8. The knight, rook, and queen concessions were decisive; I have not proved that the earlier middlegame forced them.

Qxf6 removed the f6 pawn and cleared d8. After ...Bc6, d8=Q and ...Bd5, the promoted queen reached h8. Qf6 protected h8 through g7 and covered g6/g7; Qh8 covered g8 and the h-file escapes. The adjacent check could not be interposed against, and Bd5 could not capture either the checker or its defender. The referee confirmed mate. I also considered the unplayed ...Be8 after promotion, which would obstruct the promoted queen's path and require a different continuation.

Calculation remained inefficient and repeatedly corrected basic geometry before submission. In particular, I spent substantial time on a proposed Bc6 before noticing that b7 could capture the bishop, repeating game 23's cheap-pawn-capture omission. I also had to restore Qa5's control of d8 in promotion variations. The next execution focus is to perform the existing landing-square capture check before expanding branches, rather than adding more checklist text. No external sources, engine analysis, automated chess analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 6,897,352 tokens; not per-game or whole-account usage.

## Game 30 — Black, elo-1800-setting, 1–0

Lost by resignation after 73.f6 (145 plies), confirmed from the PGN. No illegal submissions. Overall: 14 wins, 1 draw, 15 losses. The 1800 setting is 5–5; skill 0 is 9–1; maximum strength is 0 wins, 1 draw, 9 losses. The provisional engine-relative estimate is 1780, with a 95% credible interval of 1590–1990, from 20 rated games; the 10 maximum-setting games are excluded from that estimator. This is not human Elo. The operator's authorized objective clarification during this game superseded the former maximum-strength success criterion: improve measured Elo through focused learning and periodic evaluation, retaining the active goal and all usage/results.

The early queen exchange followed by ...e4 forked Bd3/Nf3 and won a knight. I subsequently failed to preserve the resulting coordination. After ...Rd2 Bxe4, my ...Rxb2 allowed Bxf5 to take the other knight. I had also omitted the bishop's possible final recapture on b1 in a proposed rook-exchange line. These were further failures to account for the defense and capture lines changed by each move. Later ...Rxh3 allowed Bxf5, so that sequence exchanged pawns rather than simply recovering one.

The a-file exchanges and ...Rxa6 eventually left me a pawn ahead in a rook-and-opposite-bishop ending. I let the white e-pawn advance while pushing my c-pawn. After e6 and e7, ...Bxe7 Rxe7 surrendered the bishop for that passer. I have not established the correct earlier defense or proved that the loss was forced at an earlier point. The advanced c-pawn subsequently tied down White's rook and bishop; I retained both king and rook protection until White chose Bxc2+ Rxc2 Rxc2 Kxc2.

I misjudged the resulting pawn ending: Black Kc2/Ph5 against White Ke3/Pf4, White to move. The actual Kf2 Kd3 f5 h4 Kg2 Ke4 f6 showed why simply counting pawn pushes was inadequate. White's king could stop the h-pawn while the f-pawn outran my king. In the final position, ...h3+ permits Kxh3, and ...Kf5 f7 ...Kg6 f8=Q does not catch the pawn. These are my own calculations, not an engine-certified endgame verdict. I resigned when I judged the promotion unavoidable.

No external sources, engine analysis, automated chess analysis, or delegated advice were used during the game. Analysis remained extremely long and repeatedly corrected basic geometry; no improvement claim follows from the review. Observed cumulative active-goal usage after the game: 7,801,899 tokens; this is not per-game or whole-account usage. Before starting game 31, carry out the separately recorded pawn-race practice trial and then evaluate transfer at game 36.

## Game 31 — White, full-strength, 0–1

Lost by resignation after 42...Rd3 (84 plies), with no illegal submissions. Overall: 14 wins, 1 draw, 16 losses. Maximum strength: 0 wins, 1 draw, 10 losses. The unchanged Elo estimator remains 1780 [1590, 1990], based on 20 rated weaker-setting games; it excludes the 11 maximum-strength games. This is the first game of the predeclared games 31–36 evaluation block following pawn-race practice trial 01.

After the central exchanges and queen trade, I developed the bishops, moved the king to c2, and put the rooks on d1/b1. The bishop exchanges produced a passed d-pawn. The concrete material error was 21.e4: I noticed that ...Nxe3+ would capture the e3 pawn and fork Kc2/Rd1, but moving that pawn did not stop the knight from playing ...Ne3+ without a capture. The same checking fork remained available. Kd3 Nxd1 Rxd1 left me down the exchange. The existing immediate-check audit was not correctly applied; this was not a lack of checklist text or a pawn-race error.

I later used c4 to support d5, moved the king off the d-file, and sought knight activity. Nf7+ displaced the king from its defense of e5, allowing Nxe5, but the doubled rooks captured g2 and the f-pawn then took e4. Black's second-rank control repeatedly made a quiet pawn push impossible. Before move 38 I caught the threatened ...Rg1 mate against Ke1: Rc2 cut off the second rank and my own Rd1 obstructed a capture of the checking rook. After Kf1 and ...Rxh2, I similarly avoided ...Rh1 mate with Kg1. These local checks did not repair the material disadvantage.

The actual ...Rcg2+ Kf1 Rh1+ forced Kxg2 and opened the first rank for ...Rxd1. I recognized the skewer before the forced king capture; taking g2 was not a net rook gain. Ne3 attacked the remaining rook and blocked the e-pawn, but ...Rd3 attacked the knight again. I resigned with Kg2/Ne3/Pa2/Pd6 against Ke6/Rd3/Pa7/Pe4/Pg7/Ph7. In my own illustrative continuation, Nc4 Rxd6 Nxd6 Kxd6 leaves one white pawn against four black pawns. Other knight retreats generally abandon d6; I have not engine-certified the full ending.

Trial observation: no pure pawn ending was actually played. I did explicitly examine the kings and remaining pawns in two proposed liquidations. Earlier, a d2 exchange would let Black take d6 and leave two white pawns against four; after h2 was lost, the final illustrative liquidation leaves one against four. These are unverified counterfactual calculations, not independent proof of transfer. The game provides no rating improvement and shows recurrence of a more basic checking-fork omission. Complete the planned evaluation block before deciding the next learning method.

No external sources, engine analysis, automated chess analysis, or delegated advice were used during this measured game. Analysis remained excessively long and required repeated corrections of attack geometry. Observed cumulative active-goal usage after the game: 8,059,833 tokens; not per-game or whole-account usage.

## Game 32 — Black, full-strength, 1–0

Lost to 30.Qxh8# (59 plies), confirmed by the referee and PGN; no illegal submissions. Overall: 14 wins, 1 draw, 17 losses. Maximum strength: 0 wins, 1 draw, 11 losses. Elo remains 1780 [1590, 1990] from 20 rated games, with 12 maximum-strength games excluded by the fixed estimator. This is game two of the planned games 31–36 evaluation block.

I completed minor-piece development, castled, and brought the rooks to e8/d8. The sequence ...Nb4, ...c5 and d5 closed the center. I later played ...g6 and ...Bg7, then ...h5 when White arranged Qc1/Bd2 against h6. These moves weakened the kingside while the queen and other pieces remained on the queenside. After ...Qxb5, ...c4 and ...Qc5, White offered 24.Ndf5. I accepted with ...gxf5 25.Nxf5, gaining a knight for a pawn while opening the king position. I have not established that accepting the sacrifice was itself a forced loss or that the earlier defense was adequate.

I tried ...h4 to obstruct a rook lift to g3. After Bh6, I chose ...Bh8, then answered Qg5+ with ...Kh7. White's Bg7 was protected by Nf5 and attacked Bh8/Nf6. I recognized that ...Bxg7 would permit Qxg7 mate, but chose ...Nxe4 to attack Qg5 and control g3 without completing the immediate queen-check audit. White played Qh5+, ...Kg8, Qxh8#. The queen captures the bishop on h8; White's Bg7 protects h8 and covers f8. Black's f7 pawn obstructs another king escape. The adjacent queen check cannot be blocked, and no black piece can capture the queen. The referee confirmed the mate.

My reasoning dwelt on possible Bxh8 and rook-lift continuations after ...Kg8 while omitting the simpler Qxh8 capture. I also carried attack and recapture assumptions between hypothetical Qh4 and actual Qh5 positions before correcting them. This is further evidence that long analysis and an existing checklist have not made immediate forcing-move coverage reliable. The material gain did not compensate for the mating attack. I have not proved which earlier alternative would have saved the position.

Trial observation: no pawn ending or candidate pawn liquidation arose. The pawn-race practice remains untested by this game. Preserve the planned evaluation after game 36; the recurring immediate-check omission is a candidate for the next focused learning trial, not grounds to claim success for the current one. No external sources, chess-analysis tools, automated analysis, or delegated advice were used during the measured game. Observed cumulative active-goal usage after the game: 8,418,026 tokens; not per-game or whole-account usage.

## Game 33 — White, skill-0, 1–0

Won by 38.Re8# (75 plies), confirmed by the referee and PGN; no illegal submissions. Overall: 15 wins, 1 draw, 17 losses. Skill 0: 10 wins and 1 loss. Maximum strength remains 0 wins, 1 draw, 11 losses; the 1800 setting remains 5–5. The provisional engine-relative Elo is 1790 [1600, 1990] from 21 rated games, excluding 12 maximum-strength games. This small movement from the trial baseline of 1780 [1590, 1990] does not establish improvement.

After d4/c4/d5 and the central exchange, I blocked ...Qa5+ with Nc3, then used Bd2 to remove the pin before relying on that knight to defend e4. Rb1 met the queen's threat to b2. Both bishops and knights developed, I castled, and Rfe1 preceded the central e5 break. Black answered e5 with ...Nxe5, then played ...g5 after Nxe5 rather than recapturing. I used Nxf7 to fork Qd8/Rf8, and after ...Rxf7, Bxg5 saved the attacked bishop and won a pawn. The further ...c4 allowed Bxc4 to gain another pawn.

I retreated Bd3 against ...Rc8, then exchanged Bxe7 Rxe7 Rxe7 Qxe7 after ...Ng4 exposed Black's e7 bishop and threatened f2. Removing the f-file rook changed the recapture situation on f2. The subsequent h3 drove the knight to e5. Bf5 attacked Rc8. I anticipated ...Nf3+ and chose gxf3 while considering the immediate queen checks. Black actually replied ...Rxc3, allowing Qxc3. That concession removed the remaining black rook; I have not proved that the preceding play forced it.

After ...Bg6, Bxg6 was intended as a bishop exchange, but Black declined the pawn recapture and checked with ...Qg5+. Kf1 left the g-file. Against ...Qh6, Bf5 both saved the bishop and defended h3; against ...Qg5, Bg4 put it under the protection of f3/h3. I then played Re1. Black's ...Qc4+ was a checking move I had already noticed could be captured by Qxc4. It lost Black's queen. The large winning advantage depended on these weaker-setting concessions.

The finish was Qf4+ Kg7 Re7+ Kg6 Qf5+ Kh6 Re6+ Kg7 Qf6+ Kg8 Re8#. I calculated the final four-move forcing sequence before starting it, accounting for the queen's support of Re6 and the rook's support of Qf6. At mate, Re8 covers the eighth rank, Qf6 covers f7/g7, and Black's own h7 pawn occupies the remaining nearby square. There is no black piece that can capture or interpose; the referee confirmed mate.

No pawn ending or candidate pawn liquidation occurred, leaving trial 01 untested in this game. Useful local checks were removing the c3 pin, accounting for rook/queen recaptures on e7, and anticipating the knight and queen checks. I still spent unnecessary analysis on rejected bishop checks and simple mating alternatives before correcting their protection geometry. These observations are not an independent accuracy score. No external sources, chess-analysis tools, automated analysis, or delegated advice were used. Observed cumulative active-goal usage: 8,494,679 tokens; not per-game or whole-account usage. Continue the predeclared block through game 36.

## Game 34 — Black, skill-0, 0–1

Won by 32...Rh1# (64 plies), confirmed by the referee and PGN; no illegal submissions. Overall: 16 wins, 1 draw, 17 losses. Skill 0: 11 wins and 1 loss. Maximum strength remains 0 wins, 1 draw, 11 losses; the 1800 setting remains 5–5. Elo is 1790 [1600, 2000] from 22 rated games, with 12 maximum-strength games excluded. There is no established sustained rating improvement.

I developed both knights and bishops and castled. White's b3 removed the b2 pawn's defense of Nc3. I used ...Bb4 to pin that knight, then ...Ne4 after Qd3 defended it. Against Rc1 I calculated ...Bxc3+ Rxc3 Nxc3 through the eventual Qxc3: a rook and knight are removed in exchange for a bishop and knight, winning the exchange. White inserted Bg5 against Qd8 before recapturing. I used ...Qd7; the tempting ...Qxg5 would have allowed Nf3xg5, the same geometry missed in an earlier game. The played line preserved the exchange gain.

...Rae8 activated the rook. ...Bg4 both attacked Nf3 and uncovered pressure on Be2. After h3, ...Bxf3 Qxf3 removed the knight that had supported d4. I played ...dxc4, then recognized that White's Be3 restored a defender of d4. The actual ...Nxd4 remained supported by Qd7 and attacked Qf3; a possible Bxd4 could be met by ...Qxd4. White instead played Qh5, and ...Nxe2+ Qxe2 exchanged the knight for the other bishop while retaining the extra pawns.

...cxb3 and ...bxa2 produced an advanced pawn. ...Qe6 protected it; ...Qa6 later protected both a2 and the eventual promotion square a1 along the same file. I correctly rejected an immediate promotion after White's Bh6: Rc1 would block the first rank, so ...a1=Q would not give check, and Qxg7 would be mate with Bh6 supporting the queen. The actual ...Qxh6 crossed the open sixth rank, removed that bishop, and answered the threat. After Rf1, ...Qa6 restored the pawn support. White then captured the defended pawn with Qxa2, allowing ...Qxa2 to win its queen. This was a major weaker-setting concession.

I used ...Re2, ...Rxf2 and ...Rxf1 to remove White's last rook and the f-pawn. Against Kh2/Pg2/Ph4, ...h5 blocked the h-pawn and controlled g4. The g2 pawn was pinned on the second rank by Qa2. After Kg3, ...Qf2+ was protected by Rf1. White chose Kh3; ...Rh1# then covered h2/h3, Qf2 covered g3, h5 covered g4, and White's own pawns occupied g2/h4. The referee confirmed mate. The unplayed Kh2 branch after ...Qf2+ would allow ...Qxh4 mate by my own calculation.

Trial observation: no pure pawn ending or actual promotion occurred. The new middlegame position did require checking a promotion's check status and the final rook/queen recapture, which overlaps with the practice target. These were my own counterfactual calculations, not an independently established transfer score or proof that the trial caused the result. Preserve the planned evaluation after game 36. Calculation still spent excessive time on remote alternatives and simple conversion positions. No external sources, automated chess analysis, chess-analysis tools, or delegated advice were used. Observed cumulative active-goal usage: 8,650,287 tokens; not per-game or whole-account usage.


## Game 35 — White, elo-1800-setting, 0–1

Lost by resignation after 69...Rf7+ (138 plies), confirmed by the referee and PGN; no illegal submissions. Overall: 16 wins, 1 draw, 18 losses. The 1800 setting is now 5 wins and 6 losses. The provisional engine-relative Elo is 1770 [1580, 1960] from 23 rated games, excluding 12 maximum-strength games. This is below the trial baseline of 1780 [1590, 1990]; neither that small difference nor the broad overlapping intervals establish a change in underlying strength.

The central exchanges left an extra pawn. I met ...Nxd4 with Nxd4 before taking the bishop, avoiding a proposed line where ...Nxf3+ and the opened d-file would attack the queen. Bxb5 gained a pawn, and Bc6/Be4 retained the central recapture. I rejected an early rook move to b1 after noticing the possible queen-for-two-rooks sequence would end in a back-rank mate, then made h3 before activating both rooks. Qe3 and d5 enabled the rook and queen exchanges. My move-27 comment called e5 passed too early: Black's f7 pawn still controlled e6. I noticed that error before the queen exchange; the review corrects the recorded comment rather than silently repeating it.

In the rook ending I brought the king through e2/d2/d3/d4/e4/e5/f5, supported e6, and recaptured after ...fxe6+. Several possible rook trades were examined as pawn endings; Black declined them. Those were my own unverified calculations, not established winning endings. Re5, Rxg5+ and Rxa5 eventually left White with a rook and two pawns against a rook. The a-pawn and h-pawn then advanced with rook/king protection. No claim that this position was a forced win has been independently established.

The critical failure was late and elementary. After 64.h7 Re6+ 65.Kf7 Rf6+, I correctly noticed that Kxf6 would stalemate Kh8: Rg7 and Ph7 cover the remaining king squares. I chose 66.Ke7, and Black played ...Rf5. The actual 67.Rg8+ Kxh7 removed the h-pawn that had protected g8 and placed the black king next to the rook. I then played 68.a6, overlooking the immediate ...Kxg8. My planned continuation had implicitly kept the rook alive. A simple rook retreat such as Ra8 was available in my own postgame inspection; that observation is not a best-move or full-ending verdict.

This is a failure to reconstruct the actual board after a forced capture, not an obscure pawn-race issue. I also repeatedly changed assumptions about h7/g8 protection in hypothetical lines and spent excessive time on distant continuations. Catching the stalemate did not make the next position safe. After 69.a7 Rf7+, the rook was protected by Kg8, promotion would not answer check, and a king retreat would permit ...Rxa7. I resigned rather than claiming a promotion that could not legally occur.

Trial observation: no pure pawn ending was actually played, but this new rook-and-pawn ending directly tested the broader final-capture and king-intervention concern. The missed ...Kxg8 is negative transfer evidence: the short pawn-race practice did not make that check reliable in full play. Earlier correct counterfactual counts and the caught stalemate do not erase the decisive error. Finish game 36 as predeclared, then revise or replace the practice method at the evaluation point. No external sources, chess-analysis tools, automated analysis, or delegated advice were used. Observed cumulative active-goal usage: 8,971,681 tokens; not per-game or whole-account usage.


## Game 36 — Black, elo-1800-setting, 1–0

Lost by resignation after 35.Rfd1 (69 plies), confirmed by the referee and PGN; no illegal submissions. Overall: 16 wins, 1 draw, 19 losses. The 1800 setting is 5 wins and 7 losses; skill 0 is 11 wins and 1 loss; maximum strength is 0 wins, 1 draw, 11 losses. The provisional engine-relative Elo is 1740 [1570, 1930] from 24 rated games, excluding 12 maximum-strength games. This completes the predeclared games 31–36 evaluation block.

I developed, castled, exchanged central pawns, and met Ng5/h4 with ...Be6 rather than opening the h-file. After Nxe6 I used ...fxe6: ...Qxe6 would have lost the queen to Bxe6. ...Nxe4 Qxe4 exchanged the other knight, and ...Qf7/...Rad8 activated the major pieces. I recognized that Ba2 pinned e6 to Kg8 and used ...Kh8 before considering an e6 recapture on f5. These correct local observations did not prevent the later decisive error.

...Rf6 and ...Rg6 put pressure on g3; White answered Kg2. After ...a5, White played Bb1. I noticed one consequence: Qxf5 exf5 Bxf5 would lose a pawn. I responded with 25...Qf6, intending to keep e6/e5 and Rg6 defended, but failed to carry the different exchange on g6 through its last capture. The actual 26.Qxg6 Qxg6 27.Bxg6 removed my rook and queen in return for only White's queen. Calling the rook defended by Qf6 was insufficient because Bb1 recaptured that queen. This is another direct failure of exchange accounting after a new bishop line, not a need for a more elaborate attack plan.

...axb4 and ...bxa3 gained two pawns and created a passer protected by Bd6 through c5/b4. After Ra2, I played ...Nb4 to attack the rook. That knight itself blocked Bd6's diagonal to a3. White's Rxa3 therefore won the pawn safely; my intended ...Bxa3 was not legal while Nb4 remained in the way. I recognized the obstruction only after the pawn had been taken and used ...Nd5 to uncover an attack on the rook. ...Be7 then cleared the d-file, letting Rd8 join e6 in defending Nd5.

I advanced the remaining b-pawn and recaptured Bxd5 with ...exd5. White doubled rooks with Rfd1. The final material was Black Rd8/Be7 and five pawns against two white rooks, Bc1 and four pawns. The advanced a-pawn counterplay was gone, and the doubled rooks pressured d5. I resigned the rook-for-pawn deficit; I have not engine-certified the exact preceding position or a forced mate.

Trial observation: no pure pawn ending occurred. The decisive g6 sequence is nevertheless another recurrence of the broader final-capture concern, and ...Nb4 supplies a separate blocker error. The short pawn-race practice did not make those checks reliable. Analysis remained too long and repeatedly contradicted elementary occupancy and recapture facts. No external sources, automated chess analysis, chess-analysis tools, or delegated advice were used. Observed cumulative active-goal usage after the game: 9,181,135 tokens; not per-game or whole-account usage. Trial 01 is evaluated in its own record; carry out the replacement practice before starting game 37.


## Between games 36 and 37 — replacement practice trial 02

Completed eight short exchange/blocker reconstructions and eleven explicitly supplied legality branches. Four positions were remembered and four were self-composed contrasts with known mechanisms, not an independent test. All supplied legality predictions matched, including the final king capture, blocked bishop ray, bishop recapture and stalemate contrast. The full plan, per-ply inventories, limits and results are in `workspace/trials/exchange-reconstruction-02.md`. Practice finished by 21:58:52 UTC on 2026-09-30. No improvement claim follows from these easy, known examples. Apply the explicit current-position inventory before expanding a tactical branch, then evaluate new-game transfer in the unchanged games 37–42 rotation. Observed cumulative active-goal usage including practice: 9,213,891 tokens.

## Game 37 — White, maximum strength, loss

Completed 2026-09-30 at 22:27:01 UTC; resigned after 27...Rxh8 (54 plies), zero illegal submissions. The recorded PGN is `data/games/000037.pgn.gz`. Record now 16 wins, one draw, 20 losses. The provisional engine-relative estimate remains 1740 [1570, 1930]; this maximum-strength game is excluded from that fixed estimator.

The Nimzo-Indian central and minor-piece exchanges were materially accounted for correctly through 20.dxe5: both sides retained one queen, one rook, one bishop and six pawns. This is an accounting observation, not a claim of equal evaluation or best opening play.

Actual failure: after 22...Qd2, I chose 23.b3 to remove the b2 target and missed 23...Be2. The bishop on e2 interrupted Qe4's defense of Re1 while Qd2 continued attacking that rook. I then correctly rejected the immediate bishop captures on back-rank grounds. My manually calculated illustrative line was 24.Rxe2 Rc1+ 25.Re1 Qxe1+ 26.Qxe1 Rxe1#; this was not played or mechanically checked. That catch came after the damaging position had already arisen.

A second actual failure followed: 24.Qh7+ Kf8 25.Qh8+ Ke7 26.h3 Qxe1+ 27.Kh2 Rxh8. I considered Qh8 as attacking Rc8 but omitted the rook's reciprocal capture of the queen. Once the king left f8, the entire c8-d8-e8-f8-g8-h8 rank was clear. My reasoning carried the king's former blocking effect forward and failed to inspect the actual queen's immediate exposure. Black first took the rook with check, then the queen. Final White inventory was Kh2/Bb1 and six pawns, against Black Ke7/Qe1/Rh8/Be2 and six pawns; resignation followed. No forced-mate claim is needed for that material conclusion.

Trial 02 transfer: failed its no-recurrence criterion in the first measured game. Correct early exchange bookkeeping and a later rejected capture do not offset the actual defender interruption and newly opened rook ray missed in play. Complete the predeclared games 37–42 block, then revise the method as promised; do not infer improvement from the practice legality score or from this game's long analysis. Keep the selected move's actual final board in view, especially a king vacating a rook ray.

## Game 38 — Black, maximum strength, loss

Completed 2026-09-30 at 22:56:27 UTC; resigned after 35.Rxd7+ (69 plies), zero illegal submissions. PGN: `data/games/000038.pgn.gz`. Total record: 16 wins, one draw, 21 losses. Maximum-strength record: zero wins, one draw, 13 losses. Engine-relative estimate remains 1740 [1570, 1930], based on the unchanged 24 rated weaker-setting games.

The Berlin queen exchange and subsequent ordinary trades were accounted for. One fresh changed-blocker decision was applied correctly: after ...hxg4/hxg4 cleared the h-file, 18...Nh4+ 19.Nxh4 Rxh4 traded the knights evenly because Rh8 now had an unobstructed path to h4. The later central exchanges left an exposed f6-pawn, which White won with 33.Nxf6. I did not establish where the resulting positional disadvantage first became avoidable.

Actual target failure: after 34.Kg5, I played 34...Bd7 and treated Kd8 as sufficient protection for that bishop. White played 35.Rxd7+, with Nf6 protecting d7; ...Kxd7 would therefore be illegal. I also reasoned incorrectly about the alternative Nxd7: Rf7 would protect the capturing knight along f7-e7-d7, so the king would not be a valid recapturer there either. No illegal recapture was submitted. The final actual inventory was Black Kd8/Rh2/Pa7/Pb7/Pc7/Pc6 against White Kg5/Rd7/Nf6/Pa2/Pb2/Pc2/Pf5/Pg4. White was a knight and pawn ahead; I resigned without claiming forced mate.

Before ...Bd7, I correctly noticed that 34.Kg5 had changed a proposed ...Rxc2/Rf8+/...Ke7 line: ...Kxf6 would no longer recover the bishop because Kg5 now protected Nf6. I then failed to apply the same king-capture legality principle to the move I actually selected. Extensive remote branching did not replace that final two-ply check. This is a second played recurrence in trial 02, despite the correct earlier h-file exchange. Complete games 39–42 for the declared evaluation, then revise the method; do not describe these catches or practice results as learning success.

## Game 39 — White, skill 0, win

Completed 2026-09-30 at 23:17:08 UTC with 54.Qd4# (107 plies), zero illegal submissions. Total record: 17 wins, one draw, 21 losses. Skill-0 record: 12 wins and one loss. Provisional engine-relative Elo: 1750 [1570, 1930], with 25 rated games and 14 excluded maximum-strength games. Observed cumulative active-goal usage after this game: 9,600,970 tokens, including earlier games and practice; not per-game or whole-account usage.

The open Sicilian led to a useful fresh exchange decision. After 18.Bxf6 Qc5+ 19.Kh1 Bxf6, the bishop had left e7 and no longer defended d6. The complete 20.Qxd6 Qxd6 21.Rxd6 exchange won that pawn. I then played 22.Rfd1 before ...Ke7, retaining a real rook defender of Rd6 against the adjacent king. Later ...b5 exposed a6 to Rxa6; after 27.Rxc6, Black inserted ...b4 rather than immediately recapturing, and 28.axb4 Nxc6 left me three pawns ahead. I anticipated the subsequent loss of c2 while moving the attacked rook, reducing that margin to two pawns.

The conversion was slow and included repeated rook moves in response to knight attacks. I kept the rook behind the passed b-pawn and advanced it to b7. I rejected Rb6 while the bishop's e3-d4-c5-b6 ray made that square unsafe, and brought the king to g3 before placing the knight on f2 where ...Bxf2+ could be answered by Kxf2. After 44.Ne5+ Ke7, 45.Nc6+ forked the king, rook and bishop; ...Kd6 46.Nxb8 won the rook. I checked that ...h4+ could be met by Kg4. With Ba7 attacking Nb8, I used Na6 rather than landing beside the king on c6 or d7. Black then allowed Nxb4, promotion and capture of its remaining bishop. The referee confirmed the manually checked final Qd4 mate.

Trial 02 observation: fresh correct defender/ray decisions occurred, with no played recurrence of the targeted error identified in this game. This is limited process evidence against the weakest setting, not proof of improved strength or best play. The already-failed block criterion remains failed because of games 37 and 38. Analysis still branched extensively; finish games 40–42 and revise the method at the declared endpoint. All moves were my own reasoning through the referee; no external chess sources, analysis code or delegated advice were used.

## Game 40 — Black, skill 0, win

Completed 2026-09-30 at 23:29:27 UTC with 33...Qf1# (66 plies), zero illegal submissions. Total record: 18 wins, one draw, 21 losses. Skill-0 record: 13 wins and one loss. Provisional engine-relative Elo: 1750 [1580, 1930], with 26 rated games and 14 excluded maximum-strength games. Observed cumulative active-goal usage: 9,663,915 tokens, including earlier games and practice; not per-game or whole-account usage.

After White's Nf3/g3/c3/d4 setup I developed, castled and played ...e5. The Nxe5/Nxe5/dxe5/Qxe5 sequence exchanged one knight and pawn from each side. ...Ne4 gained a tempo on Rd2. A relevant changed-blocker check arose after ...Be6 and Qc2: my bishop on e6 interrupted Qe7's file defense of Ne4, while White's queen and bishop both attacked e4. I used 19...f5 to supply another pawn defender rather than carrying the old queen defense forward.

After ...g5 and f3, 21...gxh4 captured White's knight. White chose 22.gxh4 instead of taking Ne4, and ...Nf6 preserved the extra knight for a pawn. ...Bd7 met Bb5's attack on Re8. White then allowed ...Bxb5 and tried c4. The concrete 25...dxc4 opened the d-file against Qd3 and also attacked that queen with the pawn. After 26.Qxd8, I selected ...Rxd8 rather than the queen recapture, and completed 27.Rxd8+ Qxd8: my queen, bishop and knight remained against one rook. The full final recapture was counted before selection.

I met Rg1+ with ...Kh8, captured the advanced e-pawn, and moved the attacked queen to d3, where c4 defended it. Rxc5 then allowed ...bxc5 to remove White's last piece. After f4, ...Qf1 covered g1 and g2 while White's own h2-pawn occupied the other escape square; the referee confirmed mate.

Trial observation: another game with relevant correct blocker/exchange accounting and no identified played target recurrence. White supplied substantial material errors, so the win offers little evidence of improved performance against stronger opposition. It does not restore trial 02's failed no-recurrence criterion. Finish the two 1800-setting games, review the complete block, then revise. No external chess sources, automated analysis or delegated advice were used.

## Game 41 — White, elo-1800-setting, win

Completed 2026-10-01 at 00:03:49 UTC with 56.Rh8# (111 plies), zero illegal submissions. Total record: 19 wins, one draw, 21 losses. The 1800-setting record is six wins and seven losses. Provisional engine-relative Elo: 1780 [1610, 1950], with 27 rated games and 14 excluded maximum-strength games. Observed cumulative active-goal usage: 9,820,698 tokens, including all prior games and practice; not per-game or whole-account usage.

Black's Nc6/e6/d6/d5 opening developed into a French-style centre. Bxc6+ doubled its c-pawns, and Na4/Ne5 attacked its advanced rook. Instead of retreating after Ne5, Black played ...Bd7, allowing 15.Nxc6 Bxc6 to win the exchange. I then completed 16.Nxc5 Bd7 17.Nxe6 Bxe6 18.Rxe6, counting the bishop recapture and final rook capture. With Be5 supported by Re6 and the d4-pawn, fxe4 won the remaining knight after ...Bf6. This produced a rook advantage and extra pawns.

Actual target failure: 25.Rd6 overlooked the still-present black c7-pawn. Black's 25...cxd6 captured the rook immediately. I had calculated queen captures, bishop support, and remote checks while omitting the cheapest capture of the selected rook destination. The bishop's protection of d6 did not make exchanging a rook for a pawn sound; moreover, an immediate Bxd6 would have allowed Qxd6. I instead took the loose bishop with 26.Qxe3. This is a third measured recurrence in trial 02, despite several correct short exchanges earlier in the game. The good result cannot cancel it.

After ...Qxa2 I moved the threatened rook to d1. Bf4 then defended Qe3 after ...Qe6. ...Qg4 and ...g5 created a difficult combination of threats to the bishop and rook on the f-file. The actual 30.Qb3+ Kh8 31.Be5+ dxe5 32.Rxf8+ recovered a rook advantage: from h8 the king could not recapture on f8. I have not established that the entire preceding combination was forced against every alternative reply. Qf7+/Qf6+ drove the king to h5; Qf3 pinned the black queen to that king and offered a supported exchange, which Black accepted with ...Qxf3/gxf3.

With queens gone, I captured the passed d-pawn, removed Black's remaining pawns, and brought the king forward. The rook confined the bare king to the back rank. Rh7 was a waiting move; after ...Ka8, Kb6 forced ...Kb8, allowing Rh8 mate. The full game was chosen through my own reasoning and the referee, with no external sources, automated analysis or delegated advice.

Trial decision remains unchanged: finish game 42, then replace the method. The next revision needs to prevent omission of an immediate pawn capture on the actual candidate square; more remote analysis or more successful remembered exercises is insufficient. The rating increase is provisional outcome evidence, not proof of sustained learning or a successful mechanism.

## Game 42 — Black, elo-1800-setting, win

Completed 2026-10-01 at 00:39:25 UTC with 70...Qb4# (140 plies), zero illegal submissions. Total record: 20 wins, one draw, 21 losses. The 1800-setting record is seven wins and seven losses. Provisional engine-relative Elo: 1800 [1630, 1970], with 28 rated games and 14 excluded maximum-strength games. Observed cumulative active-goal usage after the game: 10,018,086 tokens, including earlier games and practice; not per-game or whole-account usage.

The English move order transposed into a central d4/c4 structure. I developed and castled, accepted an isolated d-pawn, and used ...Ne4, ...Bf5 and the open files. The minor-piece exchanges were counted through their final captures. A relevant rejected pawn grab was ...Nxa3 while Qd3 was blocked by Bc3: Bxe5/Qxe5 would clear c3 and allow Qxa3. I instead addressed the kingside alignment with ...g6 and ...h5, exchanged the bishop pair, and used ...Ne5 followed by ...Nxf3+ when White chose Qb1. The actual ...gxf3 recapture exposed White's king. The later ...d4/exd4/...Rxd4 and queen exchange led to an even-material rook ending.

I used both rooks on the d-file and answered Rxd1 by capturing the other rook on c7, retaining queenside protection. After the single-rook ending began, the king reached e5/d5, ...b6 resolved the queenside tension, and ...Rc6 defended b6 and g6. The concrete 45...fxe4 46.Rd8+ Ke5 47.b5 Rf6 48.Ke2 exf3+ gained the second central pawn. ...Rf6 had also pinned f3 before the white king moved. These were fresh correct capture and king-square checks.

The conversion still exposed a process failure. I selected 50...Re6 with an intended ...Re2+ continuation, overlooking my own king on e4 blocking that file. After 51.Rf7 I also initially treated Ke4 as sufficient protection of f3; White's Kf2 would make ...Kxf3 illegal after Rxf3. Both facts were caught before an illegal submission, but after the rook relocation based on that faulty plan. I have not established that 50...Re6 itself objectively loses the winning advantage. This is an invalid played plan, not an engine-certified tactical blunder, and it is another reason not to claim reliable transfer.

I then deliberately chose 51...Re5, anticipating Rxf3 and the pin ...Rf5. The actual 52.Rxf3 Rf5 53.Rxf5 Kxf5 left three black pawns against two white pawns with an active king. White's 54.Kg2 allowed ...Kg4 and ...Kxh4; the supported kingside pawns advanced and the h-pawn promoted. I kept legal king escapes until the final supported Qb4 mate. All moves and endgame assessments were my own; no engine analysis, external chess sources, automated tactical analysis or delegated advice were used.

Trial 02 ends at 4 wins and 2 losses: both maximum-strength games lost, both skill-0 games won, both 1800-setting games won. The estimate rose by 60 points from 1740 [1570, 1930] to 1800 [1630, 1970]. Those intervals overlap substantially, and this small block does not establish sustained improvement or causation. The predeclared no-recurrence criterion failed in games 37, 38 and 41, with the additional invalid conversion plan in game 42. Replace the method before game 43; do not treat the four wins as a reason to repeat it unchanged.

## Between games 42 and 43 — replacement practice trial 03

Completed six destination-capture exercises and ten explicitly supplied legality branches, by 00:46:32 UTC on 2026-10-01. Two positions were remembered; four were self-composed contrasts with known mechanisms. All 30 supplied legal plies and two deliberately illegal replies matched the manual predictions. The examples distinguished both pawn-capture origins, a rook route blocked by its own king, and a king capture prohibited by the opposing king. This is practice correctness, not independently measured chess improvement.

The change for play is a small audit immediately before submitting a selected rook/queen move or capture: identify the landing square, inspect both enemy pawn origins on the actual board, then test the relevant final recapture. It replaces broad branching at that final step; no new general checklist is being added. The complete plan and results are in `workspace/trials/destination-capture-03.md`. Benchmark games 43–48 will test transfer under the unchanged rotation, starting from 1800 [1630, 1970]. Observed cumulative active-goal usage including practice: 10,052,289 tokens.

## Game 43 — White, maximum strength, loss

Completed 2026-10-01 at 01:05:27 UTC by resignation after 24...b4 (48 plies), zero illegal submissions. Total record: 20 wins, one draw, 22 losses. Maximum-strength record: zero wins, one draw, 14 losses. The fixed engine-relative estimate remains 1800 [1630, 1970], with 28 rated games and 15 excluded maximum-strength games. Observed cumulative active-goal usage after the game: 10,138,006 tokens.

I chose the Berlin queen exchange, counted Bxc6/dxc6, dxe5, and Qxd8+/Kxd8 correctly, and developed Bf4 and both rooks. a3/Bxc3/bxc3 left both sides with doubled c-pawns. Black used ...c5, ...Ne7 and ...Nd5 to target the bishop and c3. My 16.Rd3 plan defended c3 initially, but I had not kept its intended retreat viable after the knight moved. The actual 17.Bh2 c4 attacked the rook. The new final audit rejected Re3 because Nd5 now attacked e3, and rejected Rd3 as a retreat later because the black c4-pawn attacked d3. I chose 18.Rd4 knowing ...Nxc3 could win a pawn; that is a conscious concession after an inadequate earlier plan, not prevention of the pawn loss.

After Re3/Nd5/Ree4, Black supported the c-pawn with ...b5. My a4 was met by the other c-pawn's ...c5, again attacking Rd4. Decisive actual error: 22.Rd1 checked the immediate destination captures but omitted ...Nc3, which forked Rd1 and Re4. I had considered a different knight jump while missing the one that attacked both rooks. The response 23.Rde1 Nxe4 24.Rxe4 arranged a legal recapture, limiting the loss to the exchange. After ...b4, Black had two rooks, bishop and seven pawns against my rook, bishop, knight and six pawns, with advancing connected queenside pawns. I resigned that position without claiming an engine-certified evaluation or forced mate.

Trial 03 observation: the pawn-origin audit was applied to the selected major-piece moves and captures, and it caught unsafe rook destinations before submission. I did not identify a newly played immediate pawn-capture omission or illegal assumed recapture in this game. Nevertheless, the method did not prevent a damaging plan followed by a knight fork. These are material limits on its value; do not turn the narrower successful checks into a claim of stronger play. Preserve the declared games 43–48 evaluation block, log this failure alongside the catches, and assess both outcomes and broader tactical errors at its endpoint. All move decisions were my own reasoning through the referee, without external advice or automated chess analysis.

## Game 44 — Black, maximum strength, loss

Completed 2026-10-01 at 01:18:26 UTC by 20.Nf6# (39 plies), zero illegal submissions. The recorded PGN confirms the mating move. Total record: 20 wins, one draw, 23 losses. Maximum-strength record: zero wins, one draw, 15 losses. The fixed estimate remains 1800 [1630, 1970], with 28 rated games and 16 excluded maximum-strength games. Observed cumulative active-goal usage after the game: 10,194,508 tokens.

I used the Berlin again, with Black this time, and completed the ordinary pawn and queen recaptures correctly. White chose h3/g4 rather than the previous game's Bf4. ...Bc4 met Nd4 with an attack on Rf1; ...Nd5 and ...Be7 developed the other pieces. b3/c4 drove Ba6 and Nb6. After Nf5, ...g6 allowed the bishop exchange Nxe7/Kxe7, whose actual king capture was legal.

Decisive error: after 19.Ba3+, I chose 19...Ke8 without checking White's immediate Nf6 reply. The resulting 20.Nf6 was mate. Rd1 controlled d7 and d8; Ba3 controlled e7 and f8; f7 was occupied by my own pawn. No black piece could capture Nf6, and a knight check cannot be blocked. The issue was not legality of Ke8 or the earlier king recapture: I failed to test the opponent's next check and all escape squares. Long speculative analysis of other continuations did not perform that basic check.

Trial 03 observation: the narrow destination/pawn-origin checks do not establish successful execution of the whole move protocol. The ordinary reply-check scan, which the trial retained for all moves, was not applied adequately here. Together with game 43's fork, this is direct evidence that the current process remains unreliable. Keep the declared endpoint after game 48, but perform a short reconstruction of this exact mate before game 45 and record it as additional practice within the block. Any later outcome cannot be attributed solely to the original six exercises. No outside advice, engine analysis or automated move selection was used.

The supplemental reconstruction was completed by 01:21:39 UTC. Mechanical checks of the four supplied legal plies and six deliberately illegal responses matched the prior manual account. The Ke6 contrast established only that the same Nf6 move would not check that king, not that every alternative continuation was solved. The existing requirement to scan immediate opponent checks remains part of the actual pre-submission work for game 45 onward; do not substitute another long analysis or a legal king destination for it.

## Game 45 — White, skill 0, win

Completed 2026-10-01 at 01:51:00 UTC with 49.Nf4# (97 plies), zero illegal submissions. Total record: 21 wins, one draw, 23 losses. Skill-0 record: 14 wins and one loss. Provisional engine-relative Elo remains 1800, now [1640, 1970], with 29 rated games and 16 excluded maximum-strength games. Observed cumulative active-goal usage after the game: 10,354,535 tokens, including prior games and practice; not per-game usage.

Black's early kingside pawn advances and ...Nfg4 attacked my bishop. Bf4/Bxe5 removed one knight, then f4/gxf4/Rxf4 opened the f-file. After ...Rg8, Kh1 removed the g-file pin. I answered the combined ...Qg5 rook attack and Qxg2 mating threat with Rf2, rejecting Qf3 because Ne5 could capture the queen. Re2 met the next queen attack while retaining coverage of g2. Qf1/Qxf4/Bxf4 exchanged queens, and Rf1, Nf5, Rd1 and Red2 coordinated the pieces against d6.

Relevant exchange reconstruction: 24.Nxd6 could be answered by either bishop or rook capture, with the two white rooks completing the recaptures. Starting with the knight avoided leaving Nf5 available to ...Bxf5 during a rook-first exchange. Black instead allowed Nxd6 and Nxb7, then delayed recapturing Bxc4 with ...Ra7. The actual Nd6/Bxd6/Rxd6/Rxd6/Rxd6 sequence left my rook active. After ...Ke7, 31.Rd4 saved the attacked rook and protected Bc4. I rejected Rxc6 because Ne5 attacked c6, and Rd5 because the c6-pawn attacked d5. Black's further failure to recapture the bishop allowed an extra piece to survive the rook exchange.

The king reached d4 and legally recaptured ...Nxc4 with Kxc4: no black pawn or king supported c4. With an extra knight, I removed c6 and converted ...f5 into a passed f-pawn through exf5. Ke6 supported its advance. At f7, I rejected Kf6 as stalemate in my manual reconstruction, since both black pawns were blocked, and used Nd5 to leave ...Kg7 available. Ke7 then protected the promotion square before f8=Q. Qf6+/Kh5/Nf4 produced the referee-confirmed mate; h3 covered the otherwise available g4 escape.

Trial observation: the selected major-piece/capture audits and immediate-check scans were applied, with several fresh catches before submission and no identified played target recurrence. This is limited process evidence, not an independently verified blunder-free game. Black supplied substantial material errors, and a win against the opponent already beaten in 13 of 14 previous games does not establish improved strength. Trial 03 is now one win and two losses, with three games remaining before the declared endpoint. Continue with Black against skill 0, then both 1800-setting games. All decisions used my own reasoning, pre-existing notes and the referee; no external chess advice, automated analysis or delegated moves.

## Game 46 — Black, skill 0, win

Completed 2026-10-01 at 02:25:40 UTC with 39...Be4# (78 plies), zero illegal submissions. Total record: 22 wins, one draw, 23 losses. Skill-0 record: 15 wins and one loss. Provisional engine-relative Elo remains 1800, with interval [1640, 1980], 30 rated games and 16 excluded maximum-strength games. Observed cumulative active-goal usage after the game: 10,517,644 tokens.

Against d4/c3/Bf4, I challenged the centre with ...c5, developed, and used ...Ng4/...Be7 before returning the knight to f6. Bxf6/Bxf6 preserved the pawn structure, and ...Qe7/...Qxc5 recovered the pawn. After ...e5, b4 drove the queen back to e7. Nb3 then cleared White's d-file, and ...Be6 defended d5. Clarification of my earlier threat description: before Nb3, White's Nd2 itself blocked Rxd5. The queen retreat left d5 without a direct defender, but that does not establish that White could immediately capture it on move 17.

...e4 attacked Nf3; after Nd4, ...Nxd4/exd4 exchanged knights and ...Bf5 preserved the bishop. I rejected the earlier Bf5 idea when Qc2 could simply capture it; the actual move was made only after e4 blocked that queen ray. ...b6 drove the remaining knight to a4. The rooks were connected, ...Bg5 attacked Qd2, and ...Bg6 prepared ...e3 while putting the bishop under pawn protection. After Qa2/e3/f4, ...Bh4 preserved the supported ...Bf2+ entry. The actual f5/Bf2+/Kh2/Bxf5 sequence removed the f-pawn: Bf2 blocked Rf1's route to f5. This was a fresh correct blocker/check reconstruction, reached after excessively long analysis rather than a consistently efficient process.

Bd3 allowed ...Bxd3. White chose Rxf2, and ...exf2 removed the rook; Ra1 then allowed the protected ...f1=Q. With ...Qee2, the original queen supported the promotion square while Bd3 supported e2. Rxf1/Qxf1 removed White's last rook. Against Nb7 I rejected ...Re8 because Nd6 would fork Rc8 and Re8, choosing ...Rd7 instead. White then gave up its queen with Qxd5/Rxd5 and its knight with Nd6/Rxd6. The final ...Qf4+/g3/...Qf2+/Kh1/...Be4 was confirmed as mate by the referee.

Trial observation: the major-piece/capture audits caught relevant pawn, knight, blocker and recapture issues before submission; no played immediate-capture or invalid-recapture recurrence was identified. The avoided ...Re8/Nd6 fork also exercised the existing broader fork check. These are limited self-assessed process observations. Opponent errors, especially the passed-pawn response and Qxd5, were substantial; the win and unchanged point estimate do not establish stronger play. The block stands at two wins and two losses, with both 1800-setting games still to play. Preserve the game-48 evaluation endpoint. All play used my own reasoning and the referee, without external chess advice, automated analysis or delegated moves.

# Trial 12 — record pawn origins for minor-piece moves

Declared 2026-10-02 03:02 UTC after trial 11 and benchmark 96. Baseline: 1700 [1580, 1820], 40W/2D/54L; no sustained improvement. Fixed benchmark endpoint: games 97–102. Opponents, estimator, model and fair-play rules remain unchanged.

Target: the omitted d4 pawn in game 96's ...Ne5. I pursued a future knight fork and counted defenders of e5 without noticing that a pawn could take the knight immediately. Trial 03 already taught this principle for major-piece moves and captures, and later broader reply checks failed. This is not a new chess principle and not evidence of learning by itself.

Execution change: immediately before submitting every knight or bishop move, identify the two enemy pawn origin squares that could capture its destination and their actual occupants. Include a short factual record in the referee move note, even on a capture or checking move. For Black moving to e5 these origins are d4/f4; for White moving to e5 they are d6/f6. A friendly defender of the destination does not prevent a lower-value pawn capture. If a pawn can capture, reject a gratuitous minor-for-pawn loss or explicitly account for the concrete compensation. Then submit the chosen move, without treating this narrow pass as a complete safety check. All other checks, king safety and legality still require ordinary own reasoning.

Bounded practice: three recorded max-strength sessions, each at most 15 own moves, with a combined ceiling of 03:32 UTC on 2026-10-02 including reviews. Session 16: Black from benchmark 96 ply 39, the explicitly remembered position before ...Ne5. Session 17: White from benchmark 85 ply 30. Session 18: White from benchmark 89 ply 30. The latter two are preselected older own-game positions; they may be familiar and are not independent blind tests. Do not inspect later historical moves before these replays. Preserve any session stopped at a cap as unfinished, and add no repetitions to seek favorable results.

Practice assessment: count actual bishop/knight moves and whether each had the stated two-square record. Record rejected candidates as limited self-corrections, every unexpected pawn capture or other material loss, illegal submissions and mates. Successful notes or remembered corrections show implementation only, not stronger play. A replay win does not affect Elo. The king-deflection and checking-line failures from games 92/95/96 remain unresolved.

After all three sessions, return to the fixed benchmark rotation for 97–102 using the same brief notes on every minor-piece move. Review implementation separately from Elo and all substantive failures. A skipped note or another omitted immediate pawn capture is adverse process evidence; a clean block still requires later measured confirmation. Revise at the endpoint rather than extending the trial indefinitely.

Use only my own move decisions and the referee during play. No outside move advice, automated chess analysis, attack enumeration, engines as analysts or delegated chess work.


## Practice 16 — remembered position, loss after a rook skewer

Finished 2026-10-02 03:08:20 UTC by practical resignation after 30.Rxa8, 20 session plies / 10 own moves, zero illegal submissions. Result seq 560, hash `31aa9ad01542af8136de2617dbb869e00b5ae794af99cc8356c8cdc81235b1e7`. Referee PGN read back. This is the declared benchmark-96 ply-39 replay against maximum strength, excluded from Elo.

All three minor-piece moves had the two-origin note: ...Ne7 (d6 black bishop/f6 empty), ...Nf5 (e4 black pawn/g4 empty), ...Nxe3 (d2 empty/f2 white pawn). The last deliberately exchanged the knight for Be3 with fxe3 as the anticipated recapture. The remembered ...Ne5 was rejected because d4 held a white pawn. No unexpected pawn capture of a minor piece occurred in this short replay. This is 3/3 implementation in a remembered setting, not independent accuracy or improved strength.

...f6/gxf6/...Qxg4/Bxg4/...gxf6 traded queens and reached equal material. ...Re7 was intended to cover h7, but 27...Kf7 put my own king between that rook and h7. White's Rh7+ exposed the changed blocker. I then chose ...Kf8 while considering the rook exchange, and missed Rh8+, which checked and skewered Ra8 behind the king. ...Kg7/Rxa8 actually lost the rook. At resignation Black had R+B+4P against 2R+B+4P. This is a practical loss assessment, not a theoretical certificate.

The new pawn-origin record was implemented, but a king obstruction and an unfinished checking-line calculation still caused a direct major-piece loss. The narrow behavior did not ensure successful play. No repeat is added. Continue the two predeclared older-position sessions, then benchmarks 97–102.

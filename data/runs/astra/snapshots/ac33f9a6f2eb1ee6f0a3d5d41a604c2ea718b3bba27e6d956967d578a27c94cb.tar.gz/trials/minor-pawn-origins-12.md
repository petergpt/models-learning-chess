# Trial 12 — record pawn origins for minor-piece moves

Declared 2026-10-02 03:02 UTC after trial 11 and benchmark 96. Baseline: 1700 [1580, 1820], 40W/2D/54L; no sustained improvement. Fixed benchmark endpoint: games 97–102. Opponents, estimator, model and fair-play rules remain unchanged.

Target: the omitted d4 pawn in game 96's ...Ne5. I pursued a future knight fork and counted defenders of e5 without noticing that a pawn could take the knight immediately. Trial 03 already taught this principle for major-piece moves and captures, and later broader reply checks failed. This is not a new chess principle and not evidence of learning by itself.

Execution change: immediately before submitting every knight or bishop move, identify the two enemy pawn origin squares that could capture its destination and their actual occupants. Include a short factual record in the referee move note, even on a capture or checking move. For Black moving to e5 these origins are d4/f4; for White moving to e5 they are d6/f6. A friendly defender of the destination does not prevent a lower-value pawn capture. If a pawn can capture, reject a gratuitous minor-for-pawn loss or explicitly account for the concrete compensation. Then submit the chosen move, without treating this narrow pass as a complete safety check. All other checks, king safety and legality still require ordinary own reasoning.

Bounded practice: three recorded max-strength sessions, each at most 15 own moves, with a combined ceiling of 03:32 UTC on 2026-10-02 including reviews. Session 16: Black from benchmark 96 ply 39, the explicitly remembered position before ...Ne5. Session 17: White from benchmark 85 ply 30. Session 18: White from benchmark 89 ply 30. The latter two are preselected older own-game positions; they may be familiar and are not independent blind tests. Do not inspect later historical moves before these replays. Preserve any session stopped at a cap as unfinished, and add no repetitions to seek favorable results.

Practice assessment: count actual bishop/knight moves and whether each had the stated two-square record. Record rejected candidates as limited self-corrections, every unexpected pawn capture or other material loss, illegal submissions and mates. Successful notes or remembered corrections show implementation only, not stronger play. A replay win does not affect Elo. The king-deflection and checking-line failures from games 92/95/96 remain unresolved.

After all three sessions, return to the fixed benchmark rotation for 97–102 using the same brief notes on every minor-piece move. Review implementation separately from Elo and all substantive failures. A skipped note or another omitted immediate pawn capture is adverse process evidence; a clean block still requires later measured confirmation. Revise at the endpoint rather than extending the trial indefinitely.

Use only my own move decisions and the referee during play. No outside move advice, automated chess analysis, attack enumeration, engines as analysts or delegated chess work.


## Practice 16 — remembered position, loss after a rook skewer

Finished 2026-10-02 03:08:20 UTC by practical resignation after 30.Rxa8, 20 session plies / 10 own moves, zero illegal submissions. Result seq 560, hash `31aa9ad01542af8136de2617dbb869e00b5ae794af99cc8356c8cdc81235b1e7`. Referee PGN read back. This is the declared benchmark-96 ply-39 replay against maximum strength, excluded from Elo.

All three minor-piece moves had the two-origin note: ...Ne7 (d6 black bishop/f6 empty), ...Nf5 (e4 black pawn/g4 empty), ...Nxe3 (d2 empty/f2 white pawn). The last deliberately exchanged the knight for Be3 with fxe3 as the anticipated recapture. The remembered ...Ne5 was rejected because d4 held a white pawn. No unexpected pawn capture of a minor piece occurred in this short replay. This is 3/3 implementation in a remembered setting, not independent accuracy or improved strength.

...f6/gxf6/...Qxg4/Bxg4/...gxf6 traded queens and reached equal material. ...Re7 was intended to cover h7, but 27...Kf7 put my own king between that rook and h7. White's Rh7+ exposed the changed blocker. I then chose ...Kf8 while considering the rook exchange, and missed Rh8+, which checked and skewered Ra8 behind the king. ...Kg7/Rxa8 actually lost the rook. At resignation Black had R+B+4P against 2R+B+4P. This is a practical loss assessment, not a theoretical certificate.

The new pawn-origin record was implemented, but a king obstruction and an unfinished checking-line calculation still caused a direct major-piece loss. The narrow behavior did not ensure successful play. No repeat is added. Continue the two predeclared older-position sessions, then benchmarks 97–102.


## Practice 17 — older game-85 replay, unfinished at the move cap

Stopped explicitly at 2026-10-02 03:17:10 UTC after 30...a5, exactly 15 own moves / 30 session plies, zero illegal submissions. Result is `*`, not a draw. Result seq 593, hash `87cc9f55d7ad529673f1954e225bb9769e7811501d01c3a8716fe14043f97c35`. Referee PGN read back. Used the predeclared game-85 ply-30 position against maximum strength, with no later historical moves consulted.

The starting position was a knight down. cxd4/...Rxd4 removed the knight while losing the c-pawn; Bxb4/...Rxb4 exchanged bishops, leaving a one-pawn deficit. Both bishop moves had the recorded pawn origins: Bxb4 (a5/c5 empty) and Bf3 (e4/g4 empty). Bf3 added a defender to e2; its later capture by ...Bxf3 was recaptured with exf3. There were no omitted pawn captures of a minor piece in the played line. This is only 2/2 implementation opportunities.

My passive rook/king arrangement did not hold the pawn ending. ...Rb2 and ...Rdd2 occupied the second rank. After the bishop trade, ...Rxf2+ and ...Rxf3 took both f-pawns. I answered the subsequent rook checks without a direct unreciprocated rook loss, but ...Rxh2 took another pawn. Rxe6 recovered e6 at the cap. Final material was 2R+2P against 2R+5P; the position remains unproved and unfinished, with a clear material deterioration.

No queen or rook was lost without recapture and no illegal move occurred. The narrow note behavior was implemented, but this poor defense is not evidence of stronger play. Continue only the third declared session, then benchmarks 97–102.


## Practice 18 — older game-89 replay, unfinished at the move cap

Stopped explicitly at 2026-10-02 03:30:48 UTC after 30...Rd2, exactly 15 own moves / 30 session plies, zero illegal submissions. Result is `*`, not a draw. Result seq 626, hash `07211060f3729005af1582b2f2d00dc210eb0dffb20397cbb7aa90084cbb235b`. Referee PGN read back. Used the predeclared game-89 ply-30 position against maximum strength, with no later historical moves consulted.

All five minor-piece moves had both enemy pawn origins recorded: Nd4 (c5/e5 empty), Ne2 (d3 empty/f3 white queen), Nf4 (e5/g5 empty), Nd3 (c4 white bishop/e4 empty), Nf2 (e3/g3 empty). No unexpected pawn capture of a minor piece occurred. The audit did not establish broader safety: Nd4 removed Nf3's defense of h2, allowing ...Bxh2+. Ne2 later vacated the diagonal through d4, and ...Bxb2 took another pawn after the rook exchange. These were actual concessions from a position already one pawn down.

Qf3 answered the bishop attack on the queen. ...Rxd1/Rxd1 exchanged one rook each. The later knight relocations, Rh3 and Nf2 avoided a direct major-piece loss in the played line, but did not recover the pawns. The session ended with Q+R+B+N+4P against Q+R+B+N+7P, and ...Rd2 attacking my queen. No completed defense, theoretical evaluation or successful conversion is claimed.

## Trial-12 practice endpoint

All three declared sessions and reviews finished before the combined 03:32 UTC ceiling, with no extra repetitions. Total: one practical loss and two explicitly unfinished sessions, 40 own moves / 80 session plies, zero illegal submissions. All 10 bishop/knight moves had the brief two-origin record (3 + 2 + 5). The remembered ...Ne5 was rejected; the intended ...Nxe3/fxe3 exchanged a knight for a bishop rather than overlooking a pawn capture.

This establishes implementation in these selected replays only. Practice 16 still lost a rook after a king obstruction and checking skewer; practice 17 deteriorated to a three-pawn deficit; practice 18 conceded h2 and b2 through changed defenses. There is no practice evidence of stronger overall play. Do not turn the absence of one narrow error into a learning claim.

Return now to the fixed benchmark block 97–102, using the same notes on every minor-piece move, and assess all errors as well as the unchanged Elo. Baseline remains 1700 [1580, 1820] through 96, with 40W/2D/54L overall. No valid new cumulative usage counter is available. All practice moves and reviews were my own, using only the referee during play and no external advice, engine evaluations, automated chess analysis or delegation.


## Benchmark 97 — White versus maximum strength, pawn-ending loss

Finished 2026-10-02 03:51:05 UTC by practical resignation after 39...Qxd7, 78 plies / 39 own moves, zero illegal submissions. Result seq 7890, hash `c295062be389f16cf6531db81a0210a1afcb687c7f3fb367e0ed9dab9573728c`; snapshot `fbf8a859567d6e604a2ef966f324703eb17509b3d77d68cd2bb93af2ebcae5b6`. Referee PGN read back.

All eight bishop/knight moves had the two-origin record: Nf3 (e4 white pawn/g4 empty), Bb5 (a6 empty/c6 black knight), Bxc6 (b7 and d7 black pawns, with an intended knight-for-bishop exchange), Nc3 (b4/d4 empty), Bf4 (e5 white pawn/g5 empty), Be3 (d4 empty/f4 moving white bishop), Ne1 (d2 empty/f2 white king), Nd3 (c4/e4 empty). The Be3/...Nxe3/fxe3 and Nd3/...Bxd3/cxd3 sequences were accounted minor exchanges. Nd4 was rejected while c5 held a black pawn. No omitted immediate pawn capture of a minor occurred; 8/8 notes show execution only.

The queen and rook exchanges were materially balanced. Rd2 protected c2 from Bf5; h4 removed h3 from the same bishop's attack; after exchanging the remaining rooks, Ne1 defended c2 and Nd3 defended e5. The resulting pawn ending remained equal in pawn count but was not established as equal in value. Black's ...c5 undermined d4; ...cxd4+/cxd4 left my king tied to the central chain. I chose g4/g5 and the h-pawn exchange while Black developed the queenside majority. ...g6 fixed my g5 pawn. After ...Ke4, a4/...bxa4 produced an outside passer. My d5/d6/d7 counterplay was too slow: ...a1=Q, ...Qa4+, and ...Qxd7 actually stopped it.

At resignation White had two pawns against Q+3P. This is a practical loss assessment, not a first-losing-move or theoretical endgame certificate. No queen or rook was lost without recapture; the decisive failure was an unfavorable pawn-ending transition/plan and the lost promotion race. The narrow trial behavior did not ensure overall strength.

After 97: 40W/2D/55L overall; maximum strength 0W/2D/31L. Elo remains 1700 [1580, 1820], with 64 rated games total and the latest 50 used; 33 maximum-strength games excluded. Continue the predeclared block through 102 without extra practice or changing the method.


## Benchmark 98 — Black versus maximum strength, knight loss and fork

Finished 2026-10-02 04:01:25 UTC by practical resignation after 29.Qh5, 57 plies / 28 own moves, zero illegal submissions. Result seq 7949, hash `da4ddba9f53d6134e8cb6dae6bb93357275204a2d1f0e6305448f808a19a6021`; snapshot `00687d60c0c6928c72216ff8a75ddf10863d7b50034b96341dbaf0a8913c6df5`. Referee PGN read back.

All ten minor-piece moves had the origin note: Nc6 (b5/d5 empty), Nf6 (e5 black pawn/g5 empty), Be7 (d6 empty/f6 black knight), Na5 (b4 empty/other origin off board), Bd7 (c6/e6 empty), Nb7 (a6 black pawn/c6 empty), Bxb5 (a4 empty/c4 black pawn), Bd7 (c6/e6 empty), Nh5 (g4 empty/other origin off board), Bxf5 (e4/g4 empty). There was no omitted immediate pawn capture of a minor. However, 20...Nh5 simply hung the knight to 21.Qxh5 along the clear d1-e2-f3-g4-h5 diagonal. I considered future knight activity and the pawn origins but omitted this direct queen capture. This is an actual piece loss, not a compensated sacrifice.

The closed Spanish position had produced a passed c3 pawn after ...axb4/cxb4/...c3. White's Ndc4 blocked Qc7's support of c3, limiting that pawn's usefulness. ...f5/exf5/...Bxf5 recaptured the exchanged pawn but vacated the bishop's control of b5, allowing Nb5 with tempo on Qc7. ...Qd7 answered that attack but placed the queen where the next fork could hit it. Rxa8/...Rxa8 was a balanced rook trade, followed by 26.Nb6 attacking both Qd7 and Ra8. ...Qd8/Nxa8/...Qxa8 conceded rook for knight. Bxf5/...gxf5 then traded bishops.

Final material: Black Q+B+N+5P against White Q+R+B+N+5P. The resignation is practical, not a theoretical certificate. The direct queen capture of Nh5 and the subsequent queen/rook fork were both broader tactical failures despite 10/10 recorded pawn-origin checks. No first-losing-move claim is made.

After 98: 40W/2D/56L overall; maximum strength 0W/2D/32L. Elo remains 1700 [1580, 1820], 64 rated total/latest 50 used, 34 maximum-strength games excluded. Trial-12 benchmark notes are 18/18 so far, but both games were losses and the method has not demonstrated stronger play. Continue the fixed block 99–102, with no added practice mid-block.

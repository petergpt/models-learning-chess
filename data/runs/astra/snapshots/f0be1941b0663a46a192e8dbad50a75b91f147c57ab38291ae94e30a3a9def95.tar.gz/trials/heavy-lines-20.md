# Trial 20 — queen-and-rook lines in sparse positions

Declared 2026-10-03 02:38 UTC after benchmark 144. Baseline 1540 [1420,1660], 53W/3D/88L in 144; 96 rated total/latest 50, 48 MAX excluded. Next fixed benchmark endpoint: games 145–150. The overall run stops at 200 scored games, with no strength prerequisite.

Trial 19 failed: 1W/0D/5L, repeated opened-line queen/rook losses and missed king captures. Earlier trials 02 (reconstruction), 04 (vacated lines), 11/14 (king captures/defenders), and 18 (forcing king safety) also failed to establish sustained transfer. This is not a new rule, a larger checklist, or a claim that another correct remembered answer constitutes improvement. Change the practice task: remove bishops and knights and work with queens, rooks, kings and three pawns per side, so the actual line-changing captures are the main practical problem.

Bounded learning: mechanically check the six prewritten remembered/contrast branches below, then exactly two new self-composed nominal-1800 practices, White then Black. Each ends naturally or explicitly unfinished after at most 16 own moves and the final opponent reply. Combined study/setup/practice/review ceiling: 2026-10-03 03:18:13 UTC. No repeats, replacement positions or extensions to improve the record. If the ceiling arrives, stop an active practice and record omitted work. A composed position is not objectively certified equal or an independent blind test; its intended mechanism is known, with fresh replies supplied by the opponent.

Remembered/contrast predictions (all moves below predicted legal; checks noted):
1. Game 141 after ply 47 (24.exd5): e8e3, f2e3. The first move takes the queen through the vacated e-file. The pawn recapture does not undo that loss.
2. Game 141 after ply 81 (41.Bxg6): g7g6. The king itself can capture, despite the separately correct f7-pin observation.
3. Game 142 after ply 30 (15...Qxb2+): c1b2. The king can take the undefended queen; a checking move is not automatically safe.
4. Game 143 after ply 59 (30.Rc3): f6d5, e3e4, d5c3, b2c3. Both black knight moves give check; this is the actual fork, not the different knight route I had focused on.
5. Game 144 after ply 49 (25.Bxf6), actual branch: b3a1, b1b6, g7f6. The knight's departure opens Rb1's capture of Qb6.
6. Same 144 position, my imagined cooperative branch: b3a1, f6d8, e8d8, b1a1. Its legality would not make it the opponent's best or actual reply. Compare it with branch 5, without a search or evaluation claim.

Practice A, White, FEN `2r3k1/5p1p/pq6/8/8/P7/3Q1P1P/4R1K1 w - - 0 1`: White Kg1/Qd2/Re1/a3/f2/h2; Black Kg8/Qb6/Rc8/a6/f7/h7.
Practice B, Black, FEN `2r3k1/pq3p2/7p/8/8/4Q2P/P4P2/3R2K1 b - - 0 1`: Black Kg8/Qb7/Rc8/a7/f7/h6; White Kg1/Qe3/Rd1/a2/f2/h3. Different placement, not a color-swapped replay of A.

Working focus: restart the short capture line from each actual referee reply. After a blocker leaves, consider the king and the opposing heavy pieces as possible capturers, including a forcing check that interrupts the intended recapture. A supplied alternative branch stays hypothetical until played. Use ordinary development in benchmarks; no special queen-exchange preference, timing target or mandatory expanded move checklist.

Assessment: preserve every actual major-piece loss, king capture, checking interruption, legal recapture, confined piece and unresolved attack. A capped practice stays unfinished; a legal remembered branch measures retention only. Judge the entire 145–150 block and interval at its fixed endpoint, including unrelated errors. A sparse-practice success alone cannot establish broader learning. All moves are my own; no agents, engine analysis, automated search, scoring, attack maps or move menus.


## Trial 20 supplied-branch study result
Six remembered/controlled branches, 15 supplied plies: all starting boards valid and all 15 legality predictions matched. Both specified checking knight moves in 143 were confirmed. The actual Rxb6 branch and my imagined Bxd8 branch in 144 are both legal; that does not make the imagined reply a sufficient account of the position. The output establishes only the supplied geometry, without search, evaluation, attack enumeration or a best-move claim. Files heavy-lines-20-inputs.json, heavy-lines-20-verify.py and heavy-lines-20-legality.json preserve the exact scope. No fresh-solution accuracy or improvement is inferred. Proceed to the two predeclared compositions, without adding cases.


## Practice 35 — fresh composition A, checkmated
Natural loss by checkmate at 2026-10-03 02:42:31 UTC, 6 own moves/12 plies, zero illegal submissions. Seq 1107; hash 3cf8dc1f49e741091db1913ff920d5955643c8150fe190bf3392119a86fcbd4f. Full referee PGN read. Actual line: 1.Rc1 Re8 2.Qd7 Re6 3.Qc8+ Kg7 4.h3 Rg6+ 5.Kh2 Qxf2+ 6.Kh1 Qg2#.

Rc1 was supported by Qd2 for a possible rook exchange; Black instead moved its rook. Qd7/Qc8+ advanced the queen, with Rc1 supporting c8. I rejected an imagined Qd8+ because Qb6 could capture along c7/d8, but that local caution did not prevent the actual failure. Moving Qd2 had removed the queen's protection of f2. I treated h3 as a useful flight-square move, then met ...Rg6+ with Kh2. The king had also stopped protecting f2, and ...Qxf2+ actually won that pawn with check. Kh1 followed; I considered a later ...Qf3+ but omitted the immediate ...Qg2 mate, protected by Rg6. The king could not capture the queen through the rook's g-file protection.

No major piece was directly blundered, but queen/rook coordination and king safety failed in a sparse new position. The composition was not independently evaluated as equal or drawable; no best-move or forced-loss claim about the starting position. This loss is direct adverse practice evidence, not a reason to repeat or replace the example. Proceed only to predeclared composition B; the 16-move cap was not a minimum.


## Practice 36 — fresh composition B, unfinished
Stopped at the declared 16-own-move/32-ply cap on 2026-10-03 02:52:17 UTC, with the last opponent reply included. One illegal submission. Result *, not a win or draw. Seq 1143; hash 1aaeb7fafd14f913b11a2cad5a5512485e29ac07e89f48d2d629df34253cb361. Full referee PGN read. Actual line: 1...Qc6 2.Qd3 Qf6 3.a4 Rc3 4.Qd5 Rxh3 5.Qg2+ Qg6 6.Qxg6+ fxg6 7.Rd4 Kf7 8.Rd6 Ke7 9.Ra6 Kf7 10.Rxa7+ Kf6 11.a5 Ra3 12.Ra6+ Kg5 13.Rc6 Rxa5 14.Rb6 h5 15.Rb3 h4 16.Rf3 Kg4 17.Rf8.

After Qc6/Qd3 I submitted c8c3 while my own queen still occupied c6. The referee rejected it as the first illegal attempt on that turn; the position was unchanged. I then played Qf6, and after a4 the c-file was actually clear, so ...Rc3 was legal and supported by Qf6's diagonal. This is direct blocker-tracking failure even with few pieces, not merely a missed optimal move.

...Rxh3 won a pawn, but I had not anticipated Qg2+ checking the king and attacking the rook. I selected ...Qg6 as an interposition and exchange offer, initially thinking Qxh3 remained an option. After the actual Qxg6+/fxg6 exchange, my own review recognized the g-file pin: Qg6 also pinned Qg2 to Kg1, so moving that queen off the file to h3 would expose its king. That full defensive mechanism was not foreseen in my choice. No extra mechanical branch or best-line analysis was added. The actual exchange preserved the rook and pawn gain; calling it an immediate rook loss or crediting a fully calculated pin would both be inaccurate.

Kf7/Ke7 approached the rook but left a7 undefended and removed g6's king defender. After Ra6 I returned to f7 to cover g6, and Rxa7+ returned the pawn count to equality. In the rook ending, ...Ra3 went behind White's a-passer. White Rc6 later removed its rook's protection of a5, allowing the actual ...Rxa5 capture. This removed the passer and restored a one-pawn advantage; it was an available opponent concession, not a proved forced stop. ...h5/...h4 advanced with king/pawn support, and ...Kg4 attacked Rf3; White chose Rf8 on the final reply.

Final Black Kg4/Ra5/g6/h4 versus White Kg1/Rf8/f2. One pawn up, but no promotion, conversion or established theoretical result. No extension or replacement practice was added.

## Trial 20 practice endpoint
All six remembered/controlled branches (15 supplied plies) matched legality predictions. The two fresh compositions then finished by 02:52:17, before the 03:18:13 ceiling. Combined 22 own moves/44 plies, one illegal submission: a six-move mating loss, and an unfinished rook ending one pawn up after losing the initial extra pawn and later capturing an abandoned passer. The illegal rook move and missed mating mechanism are adverse evidence; the queen exchange and later pawn capture are local executed outcomes with the limitations above. Sparse practice has not established improvement or resolved the old failures.

Return now to the predeclared fixed benchmark block 145–150. Baseline remains 1540 [1420,1660], 53W/3D/88L in 144; practice is excluded. Preserve rotation, settings, estimator and every record. Carry the actual-position capture focus as an unproved experiment and assess the complete block, including all recurrences. No new valid cumulative token counter is available. All decisions were my own; only the referee was used during active practice.


## Benchmark 145 — White versus MAX, loss
Resigned after 32...Rxh2+ at 2026-10-03 03:08:37 UTC: 32 own moves/64 plies, zero illegal submissions. Seq 12038; hash 5c9c23d09885370573a0e839146366580988b5f0551f1272fd76b0ce93c94fd3. Full referee PGN read. Cumulative 53W/3D/89L in 145; MAX 0W/2D/47L. Elo unchanged 1540 [1420,1660], with 96 rated total/latest 50 and 49 MAX excluded.

Castled on move 5, minor development complete by 9, first rook move 15; first 15 material-clean. Qxd2 and gxf3 made the actual recaptures, accepting doubled f-pawns. Qe3 defended f3 against Qf6. Bb5 pinned Nc6 while Ke8 remained, and Bxc6+/Rxc6 was an equal exchange. After c4/cxd5, ...Nxd5 attacked the queen; Qe4 moved it and retained f3 protection. I recognized that ...Kd7 removed the former e6-pawn pin, so did not rely on the old position for Qxd5.

Bc1/Bd2 let the doubled c-file rooks penetrate. Re2 defended the bishop but ...Rxa2 won a pawn. Qxf5/exf5 was an actual equal queen exchange, not a solution to the rook pressure. Re5 attacked Nd5 and f5, but ...Kd6 attacked the rook and defended the knight; I returned to e2. After ...Rcc2, Rd1 added a bishop defender but permitted the considered ...Nc3 fork of both rooks. Actual Bxc3/Rxe2 cost an exchange. Kg2 did not save f2: ...Rxf2+ was protected by the other rook, followed by ...Rg2+ and ...Rxh2+. Final White Kh3/Rd1/Bc3/b3/d4/f3 versus Black Kd6/Ra2/Rh2/a6/b7/f5/f7/g5/h6. An exchange and three pawns down; practical resignation, not a proved forced result or checkmate.

Local pin and recapture observations were correct, but confinement, double-rook pressure and the knight fork remained unresolved. Sparse heavy-piece practice did not establish transfer here. Continue the already declared 145–150 block without added study or a replacement game.

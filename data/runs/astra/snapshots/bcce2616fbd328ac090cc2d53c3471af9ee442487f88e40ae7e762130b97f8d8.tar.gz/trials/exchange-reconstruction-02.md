# Practice trial 02: reconstruct short exchanges

Plan recorded on 2026-09-30 after game 36 and before measured game 37. Practice is separate from benchmark results.

Target: stop carrying a defender, blocker, or piece inventory forward after it has changed. The fresh failures are game 35's ...Kxh7 followed by ...Kxg8, game 36's Qxg6/Qxg6/Bxg6 exchange, and ...Nb4 blocking Bd6's defense of a3. Long speculative analysis has not made these elementary checks reliable.

Method: eight short reconstruction exercises, approximately 10–20 minutes and at most 30 minutes. Four are remembered game positions; four are self-composed variants with known mechanisms. This is deliberate practice, not a blind test or an independent accuracy score. For each supplied line, write the current relevant pieces after every ply, account for the captured pieces through the last recapture, and name any defender or blocker that changes. Only then check the explicitly supplied moves mechanically for legality and check status. No engine, search, evaluation, move generation, tactical solver, or delegated advice. For the stalemate example, manually identify the three king destinations and check only those supplied moves; do not request a legal-move menu.

Execution change for games: finish one short candidate line with an explicit current-piece inventory before expanding alternative branches. On returning to the actual referee board, reconstruct that position afresh rather than importing protection from a hypothetical line. This replaces broad speculative branching at exchange decisions; it is not a claim that a longer checklist has improved play.

Evaluation: games 37–42 under the unchanged paired-color rotation. Baseline after game 36 is 1740 [1570, 1930], with 24 rated games. Record actual recapture/defender/blocker omissions separately from errors caught before submission. Two relevant fresh decisions with correct complete accounting and no played recurrence would be limited process evidence; any repeated played omission requires another revision. Neither criterion establishes best play, causation, or sustained Elo improvement. Review the rating and uncertainty after the full six-game block and choose the next method then.

## Exercise prompts

1. Remembered game 35, after ...Kxh7: White Ke7/Rg8/Pa5; Black Kh7/Rf5; White to move. Reconstruct a6 Kxg8 and compare the immediate rook retreat Ra8. Identify exactly when g8 lost its protection.
2. Remembered game 36, after ...Qf6: follow Qxg6 Qxg6 Bxg6 with Bb1 in place. Account for every major piece removed and every one remaining.
3. Remembered game 36, after ...Nb4: follow Rxa3 and test the proposed ...Bxa3. Identify the intervening square and piece.
4. Self-composed variation of 3: put the black knight on c6 instead of b4. Follow Rxa3 Bxa3 Bxa3 and account for the exchange. Do not assume the same outcome as exercise 3.
5. Self-composed variation of 2: move White's bishop from b1 to a2. Follow Qxg6 Qxg6 and test whether that bishop can play Bxg6. Account for the changed material result.
6. Self-composed contrast to 1: White Kf7/Rg8/Pa5; Black Kh7/Ra1; White to move. After a6, test ...Kxg8. Both king and black-rook locations differ from exercise 1; this is only a capture-legality comparison, not a claim about the full ending.
7. Remembered game 35, after ...Rf6+: White Kf7/Rg7/Pa5/Ph7; Black Kh8/Rf6. Follow Kxf6. Inspect check status and the black king's three adjacent destinations.
8. Self-composed variation of 7: remove White's rook on g7. Follow Kxf6 Kxh7 a6 Kh6 a7 Kh5 a8=Q. Check the final promotion's check status and contrast the first resulting position with exercise 7.

## Work and outcome

Pending explicit per-ply reconstruction and supplied-line legality verification. No practice result or transfer claim has yet been recorded.

# Trial 10: endgame races and legal recaptures

Declared 2026-10-01 21:44 UTC after benchmark 84. Baseline 1700 [1580, 1820], overall 35W/2D/47L. No sustained improvement established. Trial 09 and its timing data are preserved; discontinue its 20-second target. Use ordinary ./play interfaces. Opponent, estimator, model and fair-play rules remain fixed.

Weakness: in game 84 I treated an advanced connected pawn pair as adequate compensation without completing the defender's rook-sacrifice line. A king's geometrical contact with a square was wrongly treated as a usable recapture despite the opposing king. Training will focus on a specific endgame skill, rather than another longer general checklist.

Before each race decision, mentally carry both sides' promotion or capture line through the next actual capture and check whether each king recapture is legal. Count moves for both sides, including checks and rook sacrifices; a promotion is not the end of the line. Record concrete errors after each session. These are my own calculations, not certified evaluations.

Bounded practice: three sessions, at nominal 1800 as Black, at most 25 learner moves each including the opponent reply. First and second start from benchmark 84 after ply 116 (58...Kxg2; White moves first), allowing one explicitly remembered repetition. Third uses the new constructed rook-ending FEN `r7/8/4k3/P4p1p/1P4p1/3K4/6PP/2R5 b - - 0 1`. The new position is an unvalidated exercise, not a known theoretical result. Combined ceiling 22:29 UTC on 2026-10-01, including setup/reviews; stop unfinished practice at the ceiling, preserve all sessions, and do not add repetitions to seek a win. Own board reasoning and referee only; no engine evaluation, move suggestions or automated chess analysis.

Next fixed evaluation: benchmark games 85–90 after this practice, regardless of practice outcome. Assess all six results and Elo uncertainty, actual endgame opportunities/errors, and recurrence of earlier tactical losses. A block with no relevant ending cannot establish endgame transfer; do not force favorable benchmark positions. Any rating rise remains provisional and requires repeated evaluation. Practice is excluded from Elo. Revise again if the approach fails.


## Practice 10 — first remembered-position session, loss

Completed 2026-10-01 21:46:31 UTC by practical resignation after 66.h6; 15 session plies, seven learner moves, zero illegal submissions. Result seq 401, hash `5d6a509b01545a5c37f0fed219e5fec51b89893f92a67cce0e232060a07c929a`. PGN read back. The supplied ply 116 is after 58...Kxg2, not after 58.Rxc8 as initially described. The referee therefore played White's 59.Rc1 before my first move. Corrected the description, retained the session unchanged; the second session will use that same specified ply.

Actual line: 59.Rc1 f3 60.Ke3 f2 61.Ke2 Kh2 62.h5 f1=Q+ 63.Rxf1 g2 64.Rb1 g1=Q 65.Rxg1 Kxg1 66.h6. I avoided the original illegal conceptual Kxf2 recapture by choosing ...Kh2, but did not escape the rook-sacrifice mechanism. Both black pawns promoted and both queens were captured. White gave its rook for the second pawn, drawing my king to g1 while its h-pawn remained unstoppable. This demonstrates why promotion alone is not a successful race endpoint. Some analogous rook-sacrifice lines were anticipated in my own reasoning, but I still chose a continuation that allowed the mechanism. No winning alternative or theoretical value of the starting position is established. Resignation is a practical conclusion, not a solver result. Practice remains excluded from Elo.

Seven own moves used, session finished below the 25-move cap. Two declared sessions remain; do not add extra repetitions or change the practice outcome into benchmark evidence. Next try a king route that addresses the h-pawn before pushing both pawns, while recognizing that the starting position may already be lost; this is an unverified candidate plan, not a supplied solution.


## Practice 11 — sole remembered repetition, loss by checkmate

Completed 2026-10-01 21:49:24 UTC, 13 session plies, six learner moves, zero illegal submissions. Result seq 416, hash `00d2eaf8c36ed49557a6254dd43fdd841e6502051b588fb44e9feac3ae3c20a2`. PGN read back. Same benchmark-84 ply-116 starting position; opponent chose Rd8 instead of Rc1.

Actual line: 59.Rd8 Kh3 60.Ke4 Kxh4 61.Rh8+ Kg4 62.Rb8 f3 63.Rg8+ Kh3 64.Kxf3 e5 65.Rh8#. The alternative king route removed the h-pawn, but ...f3 and the checking rook drove the king away from that pawn, letting Kxf3 capture it. I then considered an e-pawn advance to draw the white king away from the g-pawn, and missed the immediate mating threat. Rh8# confines Kh3 because White Kf3 controls g2/g3/g4 and my own g3 pawn blocks that square. This is an actual missed mate, referee-confirmed, and another example of a longer race idea displacing the immediate opponent reply. No claim that the earlier position was defensible or that ...e5 was the first losing move.

Both remembered drills lost. No extra repetition will be added; finish the declared third new-position session, then benchmark 85–90 regardless of its outcome. These six own moves finished below the cap. Practice remains excluded from Elo.

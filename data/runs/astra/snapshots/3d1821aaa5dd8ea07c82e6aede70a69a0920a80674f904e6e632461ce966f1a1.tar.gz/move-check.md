# Trial 10 — endgame races

See trials/endgame-races-10.md for the declared bounded practice and benchmark 85–90 endpoint. Baseline 1700 [1580, 1820]. Trial 09 failed; its 20-second target is discontinued.

In endgames, carry both sides' promotion/capture line through the recapture, including checks and rook sacrifices. A king defends a square only if it can legally capture there without approaching the enemy king or entering attack. Promotion alone is not a terminal success. These are own unverified calculations, not engine guidance.

Earlier actual-board pawn origins, blockers, vacated lines and defender changes still matter. Use own reasoning and referee only. Preserve every game and distinguish remembered practice from new positions and benchmark transfer.

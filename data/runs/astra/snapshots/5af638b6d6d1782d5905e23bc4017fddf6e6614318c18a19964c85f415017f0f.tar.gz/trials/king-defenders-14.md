# Trial 14 — keep the king's defenders usable

Declared after benchmark 108, reference clock 2026-10-02 07:34:42 UTC. Baseline 1660 [1540, 1780], 45W/2D/61L; 72 rated total/latest 50 used, 36 maximum exclusions. Next fixed benchmark endpoint: games 109–114. Opponent rotation, estimator, model and fair-play rules remain unchanged.

Target: a legal king move can pin or obstruct the very piece needed against the next check. In 108, ...Ke8 put Be7 between Re1 and the king; Nxf6+ then made the intended bishop capture illegal. In 104, the checking bishop departure from d2 changed the king/rook defense. Trials 04 and 05 already studied changed lines and defenders and failed. This trial is a focused rehearsal of an old weakness, not a claim of novelty or a longer checklist proving learning.

Practice change: defend from my own side against maximum strength for a longer short continuation, instead of the six-move role-reversed captures in trial 13. Exactly two recorded sessions, in order:

1. Black from game 108 after ply 45, before the failed ...Ke8. Remembered. Manually consider ...Qc6 as an unverified alternative: it would defend f6 with the queen while keeping the king off the e-file. The actual opponent may choose a different attack; this is not a supplied engine answer.
2. Black from game 104 after ply 49, in check after Bxh6+. Remembered. Reconstruct the checking line and choose the defense on the actual starting board. Do not presume that an earlier imagined king square is legal or safe.

Each session ends naturally or explicitly unfinished after twelve own moves and the final opponent reply. Combined practice-and-review ceiling: 2026-10-02 08:04:42 UTC. No extra repeats, no replacements for an unfavorable starting position, and no later historical move lookup during either session. End any active drill at the ceiling and record omissions. Both are remembered own failures, so even a clean continuation is rehearsal, not independent proof of transfer or a completed defense unless the game actually ends.

The immediate practice objective is to reduce the attack while preserving legal recaptures and king exits. Before a selected king move, reconstruct the new rook/bishop/queen line through the king, including any own blocker now pinned; then inspect the next forcing check using that resulting board. A piece geometrically reaching a capture square is not a usable defender if moving it exposes its king. When an opponent exchanges a defender, discard that defender from the next branch. Keep direct destination captures and ordinary checks in view, but use only brief factual notes when useful, without mandatory per-move audit claims.

Record the actual lines, material changes, illegal attempts, newly imposed pins or obstructions, and whether the attack was resolved at the cap. For benchmarks 109–114, retain every analogous recurrence and the full W/D/L/Elo outcome. A recurrence rejects reliable execution; a clean block or small rating rise still requires later repeated evaluations before sustained improvement can be claimed. Revise at 114 rather than continuing this method indefinitely.

Only own chess reasoning, own existing notes and the referee during play. No external move advice, engine analysis, automated move search/scoring/attack enumeration, tablebases or delegated chess work. No valid new cumulative usage counter is available.


## Practice 23 — remembered 108 defense, immediate mate

Finished naturally at 2026-10-02 07:36:14 UTC, one own move / two plies, zero illegal submissions. Result seq 687, hash `09189acc28a4f90e59ca78a1439a7e38594543c9817e0e9ff074bff8b5fa6c60`. PGN read back. Actual line: 23...Qc6 24.Qh8#.

The proposed ...Qc6 did add queen support to f6 while leaving Kf8 off the e-file, but it failed to answer the immediate mating threat. In the manual assessment I incorrectly treated e8 as an escape after Qh8+, focusing on Be7 blocking Re1; the queen on h8 itself controls e8 along h8-g8-f8-e8 once the king leaves f8. Be7 occupied e7, f7 was occupied, and the queen covered g7/g8. The referee confirmed mate on the next move. This is an omitted immediate check and a wrong king-exit assessment, not a successful alternative to ...Ke8.

The starting position may already require an earlier defensive improvement, but no claim that every legal defense loses has been proved. The late remembered selection cannot test recovery from a sound position merely by being called practice. Retain it, with no replacement or extra repeat. The first session already refutes reliable execution of this trial's immediate objective. Complete only the second predeclared session and preserve the benchmark endpoint 109–114; practice has no Elo effect.

# Trial25 — literal recaptures (declared 2026-10-03 11:09:25 UTC)

Baseline:174 scored,58W/4D/112L; provisional Elo1390 [1270,1520]. Fixed next evaluation:games175–180, all six retained in the existing MAX W/B, skill0 W/B, nominal1800 W/B rotation. No result-dependent extras or extension. Endpoint remains200 scored benchmarks.

Weakness: I repeatedly treat an imagined recapture as real even when the pawn moves backward, a bishop changes diagonal, or my own king blocks a rook. Longer speculative calculations have not prevented these errors.

Chosen intervention: replace the broad destination checklist with a literal recapture check. For a material transaction I rely on, identify the piece's actual origin and destination and the intervening occupied squares after the preceding capture. A remembered defender is not sufficient. Prioritize the immediate forcing reply in the current referee board before broad speculative branches. No per-move speed limit and no new mandatory long checklist. Similar geometric ideas have failed before; this is a narrower procedural revision, not a novel or proven method.

Bounded study/practice:20minutes combined, ending no later than11:29:25UTC. Exactly four remembered cases, no searches for extra examples:173 before41.Rxg3 (ply80),173 after56...Rxh7+ (ply112),172 before18...Qxf5 (ply35),174 before36...Nh7 (ply71). First three get one explicitly chosen legal alternative line each; the fourth is the successful actual five-ply exchange. Mechanical own-PGN reconstruction and legality checks only, including the known failed submissions; no evaluation/search/attack-map/candidate generation. Corrections to my factual recollection may be recorded, not concealed.

Then exactly two MAX drills, each capped at10 own moves or natural completion, with the shared deadline overriding both caps. First:White from game173 ply80, trying to preserve material without a backward recapture. Second:new self-constructed White position `r7/1k6/1p4PP/p4K2/8/8/7R/8 w - - 0 1`, concentrating on clear rook support behind passed pawns. This second setup is chosen by me and is not an independently assessed test; no claimed starting evaluation. Stop at the cap/deadline even if favorable. No repeats or extra practice.

Observable transfer: incorrect claimed recaptures, illegal submissions, major-piece losses caused by direction/obstruction errors, and the whole six-game W/D/L plus Elo/interval. Record any successful local decisions without treating them as evidence of a general improvement. Independently chosen benchmark replies, not remembered-case success, are the transfer test.


## Four remembered cases reviewed (between games, 2026-10-03)
Mechanical results are in `literal-recaptures-25-legality.json`; explicit script retained. No engine, move menu, search, attack map, or evaluation. Sixteen supplied plies were legal and the three known failed submissions were illegal. This includes two actual pre-error captures, not sixteen independent test items.

1.173/ply80:Rxg3 Rxg3 h4g3 fails because White must increase its pawn rank when capturing: h4 can capture g5, not g3. I had correctly used that same h4 pawn to support Qg5 earlier, then reversed its direction. One chosen alternative Rf3 Rg6 Ne4 was legal; it merely avoids that specific invented recapture, with no claim of best play or complete safety.
2.173/ply112:Rh2xh7 fails because the path includes occupied h6, my own king. Legal escape Kg5 Rg7+ Kh4 does not repair the earlier rook loss or establish a viable endgame.
3.172/ply35:Bf7f5 is vertical, not diagonal. The imagined intermediate e6 would make it two bishop moves with a change of diagonal, not one move. Actual Qd7xf5 Qc2xc7 Qf5d7 is legal and still concedes c7; legal is not synonymous with good.
4.174/ply71:Nh7 Rxh7 Rh6xh7 Ng5xh7 Rh4xh7 is legal. The last rook path becomes clear specifically because h6 has been vacated. Both knights and one rook on each side disappear; each side retains one rook. This successful local transaction did not prevent losing the subsequent rook ending.

These are remembered examples. Correct reconstruction after seeing the failures is not transfer evidence. Continue with the two declared drills only.


## Declared practice complete — 2026-10-03 11:20:57 UTC
Both own practice PGNs read. Exactly two MAX drills,20 own moves/40 plies total,0 illegal submissions. Both stopped at10-own-move caps, both unfinished, no wins or draws claimed. Learning ended before11:29:25 deadline; no extra practice or result-dependent extension.

- Practice45, White from remembered173/ply80: `41.Rf3 Rxb4 42.Ke2 Rxh4 43.Rxg3 Rbxd4 44.Rxd4 Rxd4 45.Rd3 Rb4 46.Rd2 Rb3 47.Kf2 a5 48.g3 Kf6 49.Ne4+ Ke5 50.Nc3 Bf5 *`. Stopped11:15:27.416172UTC, resultseq1385 hash`77ccc2830105eca599cbb2005fd834f14fe3f2232a4962b82d53976a5b7f68bb`. Avoided the backward h4xg3 fiction; captured g3 only after ...Rxh4 moved the opposing rook off the g-file. The actual rook exchange on d4 was legal and equal. Nc3 had the real forward b2xc3 pawn recapture available. However, the initial two-pawn surplus disappeared: lost b4,h4,d4 and captured g3. Final White Kf2/Rd2/Nc3/b2,c5,g3 versus Black Ke5/Rb3/Bf5/a5,c6,f7. Equal material and an active opposing king/rook, not an established draw or good evaluation.
- Practice46, White from the self-constructed setup: `1.h7 Rf8+ 2.Kg5 Rc8 3.h8=Q Rc5+ 4.Kf6 Rc6+ 5.Kg7 Rc8 6.Qh4 Rc7+ 7.Kh6 Ka7 8.Qg4 Ka6 9.g7 Rc6+ 10.Kh7 Rc7 *`. Stopped11:20:57.162415UTC, seq1408 hash`c6f4ae3d216052aa3020bf4fac69f2341e7a1e49c907d5c6afa1264f285f06ac`. Promoted with a clear rook support path; opponent chose rook checks instead of capturing the new queen. Kept queen and rook. Later Kh6 knowingly blocked the h-rook file, so I explicitly stopped relying on a recapture through it; Qg4 and g7 used the separate clear g-file, and Kh7 answered a check without blocking that queen support. Final White Kh7/Qg4/Rh2/g7 versus Black Ka6/Rc7/a5,b6. Material advantage in an intentionally chosen favorable setup, no full conversion within cap and no independent starting evaluation.

Decision: test the narrower recapture procedure in the predetermined175–180 block. Remembered repair success and favorable promotion practice do not establish benchmark transfer. Baseline remains174 scored,58W/4D/112L,1390 [1270,1520].

# Trial 07: short replays against an opponent

Planned on 2026-10-01 after benchmark game 66. Planning reference: 12:45:02 UTC. Practice ceiling: 50 minutes, ending no later than 13:35:02 UTC. Baseline: 1710 [1580, 1840], 44 rated games. Next measured evaluation: fixed benchmark games 67–72, beginning after these drills. The goal, usage counter, opponent rotation and rating method remain unchanged.

Weakness: correct supplied practice branches have not transferred to actual replies. Long speculative calculations still omitted checking moves, changed defenders and piece traps. Trial 06 failed. The new intervention is recorded opponent play from remembered failure positions, followed by an immediate short review and one revised replay. The opponent supplies only its played moves; it is not an analysis service.

Preselected initial drills, all at the nominal 1800 setting:

1. White, benchmark 65 after 62 plies: before Bxb6 and the subsequent Qb5+/Qd3/Bf1+ failure. Preserve the queen and account for the checking queen's second target.
2. Black, benchmark 66 after 59 plies: before ...Rb5 and the later b4/Bc5+/c4 rook trap. Keep the rook mobile and use real, unobstructed defenders for d3.
3. Black, benchmark 60 after 39 plies: before ...Bxb2 omitted Ne7+. Choose and play an alternative against whatever replies the opponent actually makes.
4. White, benchmark 61 after 42 plies: before Nd2 blocked the bishop's retreat and ...f4 trapped it. Preserve an actual retreat or concrete exchange response.

Each drill ends at a terminal result or after at most six learner moves, with the final opponent reply included. Use `practice end` to retain an unfinished drill explicitly. After all four, choose the most instructive failure or unresolved example for one additional replay at the same setting, again at most six learner moves. Record that adaptive selection and its reason before starting it. Stop sooner if the time ceiling is reached; record omitted drills rather than extend study indefinitely. No drill is a blind puzzle, and the repeated fifth drill is expressly a remembered correction.

Execution change: compare at most two sensible candidates at a time. On the reconstructed board, finish a short answer to the concrete forcing reply before pursuing a remote plan. Recheck immediate checks and cheaper captures before submission. Use an actual legal retreat when moving a piece into a confined area. Rebuild the board after the opponent's reply rather than continuing an imagined branch. Aim for about a minute on routine moves; longer calculation is not evidence of better play, and unresolved dangerous lines should remain labeled unresolved. This is an unproven practice change, not a claim of exhaustive checking.

After each drill record the actual continuation, starting and ending material changes, targeted errors avoided or repeated, and any unexpected reply that invalidated my plan. A remembered tactic not selected by the opponent is not a successful test of that tactic. Mechanical legality is not a strength assessment. Do not seek evaluations, hints, best moves, search output, automated tactical analysis, or delegated advice.

Evaluation: practice should produce usable corrections that survive actual replies, without hiding concessions or treating easier wins as progress. During games 67–72, record missed checks or captures that lose material and failures of defender lines or piece escape. Any recurrence prevents claiming reliable transfer. At game 72 compare all benchmark outcomes and the unchanged Elo interval with baseline. Revise on failure. A single cleaner block or rating rise still needs later confirmation before claiming sustained improvement.

Practice records live in the referee's separate `data/practice/` ledger and do not enter benchmark Elo, W/D/L or rotation. This file will contain the concise review of each drill.

## Drill 1 — practice record 1, White from game 65 / ply 62

Completed the six-move drill and explicitly ended it unfinished. Actual continuation: b3 Qd7, Ke1 Bd5, Qd4 Qb5, b4 h5, f4 Bf3, Qd2 Bg4. No captures occurred: both sides began and ended with queen, bishop and five pawns. The final position is not evaluated or proved safe beyond the supplied play.

The opponent diverged immediately with ...Qd7. Ke1 removed the original bishop-check geometry, so the later ...Qb5 was not check. I rejected Qc4 after ...Bd5 because the changed bishop could capture that queen, despite Qc4 having been usable in an earlier branch. After ...Bf3 I considered e6, then identified ...Qe2 as a mating reply against Ke1 and rejected the push. Qd2 supplied a queen capture against ...Qe2; the opponent instead chose ...Bg4. That unplayed mating assessment is my own calculation, not an independently verified solution.

The useful result is preserving all material through twelve actual plies and adapting to a newly played threat. This remembered position did not reproduce the original Bf1+ tactic, was stopped deliberately, and is neither a win nor evidence of an Elo increase.

## Drill 2 — practice record 2, Black from game 66 / ply 59

Ended unfinished after six learner moves and twelve plies. Actual continuation: ...Ke7/Raa1, ...Ke6/b4, ...Rdd5/f3, ...Rxh5/Bf4, ...Rxh1/Rxh1, ...Rd7/Rh4. Initially each side had two rooks, bishop and six pawns. At the endpoint each had one rook and bishop; Black retained six pawns and White had five. No major piece or bishop was lost outside the equal rook exchange.

Keeping Re5 instead of playing ...Rb5 preserved several exits. With the rook on e5 and b2 still unmoved, a contemplated Bc5+ could be met by ...Rxc5 without the b4-pawn recapture from the benchmark. After the actual b4, ...Rdd5 coordinated the rooks while both that rook and Bc4 still defended d3. ...Rxh5 was supported along the fifth rank by Rd5. The opponent chose Bf4 rather than Rxh5, so I traded on h1 and then used ...Rd7 to defend c7 against that newly placed bishop. The king stayed off the rook's d-file. The final Rh4 does not directly attack Bc4 because White's own bishop on f4 blocks the fourth rank.

This is a better local outcome than the remembered rook concession, and the opponent supplied a different continuation. It is not a proved winning position or a completed conversion; six moves are limited evidence. The original Bc5+/c4 trap was avoided rather than reproduced as a blind test.

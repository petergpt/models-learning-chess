# Trial 08: longer practice from fresh initial positions

Declared at 15:52:06 UTC on 2026-10-01, after completing benchmark 72 and the failed trial 07 review. Baseline: engine-relative Elo 1700 [1570, 1820], 48 rated games; total record 30W/1D/41L. Keep the fixed benchmark rotation and estimator unchanged. Next evaluation is benchmark games 73–78, after this practice period.

Weakness: known attacks are still missed during live play. In this block, the queen was left on an opposing rook's open file, an interposition was treated as resolved before the opponent king's new support was applied, and a pawn move's support for mate was overlooked. Correctly naming a line earlier has not ensured applying it to the selected move. Long speculative branches have repeatedly ended in elementary omissions.

Change the practice format: play two new games from the standard initial position through the separate practice interface, nominal Elo 1600, White then Black. The opponent supplies fresh continuations. These are not independently scored tactical tests. Each session ends naturally, by an honest practical resignation if appropriate, or explicitly unfinished after 45 learner moves and the opponent's reply. The combined ceiling is 90 minutes from this declaration: 17:22:06 UTC. If a session is still active at the ceiling, finish its pending opponent reply and end it explicitly; do not start another session after the ceiling. Preserve every record and do not repeat a favorable result to improve the count.

Use ordinary development and supported central play. For this trial, avoid voluntary material sacrifices unless a short forcing continuation actually establishes mate or recovery through the real recapture. The last mental pass before submission is from the opponent's position after the selected move: inspect immediate checks and direct captures of the moved major piece, applying the actual blockers and king/pawn support. Keep one main continuation through its real reply rather than following many remote branches. Rebuild after the actual opponent move. This is an application requirement already attempted, not a newly proved solution; the changed practice format must be tested.

During each game use only own reasoning, pre-existing notes and the referee. No engine advice, automated search/scoring/attack enumeration/move selection, external lookups or delegation. The engine is only the opponent. Board rendering and rejection of own illegal submissions remain allowed. No invented move-level token counts.

Assess each session afterward using the actual continuation: did a direct major-piece capture or immediate mate occur, did an identified recapture change after the opponent reply, and did the game continue beyond the originally imagined branch? Do not equate a win at 1600 with higher benchmark strength. Record unresolved assessments as unresolved.

At game 78, compare Elo and its interval, nominal-1800 results, and recurrence of the targeted failures. Trial 07 had such failures in four of six games, including both rated losses. A block without a direct queen/rook blunder or ignored immediate mate, fewer identified recapture errors, and a higher rating would be provisional evidence only; require repeated evaluations for sustained improvement. The rating window will reach 50 rated games during the next block, so distinguish its rolling estimate from the full record. Revise again if the errors persist. No longer checklist or practice score alone counts as improvement.

## Practice records and assessments

Pending: White at nominal 1600, then Black at nominal 1600, within the declared caps.

# Trial 23 — Pawn capture directions and immediate advances
Declared 2026-10-03 07:36 UTC, after all 162 benchmarks were complete and before this study. Baseline 56W/3D/103L; Elo 1450 [1330,1570]. Fixed next evaluation: games 163–168, all six in the unchanged rotation, no replacement or extension.

Problem: long tactical calculation repeatedly omits ordinary pawn captures, pawn support on the other diagonal, or a one-square pawn fork. Previous longer lists and remembered legality passes did not establish transfer.

Plan: at most 30 minutes total, ending by 08:06:06 UTC. Review four own remembered errors: 160 ...Nxc3/bxc3; 160 ...Rd6/exd6; 161 c4/...e4; 162 ...f5/Rxf5. Read only these own PGNs. Write the pawn origin and both forward capture squares, and distinguish a pawn's attack from its possible forward advance. No automated analysis or new tactical search. These are remembered examples, not fresh test successes.

Then exactly two fresh opponent practices from the normal starting position against maximum strength, White then Black, capped at 16 own legal moves each or the combined deadline. End unfinished drills explicitly; no repeats or extra practices. Normal opening positions address the early pawn forks that the previous sparse mixed endings did not cover. Every move remains my own.

Behaviour to try: before committing a move, briefly account for the opponent pawn nearest the candidate piece, including both capture diagonals and any immediate advance that attacks two pieces; when judging a king capture, include friendly pawn support of the target. This replaces the prior emphasis; no expanded mandatory checklist, speed requirement, or claim of parameter training.

Observable transfer: record unexpected pawn captures/forks, queen/rook losses to pawns, and whether the first 15 own moves avoid unanticipated material loss in games 163–168. A useful result would be fewer such errors than 157–162, especially no queen/rook lost to an omitted pawn capture. Six games are descriptive, not a causal trial. Wins alone, the Elo point estimate, or practice completion cannot establish learning.

## Remembered study completed — 2026-10-03 07:38 UTC
Read own full PGNs 160, 161, and 162; manually reviewed exactly the four declared examples. No chess-analysis code, external source, or independent fresh test was used.
- 160: the white b2-pawn captures a3 or c3. Moving Nb1 to d2 did not remove b2; ...Nxc3 therefore still allowed bxc3.
- 160: the white e5-pawn captures d6 or f6. A bishop defending the rook on d6 permits a later recapture, but does not make giving a rook for that pawn sound. White delayed exd6 for a move and then played it.
- 161: a black pawn on e5 captures d4/f4; after its ordinary advance to e4 it captures d3/f3. Those were exactly the bishop and knight squares. My c4 move did not address that fork.
- 162: the white pawn on e4 supports BOTH d5 and f5. ...f5 offered a pawn to Rd5xf5, and the rook remained pawn-protected on f5. My imagined ...Kxf5 was not available. Looking only at the first occupied support square was the error.

These facts are recalled corrections, not four new puzzle solves. I have not proved alternative saving moves or an improvement in play. Proceed to the two predeclared fresh practices.

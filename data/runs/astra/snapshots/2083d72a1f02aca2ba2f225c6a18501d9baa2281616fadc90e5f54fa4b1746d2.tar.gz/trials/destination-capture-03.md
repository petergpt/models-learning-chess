# Practice trial 03: audit the selected destination

Plan recorded on 2026-10-01 after game 42 and before game 43. This is practice, separate from measured games.

Target: prevent an immediate capture from being omitted while calculating a remote continuation. Game 41's Rd6/cxd6 is the clearest example. Game 42 also shows why a nearby king cannot automatically be counted as a recapturer and why the intended rook route must be physically clear.

Method: six compact exercises, approximately 10–20 minutes and at most 25 minutes from this plan. Two are remembered positions and four are self-composed contrasts using known mechanisms. This is deliberate practice, not a blind accuracy test. Before checking anything mechanically, identify the chosen landing square, both enemy pawn origins for a capture onto it, their actual occupants, other immediate captures in the supplied line, and the legal final recapture. Stop at that short concrete result; do not search remote variations. The checker may render boards and check only explicitly supplied moves, resulting occupancy and check status. No move menu, search, scoring, engine analysis or delegated advice.

Execution change in measured games: after selecting a rook/queen move or a capture, perform this small audit on the actual current board immediately before submitting it. Name the pawn origins even when empty. If a king is the intended recapturer, explicitly check the opponent's support of that square. If the audit changes the move, repeat it for the replacement. Use a concise internal factual record, not more general checklist items or claims that checking guarantees safety. For other moves, retain the ordinary checks/captures review.

Evaluation: games 43–48 under the unchanged paired-color rotation. Baseline is 1800 [1630, 1970], with 28 rated games. Record whether the audit was actually applied at relevant selected moves, catches before submission, and any played immediate-capture or invalid-recapture omission. At least three relevant fresh decisions with the audit applied and no played recurrence would be limited process evidence only. Any played recurrence requires revision at the endpoint. Review Elo and its uncertainty over the complete block; a single win, higher estimate or perfect known-example score is insufficient evidence of stronger play.

## Exercise prompts

1. Remembered game 41 after 24...Qxd5: inspect 25.Rd6, then the supplied ...cxd6 and Qxe3. Identify the two black pawn origins that could capture d6 and count the removed pieces.
2. Self-composed contrast to 1: remove the black pawn on c7. Inspect Rd6/Qxd6/Bxd6. Identify what changed and what this supplied exchange does and does not establish about the entire position.
3. Self-composed pawn-capture example: White Kg1/Rg3; Black Kg8/Pf7/Pg6/Ph7; White to move. Inspect Rxg6+ and separately each of ...fxg6 and ...hxg6. A checking move still needs both pawn origins checked.
4. Self-composed colour reversal: White Kg1/Pf2/Pg3/Ph2; Black Kg8/Rg6; Black to move. Inspect ...Rxg3+ and separately fxg3 and hxg3. State White's pawn direction correctly.
5. Remembered game 42 after 50.Rd7: reconstruct ...Re6/Rf7 and test the proposed ...Re2+. In a separate supplied continuation, reconstruct ...Re6/Rf7/...Re5/Rxf3 and test ...Kxf3; then replace that last reply with ...Rf5/Rxf5/...Kxf5. Keep the actual king locations in each branch.
6. Self-composed contrast to the second part of 5: place White's king on h2 rather than f2 in the position after ...Re6/Rf7. Reconstruct ...Re5/Rxf3/...Kxf3. Identify why this final king capture differs.

Manual answers and mechanical results will be recorded below before starting game 43.

## Manual answers, before mechanical verification

1. After Rd6, the black pawn origins for capturing d6 are c7 and e7. c7 contains a black pawn; e7 is empty. ...cxd6 removes White's rook and leaves that pawn on d6. Qxe3 then removes Black's bishop and leaves White's queen on e3. Relevant final inventory: White Kh1/Qe3/Rb1/Be5 and six pawns; Black Kg8/Qd5/Rf8 and four pawns, including the pawn now on d6. A rook has been exchanged for a bishop in this supplied line. The prior bishop protection of d6 did not prevent the pawn capture.

2. With c7 removed, both c7 and e7 are empty. There is no pawn capture onto d6 in that position. In the explicitly supplied alternative, ...Qxd6 removes Rd6, then Be5xd6 removes that queen. Final relevant major pieces are White Qe2/Rb1 against Black Rf8; White's bishop is on d6 and Black's bishop remains on e3. This counts a queen for a rook in that line. It does not show that Black must choose this exchange or that Rd6 is best.

3. Rxg6 removes the black g6-pawn and gives check along g6-g7-g8. The two black capture origins are f7 and h7, both occupied by black pawns. Each supplied reply, ...fxg6 or ...hxg6, removes the checking rook legally. The capturing pawn ends on g6; the other pawn stays on its seventh-rank square. White is left with Kg1 only. Giving check has not prevented the lower-value capture.

4. After ...Rxg3+, the relevant White pawn origins are f2 and h2, not f4/h4. Both contain white pawns. Either fxg3 or hxg3 removes Black's checking rook and leaves a white pawn on g3. Black is left with Kg8 only; White retains its king and two pawns. This is the colour-reversed rook-for-pawn loss.

5. ...Re6 lands on e6, whose White pawn origins d5 and f5 are empty. Rf7 does not change the black king's e4 location. The intended ...Re2+ cannot pass through that king on the e6-e5-e4-e3-e2 file. In the separate continuation, ...Re5 lands on e5; d4 and f4 contain no white pawn. Rf7xf3 then travels through f6, f5 and f4 and removes the black f3-pawn. ...Ke4xf3 would put the black king next to White's Kf2 and is illegal. With ...Rf5 instead, the black rook stands on f5, supported by Ke4, and pins Rf3 to Kf2. The supplied Rxf5/Kxf5 removes both rooks; the king capture is legal because f5 is not adjacent to Kf2 and neither remaining white pawn attacks it. Final inventory: Black Kf5/Pb6/Pg6/Ph5; White Kf2/Pb5/Ph4. This inventory is established separately from any claim that every alternative defense has been solved.

6. Replacing White's Kf2 with Kh2 changes the final capture's legality. After ...Re5/Rxf3, Kh2 attacks g1, g2, g3, h1 and h3; f3 is not among them. White's b5 and h4 pawns also do not attack f3. ...Kxf3 is now legal. Black retains Ke4-to-f3, Re5 and three pawns; White has Kh2 and two pawns. The same nearby black king can be a valid recapturer in this contrast and an invalid one in exercise 5.

All of these are my own known-example assessments. The supplied-move checker will verify only legality, occupancy and check status.

## Practice outcome and decision

Completed and inspected the mechanical results by 00:46:32 UTC on 2026-10-01. That is seven minutes and seven seconds after game 42 ended, including the review and planning, so the actual practice was shorter than the 10–20 minute estimate. Exact separate practice duration was not measured; the 25-minute ceiling was respected.

All ten supplied branches matched the recorded legality predictions: 30 supplied legal plies were accepted, and the two deliberately illegal continuations were rejected. Every starting board was valid. Both pawn replies removed the checking rook in each colour-reversed example. The blocked ...Re2 and the king capture beside Kf2 were rejected; moving that white king to h2 made the supplied king capture legal. The inspected final boards match the manual inventories.

Inputs are in `destination-capture-03-lines.json`; per-ply occupancy, check and legality results are in `destination-capture-03-legality.json`. The check used the vendored board module only, with bytecode writing disabled under the shared job wrapper. It did not import an engine interface, generate a move menu, search, score, or select moves.

These easy, known examples are not a strength test. Decision: carry the explicit destination/pawn-origin audit into games 43–48, applying it to the move actually submitted. The observed cumulative active-goal counter including this practice was 10,052,289 tokens. The baseline and endpoint stay fixed; record any new omission even if the game is won.

## Measured transfer log

Baseline: 1800 [1630, 1970], 28 rated games. Evaluation after game 48.

- Game 43, White versus maximum strength: loss by resignation after 24...b4, zero illegal submissions. Applied the audit to the selected major-piece moves and captures. It caught Re3 as attacked by the newly placed Nd5, and Rd3 as attacked by the c4-pawn. The preceding rook plan still conceded c3. Later 22.Rd1 omitted ...Nc3 forking both rooks; 23.Rde1/Nxe4/24.Rxe4 limited the loss to the exchange. No newly played immediate pawn-capture omission or illegal assumed recapture was identified, but the broader tactical failure means these catches are not evidence of stronger play. Elo is unchanged because the game is excluded from the fixed estimator. Continue the declared block and include the missed fork in the endpoint assessment; a narrow process criterion cannot substitute for actual performance.
- Game 44, Black versus maximum strength: loss by 20.Nf6#, zero illegal submissions. The capture audits did not prevent 19...Ke8 from walking into mate in one. I omitted the immediate knight check and the full escape-square accounting. This violates the ordinary reply-check scan retained by the trial, even though the earlier Kxe7 recapture was legal. Elo remains 1800 [1630, 1970]. Additional exact-position reconstruction is being done before game 45; the evaluation endpoint stays after game 48 and later results must not be attributed solely to the original practice session.
- Game 45, White versus skill 0: win by 49.Nf4#, zero illegal submissions. Applied the destination/pawn-origin audit at selected major-piece moves and captures, with the retained immediate-check scan. Fresh relevant decisions included Rf2 covering the Qxg2 mating threat, the Nxd6 and two-rook recapture sequence, and Rd4 after ...Ke7. The latter audit rejected Rxc6 because of Ne5 and Rd5 because of the c6-pawn. King support of Kxc4 and f8=Q was checked on the current board; Nd5 preserved a king escape before promotion. No played target recurrence was identified, but this is self-assessed process evidence, not a certified clean game. Opponent material errors drove the advantage, and the fixed estimate stayed 1800 [1640, 1970]. Block so far: one win, two losses. Continue to the declared game-48 endpoint; the two maximum-strength failures remain part of the assessment.

## Supplement after game 44 — immediate checks after a king move

This is a short correction within the declared block, not a blind test or a new benchmark result. Use the remembered position after 19.Ba3+ to reconstruct ...Ke8/Nf6 and all five on-board king destinations. Compare the supplied ...Ke6/Nf6 line only for legality and check status, without claiming that ...Ke6 solves the entire position. Verify only the explicitly supplied moves after writing the manual result.

Manual reconstruction before verification: after ...Ke8/Nf6, Black Ke8 is checked by Nf6. The knight attacks e8, d7, d5, e4, g4, g8, h5 and h7. Ke8's possible adjacent on-board destinations are d7, d8, e7, f7 and f8. Rd1 attacks d7 and d8 along a clear file. Ba3 attacks e7 and f8 through b4-c5-d6-e7-f8. f7 contains Black's own pawn. That pawn cannot capture a knight directly forward on f6. Nb6, Ba6 and the two rooks cannot capture f6 in one move; no interposition resolves a knight check. These facts account for the referee-confirmed mate. In the contrast ...Ke6/Nf6, both supplied moves should be legal, but Nf6 does not attack e6 and therefore is not check. Other White replies to ...Ke6 have not been solved by this comparison.

Execution correction for the remaining block: retain the destination audit, and actually perform the existing immediate-opponent-check scan after each selected move, especially king moves. For a candidate king move, check the opponent's knight checks and the resulting escape squares before submitting it. Do not label a legal destination safe merely because the move itself is not into check. This restates a previously existing requirement; it is not evidence of improvement.

Supplement completed and inspected by 01:21:39 UTC on 2026-10-01, three minutes and thirteen seconds after game 44 ended including its review. Both supplied two-ply lines were legal. Nf6 checked Ke8 but did not check Ke6. All five supplied king escapes and the forward f7-f6 pawn move were illegal in the mating position, as predicted. The checker did not generate replies or call a mate solver; the referee's recorded mate and the manual capture/escape accounting supply the mate conclusion. Inputs and outputs are in the two `destination-capture-03-mate-supplement-*.json` files. These remembered examples are not a new accuracy or strength result. Continue with game 45 under the same block endpoint.

# Trial 11 — the opposing king is an attacker

See trials/king-captures-11.md. Three bounded practice sessions, then benchmark 91–96. Baseline 1720 [1600, 1840]. Trial 10 is complete without established improvement.

In sparse-board conversions, locate the opposing king and all my remaining major pieces on the actual board. Resolve a legal king capture of a loose queen or rook before collecting unrelated pawns, including an attack on a piece that did not move. Check a claimed defender's actual legal recapture. Game 90's win still contained the missed Kxf1.

Use own reasoning and the referee only. No timing target, automated chess analysis, outside move advice or delegation. Preserve every result; practice success alone is not transfer.

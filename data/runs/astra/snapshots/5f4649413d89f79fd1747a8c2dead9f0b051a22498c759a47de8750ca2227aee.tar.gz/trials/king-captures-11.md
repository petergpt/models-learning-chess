# Trial 11 — opposing-king captures in sparse-board conversions

Declared 2026-10-01 23:13 UTC after benchmark 90 and the completed trial-10 review. Baseline 1720 [1600, 1840]; overall 38W/2D/50L. No sustained improvement established. Opponents, estimator and fair-play rules remain fixed.

Specific failure: in game 90 I calculated captures involving the active rook while forgetting that the other rook on f1 was capturable by Kg2. The eventual win concealed a direct rook loss. Training now isolates the opposing king as an attacker, including threats to pieces that did not move. Before choosing a conversion move, locate the opposing king and my remaining major pieces on the actual board, and resolve a legal king capture of a loose major piece before collecting unrelated pawns. A rook being elsewhere in a calculated line is not evidence that it is safe on the current board. This is a narrow practice cue, not another expanded general checklist.

Bounded practice: three recorded sessions against maximum strength, at most 15 own moves each, with a combined stopping ceiling of 23:43 UTC on 2026-10-01 including reviews. Session 1: Black, benchmark 90 after ply 51 (26.b4), an explicitly remembered position. Session 2: White, new constructed FEN `3R4/2k5/8/1p2p3/8/1R6/5PPP/6K1 w - - 0 1`. Session 3: Black, new constructed FEN `1k6/ppp5/6r1/8/3P2P1/8/5K2/4r3 b - - 0 1`. The constructed positions deliberately vary the king/rook geometry; they are not independent rated tests or certified theoretical exercises. Preserve unfinished sessions with practice end at either limit, and add no repetitions to seek a favorable outcome.

Practice observations: actual unexpected king captures or other direct major-piece losses, whether the exposed rook was moved or was left elsewhere, and whether a conversion was completed within the limit. A stopped drill is not a draw. Correcting the remembered position is not transfer. Use only own reasoning, referee board and legality checks; no external advice, delegated moves, engines as analysis tools or automated chess analysis.

Next fixed evaluation: benchmark games 91–96, all six in the existing rotation, regardless of practice results. Record Elo and uncertainty, all direct queen/rook losses and actual king-capture opportunities, including errors in games eventually won. A block with no relevant sparse ending cannot validate the specific skill. Seek repeated measured improvement rather than a practice win or a temporary rating rise; revise again if errors persist. No trial-09 clock target applies.



## Practice 13 — remembered king-capture position; win with another rook error

Completed 2026-10-01 23:19:06 UTC by 40...Qf2#, 29 session plies, 15 own moves exactly at the declared cap, zero illegal submissions. Result seq 490, hash `d74bbd8089aa97714f8b509d8c650f64c0e90191a854d98eda32bd4fe30b8dc0`. PGN read back. This was the declared benchmark-90 ply-51 position, against practice skill 20, excluded from Elo.

26...Re1 corrected the remembered exposure to Kg2. White's c6/b5/a4 advances allowed ...bxc6/...cxb5/...bxa4. I then tried to connect the rooks on the third rank with 30...Ree3, and missed f2's direct capture onto e3. 31.fxe3 took the rook; ...Rxe3 recovered only the pawn. This was an unanticipated major-piece loss despite the king-focused cue, not an intended sacrifice. It is evidence that the narrow cue is insufficient for overall safety.

I did respond to later actual king attacks: Kf2 attacked Re3, prompting ...Rc3; Kd2 attacked Rc3, prompting ...Rc8. The c-file cutoff prevented the king from reaching the a-pawn, which promoted. ...Rc2+/Kg3/...Qe5+/f4/...Qe1+/Kf3/...Qf2# finished within the move cap. Rc2 protected the final queen on f2 from Kxf2, while Nf6 covered e4/g4. No king captured a major piece in this drill, but the rook lost to a pawn remains a failure. This remembered-position win is not benchmark transfer. Two declared new-position drills remain; no extra repetition is added.


## Practice 14 — first constructed conversion, win without a major-piece loss

Completed 2026-10-01 23:23:56 UTC by 11.Rb8#, 21 session plies, 11 own moves, zero illegal submissions. Result seq 513, hash `585208e824b3061481751961e01bda2b12b8bc59fcf2f7daa82e10bab6b3a4fd`. PGN read back. Used the declared White-to-move constructed FEN against practice skill 20; no repeat or benchmark score.

Rh8 moved the initially exposed Rd8 away from Kc7. Rh5/Rxe5+ removed the e-pawn. Rbxb5 removed the other pawn while Re5 defended b5 against Kc6. After ...Kd6, I kept the two rooks' mutual protection in view: immediately moving the other rook to give a check could leave the nearer rook capturable. Rh5 and Rbf5 moved them away from the approaching king. Rh6 cut off the sixth rank; Ra5/Ra7 cut off the seventh. Against Kg8 I chose Rb6 before Rb8#, avoiding the adjacent, undefended Rh8 check.

Both rooks survived and the referee confirmed mate. No unexpected king capture, pawn capture of a major piece or other direct major-piece loss was identified. This is a successful deliberately simple constructed drill, not a result from a full game or proof of benchmark transfer. The earlier rook error in practice 13 remains. Finish the third declared drill, then return to benchmark 91–96 without adding favorable repetitions.

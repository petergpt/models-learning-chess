# Trial 16 — safe queen exchanges as a position choice

Declared after benchmark 120 at 2026-10-02 15:36:16 UTC. Baseline: 1590 [1470,1710], 48W/2D/70L; 80 rated games total, latest 50 used, 40 uncalibrated MAX exclusions. Fixed next evaluation: benchmarks 121–126 in the unchanged paired-color rotation. No estimator, opponent, model, or fair-play changes.

## Weakness and change

Trial 15 failed: 2W/0D/4L and a lower Elo endpoint. Early development did not prevent queen exposure, missed immediate recaptures, or later rook losses. The long speculative branches in 119 omitted the actual ...Rxb2 reply. Trial 09 already tested shorter timed decisions, failed its implementation criterion in most games, and did not prevent a queen loss even within the time target. Do not restart that discontinued clock method or relabel inventory/checklist work as new training.

This trial changes the positions selected. At materially comparable positions, prefer a concretely safe, materially equal queen exchange over an unverified queen attack or pawn raid. Consider a supported exchange offer when it improves development or activity. This is conditional, not a requirement to remove queens at any cost: respond to checks and captures, preserve sound forced gains, and avoid an exchange whose last recapture loses material. Keep the trial-15 opening preferences as a fallback so the new variable is the simplification preference. Do not manufacture a queen sortie merely to offer a trade.

The hypothesis is that earlier queen removal will reduce the recurring queen-exposure failures and allow more decisions in positions with fewer long-range attackers. This cannot excuse later rook or minor-piece blunders. Game 120 is one encouraging example of surviving an inferior queenless position and converting opponent mistakes, not proof of the hypothesis.

## Bounded learning and practice

First review the following own-game facts, then play exactly two fresh standard-start opponent-practice sessions at nominal 1800: White, then Black. Each has a maximum of 20 learner moves, including the reply after move 20, or ends naturally sooner. Combined deadline, including setup and reviews: 2026-10-02 16:21:16 UTC (45 minutes). At the deadline finish any already pending referee reply and end an active drill as unfinished. No favorable-result extensions or repeats. Practice records remain separate from Elo and benchmark W/D/L.

Own-game contrasts:
- In 120, ...Qc7/Qxc7/Bxc7 completed an equal queen exchange because Bd6 actually reached c7. Later ...Rc8 supplied a real defender to Bc7. The opponent declined the later bishop trade offered by ...Bc8; retain the actual continuation.
- In 119, Qxc4/Bxc4 removed queens but left White down the exchange and left Re2 attacked. The trade did not repair the earlier Qd3/Ba6 skewer or guarantee a safe ending.
- In 116, Qd5 did not leave the d-file. In 118, Qe3+ remained capturable by f2xe3. A queen's active-looking destination or checking move does not establish a safe transaction.
- In 120, Kxf7 did not win a net bishop because Rxc8 followed. Also, 79.Kg7 was an opponent error that let ...Kxf5 win the pawn; do not claim every earlier rook-versus-pawn line was proved winning.

During practice, record actual queen offers, whether they were accepted or declined, the final recapture and material result, and all unexpected piece losses. If no reasonable exchange opportunity occurs, record the lack of exposure instead of forcing one or extending practice. A stopped opening/middlegame drill has no full-game score.

## Evaluation and continuation

Return to benchmarks 121–126 after these two sessions, regardless of practice results. At 126 compare Elo with its uncertainty, full W/D/L, actual queen losses, other direct piece losses, and whether/how early queen exchanges occurred (including games that kept queens). Exchange frequency is implementation evidence, not strength. A clean practice, one win, or a single higher point estimate is insufficient; seek sustained measured improvement across repeated evaluations. If the policy merely produces inferior endings or the same blunders, revise again.

Only own reasoning, pre-existing notes and the referee during play; no external position advice, engine analysis, automated search/scoring/attack enumeration, legal-move menu, or delegation. No decision-clock target or invented token counter.

## Practice 27 — fresh White opening; no queen-exchange exposure

Ended at 2026-10-02 15:48:18 UTC after exactly 20 own moves / 40 plies, zero illegal attempts, explicitly unfinished with no score. Result seq 810, sha256 a12d9ab4000d16c709d0b78fcef595b2be7774c95e62d44da0af0c40132f0cb2. PGN read back.

1.d4 d5 2.Nf3 c6 3.e3 e6 4.Be2 Be7 5.O-O Nf6 6.c4 O-O 7.Nc3 b6 8.Bd2 Nbd7 9.Rc1 dxc4 10.Bxc4 Nd5 11.Re1 Re8 12.e4 Nxc3 13.Bxc3 Bd6 14.e5 Bc7 15.b3 a5 16.Qd2 Ba6 17.Bxa6 Rxa6 18.Bb2 Nb8 19.Red1 Qd5 20.h3 Ra8.

Castled on 5, all minors developed by 8, both rooks by 11. Pawn, knight and bishop exchanges completed as anticipated; final material equal, Q/2R/B/N/7 pawns each. No unanticipated material loss in this stopped session. b3 protected Bc4 while Rc1 retained Bc3 protection; Bb2 later cleared the c-file while Nf3 still defended Qd2. ...Nb8 defended c6, so no Rxc6 raid was attempted.

Actual queen offers: zero; completed queen exchanges: zero. The d4 pawn continued to separate Qd2 and Qd5. No safe immediate offer was identified, and the session was not extended to manufacture one. This is clean short development but does not test the new exchange preference, demonstrate stronger full-game play, or alter Elo.

One declared fresh Black session remains, at most 20 own moves with the final reply; unchanged combined deadline 16:21:16 UTC. No repetitions or extra White session. Return to fixed benchmarks 121–126 after it.


## Practice 28 — fresh Black; queen exchange followed by knight loss

Ended at 2026-10-02 15:59:51 UTC after exactly 20 own moves / 41 plies including White's final reply, one illegal attempt, explicitly unfinished with no score. Result seq 855, sha256 3961bf9097f5cc3f492d6e41aa786d6fd313dfd878e653f26f9bcb49111404f5. PGN read back.

1.e4 e6 2.Nc3 d5 3.exd5 exd5 4.Nf3 Nf6 5.Qe2+ Qe7 6.a3 Qxe2+ 7.Bxe2 Bd6 8.Nb5 O-O 9.Nxd6 cxd6 10.h3 Nc6 11.g4 Be6 12.b4 Rfe8 13.d3 Rac8 14.Kd1 Ne5 15.Nd4 Bd7 16.g5 Nfg4 17.hxg4 Nxg4 18.Kd2 Nxf2 19.Re1 Nh3 20.a4 Nxg5 21.a5.

The queen offer 5...Qe7 blocked check with Bf8 available to recapture; 6.a3 declined immediate acceptance but left the exchange available. 6...Qxe2+ 7.Bxe2 completed an equal exchange with the actual White bishop recapture. One offer, one completed exchange, queens removed on White move 7, comparable material. Castled on 8, remaining minors developed by 11, both rooks by 13. Nxd6/cxd6 was an anticipated equal bishop-for-knight exchange but left doubled central pawns.

The later failure matters: 15...Bd7 blocked d7 before 16.g5 attacked Nf6. The proposed 16...Ng8 was illegal because Black's king already occupied g8; the referee rejected it once. Other nearby squares were occupied or capturable. 16...Nfg4 knowingly allowed 17.hxg4, and ...Nxg4 recovered only the pawn. This was a knight loss caused by the earlier retreat/development choices, not successful simplification. Subsequent ...Nxf2 and ...Nxg5 recovered two more pawns. Final Black 2R/B/N/7 pawns versus White 2R/2B/N/4 pawns; do not describe the material pattern as a proved favorable ending or erase the lost piece.

Both prescribed practices are now finished before the unchanged 16:21:16 deadline, with no repeat or extension. White had no queen-exchange exposure; Black implemented the exchange preference but still mishandled a minor piece. This does not establish improvement. Proceed to the predeclared fixed benchmarks 121–126 with the same conditional queen-exchange policy and development fallback. Practice remains excluded from Elo and W/D/L; baseline stays 1590 [1470,1710], 48W/2D/70L.

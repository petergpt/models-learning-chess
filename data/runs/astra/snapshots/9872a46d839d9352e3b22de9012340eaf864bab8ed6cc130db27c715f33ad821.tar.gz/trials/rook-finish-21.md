# Trial 21 — keep the rooks safe while finishing

Declared 2026-10-03 04:09 UTC after benchmark 150. Baseline 1540 [1420,1660], 54W/3D/93L in 150; 100 rated total/latest 50, 50 MAX excluded. Next fixed benchmark endpoint: games 151–156, regardless of drill results. The entire run stops at 200 scored games.

Trial 20 failed: 1W/0D/5L with repeated direct captures and missed mates. Earlier capture, defender, rook-activity and king-safety trials also failed. Narrow this learning period to a concrete conversion skill that failed spectacularly in 147: two rooks driving back a king without handing either rook to it. This deliberately uses a large material advantage, so wins are not Elo evidence or proof of broad tactical learning. Stop treating a remembered correct line, an intended check, or a connected pair of rooks before a move as proof that the resulting position is safe.

Own study principle to test: the checking rook's move can remove the other rook's only defender. Before the next checking move, use the resulting position to see whether the opposing king can capture either rook. A king near one rook may require relocating that rook along the protected rank before giving the next check with the other. Bring the king up when needed. This is a short practical task, not a new mandatory checklist, timing target or externally supplied solution.

Bounded learning: check exactly seven prewritten remembered/controlled branches below, plus validity of two self-composed drill setups. Then exactly two fresh maximum-strength opponent practices, White and Black, each ending naturally or stopped after 18 own moves with the final opponent reply included. Combined setup/study/practice/review deadline: 2026-10-03 04:34:29 UTC. No repetitions, replacements or extensions to improve the record. Starting material and intended mechanism are known; these are not blind positions or independently evaluated starting positions.

Supplied branches, predicted legal throughout (17 total supplied plies):
1. 147 after ply 47 (24.Bxg7+): g8g7. The king captures the checking bishop.
2. 147 after ply 68 (34...c3): f7f8, d8e7. The check removes Re7's defender and the king captures it.
3. Same 147 start, a controlled alternative, not a forced/best line: e7a7, d8e8, f7h7, e8f8, a7a8. Relocate both rooks away from the king before the final checking move. I expect the final move to give check; this supplied route does not predict the opponent's actual choices.
4. 149 after ply 89 (45.Rb1): a2b1q. The pawn captures diagonally and promotes.
5. 150 after ply 35 (18.Bc4): d5c4, d1d7. Vacating d5 exposes the queen on d7.
6. 150 after ply 57 (29.Kc1): f8d8, b3f7, g8h8, f7g7. Removing f7's defender allows the actual queen attack.
7. 148 after ply 97 (49.Rc8): e5e4, c8c5. Moving e5 opens the fifth-rank check.

Fresh composition A, White: `8/1p4p1/4k3/8/R6R/8/8/6K1 w - - 0 1` (Kg1/Ra4/Rh4 versus Ke6/b7/g7).
Fresh composition B, Black: `7k/8/8/1r3r2/8/2K5/P5P1/8 b - - 0 1` (Kh8/Rb5/Rf5 versus Kc3/a2/g2). Different placements, not a color-swapped replay. The opponent may find captures or evasions I missed.

Practice observation: finish without losing a rook, avoid illegal submissions, and distinguish a check from an actual referee-confirmed mate. A capped drill is unfinished, never an assumed win. For transfer, record every direct capture, loss of a defender, mating error and promotion oversight in the entire 151–156 block, including losses outside this narrow focus. Preserve ordinary development and all measurement settings. Stop or revise the method at the fixed assessment point if failures continue. All moves remain my own; no agents, engine analysis, automated search, scoring, attack maps or move menus.


## Trial 21 supplied study result
Seven remembered/controlled branches, 17 supplied plies: every legality prediction matched, and the specified final/checking moves gave check. Both new composition boards passed validity checks. The output labels nine records as branches because it includes two setup-only records; there are seven move branches and two setups, not nine tactical tests. No move generation/menu, attack-map enumeration, search, scoring, engine analysis or best-move claim was used. The alternative rook route is a legal controlled example with stipulated king replies, not an independently solved fresh position or a forced line. No mate search was performed by the script; actual recorded benchmark mates retain their referee results. Proceed to the two declared practices without adding cases.

# Learning journal

## Method and constraints

I choose every move by my own reasoning. No engines, tablebases, move-selection code, outside move advice, or live-game lookups. The referee is the only source of opponent moves and legality checks. Reviews below are my own assessments, not engine evaluations. Measured games and results remain in the automatic records.

Before submitting a move: reconstruct the relevant occupied squares; check the move's path and king safety; consider the opponent's forcing checks and captures, including sacrifices; follow each forcing line through recaptures and check which pieces become undefended.

## Game 1 — White, full-strength, 0–1

Resigned after 32...Kd6 (64 plies). One illegal submission: 17.Rxd5 was impossible because my knight on d2 blocked the rook on d1. The accepted recapture was 17.exd5. This was a board-tracking mistake, not an infrastructure fault.

The decisive observed sequence was 23.Rac1 Bxa3+ 24.Kxa3 Rxc3+ 25.Kb2 Rxe3. I had underestimated the bishop sacrifice, the exposed king, the doubled c-file rooks, and the undefended bishop on e3. Black recovered the sacrificed bishop and won both queenside pawns. I exchanged the knights and one pair of rooks to seek activity, but 29...Re2+ also won g2. At resignation Black had six pawns to my three and threatened the d5 pawn.

Lessons to test:

- Updating a piece's square must also update blocked rook and bishop paths. My intended rook recapture no longer existed after Nd2.
- A pawn defended by the king may still fall to a sacrifice if the recapture exposes a forcing check. Count the whole sequence, including loose pieces elsewhere.
- Before defending one target, examine whether moving a loose piece removes the opponent's combination. In this game, moving the bishop off e3 deserved consideration before 23.Rac1; this is an unverified alternative, not a proven improvement.
- The king route to c2/b2 and the knight retreat cost coordination. Reconsider that plan in similar queenless positions rather than assuming queen exchanges make king safety irrelevant.

No external chess sources or post-game engine analysis used. This one loss establishes a baseline; it does not establish improvement or an Elo estimate.

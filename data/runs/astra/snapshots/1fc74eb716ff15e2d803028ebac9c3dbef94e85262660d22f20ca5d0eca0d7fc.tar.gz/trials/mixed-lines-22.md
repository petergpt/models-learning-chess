# Trial 22 — direct capture lines in mixed rook/bishop endings

Declared 2026-10-03 05:46–05:49 UTC after benchmark 156. Baseline 1500 [1370,1620], 55W/3D/98L in 156. Next fixed evaluation: benchmarks 157–162, unchanged rotation regardless of practice outcome. Entire run ends at 200 scored games.

Trial 21 failed: one win and five losses, with major rook/defender failures despite a successful supported mate in 154. The earlier checklists, short-decision trial, capture drills and remembered cases also did not establish reliable improvement. Replace the large-advantage two-rook drills with mixed rook/bishop positions where the opposing rook, bishop, king and pawns can all make immediate captures. Equal starting material is known; positional equality is not independently established.

Own approach to test: before committing to a tactical capture or rook move, reconstruct its resulting occupancy and test a concrete immediate capture against the full line, rather than inferring that a distant piece stopped defending. For a rook, include the intervening squares: in 155, a2–a3–a4–a5–a6 remained an open defending file. For a pawn, use its two capture squares: f5 attacked both e6 and g6 in 156. Check the direct reply before spending time on a long continuation. This is an unproved change in attention, not a claim that more prose or another checklist constitutes learning; no mandatory timing target.

Bounded study: exactly six supplied remembered/controlled branches, 21 plies, all predicted legal, plus validity checks for the two new setups. The only controlled variation is the unplayed ...dxe5/Rxf5 branch in 156; it is a legal-refutation test, not a best-move or forced-line claim. Mate statements in the recorded lines come from the referee; the script checks supplied move legality and resulting check status only, without enumerating moves or performing mate search.

1. 155 after ply 52: b6a6, a2a6. The rook on a2 still protects a6.
2. 151 after ply 18: b1c3, d5d4, e3g3, d4c3, b2c3. A pawn fork costs the knight.
3. 156 after ply 33: f8g6, f4f5, e6c4, d3c4, g6e5. Clearing a bishop retreat did not prevent the f5 fork.
4. 156 after ply 64, controlled branch: f4e5, d6e5, f1f5. Moving Bf4 exposes Qf5 to the f1 rook; the imagined pawn recapture fails.
5. 156 after ply 81: e5d4, e1e4. The final rook check is protected by Bh7; the actual game ended in mate.
6. 154 after ply 48: e2e4, d5e4, c1f4, h3h1. Capturing the blocker preserves the bishop's protection of h1 in the actual winning line.

Then exactly two fresh maximum-strength opponent practices, one White and one Black, at most 16 own moves each, including the last opponent reply. Natural results or practical resignation are allowed. Stop a capped game explicitly as unfinished. Combined setup/study/practice/review ceiling: 2026-10-03 06:16:44 UTC. No added examples, repeats, replacements, or extensions to improve results. If time runs short, stop the current drill and still record the second setup briefly within the same deadline.

Composition A, White: `1r4k1/p3bp2/7p/8/2B5/7P/P4P2/3R2K1 w - - 0 1` — White Kg1/Rd1/Bc4/a2/f2/h3; Black Kg8/Rb8/Be7/a7/f7/h6.
Composition B, Black: `2k3r1/1p2p2p/3b4/8/8/4B3/1P2P2P/2K4R b - - 0 1` — Black Kc8/Rg8/Bd6/b7/e7/h7; White Kc1/Rh1/Be3/b2/e2/h2. Different geometry, not a color-swapped replay. These are self-composed, known-material tasks, not blind independently rated test positions.

Observe actual unexpected direct captures, failure to retain a defender, pawn forks, king safety, and illegal submissions. Keeping both pieces during a capped drill is only a local observation, not a win. For transfer, assess all six benchmark games and every major error, including errors outside the rook/bishop focus. No external advice, agent delegation, engine analysis, automated search/scoring, attack-map generation or move menus. No valid new token counter is available.


## Trial 22 supplied study result
Six remembered/controlled branches, 21 supplied plies: all legality predictions matched. The two recorded final rook checks were checks in the reconstructed boards; their mate results remain referee-established, not independently searched by this script. Both self-composed setups were valid. The output's eight records comprise six move branches plus two setup-only records, not eight tactical tests. The controlled ...dxe5/Rxf5 variation confirms a legal queen capture after the f-file opens; it does not claim a best reply or an independently solved new example. No move menu, search, scoring, attack-map enumeration or engine analysis was used. Proceed to the two declared practices without adding examples.

# Practice trial 03: audit the selected destination

Plan recorded on 2026-10-01 after game 42 and before game 43. This is practice, separate from measured games.

Target: prevent an immediate capture from being omitted while calculating a remote continuation. Game 41's Rd6/cxd6 is the clearest example. Game 42 also shows why a nearby king cannot automatically be counted as a recapturer and why the intended rook route must be physically clear.

Method: six compact exercises, approximately 10–20 minutes and at most 25 minutes from this plan. Two are remembered positions and four are self-composed contrasts using known mechanisms. This is deliberate practice, not a blind accuracy test. Before checking anything mechanically, identify the chosen landing square, both enemy pawn origins for a capture onto it, their actual occupants, other immediate captures in the supplied line, and the legal final recapture. Stop at that short concrete result; do not search remote variations. The checker may render boards and check only explicitly supplied moves, resulting occupancy and check status. No move menu, search, scoring, engine analysis or delegated advice.

Execution change in measured games: after selecting a rook/queen move or a capture, perform this small audit on the actual current board immediately before submitting it. Name the pawn origins even when empty. If a king is the intended recapturer, explicitly check the opponent's support of that square. If the audit changes the move, repeat it for the replacement. Use a concise internal factual record, not more general checklist items or claims that checking guarantees safety. For other moves, retain the ordinary checks/captures review.

Evaluation: games 43–48 under the unchanged paired-color rotation. Baseline is 1800 [1630, 1970], with 28 rated games. Record whether the audit was actually applied at relevant selected moves, catches before submission, and any played immediate-capture or invalid-recapture omission. At least three relevant fresh decisions with the audit applied and no played recurrence would be limited process evidence only. Any played recurrence requires revision at the endpoint. Review Elo and its uncertainty over the complete block; a single win, higher estimate or perfect known-example score is insufficient evidence of stronger play.

## Exercise prompts

1. Remembered game 41 after 24...Qxd5: inspect 25.Rd6, then the supplied ...cxd6 and Qxe3. Identify the two black pawn origins that could capture d6 and count the removed pieces.
2. Self-composed contrast to 1: remove the black pawn on c7. Inspect Rd6/Qxd6/Bxd6. Identify what changed and what this supplied exchange does and does not establish about the entire position.
3. Self-composed pawn-capture example: White Kg1/Rg3; Black Kg8/Pf7/Pg6/Ph7; White to move. Inspect Rxg6+ and separately each of ...fxg6 and ...hxg6. A checking move still needs both pawn origins checked.
4. Self-composed colour reversal: White Kg1/Pf2/Pg3/Ph2; Black Kg8/Rg6; Black to move. Inspect ...Rxg3+ and separately fxg3 and hxg3. State White's pawn direction correctly.
5. Remembered game 42 after 50.Rd7: reconstruct ...Re6/Rf7 and test the proposed ...Re2+. In a separate supplied continuation, reconstruct ...Re6/Rf7/...Re5/Rxf3 and test ...Kxf3; then replace that last reply with ...Rf5/Rxf5/...Kxf5. Keep the actual king locations in each branch.
6. Self-composed contrast to the second part of 5: place White's king on h2 rather than f2 in the position after ...Re6/Rf7. Reconstruct ...Re5/Rxf3/...Kxf3. Identify why this final king capture differs.

Manual answers and mechanical results will be recorded below before starting game 43.

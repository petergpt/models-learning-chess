# Learning journal

## Method and constraints

I choose every move by my own reasoning. No engines, tablebases, move-selection code, outside move advice, or live-game lookups. The referee is the only source of opponent moves and legality checks. Reviews below are my own assessments, not engine evaluations. Measured games and results remain in the automatic records.

Before submitting a move: reconstruct the relevant occupied squares; check the move's path and king safety; consider the opponent's forcing checks and captures, including sacrifices; follow each forcing line through recaptures and check which pieces become undefended.

## Game 1 — White, full-strength, 0–1

Resigned after 32...Kd6 (64 plies). One illegal submission: 17.Rxd5 was impossible because my knight on d2 blocked the rook on d1. The accepted recapture was 17.exd5. This was a board-tracking mistake, not an infrastructure fault.

The decisive observed sequence was 23.Rac1 Bxa3+ 24.Kxa3 Rxc3+ 25.Kb2 Rxe3. I had underestimated the bishop sacrifice, the exposed king, the doubled c-file rooks, and the undefended bishop on e3. Black recovered the sacrificed bishop and won both queenside pawns. I exchanged the knights and one pair of rooks to seek activity, but 29...Re2+ also won g2. At resignation Black had six pawns to my three and threatened the d5 pawn.

Lessons to test:

- Updating a piece's square must also update blocked rook and bishop paths. My intended rook recapture no longer existed after Nd2.
- A pawn defended by the king may still fall to a sacrifice if the recapture exposes a forcing check. Count the whole sequence, including loose pieces elsewhere.
- Before defending one target, examine whether moving a loose piece removes the opponent's combination. In this game, moving the bishop off e3 deserved consideration before 23.Rac1; this is an unverified alternative, not a proven improvement.
- The king route to c2/b2 and the knight retreat cost coordination. Reconsider that plan in similar queenless positions rather than assuming queen exchanges make king safety irrelevant.

No external chess sources or post-game engine analysis used. This one loss establishes a baseline; it does not establish improvement or an Elo estimate.

## Game 2 — Black, full-strength, 0–1

Checkmated by 34.Rh6# (67 plies), confirmed from the referee's compressed PGN. No illegal submissions. Full-strength baseline is now two losses, one with each color.

Opening: Caro-Kann Advance with 4.h4 h5 and exchanged light-squared bishops. After 13...Bb6 14.Neg5 g6, White played 15.Nxe6! and obtained four pawns and a sustained king attack for the knight. I anticipated the sacrifice but underestimated the continuing attack, particularly Qxe6+ and Bh6. Exchanging queens required giving up a rook for a bishop. There is no demonstrated opening improvement here. A more defensive bishop placement on move 13 deserves examination in a future game; it has not been verified.

Final observed pattern: after 31...Kh5 32.Kh3, my king had no safe adjacent square. The knight on g6 temporarily blocked the rook's sixth-rank line. After 33.Nf7, the white knight also protected h6. I played 33...Nxe5 while focusing on the possible g4+ threat, and missed the immediate 34.Rh6# that removing the blocker allowed. This is a direct one-move mate oversight.

Revised decision check for the next games:

1. Before considering plans, enumerate the opponent's immediate checks from the resulting position.
2. For an exposed king, name its available escape squares and their attackers. A blocking piece can be essential even if it appears free to capture a pawn.
3. Recheck the opponent's forcing replies after choosing a move; do not stop after finding an answer to only one threat.
4. Assess sacrifices through the next attacking piece's arrival, not only through the initial material count.

No external sources or engine review used. Reviews are hypotheses plus observed tactical facts, not verified evaluations. Recorded cumulative goal-token observations: 56,051 after game 1 and 126,444 after game 2; these are the active goal's reported counter, not per-game usage or whole-account totals.

## Game 3 — White, skill-0, 1–0

Won by 26.Rxd8# (51 plies), with no illegal submissions. The opponent setting came from the fixed rotation.

After a Scandinavian-style opening, 12.c4 displaced the rook and 13.b4 displaced the queen. The observed fork was 14.c5, attacking the queen on b6 and rook on d6. Black replied 14...Rd7, leaving the queen to 15.cxb6. I subsequently captured an undefended bishop and converted the large advantage.

The final mating pattern was 24.Rc8+ Bd8 25.Qc7 a6 26.Rxd8#. The queen on c7 supported d8 and controlled the seventh-rank escape squares. Capturing with the rook preserved that control; capturing with the queen would have changed it.

This was a successful conversion after major opponent errors, not evidence of improvement against the maximum setting. Keep the same forcing-move and blocker checks in the next game rather than reducing attention because of an opponent label.

# Practice trial 04: reconstruct the changed lines first

Plan and manual work begun after game 48, with planning reference time 03:07:12 UTC on 2026-10-01. Complete the practice within 20 minutes of that reference time. This is separate from measured play. Baseline: 1770 [1610, 1920], 32 rated games. Evaluation endpoint: games 49–54 in the unchanged paired-color rotation.

Target: the repeated failure to update a line when a piece leaves its square. Game 48's ...exd4 uncovered a bishop capture of my queen; game 47's ...Nf3 uncovered a second check, invalidating my planned Rxf3. Successful destination-only checks and extensive remote calculation did not prevent either error.

Method: rehearse eight positions with ten explicitly supplied branches. Two positions are remembered actual failures; the other six are self-composed examples or contrasts using known mechanisms. These are not blind or independently supplied puzzles. Before checking the branches mechanically, name the relevant king and queen locations, clear the proposed origin square in the manual reconstruction, trace the changed line, and predict legality, check status and the resulting captured pieces. Stop at that concrete result. Do not solve the whole position or produce a move menu.

The checker may verify only starting-board validity, legality of the listed moves, resulting occupancy and check status. It must not enumerate attackers/checkers, search, score, generate best moves or call an engine interface. Use the shared job wrapper and preserve the input and result files under workspace/.

Execution change: the compact `workspace/move-check.md` replaces the narrow final destination audit; the old longer protocol is archived as `move-check-before-04.md`. For every selected move, make the short resulting-board reconstruction before remote continuation analysis. Start with king and queen exposure through the origin and destination squares, then check captures and immediate forcing replies. Rebuild it if the candidate changes. When responding to check, reconstruct all checks first, including the line opened by the opponent's vacated square. This changes the order and scope of actual attention; it is not an additional generic checklist or a claim that calculation has been made reliable.

Evaluation: record fresh uses of this reconstruction, catches before submission, and every recurrence involving an opened line, an invalid check response or a lost king/queen. Any such played recurrence means the method needs revision; do not excuse it because several local captures were checked correctly. At least three fresh relevant decisions without a recurrence would be limited process evidence only. Report the complete six-game score and fixed Elo interval at game 54. A single higher estimate or successful known-example practice is insufficient: seek sustained stronger results over later repeated evaluations before attributing an improvement to this change. No model, reasoning-setting, opponent or estimator changes are part of the trial.

## Manual reconstruction before mechanical checking

1. Remembered game 48 before 15...exd4: Black Kg8/Qd6; White Bg3. The e5 pawn blocks Bg3-f4-e5-d6. ...exd4 leaves e5 empty and a black pawn on d4, exposing Qd6. The supplied Bxd6 is legal and removes the queen; ...Rxd6 is legal and removes that bishop. All three resulting side-to-move check statuses are false. The branch exchanges Black's queen for White's bishop while also capturing the d4 pawn. It does not establish any other move as best.
2. Self-composed contrast: move the black queen from d6 to b6 in that starting board. ...exd4 still opens the g3-d6 diagonal, but no queen now stands on d6. The supplied g3-d6 is a legal quiet bishop move, followed by legal ...Rxd6. Black's queen remains on b6 and White's bishop is lost. None of the resulting positions checks the side to move. Identical move coordinates need not remove identical pieces.
3. Remembered game 47 after 40.Re3, before ...Nf3: Black Qd5 and Nd4, White Kd2/Qh2/Re3. Moving Nd4-f3 both attacks d2 with the knight and opens Qd5-d4-d3-d2. ...Nf3 is legal and checks White. Rxf3 is illegal because the queen's check remains. The rejected move leaves the same checked board.
4. Self-composed contrast to 3: add a white pawn on d3. After ...Nf3, that pawn stops the queen ray before Kd2. Rxf3 is now a legal capture of the sole checker; it does not check Black. This verifies only a changed legality condition, not a sound material choice.
5. Self-composed rook skewer using a remembered mechanism: White Kg1/Rc8; Black Kf8/Qh8; Black to move in check. ...Ke7 is legal. Clearing f8 opens Rc8-d8-e8-f8-g8-h8, and Rxh8 legally removes the queen. Neither resulting side-to-move position is in check. A legal king escape can expose a more valuable piece.
6. Self-composed contrast to 5: add a black bishop on g8. ...Ke7 is legal, but c8-h8 is now illegal because Bg8 remains in the rook's path. In a separate supplied branch, Rxg8 captures that bishop legally, and Qxg8 legally captures the rook and checks Kg1 along the g-file. The queen survives and Black trades a bishop for a rook in that branch. The origin was cleared, but another blocker remained.
7. Self-composed colour reversal: White Kg1/Qd3/Rd1/Pe4; Black Kg8/Bg6/Pd5; White to move. Both exd5 and the separate quiet e5 clear the e4 blocker on Bg6-f5-e4-d3. In either branch, ...Bxd3 removes White's queen, and Rxd3 then removes the bishop. All supplied moves are legal and none gives check. The quiet pawn move is as relevant to the opened line as the capture; Black's d5 pawn survives only in the quiet branch.
8. Self-composed knight blocker: White Kg1/Qf2/Re1/Nd4; Black Kg8/Bb6. Nf5 is legal and does not check Black, but clears Bb6-c5-d4-e3-f2. ...Bxf2 is legal, captures the queen, and checks Kg1. Kxf2 then legally removes the bishop: Black's king is distant and no other black piece supports f2. Black is not checked afterward. The legal king recapture does not recover the queen's value.

These manual answers were recorded before running the supplied-move checker. Mechanical results and the decision to begin game 49 will be recorded below.

## Practice outcome and decision

Completed and inspected by 03:13:51 UTC, six minutes and 39 seconds after the planning reference time. That interval includes the prior trial review, planning, manual reconstruction and file work; exact isolated practice duration was not measured. The 20-minute ceiling was respected.

All eight distinct starting positions, represented in ten branches, were valid. All 24 supplied legal plies and both deliberately illegal moves matched the recorded predictions, as did the check statuses and captured-piece inventories. In the actual game-48 branch the bishop captured a queen on d6; in the b6 contrast the same bishop move captured nothing and the queen survived. The double-check capture stayed illegal until the d3 blocker was added. In the rook example, the added Bg8 stopped Rxh8; Rxg8/Qxg8 instead left the queen alive and checked Kg1. Both white pawn moves and the knight move exposed their queens exactly as described.

Inputs and results are in `vacated-lines-04-inputs.json` and `vacated-lines-04-results.json`. The mechanical check used only the listed board/legality/occupancy operations under the shared wrapper. No attack enumeration, move menu, search, scoring, engine analysis or outside advice was used.

Decision: begin game 49 with the short reconstruction in the new move procedure. The practice was easy and based on known mechanisms; it does not establish that the action will be performed reliably in unfamiliar positions. Keep the declared game-54 endpoint, baseline and failure condition. No successful practice count can replace the measured score, Elo uncertainty and recurrence assessment.

## Measured transfer log

Baseline: 1770 [1610, 1920], 32 rated games. Evaluation after game 54. No measured games in this trial yet.

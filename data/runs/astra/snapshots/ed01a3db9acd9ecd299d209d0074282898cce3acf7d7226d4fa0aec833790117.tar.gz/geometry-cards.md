# Geometry cards from my games

My own reconstructions from recorded play. These are reminders, not engine-verified evaluations or evidence of improvement.

## Opened defender: game 8, after 20.Qe1

Relevant pieces: Black Qa5, Nb4; White Bd2, Qe1. The line is e1–d2–c3–b4–a5.

Bxb4 removes the knight and vacates d2. Qa5 now attacks the bishop on b4, but Qxb4 Qxb4 loses the black queen. A queen behind a pinned knight is not sufficient defense when the capturing bishop is backed by another queen. Count the final recapture and its value.

## Rook rank: game 8, after 31.Rg7+

White Rg7 and Qh6; Black Kf7, Bb7, Qd5, Re5, Ra8. The rook's leftward ray is g7–f7–e7–d7–c7–b7, ending at the black bishop. Every empty square on that ray is controlled, not just f7.

Ke8 Qh8+ leaves no king escape. Qg8 Qxg8# finishes the game. The black king on e8 prevents Ra8 from traveling through e8 to interpose on f8 or g8.

## Discovered check: game 7, final net

Before 29...Rc8+, Black Rc3 shielded Bb4 from White Kd2. Moving the rook to c8 uncovered Bb4–c3–d2 and controlled c1/c2/c3 along the c-file. Bb3 controlled d1 via c2. White's own Be2 and e3 pawn occupied two other escape squares. Kd3 was forced, then Bc2+ forced Kd4 and Bc3# followed.

The alternative 29.Ke1 in the preceding position allowed Rc1#, checking with both rook and bishop. Capturing the rook with Ra1 would leave the bishop check unresolved.

## Use before a forcing line

1. Identify occupied squares along each relevant ray, including my own blockers.
2. After each move, update the vacated and occupied squares before assigning checks or defenders.
3. At a check, count every checking piece and every legal king escape before calculating a longer continuation.
4. At an exchange, finish the recaptures and count material; one expensive defender may not protect a target from a cheaper supported attacker.

## Queen changes line: game 9, after 55...Be1+

White Kg3, Rg7, Ne5, pawns a2/c2/f4; Black Kc8, Qd5, Be1, pawns a4/b6/f5. I chose 56.Kh3 to avoid Qxf4 with check, but missed 56...Qh1# along d5–e4–f3–g2–h1.

On h1, the queen checks along the h-file. Be1 controls g3 and h4, while f5 controls g4. The queen controls g2 and h2. White cannot capture the queen or interpose on h2, so every response fails. The alternative Kh2 avoids this particular immediate mate; it is not a claim that the losing position could be saved.

The missed check came from a change of line: the queen traveled diagonally, then attacked along a file. Checking only the most prominent capture, Qxf4, was insufficient.

## Optional recapture: game 11, 21.Qe4?

Black Qf4 and Bb7 both attacked e4 through clear paths. I placed my queen there while imagining a queen exchange followed by minor-piece exchanges. Black instead played Bxe4. After a white bishop or knight recapture, Black was not obliged to put its queen on e4; after Rxe4, it could move the attacked queen away. A defended queen was still available to the cheaper attacker. The played 22...g5 23.Rxf4 gxf4 subsequently reduced my loss to an exchange, but did not justify 21.Qe4.

## Illegal king recapture: game 11, 45.Ne5?

Relevant pieces: White Kf4 and Nf3; Black Rd5, Ng4, and h5 pawn. I played Ne5 and counted Kf4 as a defender. After ...Nxe5, the knight on e5 was protected by Rd5 along d5–e5. Kxe5 would move into rook check and was therefore illegal. The king's adjacency did not make the knight safe.

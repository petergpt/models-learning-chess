# Trial 24 — verify the destination and opposing checks

Declared 2026-10-03 09:08:20 UTC after 168 scored games and before study. Baseline 57W/3D/108L, Elo 1410 [1280,1530]. Fixed next evaluation: all six benchmarks 169–174. Do not extend, replace, repeat, or add drills based on outcomes.

Weakness: favorable plans and long candidate calculations have omitted immediate captures by pawns and kings, and checking bishop forks. Try briefly reconstructing the candidate's destination and the opponent's immediate captures/checks before choosing it, including the opposing king. This replaces the pawn-only focus; no added mandatory long checklist or time-per-move rule. Similar ideas have failed in prior trials; this is another test, not a novel or proven method.

Bound: at most 20 minutes combined study/practice, ending 09:28:20 UTC. Exactly four remembered cases: game 166 before 26...Ned5, game 167 before 24.Rf3, game 168 before 30...Ne3+, and game 168 before 39...Rg2. Read/reconstruct only these own records, identify the actual omitted reply, and consider at most one repair per case. Mechanical board reconstruction or checking explicitly chosen lines is allowed; no search, evaluation, attack maps, or generated candidate moves.

Then exactly two MAX opponent drills, at most 12 own moves each or earlier natural completion/deadline. First: Black from game 168 after ply 77, a remembered position with fresh opponent continuation. Second: White from the self-constructed position 6k1/4R2p/1p3P2/3Kp3/2P3b1/1P6/8/8 w - - 0 1. The latter is new but deliberately favorable in material and has no independently established evaluation. If the deadline prevents a drill, record that; no extension. Do not claim remembered replay success or a favorable practice win as benchmark transfer.

Observable benchmark outcomes: queen/rook losses to immediate captures, minor losses to omitted pawn captures, missed checking forks, full-game W/D/L and Elo uncertainty. Compare descriptively with trial 23's 1W/5L and recurrent material losses. Preserve all records. No external chess sources or assistance.

## Remembered review
Reconstructed only the four declared own positions. System Python initially lacked python-chess; reran with the existing vendored chess library and bytecode disabled. No files under .arena were changed. The saved verification script checks only the twelve explicitly supplied moves in four three-ply lines; all were legal. It does not search, evaluate, generate candidate moves, or establish best play.

166: ...Ned5 missed Bf5+, which attacked Kh7 and Rd3. Proposed ...Rd6 Bf5+ Kg8 moves the rook off that diagonal, but also relinquishes its defence of c3; this is a local repair with a cost, not a winning claim.
167: Rf3 let ...Be2 attack both rooks. Proposed Rf2 Be2 Rd2 keeps the f-rook off the e2–f3 diagonal and preserves a blocker on the d-file. Only this line was checked.
168, move 30: support by d4 did not prevent f2xe3 from taking the knight. Proposed ...Nf6 Rxh6+ ...Kg7 avoids that capture but concedes h6 and leaves an attack; no claim it resolves all threats.
168, move 39: Kf1 can capture g2 directly. Proposed ...Rd8 g7 ...Rg8 instead places the rook far from that king and blocks promotion. This narrow repair is remembered; the next opponent drill tests subsequent choices.

Updated playing reminder: reconstruct the candidate destination, include opposing kings and pawns among immediate capturers, and notice checking forks. This is a brief verification focus, not a longer checklist or an evidence claim.

## Practice 43 — Black MAX, loss
Started from own game 168 after ply 77, a remembered setup. Resigned 09:14:43 UTC after seven own moves / 14 plies, zero illegal submissions. Seq 1335, hash 8ee020d70b1b415d5cb95493dadfc7e473af7f59350dc74751dc561231aed3cb. PGN read in full: 39...Rd8 40.Ke1 Rg8 41.Bc4 Rg7 42.Bf7 Kf3 43.c3 e2 44.b4 Rh7 45.gxh7 Ke3 46.h8=Q. The remembered Rg2 error was avoided; I also avoided an unverified ...Rxg6/Bd3+ fork line. Then ...Rh7 simply placed the rook on g6's capture square. I noticed a possible forward g7 advance but omitted gxh7. White promoted; resignation recorded as a practice loss, not an unfinished drill. This is strong negative evidence for reliability even within the local exercise. No repeat.

# Learning journal

## Method and constraints

I choose every move by my own reasoning. No engines, tablebases, move-selection code, outside move advice, or live-game lookups. The referee is the only source of opponent moves and legality checks. Reviews below are my own assessments, not engine evaluations. Measured games and results remain in the automatic records.

Before submitting a move: reconstruct the relevant occupied squares; check the move's path and king safety; consider the opponent's forcing checks and captures, including sacrifices; follow each forcing line through recaptures and check which pieces become undefended.

## Game 1 — White, full-strength, 0–1

Resigned after 32...Kd6 (64 plies). One illegal submission: 17.Rxd5 was impossible because my knight on d2 blocked the rook on d1. The accepted recapture was 17.exd5. This was a board-tracking mistake, not an infrastructure fault.

The decisive observed sequence was 23.Rac1 Bxa3+ 24.Kxa3 Rxc3+ 25.Kb2 Rxe3. I had underestimated the bishop sacrifice, the exposed king, the doubled c-file rooks, and the undefended bishop on e3. Black recovered the sacrificed bishop and won both queenside pawns. I exchanged the knights and one pair of rooks to seek activity, but 29...Re2+ also won g2. At resignation Black had six pawns to my three and threatened the d5 pawn.

Lessons to test:

- Updating a piece's square must also update blocked rook and bishop paths. My intended rook recapture no longer existed after Nd2.
- A pawn defended by the king may still fall to a sacrifice if the recapture exposes a forcing check. Count the whole sequence, including loose pieces elsewhere.
- Before defending one target, examine whether moving a loose piece removes the opponent's combination. In this game, moving the bishop off e3 deserved consideration before 23.Rac1; this is an unverified alternative, not a proven improvement.
- The king route to c2/b2 and the knight retreat cost coordination. Reconsider that plan in similar queenless positions rather than assuming queen exchanges make king safety irrelevant.

No external chess sources or post-game engine analysis used. This one loss establishes a baseline; it does not establish improvement or an Elo estimate.

## Game 2 — Black, full-strength, 0–1

Checkmated by 34.Rh6# (67 plies), confirmed from the referee's compressed PGN. No illegal submissions. Full-strength baseline is now two losses, one with each color.

Opening: Caro-Kann Advance with 4.h4 h5 and exchanged light-squared bishops. After 13...Bb6 14.Neg5 g6, White played 15.Nxe6! and obtained four pawns and a sustained king attack for the knight. I anticipated the sacrifice but underestimated the continuing attack, particularly Qxe6+ and Bh6. Exchanging queens required giving up a rook for a bishop. There is no demonstrated opening improvement here. A more defensive bishop placement on move 13 deserves examination in a future game; it has not been verified.

Final observed pattern: after 31...Kh5 32.Kh3, my king had no safe adjacent square. The knight on g6 temporarily blocked the rook's sixth-rank line. After 33.Nf7, the white knight also protected h6. I played 33...Nxe5 while focusing on the possible g4+ threat, and missed the immediate 34.Rh6# that removing the blocker allowed. This is a direct one-move mate oversight.

Revised decision check for the next games:

1. Before considering plans, enumerate the opponent's immediate checks from the resulting position.
2. For an exposed king, name its available escape squares and their attackers. A blocking piece can be essential even if it appears free to capture a pawn.
3. Recheck the opponent's forcing replies after choosing a move; do not stop after finding an answer to only one threat.
4. Assess sacrifices through the next attacking piece's arrival, not only through the initial material count.

No external sources or engine review used. Reviews are hypotheses plus observed tactical facts, not verified evaluations. Recorded cumulative goal-token observations: 56,051 after game 1 and 126,444 after game 2; these are the active goal's reported counter, not per-game usage or whole-account totals.

## Game 3 — White, skill-0, 1–0

Won by 26.Rxd8# (51 plies), with no illegal submissions. The opponent setting came from the fixed rotation.

After a Scandinavian-style opening, 12.c4 displaced the rook and 13.b4 displaced the queen. The observed fork was 14.c5, attacking the queen on b6 and rook on d6. Black replied 14...Rd7, leaving the queen to 15.cxb6. I subsequently captured an undefended bishop and converted the large advantage.

The final mating pattern was 24.Rc8+ Bd8 25.Qc7 a6 26.Rxd8#. The queen on c7 supported d8 and controlled the seventh-rank escape squares. Capturing with the rook preserved that control; capturing with the queen would have changed it.

This was a successful conversion after major opponent errors, not evidence of improvement against the maximum setting. Keep the same forcing-move and blocker checks in the next game rather than reducing attention because of an opponent label.

## Game 4 — Black, skill-0, 0–1

Won by 64...Qh1# (128 plies), confirmed from the recorded PGN. Two illegal submissions. The skill-0 pair is now two wins; the maximum-strength pair remains two losses. These four games do not establish improvement against the target.

Observed mistakes:

- After 12...Ra4 13.Ng5 Bxa3 14.Nc5 Bxc5 15.Rxa4, I could not safely recapture the rook with the queen: moving the white knight off b3 had opened Qc2–b3–a4. I had failed to update that defender. White obtained a rook for a knight and pawn.
- After 18...hxg5 19.Qxc5, I submitted the illegal 19...dxc5. I had repeatedly treated the black pawn on d4 as defending c5. Black pawns capture toward lower ranks: d4 attacks c3 and e3. The accepted move was 19...g4. The imagined defense of c5 had already distorted my preceding calculations.
- After 32.Qd5, I submitted the illegal ...Qd6. The queen on e6 was pinned to the king on g8 along d5–e6–f7–g8. The accepted 32...Kf7 defended the queen while remaining behind its block. Later ...Rh8 and ...Ke7 supported h3 and released the pin.

The advance ...e3 and the en passant capture 22...gxh3 produced restrictive pawns. I kept two extra pawns for the exchange through a long maneuvering phase. That is a material description, not a verified evaluation. White gave repeated checks on moves 51–54; I allowed the repeating king route rather than claiming a forced win. White broke the repetition with 55.Qh6.

The decisive errors were 55...Qh5 56.Kg2 Qxh6 and 57.Rxb6+ Kxb6: White left its queen and then its last rook capturable. After 58...gxf5, its remaining pawns on c4, d3, and e2 were blocked by my c5, d4, and e3 pawns. I brought the king from b6 through c6, d6, e5, and f4 to g3, preserving White's king moves until 64...Qh1#.

Method revision for the next pair:

1. Before calculating captures, state the relevant pawn's actual attack squares. White pawns increase ranks; Black pawns decrease ranks.
2. Check whether the proposed move removes a blocker on a line to either king. Being out of check does not mean a piece is free to move.
3. Update opened lines after the opponent's move as well as after my own move. Recheck defenders at the position where the capture occurs; do not carry an earlier defender list forward unchanged.
4. Check the opponent's immediate checks and captures after selecting a candidate. Give short, reconstructed forcing lines priority over long speculative continuations; extensive thinking in this game did not prevent basic geometry errors.
5. When the opponent has no mobile pieces except its king, verify at least one legal reply to every quiet move. Use the king to help finish the mate rather than accidentally closing the last escape square.

These revisions are untested working rules. No external sources, engines, or delegated move advice were used. The observed cumulative active-goal token counter after this game was 559,524; it is not per-game usage or a whole-account total.

## Game 5 — White, elo-1800-setting, 1–0

Won by 35.Qh6# (69 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are three wins and two losses; the maximum-strength results remain two losses.

Black lost time with ...Nf6–g8 and repeated queen moves. I developed, defended the exposed e5 pawn with Bf4, used Qe2 to defend Bc4 after ...Qc7, and castled. These are observed defensive purposes, not an engine assessment of the opening.

The main material gains depended on opponent mistakes: 14.Nxc5 d5 left the bishop uncaptured, and 16.Nxc6 Kf8 left another captured piece uncompensated. I withdrew the knights safely. After Nd3 blocked the d-file, the rook on d1 no longer defended Nd4; 19.Be3 supplied a defender against Qb6. This was a useful application of the blocker check from earlier games.

The tactical sequence 22.Nxe6+ opened Be3–d4–c5–b6 against the queen while checking the king on g7. Black chose 22...Qxe6, and 23.dxe6 won the queen. The connected passed pawns then reached e7 and f7. The promotions 28.f8=Q+ Rhxf8 29.exf8=Q+ Rxf8 removed one black rook; the other remained on f8. After 30.Nf4 Rxf4 31.Qxf4, both black rooks were gone.

The final net used 32.Rd6 to control the sixth rank and support the queen. Black's 32...Bd5 blocked the bishop's diagonal to g8, so 33.Bxd5 removed that defender. Then 34.Qf6+ forced 34...Kh7, and 35.Qh6# was supported by Rd6 while Bd5 controlled g8.

Continue checking changed defenders and forcing replies. This clean conversion against the weaker setting does not establish improvement against the maximum opponent. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 779,486 tokens; this is not per-game or whole-account usage.

## Game 6 — Black, elo-1800-setting, 1–0

Lost by resignation after 53.Qxf3 (105 plies), with no illegal submissions. Confirmed from the recorded PGN. The 1800-setting pair is one win and one loss. Overall: three wins and three losses; maximum strength remains 0/2.

I developed normally, castled, and played in the center. White's 24.b5 axb5 and the sequence 30...Nxb4 31.axb4 Rxb4 gave me two extra pawns. I exchanged rooks and reached queen-and-bishop play with opposite-colored bishops. I did not establish a forced win from that advantage.

The first missed defense was 42...f6 43.Bxb7. White's queen on f3 supported the bishop on b7 along f3–e4–d5–c6–b7 after the bishop vacated d5. My queen on c7 could not recapture without being lost to Qxb7. This repeats the opened-line error from game 4; one queen defending a pawn was not sufficient against the supported bishop capture. I was then only one pawn ahead.

The decisive mistake was 51...Kd5 after 50.Qa1+ Ke6 51.Qa6+. White replied 52.Qb7+, lining up Qb7–c6–Kd5–e4–Qf3. My king screened my loose queen, so a legal king escape uncovered the capture. The recorded continuation was 52...Kc4 53.Qxf3. My preceding calculations considered king escape squares and my own mating threat but failed to check what White's next check would expose behind the king.

I resigned with a queen lost for no compensation sufficient to continue: ...b3 could be met by Bxb3+, with the bishop protected along the third rank by Qf3. Resignation preserved the loss in the record.

For the next games, use the short protocol in `move-check.md`. In particular, after choosing a king move, inspect lines that would join the king to the queen or a rook, and consider the opponent's checking squares on those lines. In my reconstruction, 51...Ke7 would not create the same b7–f3 skewer; that is an untested alternative, not a proven winning continuation.

Long speculative analysis did not prevent this one-reply tactical loss. Zero illegal moves is useful but is not evidence that move quality improved. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,071,029 tokens; not per-game or whole-account usage.

## Game 7 — White, full-strength, 0–1

Checkmated by 31...Bc3# (62 plies), confirmed from the recorded PGN. No illegal submissions. Maximum-strength results are now three losses; overall results are three wins and four losses. There is no demonstrated improvement against the target.

The early queen trade followed 7.Nxd5 Qxd5 8.e3 Be7 9.Nf3 Qxd1+ 10.Kxd1. My plan for an isolated black d-pawn did not occur because Black recaptured with the queen. Moving the knight off d4 opened the queen exchange and removed my castling rights. I again sent the king toward c2 in a queenless position, but the remaining rook and bishops kept king safety important.

The first material loss followed 19.Kd2 Bd5 20.a3 Ne4+ 21.Ke1 Nxc3 22.Rc1 Rc7 23.bxc3 Bxa3. The b2 pawn could not both recapture the knight and keep a3 defended. After 24.Rc2 Be4 25.Ra2 Rxc3, Black had won both queenside pawns. The intermediate rook pressure did not prevent that loss.

The mating sequence was 27.Kd1 Bd5 28.Ra1 Bb3+ 29.Kd2 Rc8+ 30.Kd3 Bc2+ 31.Kd4 Bc3#. My initial spoken diagnosis blamed 30.Kd3; checking the occupied and attacked squares shows that d3 was the only king escape after 29...Rc8+. After 30...Bc2+, d4 was likewise forced. At the final mate, Rc8 controlled c3/c4/c5, Bc2 controlled d3/e4, Bc3 checked d4 and controlled e5, the e6 pawn controlled d5, and my own e3 pawn occupied the remaining adjacent square.

The earlier error was allowing the net with 28.Ra1. After 28...Bb3+, the alternative 29.Ke1 also fails to 29...Rc1#: moving the rook off c3 uncovers Bb4–c3–d2–e1 as well as giving the rook check. Rxc1 would remove only one check, so the first-rank rook was not an adequate defense. In the played line, ...Rc8+ instead uncovered the bishop against Kd2. This is my own reconstruction, not an engine review.

Lessons to test:

- When a checking move vacates a line, identify every checking piece. A capture of one attacker may leave a second check unresolved.
- Before moving an exposed king, count actual escape squares after the opponent's forcing reply. In this game my own bishop and pawns closed several squares.
- A defended piece can still be lost through an overloaded pawn. Follow the recapture and then recheck the pawn's previous defensive duties.
- Earlier active rook moves such as 19.Rd4 or 28.Ra4 deserve consideration. These are untested candidates, not established improvements or claims that the position could be saved.
- Long speculative lines again contained stale blockers and missed forced checks. Use the current board to verify short forcing replies before extending a variation.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,177,322 tokens; not per-game or whole-account usage.

## Game 8 — Black, full-strength, 1–0

Checkmated by 33.Qxg8# (65 plies), confirmed from the recorded PGN. No illegal submissions. Maximum strength is now 0 wins, 0 draws, 4 losses; overall results are 3 wins and 5 losses. The second maximum-strength pair did not demonstrate improvement.

I played a Ruy Lopez structure, castled on move 8, and developed both bishops. The central sequence was 13...exd4 14.cxd4 Nb4 15.Bb1 c5 16.d5 c4. My 17...Qa5 supported Nb4 but also put the queen behind it on the d2–c3–b4–a5 diagonal. After 18.Bd2 Nd7 19.Re3 g6 20.Qe1, the queen on e1 supported the bishop's capture on b4 through the square that bishop would vacate. Thus Bxb4 Qxb4 Qxb4 would lose my queen. Counting Qa5 as a defender of Nb4 had missed the final recapture.

I did not find a satisfactory repair. The recorded attempt 20...Nd3 21.Bxd3 Qb6 22.Bc2 lost the knight. White did not choose the queen exchange I had sought. The bishop retreat preserved White's extra piece. This does not prove that every earlier alternative failed; the pin needed attention before Qe1 made it decisive in the played line.

The later exchange sequence was 25...f5 26.Nxe5 Bxe5 27.Bxe5 Rxe5 28.exf5 gxf5. This opened the g-file. White used 29.Rg3+ Kf7 30.Qxh6, and I played 30...Qxd5 to recover the passed pawn. That did not address the mating threat. The finish was 31.Rg7+ Ke8 32.Qh8+ Qg8 33.Qxg8#.

The rook on g7 controlled f7, e7, d7, and c7, stopping at my bishop on b7. My calculation repeatedly treated d7 as a possible king escape while forgetting that whole rank. Once the queen arrived on h8, my own king on e8 also blocked Ra8 from crossing to f8 or g8. Interposing Qg8 did not save the game. In my reconstruction, 30...Rg8 from a8 was legal and would guard g7; it is an untested defensive alternative, not a claim that the game could be saved.

I created `geometry-cards.md` with short reconstructions from these games. The next trial is to verify occupied rays and the last recapture explicitly, instead of extending speculative variations while carrying stale square information. No engine, external source, or delegated advice was used. Observed cumulative active-goal usage after this game: 1,309,508 tokens; not per-game or whole-account usage.

## Game 9 — White, skill-0, 0–1

Checkmated by 56...Qh1# (112 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 3 wins and 6 losses; skill 0 is 2 wins and 1 loss; maximum strength remains 4 losses. The existing review protocol has not prevented recurring tactical errors.

The early mistake was opening the h-file while my king remained exposed. After 14.h3 h5, I recognized that immediately taking the knight on g4 would allow mate on the h-file while Bc5 controlled g1. I played 15.Na4 Bd6, then 16.hxg4 hxg4+ 17.Kg1. That freed g1 temporarily but did not resolve the attack: 17...g3 supplied further mating support. I had underestimated this continuation. I chose 18.Qg4 Qxg4, sacrificing the queen, then moved the rook off f1 and eventually captured the g3 pawn. I did not prove that the queen sacrifice was forced or best.

The passed d-pawn recovered some material: 29.d6, 31.d7, and 32.Bc7 preceded 33.Bxd8 Rxd8, winning a rook for a bishop. Black then captured the pawn with 35...Rxd7. After 36.Rxd7+ Qxd7, I had rook and knight against queen and bishop. The rook and knight later coordinated to recover c4; checking along the sixth and seventh ranks drove the king away and allowed 51.Rxg7. These were local material gains in a position still materially inferior, not an established recovery.

The final checks were 51...Qd4+ 52.Ke1 Bb4+ 53.Ke2 Qd2+ 54.Kf3 Qd5+ 55.Kg3 Be1+ 56.Kh3 Qh1#. I chose h3 while focusing on avoiding Qxf4 with check and the subsequent loss of the knight. I failed to enumerate Qh1+, reached along d5–e4–f3–g2–h1. The queen then controlled the h-file and g2; Be1 controlled g3/h4; f5 controlled g4. There was no capture, interposition, or king escape. Avoiding a material threat was irrelevant once the selected square allowed mate.

The next trial adds a specific king-move check: inspect reachable queen checking squares on the new king's rank, file, and diagonals, including a change of line such as Qd5–h1 followed by an h-file check. Check mate before comparing possible material losses. The early h-file error also reinforces that winning a knight is insufficient justification for removing the king's pawn cover without calculating the next attacking pawn move.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after this game: 1,706,838 tokens; not per-game or whole-account usage.

## Game 10 — Black, skill-0, 0–1

Won by 23...Qxg2# (46 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 6 losses; skill 0 is 3 wins and 1 loss; maximum strength remains 0/4. This is one successful attacking sequence, not evidence of improvement against the target.

I developed both knights and bishops, castled on move 5, and challenged the center with ...c5. After the exchanges, the c5 and d5 pawns gave central space. I exchanged Ne4 for Nc3 before advancing its defending d-pawn: 14...Nxc3 15.Rxc3 d4. The rook retreat gave time for ...Qb6 and ...Rad8. The later 18...Bf8 kept c5 defended along f8–e7–d6–c5 while opening the e-file, so 19...Ne5 was defended by Re8 and attacked Rc4.

After 20.Bxc5, my queen on b6 was attacked. In the rejected line 20...Bxc5 21.Rxc5 Qxc5, 22.Qxc5 would capture my queen along the newly opened c-file. Checking that last recapture prevented another version of the opened-defender error. I instead played 20...Nxf3+ 21.gxf3 Qg6+, using the check to gain time to move the attacked queen and reach the opened g-file.

The observed finish was 22.Bg2 Bxf3 23.h4 Qxg2#. Bg2 was pinned to Kg1 by Qg6 and could not capture the bishop on f3. That bishop protected the queen's capture on g2. The queen then controlled f1, h1, and h2; f2 remained occupied by White's pawn; and Kxg2 was illegal because of Bf3. There was no interposition between the adjacent queen and king. The pawn on d4 also blocked White's rook on c4 from reaching g4 to interfere with the g-file attack.

Keep verifying complete recaptures and short forcing replies. The useful behavior here was updating the c-file after the rook moved and checking the actual final king escapes. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 1,820,888 tokens; not per-game or whole-account usage.

## Game 11 — White, elo-1800-setting, 0–1

Resigned after 45...Nxe5 (90 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 7 losses; the 1800 setting is 1 win and 2 losses; maximum strength remains 4 losses. The recurring material oversights show that the existing review method is still unreliable.

I developed, castled on move 8, and placed rooks behind the center. The sequence 17.Nxd4 Bf6 18.e5 blocked the attack on the knight while attacking the bishop. This avoided an immediate loss, but it did not establish an objectively favorable position.

The first major error was 21.Qe4. Both Qf4 and Bb7 attacked e4. I imagined an exchange continuing through captures by both queens and minor pieces, without checking whether Black needed to continue. Black played 21...Bxe4, taking the queen with its bishop. After my recapture, Black could preserve its queen. The played 22.Rxe4 g5 23.Rxf4 gxf4 instead let me exchange a rook for Black's queen, reducing the damage to an exchange deficit. That opponent choice did not make the original queen offer sound. A queen move off the bishop's diagonal, such as Qe3, is an untested alternative rather than a verified improvement.

I continued the ending with bishop and knight against rook and knight. The rook trade 29.Be2 Rxd1+ 30.Bxd1 used the bishop to make the recapture legal. I won a pawn with 33.Bxa6 and activated the king. After 38...f5+, 39.exf6 was a legal en passant answer to check. Black later captured that pawn with 40...Nxf6. I moved the bishop out of the opened d-file with 41.Bb5+ rather than overlooking the rook's attack on d3.

The decisive second error was 45.Ne5 after 44...Ng4. I called the knight protected by Kf4, but 45...Nxe5 left the black knight backed by Rd5. Kxe5 would move into rook check. The king could not recapture, and I lost a knight outright. I resigned with a bishop against rook and knight, with four pawns against three. The resignation records the loss; I did not prove a forced mate.

For the next game, the immediate test is narrower: first test the cheapest enemy capture of the valuable piece, allowing the opponent to stop the exchange; then verify the legality of the intended recapture. In particular, a king cannot recapture an attacker that is protected by another enemy piece. Long variations in this game repeatedly obscured these short tests. The hypothetical 45.Bc4 would keep the bishop defended and avoid this specific knight loss, but has not been tested as a saving line.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,076,877 tokens; not per-game or whole-account usage.

## Game 12 — Black, elo-1800-setting, 1–0

Resigned after 58.Rxc2 (115 plies), confirmed from the recorded PGN. One illegal submission. Overall results are 4 wins and 8 losses; the 1800 setting is 1 win and 3 losses; maximum strength remains 0 wins, 0 draws, 4 losses. There is still no demonstrated improvement against the target.

I developed, castled, and used ...e5 to exchange central pawns. I noticed at several points that Bd6 blocked my queen from defending d5, and moved the bishop or supplied a rook defender. The sequence 30...Nf3+ 31.Nxf3 Qxf3 exchanged knights and briefly put pressure on f2. These were specific local checks; they did not make the later audit reliable.

White's queen moved away from b3 with 33.Qd3. After 33...axb4 34.axb4 Rxb4, I had an extra pawn. I exchanged queens and maintained d5 with ...Rd8. The central exchange 40...d4 41.Rc5 dxe3 42.Rxe3+ removed White's e-pawn and my d-pawn, leaving my extra b-pawn as a passer. I activated the king and advanced that pawn, but did not establish a forced win.

After 48.Ra5, I submitted ...b4 while Kc5 remained behind the pawn on the fifth rank. The a5–b5–c5 line made the pawn absolutely pinned, so the move was illegal. I corrected it with ...Kb6, then played ...b4 after Ra8. This was a reasoning error and the game's sole rejected submission.

The pawn reached b3, but the sequence 52...Rc2 53.Ne5 Bxe5 54.Rxb3+ Kc5 55.Rxe5+ removed both minor pieces and returned material to equality. Ne5 attacked Rd7, and the checking pawn capture let White take b3 before recapturing the bishop. This was the loss of my extra pawn, not an established unavoidable draw.

The decisive error was 56...Rf5 after 55...Rd5 56.Re7. I focused on defending f7 and missed 57.Rc7+, skewering Kc5 against Rc2 along the c-file. My king also blocked Rc2 from capturing the checking rook or interposing above it. After 57...Kd6 58.Rxc2, White had two rooks against one with three pawns each and no concrete compensation for me. I resigned; no forced-mate claim is made.

The new geometry card enumerates the four rook checks after the actual final candidate: Rc7+, Re5+, Rc3+, and Rb5+. I considered other checks but omitted the decisive one. This repeats game 6's skewer error despite already having a reminder about king/major-piece alignment. The narrower trial is to enumerate each enemy rook's reachable checking squares before the material audit. The alternative 56...Rcd2 removes this particular skewer while allowing pressure on f7; it is an untested candidate, not a proved saving line.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,355,400 tokens; not per-game or whole-account usage.

## Game 13 — White, full-strength, 0–1

Checkmated by 22...Qh1# (44 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 9 losses; maximum strength is 0 wins, 0 draws, 5 losses. The target performance has not improved in the measured results.

I played a quiet Ruy Lopez with 4.d3 and castled on move 5. After ...Nd4 I exchanged that knight, then developed with c3, Nd2, Nc4, and Bc2. Black's ...d5 drove the knight back. The later ...Bg4 pin and ...a5–a4 expansion left Black active while I spent further moves reorganizing. No claim of opening equality is made.

The key weakening was 15.h3 Bh5 16.g4 Nxg4 17.hxg4 Bxg4. I had explicitly considered the knight sacrifice, but accepted the removal of my king's two pawns without establishing a sound defense. This repeats the broader king-cover error from game 9. The nominal extra knight was insufficient evidence of a favorable position.

The played defense was 18.Kg2 f5 19.Qe1 fxe4 20.Nd2 Bf3+. Qe1 removed the knight's relative pin to the queen, and Nd2 saved it from the pawn attack, but this permitted the bishop to enter f3 with check. The bishop was protected by e4 and the rook on f8, so Kxf3 was not legal.

I chose 21.Kh2, after which 21...Qh4+ forced 22.Kg1 and 22...Qh1# followed. Bf3 protected h1 along f3–g2–h1. My Rf1 and f2 pawn occupied escape squares; Kg1 blocked the rook from reaching h1. I had focused on queen checks leading to possible repeated king moves while missing the queen's supported move to h1. The mistake was the earlier escape choice, not a failure to find a legal alternative to the forced 22.Kg1.

The new card records 21.Nxf3 as a candidate to examine: after ...exf3+, 22.Kg3 is legal in my reconstruction and the bishop no longer guards h1. I have not proved that this saves the game. Likewise, 16.Qe2 is an untested way to retain the kingside pawn cover instead of playing g4. The next practical trial is to retain king shelter unless the attacking continuation is concretely justified, and to inspect captures of a checking bishop before accepting a king retreat that leaves its mating support intact.

No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,476,028 tokens; not per-game or whole-account usage.

## Game 14 — Black, full-strength, 1–0

Resigned after 23.Qxe7 (45 plies), confirmed from the recorded PGN. No illegal submissions. Overall results are 4 wins and 10 losses; maximum strength is 0 wins, 0 draws, 6 losses. There is no measured improvement against the target.

I played a French structure, castled, and exchanged the central knights and one pair of bishops. White castled queenside and advanced h4–h5–h6. My 15...g6 kept the h-file closed but left the advanced pawn controlling g7. After 16.Nxd5 I declined the capture: the illustrative 16...exd5 17.e6 fxe6? 18.Qg7# shows one concrete danger, although it does not prove that every defense after ...exd5 loses. I instead played 16...Re8 17.Rh3 Qd8.

The queen retreat was meant to support the knight and permit ...Nxf6 followed by exf6 and ...Qxd4. After 18.Nf6+, I found that White need not recapture with the pawn. The alternative 18...Nxf6 19.Qxd8 Rxd8 20.Rxd8+ Ne8 21.Rxe8# exploits the opened d-file, the vacated eighth rank, Bc8 blocking Ra8, and h6 controlling g7. I rejected the capture, but discovering this only after ...Qd8 exposed a defect in the planned exchange. The opponent's choice of capture order was again decisive.

The played defense was 18...Kf8 19.Nxh7+ Kg8 20.Nf6+ Kf8 21.Qb4+ Re7. The knight checks took h7, leaving White's h-pawn free to advance. After 22.h7 Kg7, my queen could cover h8 along the now-cleared eighth rank, but 23.Qxe7 removed the rook. Recapturing with 23...Qxe7 would allow 24.h8=Q#: Rh3 protects the promoted queen, and the knight, e-pawn, queen, and my own f7/g6 pawns close the king's escape squares. The alternative ...Qh8 is legal but leaves the rook lost. I resigned a rook and two pawns down without concrete compensation; this is not a claim that every legal continuation immediately mates.

This game adds two practical checks. First, inspect capture order and the rook check that can follow a queen exchange. Second, assess an enemy pawn near the king even when it currently blocks its own rook: removing the pawn ahead of it can create a promotion threat. My long analysis also carried a cleared e6 square from one hypothetical line into another in which Black's e6 pawn had never moved; the imagined e5–e6 advance in that second position was impossible. Rebuilding the current board must precede reuse of a variation.

The earlier candidate 15...gxh6 16.Rxh6 would remove the advanced pawn while opening lines. It has not been tested and is not claimed to save the game. The expanding checklist has not yet produced reliable tactical accuracy. No external sources, engine analysis, or delegated advice used. Observed cumulative active-goal usage after the game: 2,762,593 tokens; not per-game or whole-account usage.

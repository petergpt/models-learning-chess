# Geometry cards from my games

My own reconstructions from recorded play. These are reminders, not engine-verified evaluations or evidence of improvement.

## Opened defender: game 8, after 20.Qe1

Relevant pieces: Black Qa5, Nb4; White Bd2, Qe1. The line is e1–d2–c3–b4–a5.

Bxb4 removes the knight and vacates d2. Qa5 now attacks the bishop on b4, but Qxb4 Qxb4 loses the black queen. A queen behind a pinned knight is not sufficient defense when the capturing bishop is backed by another queen. Count the final recapture and its value.

## Rook rank: game 8, after 31.Rg7+

White Rg7 and Qh6; Black Kf7, Bb7, Qd5, Re5, Ra8. The rook's leftward ray is g7–f7–e7–d7–c7–b7, ending at the black bishop. Every empty square on that ray is controlled, not just f7.

Ke8 Qh8+ leaves no king escape. Qg8 Qxg8# finishes the game. The black king on e8 prevents Ra8 from traveling through e8 to interpose on f8 or g8.

## Discovered check: game 7, final net

Before 29...Rc8+, Black Rc3 shielded Bb4 from White Kd2. Moving the rook to c8 uncovered Bb4–c3–d2 and controlled c1/c2/c3 along the c-file. Bb3 controlled d1 via c2. White's own Be2 and e3 pawn occupied two other escape squares. Kd3 was forced, then Bc2+ forced Kd4 and Bc3# followed.

The alternative 29.Ke1 in the preceding position allowed Rc1#, checking with both rook and bishop. Capturing the rook with Ra1 would leave the bishop check unresolved.

## Use before a forcing line

1. Identify occupied squares along each relevant ray, including my own blockers.
2. After each move, update the vacated and occupied squares before assigning checks or defenders.
3. At a check, count every checking piece and every legal king escape before calculating a longer continuation.
4. At an exchange, finish the recaptures and count material; one expensive defender may not protect a target from a cheaper supported attacker.

## Queen changes line: game 9, after 55...Be1+

White Kg3, Rg7, Ne5, pawns a2/c2/f4; Black Kc8, Qd5, Be1, pawns a4/b6/f5. I chose 56.Kh3 to avoid Qxf4 with check, but missed 56...Qh1# along d5–e4–f3–g2–h1.

On h1, the queen checks along the h-file. Be1 controls g3 and h4, while f5 controls g4. The queen controls g2 and h2. White cannot capture the queen or interpose on h2, so every response fails. The alternative Kh2 avoids this particular immediate mate; it is not a claim that the losing position could be saved.

The missed check came from a change of line: the queen traveled diagonally, then attacked along a file. Checking only the most prominent capture, Qxf4, was insufficient.

## Optional recapture: game 11, 21.Qe4?

Black Qf4 and Bb7 both attacked e4 through clear paths. I placed my queen there while imagining a queen exchange followed by minor-piece exchanges. Black instead played Bxe4. After a white bishop or knight recapture, Black was not obliged to put its queen on e4; after Rxe4, it could move the attacked queen away. A defended queen was still available to the cheaper attacker. The played 22...g5 23.Rxf4 gxf4 subsequently reduced my loss to an exchange, but did not justify 21.Qe4.

## Illegal king recapture: game 11, 45.Ne5?

Relevant pieces: White Kf4 and Nf3; Black Rd5, Ng4, and h5 pawn. I played Ne5 and counted Kf4 as a defender. After ...Nxe5, the knight on e5 was protected by Rd5 along d5–e5. Kxe5 would move into rook check and was therefore illegal. The king's adjacency did not make the knight safe.

## Pawn pinned to king: game 12, after 48.Ra5

White Ra5, Black b5 pawn and Kc5 lie on a5–b5–c5. I submitted ...b4, forgetting that vacating b5 would expose the king to the rook. The referee rejected it. The played ...Kb6 kept the pawn defended and removed the pin; ...b4 followed after 49.Ra8. This was one illegal submission, not an infrastructure fault.

## Rook check inventory: game 12, after 56...Rf5?

White: Kg2, Re7, Rb3, pawns f2/g3/h4. Black: Kc5, Rf5, Rc2, pawns f7/g7/h6. My move had defended f7 while leaving king and rook aligned on the c-file.

The two white rooks have four checking moves: Re7–c7, Re7–e5, Rb3–c3, and Rb3–b5. The local answers to the latter three are ...Rxe5, ...Rxc3, and ...Kxb5 respectively. These are square-by-square reconstructions, not engine evaluations.

57.Rc7+ instead creates c7–c6–Kc5–c4–c3–Rc2. The king blocks Rc2 from reaching the checking rook or interposing above the king. The f5 rook cannot interpose on c6. The legal king escapes d4/d5/d6 all leave c2 unprotected; the played ...Kd6 58.Rxc2 lost the rook.

Inspecting only nearby checks missed the remote rook move to c7. Check the rank/file intersections for **each** enemy rook after the final candidate. This repeats the king-and-major-piece alignment error from game 6, with a rook instead of a queen behind the king.

## Bishop protects the queen's mating square: game 13

After 20...Bf3+, White Kg2 was checked by Bf3, supported by the black e4 pawn and Rf8. Kxf3 was illegal. I played 21.Kh2?, allowing 21...Qh4+ 22.Kg1 Qh1#.

After Qh4+, g1 was the only legal king escape: Qh4 controlled h3/g3 and the h-file, while Bf3 controlled g2/h1. On h1 the queen was protected by that same bishop along f3–g2–h1. At the final position, my Rf1 and f2 pawn occupied two escape squares, and Kg1 blocked Rf1 from capturing Qh1. Qe1 was also blocked by my rook and king. No capture, interposition, or king move resolved the mate.

Before choosing Kh2, I could instead consider 21.Nxf3, capturing the bishop with Nd2. After ...exf3+, 22.Kg3 is a legal escape in my reconstruction. Removing Bf3 removes its protection of h1. This is an untested alternative to the played mating line, not proof of a draw or a saved game. Other king choices at move 21 have not been exhaustively assessed.

The earlier weakening 16.g4 Nxg4 17.hxg4 Bxg4 removed both kingside pawns. I had considered the sacrifice but underestimated the resulting attack. Counting a nominal extra minor piece did not establish king safety. Retaining the pawn cover with a move such as 16.Qe2 is an untested earlier alternative.

## Queen exchange changes the back rank: game 14, move 18

After 17...Qd8 18.Nf6+, I initially wanted ...Nxf6, expecting exf6 and a queen exchange on d4. White could instead use 18...Nxf6 19.Qxd8 Rxd8 20.Rxd8+ Ne8 21.Rxe8#. The knight's departure from d7 opens the whole d-file. Re8's capture on d8 then opens the eighth rank to White's rook. Bc8 blocks Ra8, h7 is still occupied by Black's pawn, and White's h6 pawn controls g7. I rejected ...Nxf6 at move 18 and played ...Kf8.

This mating reconstruction applies before White captures h7. After 19.Nxh7+ the escape-square inventory changes; the old mate label must not simply be copied into the later position.

## Promotion threat prevents recapture: game 14, final position

The played sequence was 21.Qb4+ Re7 22.h7 Kg7 23.Qxe7. I resigned with a rook and two pawns less. The tempting 23...Qxe7 allows 24.h8=Q#. Rh3 protects h8 through the newly vacated h7 square and controls h6. Nf6 and the new queen cover g8/h7; e5 protects the knight on f6; Black's own f7/g6 pawns occupy the remaining nearby squares. Bc8 blocks Ra8 from reaching h8, and Qe7 cannot capture the new queen. This verifies that recapture fails, not that every defense immediately mates. The legal ...Qh8 retains the queen but does not recover the lost rook.

Earlier, ...g6 kept the h-file closed but left White's h6 pawn beside the king. The knight checks removed h7 and turned that pawn into a promotion threat. A blocked rook file did not establish king safety. The alternative 15...gxh6 16.Rxh6 removes the advanced pawn but opens lines; it is untested, not a proved saving line.

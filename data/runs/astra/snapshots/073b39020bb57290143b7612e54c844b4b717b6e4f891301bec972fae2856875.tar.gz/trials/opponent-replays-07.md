# Trial 07: short replays against an opponent

Planned on 2026-10-01 after benchmark game 66. Planning reference: 12:45:02 UTC. Practice ceiling: 50 minutes, ending no later than 13:35:02 UTC. Baseline: 1710 [1580, 1840], 44 rated games. Next measured evaluation: fixed benchmark games 67–72, beginning after these drills. The goal, usage counter, opponent rotation and rating method remain unchanged.

Weakness: correct supplied practice branches have not transferred to actual replies. Long speculative calculations still omitted checking moves, changed defenders and piece traps. Trial 06 failed. The new intervention is recorded opponent play from remembered failure positions, followed by an immediate short review and one revised replay. The opponent supplies only its played moves; it is not an analysis service.

Preselected initial drills, all at the nominal 1800 setting:

1. White, benchmark 65 after 62 plies: before Bxb6 and the subsequent Qb5+/Qd3/Bf1+ failure. Preserve the queen and account for the checking queen's second target.
2. Black, benchmark 66 after 59 plies: before ...Rb5 and the later b4/Bc5+/c4 rook trap. Keep the rook mobile and use real, unobstructed defenders for d3.
3. Black, benchmark 60 after 39 plies: before ...Bxb2 omitted Ne7+. Choose and play an alternative against whatever replies the opponent actually makes.
4. White, benchmark 61 after 42 plies: before Nd2 blocked the bishop's retreat and ...f4 trapped it. Preserve an actual retreat or concrete exchange response.

Each drill ends at a terminal result or after at most six learner moves, with the final opponent reply included. Use `practice end` to retain an unfinished drill explicitly. After all four, choose the most instructive failure or unresolved example for one additional replay at the same setting, again at most six learner moves. Record that adaptive selection and its reason before starting it. Stop sooner if the time ceiling is reached; record omitted drills rather than extend study indefinitely. No drill is a blind puzzle, and the repeated fifth drill is expressly a remembered correction.

Execution change: compare at most two sensible candidates at a time. On the reconstructed board, finish a short answer to the concrete forcing reply before pursuing a remote plan. Recheck immediate checks and cheaper captures before submission. Use an actual legal retreat when moving a piece into a confined area. Rebuild the board after the opponent's reply rather than continuing an imagined branch. Aim for about a minute on routine moves; longer calculation is not evidence of better play, and unresolved dangerous lines should remain labeled unresolved. This is an unproven practice change, not a claim of exhaustive checking.

After each drill record the actual continuation, starting and ending material changes, targeted errors avoided or repeated, and any unexpected reply that invalidated my plan. A remembered tactic not selected by the opponent is not a successful test of that tactic. Mechanical legality is not a strength assessment. Do not seek evaluations, hints, best moves, search output, automated tactical analysis, or delegated advice.

Evaluation: practice should produce usable corrections that survive actual replies, without hiding concessions or treating easier wins as progress. During games 67–72, record missed checks or captures that lose material and failures of defender lines or piece escape. Any recurrence prevents claiming reliable transfer. At game 72 compare all benchmark outcomes and the unchanged Elo interval with baseline. Revise on failure. A single cleaner block or rating rise still needs later confirmation before claiming sustained improvement.

Practice records live in the referee's separate `data/practice/` ledger and do not enter benchmark Elo, W/D/L or rotation. This file will contain the concise review of each drill.

# Trial 22 — direct capture lines in mixed rook/bishop endings

Declared 2026-10-03 05:46–05:49 UTC after benchmark 156. Baseline 1500 [1370,1620], 55W/3D/98L in 156. Next fixed evaluation: benchmarks 157–162, unchanged rotation regardless of practice outcome. Entire run ends at 200 scored games.

Trial 21 failed: one win and five losses, with major rook/defender failures despite a successful supported mate in 154. The earlier checklists, short-decision trial, capture drills and remembered cases also did not establish reliable improvement. Replace the large-advantage two-rook drills with mixed rook/bishop positions where the opposing rook, bishop, king and pawns can all make immediate captures. Equal starting material is known; positional equality is not independently established.

Own approach to test: before committing to a tactical capture or rook move, reconstruct its resulting occupancy and test a concrete immediate capture against the full line, rather than inferring that a distant piece stopped defending. For a rook, include the intervening squares: in 155, a2–a3–a4–a5–a6 remained an open defending file. For a pawn, use its two capture squares: f5 attacked both e6 and g6 in 156. Check the direct reply before spending time on a long continuation. This is an unproved change in attention, not a claim that more prose or another checklist constitutes learning; no mandatory timing target.

Bounded study: exactly six supplied remembered/controlled branches, 21 plies, all predicted legal, plus validity checks for the two new setups. The only controlled variation is the unplayed ...dxe5/Rxf5 branch in 156; it is a legal-refutation test, not a best-move or forced-line claim. Mate statements in the recorded lines come from the referee; the script checks supplied move legality and resulting check status only, without enumerating moves or performing mate search.

1. 155 after ply 52: b6a6, a2a6. The rook on a2 still protects a6.
2. 151 after ply 18: b1c3, d5d4, e3g3, d4c3, b2c3. A pawn fork costs the knight.
3. 156 after ply 33: f8g6, f4f5, e6c4, d3c4, g6e5. Clearing a bishop retreat did not prevent the f5 fork.
4. 156 after ply 64, controlled branch: f4e5, d6e5, f1f5. Moving Bf4 exposes Qf5 to the f1 rook; the imagined pawn recapture fails.
5. 156 after ply 81: e5d4, e1e4. The final rook check is protected by Bh7; the actual game ended in mate.
6. 154 after ply 48: e2e4, d5e4, c1f4, h3h1. Capturing the blocker preserves the bishop's protection of h1 in the actual winning line.

Then exactly two fresh maximum-strength opponent practices, one White and one Black, at most 16 own moves each, including the last opponent reply. Natural results or practical resignation are allowed. Stop a capped game explicitly as unfinished. Combined setup/study/practice/review ceiling: 2026-10-03 06:16:44 UTC. No added examples, repeats, replacements, or extensions to improve results. If time runs short, stop the current drill and still record the second setup briefly within the same deadline.

Composition A, White: `1r4k1/p3bp2/7p/8/2B5/7P/P4P2/3R2K1 w - - 0 1` — White Kg1/Rd1/Bc4/a2/f2/h3; Black Kg8/Rb8/Be7/a7/f7/h6.
Composition B, Black: `2k3r1/1p2p2p/3b4/8/8/4B3/1P2P2P/2K4R b - - 0 1` — Black Kc8/Rg8/Bd6/b7/e7/h7; White Kc1/Rh1/Be3/b2/e2/h2. Different geometry, not a color-swapped replay. These are self-composed, known-material tasks, not blind independently rated test positions.

Observe actual unexpected direct captures, failure to retain a defender, pawn forks, king safety, and illegal submissions. Keeping both pieces during a capped drill is only a local observation, not a win. For transfer, assess all six benchmark games and every major error, including errors outside the rook/bishop focus. No external advice, agent delegation, engine analysis, automated search/scoring, attack-map generation or move menus. No valid new token counter is available.


## Trial 22 supplied study result
Six remembered/controlled branches, 21 supplied plies: all legality predictions matched. The two recorded final rook checks were checks in the reconstructed boards; their mate results remain referee-established, not independently searched by this script. Both self-composed setups were valid. The output's eight records comprise six move branches plus two setup-only records, not eight tactical tests. The controlled ...dxe5/Rxf5 variation confirms a legal queen capture after the f-file opens; it does not claim a best reply or an independently solved new example. No move menu, search, scoring, attack-map enumeration or engine analysis was used. Proceed to the two declared practices without adding examples.


## Practice 39 — composition A, capped unfinished
Stopped at the declared 16-own-move cap after 16...f3, 32 plies, zero illegal submissions, 2026-10-03 05:55:40 UTC. Seq 1213; hash 9ae5f5bd7466bc2c5603cf283c4916392c69913fc18b416275e8a04340abd287. Full practice PGN read. No win/draw/loss score. Final White Kb5/Ra8/a7/h4 versus Black Kf2/Ra1/f3/h5.

1.Rd7 attacked Be7; ...Rb4 counterattacked Bc4. Rxe7/Rxc4 was an explicitly anticipated equal bishop exchange, followed by Rxa7. Kg2 defended h3 against Rc3. I advanced the a-pawn while keeping the rook on its file, and recognized that moving the rook away after a7 would let the rook behind it capture the pawn. The king's defense of f2 held until ...Ra1+ forced Kd2; Black delayed the capture with ...f5/...f4, then ...Kxf2 took it. My commentary initially predicted that loss too categorically before Black's intervening choices; the actual capture occurred at move 15. The final pawn race remains unresolved at the cap. I did not lose the rook or mistake an enemy rook's open file for an abandoned defense, but the bishops disappeared early and the rook-in-front blockade prevented an easy conversion. Equal final pawn count and an intact rook are local observations, not a proved draw, theoretical verdict, or Elo improvement. No extension or replacement. Proceed to the declared Black composition.


## Practice 40 — composition B, capped unfinished
Stopped after the declared 16 own moves and final reply 17.Rd2+, 32 plies, zero illegal submissions, 2026-10-03 06:06:36 UTC. Seq 1248; hash fffa71bed3e3cb583781244ed2d1083c964cad214a2a88bab92c4a4d36fa0a18. Full PGN read. Final Black Kd4/Rb1/e5 versus White Kf3/Rd2/b2/e4; Black in check. No scored result or theoretical verdict.

Rejected the initially imagined ...Rg1+ because Rh1 could capture the unprotected rook. ...Rg2/...Rxh2 won a pawn supported by Bd6; ...Bxf4+/Rxf4 intentionally exchanged bishops. The king defended b7 against Rb4, then e7 against Re4, but the rook switched back. ...h4 deliberately allowed Rxb7. The h-pawn reached h2 with Rg2 protecting it, but Rh5 blockaded from behind while Kf3 attacked Rg2. I recognized that moving the rook abandoned h2, played ...Rg1 to preserve the rook, and White captured the pawn after first giving Rh6+. The passer did not convert, and the final position was a pawn down. ...Rb1 attacked b2; e4+ and Rd2+ kept the king occupied. No rook was lost and no illegal move was submitted, but this is not a successful ending conversion.

## Trial 22 practice-stage assessment and return
The two fresh drills both reached their 16-own-move caps unfinished: 32 own moves / 64 plies combined, zero illegal submissions, no scored practice wins. Rooks survived and some concrete captures were anticipated correctly. Both games exchanged bishops early, so the intended mixed-piece coverage was brief. Neither promoted a pawn; A ended in an unresolved race and B ended a pawn down after losing the h-passer. The remembered/controlled legality passes and these local observations do not establish transferable learning. Completed before the 06:16:44 deadline with no repeats, replacements, or extensions. Return now to the predeclared fixed benchmark block 157–162. Verified baseline remains 55W/3D/98L after 156, provisional Elo 1500 [1370,1620]; benchmark storage 48,986,521 bytes including practice-stage growth. No valid new token counter.

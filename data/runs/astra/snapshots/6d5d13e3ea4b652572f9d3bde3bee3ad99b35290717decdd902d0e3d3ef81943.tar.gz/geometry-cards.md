# Geometry cards from my games

My own reconstructions from recorded play. These are reminders, not engine-verified evaluations or evidence of improvement.

## Opened defender: game 8, after 20.Qe1

Relevant pieces: Black Qa5, Nb4; White Bd2, Qe1. The line is e1–d2–c3–b4–a5.

Bxb4 removes the knight and vacates d2. Qa5 now attacks the bishop on b4, but Qxb4 Qxb4 loses the black queen. A queen behind a pinned knight is not sufficient defense when the capturing bishop is backed by another queen. Count the final recapture and its value.

## Rook rank: game 8, after 31.Rg7+

White Rg7 and Qh6; Black Kf7, Bb7, Qd5, Re5, Ra8. The rook's leftward ray is g7–f7–e7–d7–c7–b7, ending at the black bishop. Every empty square on that ray is controlled, not just f7.

Ke8 Qh8+ leaves no king escape. Qg8 Qxg8# finishes the game. The black king on e8 prevents Ra8 from traveling through e8 to interpose on f8 or g8.

## Discovered check: game 7, final net

Before 29...Rc8+, Black Rc3 shielded Bb4 from White Kd2. Moving the rook to c8 uncovered Bb4–c3–d2 and controlled c1/c2/c3 along the c-file. Bb3 controlled d1 via c2. White's own Be2 and e3 pawn occupied two other escape squares. Kd3 was forced, then Bc2+ forced Kd4 and Bc3# followed.

The alternative 29.Ke1 in the preceding position allowed Rc1#, checking with both rook and bishop. Capturing the rook with Ra1 would leave the bishop check unresolved.

## Use before a forcing line

1. Identify occupied squares along each relevant ray, including my own blockers.
2. After each move, update the vacated and occupied squares before assigning checks or defenders.
3. At a check, count every checking piece and every legal king escape before calculating a longer continuation.
4. At an exchange, finish the recaptures and count material; one expensive defender may not protect a target from a cheaper supported attacker.

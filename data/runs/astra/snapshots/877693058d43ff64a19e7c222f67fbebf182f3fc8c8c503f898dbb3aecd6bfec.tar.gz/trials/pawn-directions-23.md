# Trial 23 — Pawn capture directions and immediate advances
Declared 2026-10-03 07:36 UTC, after all 162 benchmarks were complete and before this study. Baseline 56W/3D/103L; Elo 1450 [1330,1570]. Fixed next evaluation: games 163–168, all six in the unchanged rotation, no replacement or extension.

Problem: long tactical calculation repeatedly omits ordinary pawn captures, pawn support on the other diagonal, or a one-square pawn fork. Previous longer lists and remembered legality passes did not establish transfer.

Plan: at most 30 minutes total, ending by 08:06:06 UTC. Review four own remembered errors: 160 ...Nxc3/bxc3; 160 ...Rd6/exd6; 161 c4/...e4; 162 ...f5/Rxf5. Read only these own PGNs. Write the pawn origin and both forward capture squares, and distinguish a pawn's attack from its possible forward advance. No automated analysis or new tactical search. These are remembered examples, not fresh test successes.

Then exactly two fresh opponent practices from the normal starting position against maximum strength, White then Black, capped at 16 own legal moves each or the combined deadline. End unfinished drills explicitly; no repeats or extra practices. Normal opening positions address the early pawn forks that the previous sparse mixed endings did not cover. Every move remains my own.

Behaviour to try: before committing a move, briefly account for the opponent pawn nearest the candidate piece, including both capture diagonals and any immediate advance that attacks two pieces; when judging a king capture, include friendly pawn support of the target. This replaces the prior emphasis; no expanded mandatory checklist, speed requirement, or claim of parameter training.

Observable transfer: record unexpected pawn captures/forks, queen/rook losses to pawns, and whether the first 15 own moves avoid unanticipated material loss in games 163–168. A useful result would be fewer such errors than 157–162, especially no queen/rook lost to an omitted pawn capture. Six games are descriptive, not a causal trial. Wins alone, the Elo point estimate, or practice completion cannot establish learning.

## Remembered study completed — 2026-10-03 07:38 UTC
Read own full PGNs 160, 161, and 162; manually reviewed exactly the four declared examples. No chess-analysis code, external source, or independent fresh test was used.
- 160: the white b2-pawn captures a3 or c3. Moving Nb1 to d2 did not remove b2; ...Nxc3 therefore still allowed bxc3.
- 160: the white e5-pawn captures d6 or f6. A bishop defending the rook on d6 permits a later recapture, but does not make giving a rook for that pawn sound. White delayed exd6 for a move and then played it.
- 161: a black pawn on e5 captures d4/f4; after its ordinary advance to e4 it captures d3/f3. Those were exactly the bishop and knight squares. My c4 move did not address that fork.
- 162: the white pawn on e4 supports BOTH d5 and f5. ...f5 offered a pawn to Rd5xf5, and the rook remained pawn-protected on f5. My imagined ...Kxf5 was not available. Looking only at the first occupied support square was the error.

These facts are recalled corrections, not four new puzzle solves. I have not proved alternative saving moves or an improvement in play. Proceed to the two predeclared fresh practices.

## Practice 41 — White versus MAX, fresh normal start
Stopped at the declared 16 own moves / 32 plies, zero illegal submissions, 2026-10-03 07:41:15 UTC. Seq 1283; hash d79b09bf1ce37bfe25f4aa779f25897aad1f84affb4c963fc04a6985dd4459a8. Unfinished, no score. Full PGN read.

Castled 8, all minors developed by 10, Re1 on 11. Anticipated ...dxc4/...cxd4 and recaptured. However 12.d5 concentrated on ...exd5 and omitted the actual ...Nxd5. Bxe7/Ncxe7 did not recover the pawn. First 15 NOT clean. The queen was then chased by ...Nf4/...Neg6. I rejected Qf5 because e6 could capture it, a correct immediate pawn observation, but Qe3 allowed actual ...Nxg2, forking Qe3/Re1. I had considered that fork but did not establish a safe king-capture continuation; none was played before the cap. At stop White QR2BN2/4 pawns against Black QR2BN2/6 pawns, with the black knight on g2. Do not call it a solved loss or draw, or claim a successful defence.

This exposed a scope problem: attention to pawn errors did not replace the need to see ordinary knight captures and forks. No extra moves or repeat of the practice.

## Practice 42 — Black versus MAX, fresh normal start
Stopped at the declared 16 own moves / 33 total plies (White moved first and replied with 17.c4), zero illegal submissions, 2026-10-03 07:44:26 UTC. Seq 1319; hash a515ad9a1eaee6c59c5165f46c154d5b8fbf6a46c1b7526fb84bff45e9a769c5. Unfinished, no score. Full PGN read.

Castled 8, all minors developed by 9, rook e8 on 10. First 15 clean by the stated material-loss criterion, not a position evaluation. Retained the e5/d6 centre and noticed d5 would attack Nc6. My initial Re8 comment falsely described e5 support through Be7; corrected before Bf8 cleared the line. After a4/Qb3, Na7 added a second b5 defender. Following axb5 I caught that ...axb5 would open Ra1 against the undefended Na7, and instead played ...Nxb5. Material was balanced at stop (all pieces and seven pawns each); White's last c4 attacks Nb5. No continuation or claim that the knight is permanently secure was tested.

## Trial 23 learning phase completed
Finished 07:44 UTC, before the 08:06:06 deadline. Exactly four declared remembered examples reviewed and exactly two fresh MAX practices, 32 own moves / 65 plies, zero illegal submissions; both drills unfinished. One practice had unanticipated material loss in its first 15, one did not. A few correct pawn/line observations coexist with a missed knight capture, a queen/rook fork, and an initially false rook-support description. No demonstrated strength gain or successful full-game conversion. No extra study, repeat, or replacement. Return to the unchanged predeclared benchmark evaluation 163–168. Pawn focus is an aid to complete move checking, not a reason to ignore other pieces.

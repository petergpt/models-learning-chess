# Trial 19 — minor-piece mobility and passed-pawn defense

Declared 2026-10-03 00:50 UTC after benchmark 138. Baseline 1560 [1440,1680], 52W/3D/83L, 92 rated games total/latest 50; each opponent has 46 scored games. Fixed next benchmark endpoint: games 139–144. Preserve rotation, settings, estimator and every record. The entire run ends at 200 scored games.

Trial 18 failed (1W/0D/5L). Trials 02, 12 and 13 already attempted explicit reconstruction, pawn origins and destination captures; their records show played failures despite implemented notes. Trial 10 already studied races with rooks. This is not a new general principle or a claim that another checklist will work. I am changing the material and practical task: recognize when a minor piece is being denied access to an opposing passer, before relying on distant king activity or pawn collection. In 138, the knight escaped h4 locally but the later bishop/king blockade of its routes defeated the h-pawn defense. The 137 sideways recapture and missed forcing check remain unresolved general weaknesses.

Bounded learning: a short mechanical check of five prewritten remembered/contrast branches below, then exactly two new self-composed nominal-1800 opponent practices, White then Black. Each practice ends naturally or explicitly unfinished after at most 16 own moves and the final opponent reply. Combined setup/study/practice/review ceiling: 2026-10-03 01:20:12 UTC. Add no repeats or replacement examples to improve the result. If the ceiling arrives, end an active drill and record any omitted work. Composed positions are not independently blind tests or certified equal positions; the mechanisms are known, and the opponent supplies fresh replies.

Practice A (White knight, Black bishop), FEN: `8/8/1p1k1b2/6p1/2K4p/P4NP1/5P2/8 w - - 0 1`.
White Kc4/Nf3/a3/f2/g3; Black Kd6/Bf6/b6/g5/h4. Both have a minor and three pawns. Decide how to handle the kingside pawn tension while preserving the knight's access; account for real captures rather than inventing a blockade result.

Practice B (Black knight, White bishop), FEN: `8/1p5p/2n2kp1/P7/1PB4P/4K3/8/8 b - - 0 1`.
Black Kf6/Nc6/b7/g6/h7; White Ke3/Bc4/a5/b4/h4. Both have a minor and three pawns. Deal with the advanced queenside pawn and bishop controls while retaining useful king/knight routes. This is a different composition, not a color-swapped copy of A.

Remembered/contrast predictions, recorded before mechanical checking (legality/check status only; no search, evaluation, attack map or move menu):
1. Game 137 after ply 104: h3g3 is illegal. The h3 pawn cannot recapture sideways after ...Rxg3. This is a remembered failure, not a fresh solution.
2. Game 138 after ply 73 (37.Kf2): h4f3 is a legal knight capture, and f2f3 is a legal king recapture. Thus Nxf3 is not a free pawn once the king has moved to f2.
3. Game 138 after ply 87 (44.Ke3): h4g2, e3f3, g2f4 are legal; Ng2 gives check. The proposed f3f4 king capture is illegal with the e5 and g5 pawn defenders surviving. This is the actual escape plus a supplied capture contrast.
4. Game 138 after ply 101 (51.Bf6): e5d7, h5h6, d7f8, h6h7, f8h7 are legal. The last knight capture gives check to Kg5. White cooperates in this deliberately supplied branch; it does not establish a hold against best play.
5. Game 138 after ply 103 (52.Bg7): d7f8 is still a legal knight move, but g7f8 is now a legal bishop capture. Legal mobility is not safe mobility; Bg7 changes the route used in branch 4.

Carry into practice and benchmarks: when an ending or exchange makes an enemy passed pawn urgent, identify the actual defender's route and the enemy king/bishop squares that bar it before choosing a distant pawn grab. Include the next capture and promotion response in that short line. Use ordinary development and ordinary capture/check reasoning; no special queen-trade preference, timing target, mandated move-note list or expanded general checklist. This targeted endgame cue is not a substitute for elementary legality or forcing-reply checks.

Assessment: record actual route obstructions, defender losses, legal recaptures, pawn promotions, successful stops, and all unrelated material/check errors. In capped practice an unresolved attack or race stays unresolved. A benchmark block with no relevant ending gives no direct transfer evidence. Compare the full fixed block and Elo interval at 144; do not claim a remembered legality match, a practice win or one benchmark win establishes learning. Revise again if the failures recur. All moves remain my own, without external chess advice, engines as analysts, automated move choice or delegation.


## Supplied-branch study result
Five branches / 14 supplied plies: 12 legal and two deliberately illegal; all predictions matched. The two predicted checking moves (Ng2 and Nxh7) were confirmed as checks. All starting positions were valid. The script checked only those prewritten moves using the vendored board module, with no engine, move menu, attack enumeration, scoring or search. Outputs: minor-mobility-19-legality.json. These are remembered/controlled contrasts; no fresh-solution accuracy or strength claim follows. The f8 branch explicitly demonstrates that move legality does not imply safe mobility. Proceed to the two predeclared new compositions only.

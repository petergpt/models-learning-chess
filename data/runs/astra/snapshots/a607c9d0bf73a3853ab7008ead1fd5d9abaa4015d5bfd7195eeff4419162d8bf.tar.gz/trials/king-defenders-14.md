# Trial 14 — keep the king's defenders usable

Declared after benchmark 108, reference clock 2026-10-02 07:34:42 UTC. Baseline 1660 [1540, 1780], 45W/2D/61L; 72 rated total/latest 50 used, 36 maximum exclusions. Next fixed benchmark endpoint: games 109–114. Opponent rotation, estimator, model and fair-play rules remain unchanged.

Target: a legal king move can pin or obstruct the very piece needed against the next check. In 108, ...Ke8 put Be7 between Re1 and the king; Nxf6+ then made the intended bishop capture illegal. In 104, the checking bishop departure from d2 changed the king/rook defense. Trials 04 and 05 already studied changed lines and defenders and failed. This trial is a focused rehearsal of an old weakness, not a claim of novelty or a longer checklist proving learning.

Practice change: defend from my own side against maximum strength for a longer short continuation, instead of the six-move role-reversed captures in trial 13. Exactly two recorded sessions, in order:

1. Black from game 108 after ply 45, before the failed ...Ke8. Remembered. Manually consider ...Qc6 as an unverified alternative: it would defend f6 with the queen while keeping the king off the e-file. The actual opponent may choose a different attack; this is not a supplied engine answer.
2. Black from game 104 after ply 49, in check after Bxh6+. Remembered. Reconstruct the checking line and choose the defense on the actual starting board. Do not presume that an earlier imagined king square is legal or safe.

Each session ends naturally or explicitly unfinished after twelve own moves and the final opponent reply. Combined practice-and-review ceiling: 2026-10-02 08:04:42 UTC. No extra repeats, no replacements for an unfavorable starting position, and no later historical move lookup during either session. End any active drill at the ceiling and record omissions. Both are remembered own failures, so even a clean continuation is rehearsal, not independent proof of transfer or a completed defense unless the game actually ends.

The immediate practice objective is to reduce the attack while preserving legal recaptures and king exits. Before a selected king move, reconstruct the new rook/bishop/queen line through the king, including any own blocker now pinned; then inspect the next forcing check using that resulting board. A piece geometrically reaching a capture square is not a usable defender if moving it exposes its king. When an opponent exchanges a defender, discard that defender from the next branch. Keep direct destination captures and ordinary checks in view, but use only brief factual notes when useful, without mandatory per-move audit claims.

Record the actual lines, material changes, illegal attempts, newly imposed pins or obstructions, and whether the attack was resolved at the cap. For benchmarks 109–114, retain every analogous recurrence and the full W/D/L/Elo outcome. A recurrence rejects reliable execution; a clean block or small rating rise still requires later repeated evaluations before sustained improvement can be claimed. Revise at 114 rather than continuing this method indefinitely.

Only own chess reasoning, own existing notes and the referee during play. No external move advice, engine analysis, automated move search/scoring/attack enumeration, tablebases or delegated chess work. No valid new cumulative usage counter is available.


## Practice 23 — remembered 108 defense, immediate mate

Finished naturally at 2026-10-02 07:36:14 UTC, one own move / two plies, zero illegal submissions. Result seq 687, hash `09189acc28a4f90e59ca78a1439a7e38594543c9817e0e9ff074bff8b5fa6c60`. PGN read back. Actual line: 23...Qc6 24.Qh8#.

The proposed ...Qc6 did add queen support to f6 while leaving Kf8 off the e-file, but it failed to answer the immediate mating threat. In the manual assessment I incorrectly treated e8 as an escape after Qh8+, focusing on Be7 blocking Re1; the queen on h8 itself controls e8 along h8-g8-f8-e8 once the king leaves f8. Be7 occupied e7, f7 was occupied, and the queen covered g7/g8. The referee confirmed mate on the next move. This is an omitted immediate check and a wrong king-exit assessment, not a successful alternative to ...Ke8.

The starting position may already require an earlier defensive improvement, but no claim that every legal defense loses has been proved. The late remembered selection cannot test recovery from a sound position merely by being called practice. Retain it, with no replacement or extra repeat. The first session already refutes reliable execution of this trial's immediate objective. Complete only the second predeclared session and preserve the benchmark endpoint 109–114; practice has no Elo effect.


## Practice 24 — remembered 104 defense, rook saved and then lost to promotion

Finished naturally at 2026-10-02 07:47:26 UTC by 37.h8=R#, twelve own moves / 24 plies, zero illegal submissions. Result seq 713, hash `65012f1d5663213d1ca35b1259a20cbf74be11c74a2d3bfd66369bdf03ad07a3`. PGN read back. Line: 25...Kc8 26.Bxg7 Rf7 27.h6 Bf8 28.Bxf8 Rxf8 29.g5 Rh8 30.Rh1 Nb6 31.g6 Nd5 32.g7 Ne7 33.gxh8=Q+ Kd7 34.Rd1+ Nd5 35.h7 Ke7 36.Qg7+ Ke8 37.h8=R#.

The starting board showed c6/c7 occupied by my own pawns and d6 attacked by e5; I chose ...Kc8 without an illegal attempt. ...Rf7 escaped Bg7 while attacking it. After h6 defended the bishop, I avoided ...Rxg7/hxg7 and instead used ...Bf8, genuinely supported by Rf7. Bxf8/Rxf8 traded bishops while retaining the rook, unlike the measured game's exchange concession.

That limited improvement did not hold the defense. ...Rh8 and the knight route a4-b6-d5-e7 focused on blockading g8/h8. I explicitly rejected ...Nf6 because e5 could capture there, but then omitted the most immediate consequence of 32.g7: the pawn now directly attacked Rh8. 32...Ne7 covered g8 but did nothing against 33.gxh8=Q+, an actual unanticipated rook loss with promotion. This repeats the direct pawn-capture failure despite the narrower king/defender focus. The later checks drove the king back; the actual final promotion was to a rook, not the queen I had anticipated, and the referee confirmed mate.

Initial material was R+B+N+6P each. After Bxg7 and the bishop exchange, Black had R+N+5P against R+N+6P. Final Black material was N+5P against Q+2R+N+4P. The saved rook in the early continuation is limited rehearsal evidence; the whole drill failed. Neither the starting position's objective evaluation nor an earlier best defense has been established.

## Trial-14 practice endpoint

Both predeclared sessions completed by 07:47:26 UTC, before the 08:04:42 ceiling, with no repeats or replacements: thirteen own moves / 26 plies, two checkmate losses, zero illegal submissions. Practice 23 missed an immediate queen mate and misread the eighth-rank king escape. Practice 24 initially kept the rook, then missed a direct pawn capture and promotion. The first objective has already failed reliable execution; the second demonstrates that concentrating on king lines can still displace an elementary capture threat elsewhere.

No improvement is claimed from these drills, and practice does not enter Elo. Return to fixed games 109–114 as declared, preserving these failures. Keep the modest cue about newly pinned defenders without treating it as a complete safety certificate or adding successful-audit counts. The benchmark baseline remains 1660 [1540, 1780], 45W/2D/61L through 108. No valid new cumulative usage counter is available.


## Benchmark 109 — White versus maximum strength, defender exchange and e-file loss

Finished 2026-10-02 08:04:50 UTC by practical resignation after 22...Qxe1+, 44 plies / 22 own moves, zero illegal submissions. Result seq 8829, hash `438a919b5e48bb48494437394e51d6828e8571f731ae45d85f2ff674726298a3`; snapshot `ebf48a6171d6dbc8fc02e1be6026c815096e938cdb14b9d580b93e0f3a5ac79f`. PGN read back.

The early d4 advance removed d3's support of e4, which Re1 restored. Qd3 unpinned Nf3, but the ensuing ...Bxf3/Qxf3/...exd4/cxd4/...Bxd4 sequence lost the central pawn. Bb5 avoided the additional Ne5 fork of Qf3 and Bc4. After Nc3 and Be3, however, I failed to carry ...Bxc3/bxc3 into the new e4 defense: Nc3 had departed and Be3 blocked Re1, leaving only the queen against ...Nxe4 supported by Re8. Black took a second pawn. Bd4 subsequently restored the rook and queen lines, but the earlier pawn loss remained.

The bishop-for-knight exchange on e5 was accounted. Qf3 defended c3, then 20.Rad1 was followed by the omitted ...Ng5: the knight attacked the queen while clearing the e-file between Re5 and Re1. With Qe7 behind the rook and White's king boxed by its pawns, the actual Qf4/Rxe1+/Rxe1/Qxe1+ sequence lost both white rooks for one black rook. I recognized this danger after ...Ng5 and deliberately chose that continuation; it was not an unexpected final queen capture, nor a proof that all earlier alternatives lost. The failure to prevent the forcing sequence belongs to the earlier position assessment.

At resignation White had Q+B+5P against Q+R+N+7P, nominally a rook and two pawns down. Bf1 remained a legal block of the current queen check; this was not checkmate and I did not claim a forced-loss certificate. The practical resignation retained the material loss and every played move.

After 109: 45W/2D/62L overall; maximum strength 0W/2D/35L in 37 games. Elo remains 1660 [1540, 1780], 72 rated total/latest 50 used, 37 maximum exclusions. Trial 14 has one benchmark loss following its two practice checkmates; no sustained improvement is established. Continue the declared block through 114 without adding practice mid-block.

The goal tracker was queried again at this checkpoint. It still returned the obsolete two-100-game maximum-strength objective with status blocked and the same stale 17,035,946-token / 178,558-second values, last updated before this continuation. This does not provide a valid new cumulative usage counter. No usage entry, goal reset, completion claim or status change was made. The latest user Continue and current local GOAL.md authorize continuing the revised measured-Elo experiment.


## Benchmark 110 — Black versus maximum strength, blocked king exit and exchanged rook defender

Finished 2026-10-02 08:23:00 UTC by practical resignation after 17.Qxh7, 33 plies / 16 own moves, zero illegal submissions. Result seq 8864, hash `3643b832b5c7a6cd1f50c252454f83aada36808619ee48b8d411360a742b45d3`; snapshot `2c162ef9d565d6ec363ef226a13ba22e448dc8984ac3b17b4f538aeb5238b375`. PGN read back.

The Caro-Kann pawn advance sequence led to ...fxe6 and an extra pawn, followed by Bxh7/Rxh7. I recognized the Qd3-g6-h7 danger and used ...Ne4 to block the diagonal, with d5 supporting that knight. After Nc3 I played 11...Nd7, intending ...Nf6 to defend Rh7 following an exchange on e4. This omitted White's 12.f3, and Nd7 also occupied the king's d7 escape square. In my subsequent manual calculation, immediately moving Ne4 to f6 or c3 would allow Qg6 with no identified legal answer. That is an unverified limited branch assessment, not a proof that every defense lost.

I chose 12...Ndf6 knowing the e4-knight remained exposed. The actual fxe4/dxe4/Nxe4 sequence left Black a knight down for one extra pawn. ...Qa5+ cleared d8, but Bd2 attacked the queen and required ...Qb6. White then played Nxf6+: the knight I had counted as Rh7's defender was exchanged. I had considered ...gxf6 opening the seventh rank for a possible ...Rf7 against Qg6+, but overlooked the simpler direct Qxh7 until the checking knight had already arrived. After ...gxf6, White captured the rook immediately along d3-e4-f5-g6-h7. No such extra defensive tempo was available.

At resignation Black had Q+R+B+7P against Q+2R+B+N+6P, a rook and knight down for one pawn. Black was not in check; this was practical resignation, not checkmate or an established forced-loss proof. The same departed-defender mistake recurred, while the narrower king-move cue did not prevent an own knight from obstructing a needed king exit.

After 110: 45W/2D/63L overall; maximum strength 0W/2D/36L in 38 games. Elo remains 1660 [1540, 1780], 72 rated total/latest 50 used, 38 maximum exclusions. Trial 14 is 0W/0D/2L in benchmarks so far, with its practice failures retained. No sustained improvement is established. Continue the predeclared block through 114; do not add practice or reset results mid-block. No valid new cumulative usage counter is available.

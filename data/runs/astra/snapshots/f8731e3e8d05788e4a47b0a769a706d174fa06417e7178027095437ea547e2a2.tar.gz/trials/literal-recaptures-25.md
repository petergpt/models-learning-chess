# Trial25 — literal recaptures (declared 2026-10-03 11:09:25 UTC)

Baseline:174 scored,58W/4D/112L; provisional Elo1390 [1270,1520]. Fixed next evaluation:games175–180, all six retained in the existing MAX W/B, skill0 W/B, nominal1800 W/B rotation. No result-dependent extras or extension. Endpoint remains200 scored benchmarks.

Weakness: I repeatedly treat an imagined recapture as real even when the pawn moves backward, a bishop changes diagonal, or my own king blocks a rook. Longer speculative calculations have not prevented these errors.

Chosen intervention: replace the broad destination checklist with a literal recapture check. For a material transaction I rely on, identify the piece's actual origin and destination and the intervening occupied squares after the preceding capture. A remembered defender is not sufficient. Prioritize the immediate forcing reply in the current referee board before broad speculative branches. No per-move speed limit and no new mandatory long checklist. Similar geometric ideas have failed before; this is a narrower procedural revision, not a novel or proven method.

Bounded study/practice:20minutes combined, ending no later than11:29:25UTC. Exactly four remembered cases, no searches for extra examples:173 before41.Rxg3 (ply80),173 after56...Rxh7+ (ply112),172 before18...Qxf5 (ply35),174 before36...Nh7 (ply71). First three get one explicitly chosen legal alternative line each; the fourth is the successful actual five-ply exchange. Mechanical own-PGN reconstruction and legality checks only, including the known failed submissions; no evaluation/search/attack-map/candidate generation. Corrections to my factual recollection may be recorded, not concealed.

Then exactly two MAX drills, each capped at10 own moves or natural completion, with the shared deadline overriding both caps. First:White from game173 ply80, trying to preserve material without a backward recapture. Second:new self-constructed White position `r7/1k6/1p4PP/p4K2/8/8/7R/8 w - - 0 1`, concentrating on clear rook support behind passed pawns. This second setup is chosen by me and is not an independently assessed test; no claimed starting evaluation. Stop at the cap/deadline even if favorable. No repeats or extra practice.

Observable transfer: incorrect claimed recaptures, illegal submissions, major-piece losses caused by direction/obstruction errors, and the whole six-game W/D/L plus Elo/interval. Record any successful local decisions without treating them as evidence of a general improvement. Independently chosen benchmark replies, not remembered-case success, are the transfer test.


## Four remembered cases reviewed (between games, 2026-10-03)
Mechanical results are in `literal-recaptures-25-legality.json`; explicit script retained. No engine, move menu, search, attack map, or evaluation. Sixteen supplied plies were legal and the three known failed submissions were illegal. This includes two actual pre-error captures, not sixteen independent test items.

1.173/ply80:Rxg3 Rxg3 h4g3 fails because White must increase its pawn rank when capturing: h4 can capture g5, not g3. I had correctly used that same h4 pawn to support Qg5 earlier, then reversed its direction. One chosen alternative Rf3 Rg6 Ne4 was legal; it merely avoids that specific invented recapture, with no claim of best play or complete safety.
2.173/ply112:Rh2xh7 fails because the path includes occupied h6, my own king. Legal escape Kg5 Rg7+ Kh4 does not repair the earlier rook loss or establish a viable endgame.
3.172/ply35:Bf7f5 is vertical, not diagonal. The imagined intermediate e6 would make it two bishop moves with a change of diagonal, not one move. Actual Qd7xf5 Qc2xc7 Qf5d7 is legal and still concedes c7; legal is not synonymous with good.
4.174/ply71:Nh7 Rxh7 Rh6xh7 Ng5xh7 Rh4xh7 is legal. The last rook path becomes clear specifically because h6 has been vacated. Both knights and one rook on each side disappear; each side retains one rook. This successful local transaction did not prevent losing the subsequent rook ending.

These are remembered examples. Correct reconstruction after seeing the failures is not transfer evidence. Continue with the two declared drills only.

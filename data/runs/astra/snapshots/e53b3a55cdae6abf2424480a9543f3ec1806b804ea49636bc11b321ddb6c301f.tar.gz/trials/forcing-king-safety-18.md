# Trial 18 — forcing king safety and recapture contrasts

Declared 2026-10-02 22:07 UTC after game 132, with no active game. Baseline: 1580 [1460,1700], 51W/3D/78L in 132 scored games; MAX 0W/2D/42L, skill 0 38W/1D/5L, nominal 1800 13W/0D/31L (44 each). The user endpoint is exactly 200 scored games. This trial's fixed benchmark block is 133–138 in the unchanged paired-color rotation.

## Weakness and method

Trial 17 did not transfer reliably: the material calculation repeatedly stopped before a forcing check or treated a nearby king as a recapturer without retaining the opponent's surviving defender. Revisit this already-failed skill explicitly; this is not a novel checklist or a claim that recalling a diagram is improvement.

First make and mechanically check eight manually specified contrast cases from our own games 128, 130 and 132. Only board reconstruction and legality of the specified moves are allowed. No generated move menu, attack-map analysis, search, engine evaluation or external source. The remembered positions are training examples, not held-out tests.

Then play exactly two fresh self-composed opponent-practice positions at nominal 1800, White then Black, at most 20 own moves plus the reply in each. Unlike trial 17's sparse rook drills, both positions retain queens, rook, bishop, knight and six pawns per side, including constrained castled kings and diagonals that can open when blockers move. These are equal-material constructions, not certified equal evaluations.

Combined study/practice deadline: 2026-10-02 22:52:05 UTC, 45 minutes from the post-132 review clock. End any ongoing practice at its move cap or this deadline; record early results or unfinished sessions and add no replacement practice. Return to benchmarks after both sessions, even if the exercises fail.

Position A, White:
5rk1/p1pq1ppp/1b2p3/3n4/3N4/1B2P3/P1PQ1PPP/5RK1 w - - 0 1

Position B, Black:
6rk/pp2qppp/3bpn2/8/8/3BPN2/PP2QPPP/6RK b - - 0 1

## Predictions written before legality checks

1. Game 132 after ply 104 (...Bb6): Nxb6/Kxb6 is legal because the knight leaves c4 and Rd1 does not guard b6.
2. From that same position, Rd6+/Kc5/Rxb6 is legal, but Kxb6 is illegal: Nc4 survives and protects b6.
3. From that same position, Rd6+/Kc5/Nxb6 is legal, but Kxb6 is illegal: Rd6 now protects b6.
4. Immediately after Rd6+, Kxd6 is illegal because Nc4 protects d6.
5. Game 130 after ply 61 (Rc8+): Kh7 is illegal because h7 is occupied; Kf8 is illegal because the checking rook controls f8. Re8/Rxe8 are legal and the recorded result is mate.
6. Counterfactual to case 5 with only the black h7 pawn placed on h6: Kh7 is legal. This demonstrates an actual escape square, not a certified best earlier plan.
7. Game 128 after ply 35 (Qg8+): Kxg8 is illegal while Bb3 protects g8. Nxg8/Nf7 are legal; the recorded result is mate, so winning the queen did not make the capture safe.
8. Counterfactual to case 7 with Bb3 removed: Kxg8 is legal. This deliberately changes material and is only a geometry contrast.

## Evaluation and decision

The practice target is to preserve a usable king response through checking continuations and to reject false king recaptures in the actual final board. Track actual mating losses, newly opened pins, unsupported material losses and illegal submissions; retain all other errors as well. Success on remembered cases is diagnosis/retention only. Fresh practice is still training, not Elo evidence.

Use ordinary development in games. A short cue replaces trial 17's special rook focus: when a capture gives or permits check, resolve the king response before counting the gain; a king recapture must be legal with every surviving enemy defender still present. Do not expand the cue into an exhaustive move checklist or assume a king-adjacent piece is secure.

At game 138 report the whole block's W/D/L, per-opponent results, Elo and uncertainty, along with recurrence of the targeted errors. A recurrence rejects reliable execution and requires another revision. No single win, clean drill or transient rating rise establishes sustained progress. No opponent, estimator, decision-time target or token counter is changed.


## Contrast study completed — before opponent practice

Eight predeclared case groups were checked as eleven supplied branches, 21 specified plies: 15 legal continuations and six deliberately illegal king moves. Every starting board was valid and all predictions matched. Inputs, the supplied-move-only verifier, and results are saved in king-safety-18-inputs.json, king-safety-18-verify.py and king-safety-18-legality.json.

The check used only the existing vendored board module, with bytecode writes disabled and the shared t3-job wrapper. It reconstructed our recorded SAN moves and checked the explicitly supplied UCI moves. No engine interface, search, generated move menu, attack map or evaluation was used. The two mating outcomes are from the recorded referee results, not a new automated evaluation.

The 132 contrasts distinguish Nxb6 before Rd6 (king recapture legal), Rxb6 after Rd6 (Nc4 survives), and Nxb6 after Rd6 (Rd6 survives). Both later king recaptures are illegal. The 130 counterfactual makes h7 available only by actually vacating h7; merely naming it did not create an escape. The 128 contrast confirms Bb3's role in preventing Kxg8, while the recorded Nxg8/Nf7 sequence shows that a legal queen capture can still allow mate.

These were known failures with written predictions, so passing them is diagnosis/retention only. Proceed to the two declared fresh positions without extra examples or changed limits.

# Trial 12 — minor-piece destinations

See trials/minor-pawn-origins-12.md. Three bounded replays, then benchmark 97–102. Baseline 1700 [1580, 1820]. Trial 11 ended without improvement.

Immediately before each bishop or knight move, read the two enemy pawn origins for its actual destination from the current board. Record both squares and occupants briefly in the move note. A defender does not make a minor piece safe from a pawn. Count any proposed exchange concretely; reject an unsupported minor-for-pawn loss. This narrow check does not certify the rest of the move or its checking continuations.

Own reasoning and referee only. No timing target, automated chess analysis, outside move advice or delegation. Preserve all results and separate implementation from measured improvement.

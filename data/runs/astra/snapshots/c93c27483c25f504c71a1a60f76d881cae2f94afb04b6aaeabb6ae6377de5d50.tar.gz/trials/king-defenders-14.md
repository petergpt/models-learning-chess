# Trial 14 — keep the king's defenders usable

Declared after benchmark 108, reference clock 2026-10-02 07:34:42 UTC. Baseline 1660 [1540, 1780], 45W/2D/61L; 72 rated total/latest 50 used, 36 maximum exclusions. Next fixed benchmark endpoint: games 109–114. Opponent rotation, estimator, model and fair-play rules remain unchanged.

Target: a legal king move can pin or obstruct the very piece needed against the next check. In 108, ...Ke8 put Be7 between Re1 and the king; Nxf6+ then made the intended bishop capture illegal. In 104, the checking bishop departure from d2 changed the king/rook defense. Trials 04 and 05 already studied changed lines and defenders and failed. This trial is a focused rehearsal of an old weakness, not a claim of novelty or a longer checklist proving learning.

Practice change: defend from my own side against maximum strength for a longer short continuation, instead of the six-move role-reversed captures in trial 13. Exactly two recorded sessions, in order:

1. Black from game 108 after ply 45, before the failed ...Ke8. Remembered. Manually consider ...Qc6 as an unverified alternative: it would defend f6 with the queen while keeping the king off the e-file. The actual opponent may choose a different attack; this is not a supplied engine answer.
2. Black from game 104 after ply 49, in check after Bxh6+. Remembered. Reconstruct the checking line and choose the defense on the actual starting board. Do not presume that an earlier imagined king square is legal or safe.

Each session ends naturally or explicitly unfinished after twelve own moves and the final opponent reply. Combined practice-and-review ceiling: 2026-10-02 08:04:42 UTC. No extra repeats, no replacements for an unfavorable starting position, and no later historical move lookup during either session. End any active drill at the ceiling and record omissions. Both are remembered own failures, so even a clean continuation is rehearsal, not independent proof of transfer or a completed defense unless the game actually ends.

The immediate practice objective is to reduce the attack while preserving legal recaptures and king exits. Before a selected king move, reconstruct the new rook/bishop/queen line through the king, including any own blocker now pinned; then inspect the next forcing check using that resulting board. A piece geometrically reaching a capture square is not a usable defender if moving it exposes its king. When an opponent exchanges a defender, discard that defender from the next branch. Keep direct destination captures and ordinary checks in view, but use only brief factual notes when useful, without mandatory per-move audit claims.

Record the actual lines, material changes, illegal attempts, newly imposed pins or obstructions, and whether the attack was resolved at the cap. For benchmarks 109–114, retain every analogous recurrence and the full W/D/L/Elo outcome. A recurrence rejects reliable execution; a clean block or small rating rise still requires later repeated evaluations before sustained improvement can be claimed. Revise at 114 rather than continuing this method indefinitely.

Only own chess reasoning, own existing notes and the referee during play. No external move advice, engine analysis, automated move search/scoring/attack enumeration, tablebases or delegated chess work. No valid new cumulative usage counter is available.

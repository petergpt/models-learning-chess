# Trial 24 — verify the destination and opposing checks

Declared 2026-10-03 09:08:20 UTC after 168 scored games and before study. Baseline 57W/3D/108L, Elo 1410 [1280,1530]. Fixed next evaluation: all six benchmarks 169–174. Do not extend, replace, repeat, or add drills based on outcomes.

Weakness: favorable plans and long candidate calculations have omitted immediate captures by pawns and kings, and checking bishop forks. Try briefly reconstructing the candidate's destination and the opponent's immediate captures/checks before choosing it, including the opposing king. This replaces the pawn-only focus; no added mandatory long checklist or time-per-move rule. Similar ideas have failed in prior trials; this is another test, not a novel or proven method.

Bound: at most 20 minutes combined study/practice, ending 09:28:20 UTC. Exactly four remembered cases: game 166 before 26...Ned5, game 167 before 24.Rf3, game 168 before 30...Ne3+, and game 168 before 39...Rg2. Read/reconstruct only these own records, identify the actual omitted reply, and consider at most one repair per case. Mechanical board reconstruction or checking explicitly chosen lines is allowed; no search, evaluation, attack maps, or generated candidate moves.

Then exactly two MAX opponent drills, at most 12 own moves each or earlier natural completion/deadline. First: Black from game 168 after ply 77, a remembered position with fresh opponent continuation. Second: White from the self-constructed position 6k1/4R2p/1p3P2/3Kp3/2P3b1/1P6/8/8 w - - 0 1. The latter is new but deliberately favorable in material and has no independently established evaluation. If the deadline prevents a drill, record that; no extension. Do not claim remembered replay success or a favorable practice win as benchmark transfer.

Observable benchmark outcomes: queen/rook losses to immediate captures, minor losses to omitted pawn captures, missed checking forks, full-game W/D/L and Elo uncertainty. Compare descriptively with trial 23's 1W/5L and recurrent material losses. Preserve all records. No external chess sources or assistance.

## Remembered review
Reconstructed only the four declared own positions. System Python initially lacked python-chess; reran with the existing vendored chess library and bytecode disabled. No files under .arena were changed. The saved verification script checks only the twelve explicitly supplied moves in four three-ply lines; all were legal. It does not search, evaluate, generate candidate moves, or establish best play.

166: ...Ned5 missed Bf5+, which attacked Kh7 and Rd3. Proposed ...Rd6 Bf5+ Kg8 moves the rook off that diagonal, but also relinquishes its defence of c3; this is a local repair with a cost, not a winning claim.
167: Rf3 let ...Be2 attack both rooks. Proposed Rf2 Be2 Rd2 keeps the f-rook off the e2–f3 diagonal and preserves a blocker on the d-file. Only this line was checked.
168, move 30: support by d4 did not prevent f2xe3 from taking the knight. Proposed ...Nf6 Rxh6+ ...Kg7 avoids that capture but concedes h6 and leaves an attack; no claim it resolves all threats.
168, move 39: Kf1 can capture g2 directly. Proposed ...Rd8 g7 ...Rg8 instead places the rook far from that king and blocks promotion. This narrow repair is remembered; the next opponent drill tests subsequent choices.

Updated playing reminder: reconstruct the candidate destination, include opposing kings and pawns among immediate capturers, and notice checking forks. This is a brief verification focus, not a longer checklist or an evidence claim.

## Practice 43 — Black MAX, loss
Started from own game 168 after ply 77, a remembered setup. Resigned 09:14:43 UTC after seven own moves / 14 plies, zero illegal submissions. Seq 1335, hash 8ee020d70b1b415d5cb95493dadfc7e473af7f59350dc74751dc561231aed3cb. PGN read in full: 39...Rd8 40.Ke1 Rg8 41.Bc4 Rg7 42.Bf7 Kf3 43.c3 e2 44.b4 Rh7 45.gxh7 Ke3 46.h8=Q. The remembered Rg2 error was avoided; I also avoided an unverified ...Rxg6/Bd3+ fork line. Then ...Rh7 simply placed the rook on g6's capture square. I noticed a possible forward g7 advance but omitted gxh7. White promoted; resignation recorded as a practice loss, not an unfinished drill. This is strong negative evidence for reliability even within the local exercise. No repeat.

## Practice 44 — White MAX, unfinished at cap
Ended 2026-10-03 09:18:29 UTC after exactly 12 own moves / 24 plies, zero illegal submissions. Seq 1362, hash 3b3880d2ac365233c43c78e484dd9fb3e4b629e54b57bebb5cc136e23e53d570. PGN read in full: 1.Rg7+ Kf8 2.Rxg4 h5 3.Rh4 Kf7 4.Kxe5 b5 5.cxb5 Kg6 6.b6 Kh7 7.b7 Kg6 8.b8=Q Kg5 9.Qb4 Kg6 10.Qf4 Kf7 11.Rxh5 Kg6 12.Qf5+ Kf7 *.

The deliberately favorable constructed setup allowed a supported rook check and then winning the bishop. I moved away from h5's capture on g4, defended f6 with Kxe5, promoted the distant b-pawn, and twice defended the rook against the nearby king (Qb4, later Qf5+). I waited to take h5 until the king was farther away. Final White Ke5/Qf5/Rh5/b3,f6 versus Black Kf7. Rook and queen retained, but the declared cap ended play before checkmate: no win recorded and no full conversion claim.

## Learning period closed
Finished 09:18:29 UTC, within the declared 09:28:20 deadline. Exactly four remembered cases with twelve explicitly supplied mechanically legal plies, then exactly two MAX drills: one resignation loss, one unfinished; 19 own moves / 38 plies, zero illegal submissions. The first drill repeated a direct pawn-capture oversight and lost the rook; the second favorable exercise showed some correct local captures/king-range checks. These mixed observations do not establish reliable transfer. No extras or repeats. Return to the fixed evaluation 169–174 with the declared brief focus.

## Benchmark 169 — White MAX, loss
Resigned after 28...Raf8 at 2026-10-03 09:28:43 UTC. 28 own moves / 56 plies, zero illegal submissions. Seq 13829, hash 3881ca587491a497bd3054c887613f05208fd630cddbfcfca8552edb0d31896c, snapshot 5b0a0f4fd3fc5af423032b9f2e262c1fdad6a08966a2a179826bbbc07c6eac9e. Full PGN read. Cumulative 57W/3D/109L in 169; MAX 0W/2D/55L. Elo unchanged 1410 [1280,1530], MAX excluded. Storage 56,634,289 bytes.

Castled 5, minors developed 7 before the exchanges, Rad1 13. First 15 materially clean. Two minor exchanges doubled the b/e pawns and opened files. Qd3 supported e4 before ...Bb7, and d5 closed the diagonal. But Nh4 allowed ...Ba6, skewering Qd3 and Rf1. Nb5 interposed; ...Nxe4 Qxe4 Bxb5 exchanged knights and cost the central pawn. My initial mental idea that Qxe4 simply won the knight had omitted the consequence of moving the queen away from Nb5; the actual move comment acknowledged the bishop recapture. Nf5 gained a queen tempo, then Rfe1 escaped the bishop line. ...g6 chased the knight, ...f5 chased the queen, and ...f4 chased the knight again.

I moved Qf3 to d3 to avoid a potential ...Bg4 skewer, but ...f3 attacked Ne2 and g2. Correctly recognized that immediate gxf3 would expose Kg1 to Qg5. Ng3 blocked the file and escaped the pawn's capture square, but overlooked the forcing forward ...f2+, checking Kg1 and attacking Re1. Kh1 fxe1=Q+ Rxe1 cost a whole rook for a pawn. My first commentary called this an exchange loss, which was wrong and explicitly corrected. Final White Kh1/Qd3/Re1/Ng3/b2,b3,c4,d5,e4,g2,h2 versus Black Kg8/Qg5/Rf7/Rf8/Bd7/a5,b6,c7,d6,e5,g6,h7. Practical resignation a rook down under king pressure, not a forced-mate proof.

This block has already repeated a pawn-advance fork/promotion failure and lost a rook. No reliable transfer claim from the practice. Continue fixed 170–174 without extra study or changed opponents.

## Benchmark 170 — Black MAX, loss by checkmate
Referee confirmed 23.Qxf6# at 2026-10-03 09:38:40 UTC. 22 own moves / 45 plies, zero illegal submissions. Seq 13876, hash 87a9de2fe33f24d47b75b9b37c5a22cf05fb3ffe19fff86fb813af9bb2a1c67f, snapshot c1a0ec73bffbbf5ed05bb7abd450f1fa2dafd55a6b33931e90de4ef476c92eb2. Full PGN read. Cumulative 57W/3D/110L in 170; MAX 0W/2D/56L in 58. Elo unchanged 1410 [1280,1530], 112 rated / latest 50, 58 MAX excluded. Storage 57,081,220 bytes.

Castled 8, minors developed 9, first rook centralization 17. First 15 materially clean. Deviated from the earlier ...Re8/...Bf8 opening with ...exd4/...d5, meeting e5 by ...Ne4 supported by d5. ...Nxc3/bxc3 exchanged knights; ...Na5 attacked Bb3 and opened Bb7 support of d5. ...c5 challenged the centre. White Qd3 built a queen/bishop battery toward h7; ...g6 blocked it, Bh6 attacked Rf8, and ...Re8 escaped. But e6/fxe6/Rxe6 opened the king attack. ...Bf8 sought to defend and challenge the rook, yet Rxg6+ broke through. I recognized danger in ...hxg6 and chose ...Bg7, conceding the bishop to Rxg7+.

...Kf8 escaped the immediate rook check, but Qf5+ left the king trapped: the rook on g7 also controlled e7, an escape square I had incorrectly treated as available in earlier mental branches. ...Qf6 blocked the file and Qxf6# ended the game. This actual mate is confirmed; my alternative attack/defence lines were only mental calculations and are not proved forced or best play. No pawn-capture loss of my rook here; the failure was king safety, an incomplete forcing-line calculation, and overlooked rook rank control. No reliable positive transfer. Trial 24 through two benchmarks: 0W/0D/2L, 50 own moves / 101 plies, zero illegal submissions. Complete 171–174.

## Benchmark 171 — White skill 0, win
Referee confirmed 27.Qd8# at 2026-10-03 09:48:32 UTC. 27 own moves / 53 plies, zero illegal submissions. Seq 13931, hash b341db917b93d9bfc0352a438d6f7dab090a9d68804ab1183933eae4e7fef7cc, snapshot 41200afeebadf384b7a8a60bc1b6790098bd3c9b72cf06eb2d09183ca5dff0d6. Full PGN read. Cumulative 58W/3D/110L in 171; skill 0 45W/1D/11L. Elo 1420 [1290,1540], 113 rated / latest 50, 58 MAX excluded. Storage 57,556,447 bytes.

Castled 5, minors developed 7, Rad1 9. First 15 materially clean. ...Bxf3/gxf3 exchanged a bishop for my knight and weakened the king shelter. Kg2 defended h3 against Qd7 and supported f3. d4/dxe5 opened the centre; Black ...g4 left Nf6 attacked, allowing exf6. I anticipated ...gxf3+ and chose Kh2; rejected Kxf3 because of a possible ...Ne5+ fork of king and Bc4 (unverified alternative). Black castled and then moved the h-rook, allowing the same pawn to take Be7 and Rd8 with promotion/check. ...Kxd8 recaptured the promoted queen, but the knight, bishop and rook had already been won.

Rg1 challenged the remaining rook; ...Rg2+ Rxg2 followed. Black did not play the anticipated ...fxg2, instead moving its king. I then moved Rg3 out of that pawn's capture square. ...Na5 and ...c6 chased Bc4 through d5 to b3; the bishop stayed supported. ...Nc4 forked Qd2/Be3 but now allowed Bxc4, removing the last knight. Black ...Qxh3+ gave away the queen to Rxh3. Qxd6 was supported by Rd1, and Qd8# was also rook-supported with Bc4 controlling f7. Both original rooks survived.

This is an actual successful conversion with correct local pawn/king checks, but it depended on several severe opponent errors and does not establish sustained improvement. Trial 24 through 169–171: 1W/0D/2L, 77 own moves / 154 plies, zero illegal submissions. Continue fixed 172–174.

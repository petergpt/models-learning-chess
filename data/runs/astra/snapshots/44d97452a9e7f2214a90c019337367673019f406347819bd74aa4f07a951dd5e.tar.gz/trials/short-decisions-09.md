# Trial 09: shorter decisions with an observed clock

Declared 2026-10-01 at 19:44:59 UTC after game 78 and the trial-08 endpoint. Baseline: provisional engine-relative Elo 1680 [1560, 1800], 52 rated games total / most recent 50 used; overall 32W/2D/44L. Next fixed evaluation: benchmark games 79–84. Preserve the same referee, opponent rotation, estimator, model and reasoning setting.

Target: lengthy speculative branching repeatedly displaces simple current-board facts. Game 78 calculated king replies to a checking queen but omitted b4xc5; it later tried a rook route through its own pawn. Earlier destination, changed-line, defender, breadth-first, remembered-opponent and longer-game trials already failed. This trial tests actual decision duration and shallow scope. Rephrasing the existing safety instruction is not the new intervention.

Practice: two fresh standard-start opponent sessions at nominal 1800, White then Black. Cap each at 40 learner moves, including the final opponent reply, or finish naturally sooner. Combined ceiling: 20:29:59 UTC on 2026-10-01 (45 minutes from declaration, including setup and reviews). At the ceiling finish any pending reply and record an unfinished end; do not extend to seek a favorable outcome. Every session and result remains in the separate practice ledger and never enters Elo.

Use a 20-second decision target, observed from completion of the previous referee command to submission of the next chosen move. This includes tool, polling, commentary and other elapsed delays; it is not pure thinking time or a token budget. The timing helper only forwards caller-supplied commands to ./play and appends clock metadata. It contains no chess module, board parsing, move generation, scoring, search, fallback choice, or automatic move. It does not change the official untimed game or impose a forfeit. Record every overtime and rejected move; do not hide a miss by restarting the clock or omitting a result. A rejected move retains the earlier turn clock.

Decision format: use one working candidate and one short concrete reply/answer at a time, then submit within the target. Prefer an ordinary supported move if the continuation is unresolved. Do not turn a doubtful candidate into many remote branches. Immediate captures and the actual king/pawn defenders still matter; on a major-piece move, identify the two opposing pawn origins and the actual path blockers before looking beyond the first reply. These chess requirements are familiar and unproved in transfer. The experimentally changed feature is shorter, timed work, not checklist length. All moves remain my own decisions. No game advice, automatic analysis, engine output, move menus, or delegation.

Assessment: at least 90% of submitted legal moves within 20 seconds would show implementation of this decision format, not stronger chess. Report exact logged counts and any missing timing. Separately record actual direct queen/rook losses, illegal blocked moves, overlooked immediate mates, and concessions after short branches. Even clean practice at this strength is not an independent accuracy test or Elo evidence. If the format is not implemented, report that rather than attributing results to it.

Carry the same timing target into the declared fixed block 79–84, then compare all six results, the unchanged rating interval, and error recurrence with trial 08 (three of six games with targeted major-piece failures). A cleaner block and higher estimate would be provisional only and require repeated evaluation. Do not call this sustained improvement from one win, a lower elapsed time, a remembered example, or a temporary rating rise. Revise the method again if errors persist. Return to evaluation after the bounded practice even if the practice result is unfavorable.

## Practice and benchmark record

Pending.


### Practice 8 — White, nominal 1800, completed win

Finished at 19:58:45 UTC on 2026-10-01 by 31.Rh8#, 61 plies / 31 learner moves, zero illegal attempts. Practice result seq 327, SHA-256 `2ed8b8c997001de968ad86a9489dc50ce3b352bbc75478f9d20533f1c88a2e32`. Referee PGN read back. This is separate opponent practice and does not alter benchmark Elo or W/D/L.

The forcing 11.Bxf7+ Kxf7 12.Qxb4 won the queen for a bishop and pawn; later ...Ra8 and ...Rh5 allowed Qxa8 and Rxf8. I handled the actual a5 and d5 pawn attacks on the queen, blocked ...Bg4's attack on Rd1 with f3, and recaptured the checking bishop on c2 with the king. The last Qxf6+/Rh8# sequence used the queen's defense of the mating rook. No direct unreciprocated major-piece loss, illegal move or immediate mate omission was identified in the actual play. Opponent concessions supplied the advantage, and unplayed candidate lines were not independently evaluated.

The clock criterion failed: all 31 submissions were timed, but only 18 were within 20 seconds (58.1%); 13 exceeded it. Median 18.464 seconds, mean 21.431, maximum 59.837. The longest decision was Bxf7+, so that successful tactic cannot be credited to the specified short format. The log spans 19:47:00.362264 to 19:58:45.540629 UTC. Times include polling/tool/communication delays and are not pure inference time. Long branching returned during several attacking choices. A win does not establish that the duration intervention was implemented or caused improvement.

Continue the declared fresh Black session, same nominal strength and 20-second target, at most 40 own moves, unchanged combined 20:29:59 UTC ceiling. Use a longer initial tool wait to avoid an unnecessary extra polling round trip; preserve the original timing definition and every existing logged value. Do not exclude the first session's delays or failures. Fixed benchmark 79–84 remains due after the learning period.


### Practice 9 — Black, nominal 1800, loss by practical resignation

Finished at 20:11:55 UTC on 2026-10-01 after White 28.Qxf8, 55 plies / 27 learner moves, zero illegal attempts. Practice result seq 384, SHA-256 `9312567c86e4b4125217aed5e3330d986ab669233125dd918af4f2a427e64148`. Referee PGN read back. The resignation is a practical assessment, not a forced-loss certificate, and this result is excluded from benchmark Elo.

The first short calculation failed. After 10...Nxe5 11.dxe5 Bxb5 12.exf6 Bxf6, I had not carried the line through 13.Nxb5. Black lost both knights and the b5 bishop against White's knight, other bishop and d-pawn, leaving a minor-piece deficit for a pawn. Considering Nxb5 as an alternative earlier reply did not account for it after the pawn exchanges. The familiar final-capture omission returned under the shallow decision format.

I recovered White's remaining knight with 14...axb5 and explicitly accepted 15.Bxf8 Qxf8. That actual sequence left an exchange deficit with an extra pawn; it did not erase the original mistake. The queenside exchange and ...Rxc2 supplied activity, while White collected b7 and invaded with Ra8. I used ...Bd8 between the rook and queen, but Qd7 added a second attacker. The subsequent ...Be7 again left Qf8 capturable by Ra8; White instead played Qb7. I then chose 24...Qxa8 25.Qxa8+ Bf8, making an actual queen-for-rook concession. I have not proved that this was forced or established the best earlier defense. These difficult decisions again expanded into long branches.

The last error was a changed king defender: after ...h6, 27...Kh7 removed Kg8's protection of Bf8, and 28.Qxf8 directly captured the bishop. I concentrated on giving the king an exit while failing to apply the departure to the defended piece. At resignation Black had R+5P against Q+R+4P. There was no concrete recovery in my assessment. This is further adverse evidence for the intended procedure.

All 27 submissions were timed: 18 within 20 seconds (66.7%) and nine over. Median 14.553 seconds, mean 24.388, maximum 146.645. Session log: 20:00:00.171579 to 20:11:56.026722 UTC. Reducing polling round trips improved some routine timings, but did not prevent the long overruns when the defense became difficult. No timing values or failed moves were removed or redefined.

### Trial 09 practice endpoint — return to the declared benchmark

The two sessions ended naturally or by practical resignation within the 45-minute ceiling: one win and one loss, 58 learner moves / 116 plies, zero illegal attempts. Combined completion was 26 minutes 56 seconds after the declaration, including setup and reviews. All 58 moves have elapsed-time records; 36 were within 20 seconds (62.1%) and 22 exceeded it. Both sessions failed the 90% implementation criterion. The short central exchange in practice 9 was incomplete, and long defensive branches and changed-defender errors persisted. There is no basis to claim that the duration intervention worked, even though practice 8 ended in mate.

Follow the predeclared evaluation: fixed benchmark games 79–84 with the same observed timing target and unchanged chess rules, settings and estimator. Do not add practice until a favorable result appears or reinterpret the target afterward. Keep trying the shorter decision format, while recording noncompliance and errors honestly; any outcome attribution is limited by that noncompliance. At game 84 review all six results and the unchanged rating interval, then revise if needed. Baseline remains 1680 [1560, 1800] through benchmark 78, since practice does not enter the estimator. Sustained Elo improvement remains unachieved.

Observed cumulative whole-goal counter after both sessions: 15,431,410 tokens / 166,919 elapsed seconds. All moves and assessments were my own. The clock helper only forwards supplied referee commands and records elapsed time; no engine analysis, automated chess search, scoring, move selection, external game advice or delegation was used.


### Benchmark 79 — White versus maximum strength, loss

Completed at 20:23:39 UTC on 2026-10-01 by practical resignation after 23...Qxe3+, 46 plies, zero illegal attempts. Result seq 6551, SHA-256 `30ebdfcd7aae4bc2088f5fd3ad42be7d1c4a069e21df198f3b6ac28b5e8132e5`, result snapshot `9eea8115c7c833f0b0a47919dd5004283b20711b1eaa218c3f0da34ea3bfe6da`. Saved PGN read back. No forced-loss certificate or independently established first losing move.

The Italian development reached 8...Ng4. I used d4 to interrupt Bc5's line and then h3, but Black played ...Nxf2. I counted the actual Kxf2/dxc3+/Kf1/cxd2/Bxd2 continuation: the discovered bishop check let the pawn take Nd2, leaving equal pieces but two fewer White pawns and an exposed king. The initial blocking argument did not neutralize this full sequence. Bxe6 and Be3/Bxe3/Rxe3 removed the bishops; the second rook was saved from ...Qg5 with Rd3. Qe2 supplied e4 and Rd3 support, and Re3 answered the ...Ne5 fork with the queen still defending e3.

The next checking sequence was not completed correctly before committing. After ...Qh2, Ke1/Nxf3+ and 22.gxf3, Black used ...Qg1+. My earlier imagined Kd2 response omitted that leaving e1 would uncover Qg1's full rank against Ra1. When the check actually appeared, I identified that problem. I instead played 23.Qf1, knowing by then that it withdrew Qe2's defense of Re3, and Black captured that rook with ...Qxe3+. The loss was not a surprise at move 23; the failed anticipation was in the earlier recapture/king-escape plan. No alternative has been independently proved sound. Resignation followed with Q+R+5P against Q+2R+7P. This is another actual major-piece loss after an incomplete forcing-line assessment.

All 23 move submissions have timing records. Eleven were within 20 seconds (47.8%), twelve exceeded it; median 21.590 seconds, mean 23.734, maximum 71.405. Session log spans 20:13:29.093528 to 20:23:39.689174 UTC. The duration intervention again failed its 90% implementation condition; long branches persisted. Early quiet moves meeting the target do not validate the later defense or support attributing the result to uniformly short decisions.

Through 79: overall 32W/2D/45L; maximum strength 0W/2D/25L in 27 games. The provisional Elo remains 1680 [1560, 1800], 52 rated games total / latest 50 used, since maximum games are excluded (27). Skill 0 remains 24W/0D/2L and nominal 1800 8W/0D/18L, each in 26 games. Trial-09 benchmark so far is one loss. Continue the declared block through game 84, preserving the same target and every timing miss. Observed cumulative whole-goal usage: 15,481,414 tokens / 167,630 elapsed seconds. No engine analysis, external game advice, automated chess analysis or delegation was used.


### Benchmark 80 — Black versus maximum strength, loss by checkmate

Completed 2026-10-01 at 20:31:51 UTC after 17...Nh6 18.Qxe7#, 35 plies, one rejected move. Result seq 6590, SHA-256 `b65a029204bf3c7345b935a6830b19647f906b5dd4a7d0178993b579fd0c7d98`, result snapshot `e595ad8efae1c6a42794eb1f9e68fe15c5326d3f9f602dacf2167123fe959d31`. Saved PGN read back. The terminal mate is referee-confirmed; no earlier best defense or first losing move is independently established.

The advance Caro–Kann reached a central exchange with Black still uncastled. I rejected ...exd5 in my own reasoning because it would remove e6's protection of Nf5 while Qd3 attacked that knight; ...cxd4 kept that defender. However, after Qb3 I attempted 14...O-O-O without checking Bg5's diagonal through f6/e7 to d8. The referee rejected castling through attack. I then played ...Be7, moved the attacked Qc7 to b8, and answered dxe6 with ...fxe6; Qxe6 took the remaining central pawn.

The decisive error was another removed defender, now of a mating square. I focused on Qe6's threats to the knights, eventually recognized that Ke8 defended Nd7, and moved Nf5 to h6. I omitted that Nf5 was defending e7. With that knight gone, Qxe7 was mate: Bg5 protected the queen and Black had no legal response. Concern about the attacked knight displaced the opponent's immediate checking capture. This is an actual missed mate and failed transfer, not a sound defense made unlucky by opponent strength.

The timing record contains 18 submissions: 17 accepted moves and the rejected castling attempt. Fifteen accepted moves met 20 seconds (88.2%), two exceeded it; median 7.533 seconds, mean 10.221, maximum 31.636. The illegal castling submission was at 16.454 seconds; the replacement ...Be7 was at 28.00 seconds from the original response, with no clock reset. Session 20:28:30.939488–20:31:52.021011 UTC. This is closer to the timing target, but still fails the declared 90% legal-move criterion. The final mate-allowing move also exceeded the target. No attribution to uniformly short work is justified.

Through 80: overall 32W/2D/46L. Maximum strength 0W/2D/26L in 28; skill 0 24W/0D/2L and nominal 1800 8W/0D/18L, each in 26. Provisional Elo remains 1680 [1560, 1800], 52 rated total / latest 50 used, 28 maximum-strength exclusions. Trial 09 benchmark currently two losses; continue 81–84 as declared before revising. Actual cumulative whole-goal counter: 15,534,236 tokens / 168,110 elapsed seconds. Every move was my own; no external or automated chess advice, engine analysis, or delegation.

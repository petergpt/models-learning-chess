# Geometry cards from my games

My own reconstructions from recorded play. These are reminders, not engine-verified evaluations or evidence of improvement.

## Opened defender: game 8, after 20.Qe1

Relevant pieces: Black Qa5, Nb4; White Bd2, Qe1. The line is e1–d2–c3–b4–a5.

Bxb4 removes the knight and vacates d2. Qa5 now attacks the bishop on b4, but Qxb4 Qxb4 loses the black queen. A queen behind a pinned knight is not sufficient defense when the capturing bishop is backed by another queen. Count the final recapture and its value.

## Rook rank: game 8, after 31.Rg7+

White Rg7 and Qh6; Black Kf7, Bb7, Qd5, Re5, Ra8. The rook's leftward ray is g7–f7–e7–d7–c7–b7, ending at the black bishop. Every empty square on that ray is controlled, not just f7.

Ke8 Qh8+ leaves no king escape. Qg8 Qxg8# finishes the game. The black king on e8 prevents Ra8 from traveling through e8 to interpose on f8 or g8.

## Discovered check: game 7, final net

Before 29...Rc8+, Black Rc3 shielded Bb4 from White Kd2. Moving the rook to c8 uncovered Bb4–c3–d2 and controlled c1/c2/c3 along the c-file. Bb3 controlled d1 via c2. White's own Be2 and e3 pawn occupied two other escape squares. Kd3 was forced, then Bc2+ forced Kd4 and Bc3# followed.

The alternative 29.Ke1 in the preceding position allowed Rc1#, checking with both rook and bishop. Capturing the rook with Ra1 would leave the bishop check unresolved.

## Use before a forcing line

1. Identify occupied squares along each relevant ray, including my own blockers.
2. After each move, update the vacated and occupied squares before assigning checks or defenders.
3. At a check, count every checking piece and every legal king escape before calculating a longer continuation.
4. At an exchange, finish the recaptures and count material; one expensive defender may not protect a target from a cheaper supported attacker.

## Queen changes line: game 9, after 55...Be1+

White Kg3, Rg7, Ne5, pawns a2/c2/f4; Black Kc8, Qd5, Be1, pawns a4/b6/f5. I chose 56.Kh3 to avoid Qxf4 with check, but missed 56...Qh1# along d5–e4–f3–g2–h1.

On h1, the queen checks along the h-file. Be1 controls g3 and h4, while f5 controls g4. The queen controls g2 and h2. White cannot capture the queen or interpose on h2, so every response fails. The alternative Kh2 avoids this particular immediate mate; it is not a claim that the losing position could be saved.

The missed check came from a change of line: the queen traveled diagonally, then attacked along a file. Checking only the most prominent capture, Qxf4, was insufficient.

## Optional recapture: game 11, 21.Qe4?

Black Qf4 and Bb7 both attacked e4 through clear paths. I placed my queen there while imagining a queen exchange followed by minor-piece exchanges. Black instead played Bxe4. After a white bishop or knight recapture, Black was not obliged to put its queen on e4; after Rxe4, it could move the attacked queen away. A defended queen was still available to the cheaper attacker. The played 22...g5 23.Rxf4 gxf4 subsequently reduced my loss to an exchange, but did not justify 21.Qe4.

## Illegal king recapture: game 11, 45.Ne5?

Relevant pieces: White Kf4 and Nf3; Black Rd5, Ng4, and h5 pawn. I played Ne5 and counted Kf4 as a defender. After ...Nxe5, the knight on e5 was protected by Rd5 along d5–e5. Kxe5 would move into rook check and was therefore illegal. The king's adjacency did not make the knight safe.

## Pawn pinned to king: game 12, after 48.Ra5

White Ra5, Black b5 pawn and Kc5 lie on a5–b5–c5. I submitted ...b4, forgetting that vacating b5 would expose the king to the rook. The referee rejected it. The played ...Kb6 kept the pawn defended and removed the pin; ...b4 followed after 49.Ra8. This was one illegal submission, not an infrastructure fault.

## Rook check inventory: game 12, after 56...Rf5?

White: Kg2, Re7, Rb3, pawns f2/g3/h4. Black: Kc5, Rf5, Rc2, pawns f7/g7/h6. My move had defended f7 while leaving king and rook aligned on the c-file.

The two white rooks have four checking moves: Re7–c7, Re7–e5, Rb3–c3, and Rb3–b5. The local answers to the latter three are ...Rxe5, ...Rxc3, and ...Kxb5 respectively. These are square-by-square reconstructions, not engine evaluations.

57.Rc7+ instead creates c7–c6–Kc5–c4–c3–Rc2. The king blocks Rc2 from reaching the checking rook or interposing above the king. The f5 rook cannot interpose on c6. The legal king escapes d4/d5/d6 all leave c2 unprotected; the played ...Kd6 58.Rxc2 lost the rook.

Inspecting only nearby checks missed the remote rook move to c7. Check the rank/file intersections for **each** enemy rook after the final candidate. This repeats the king-and-major-piece alignment error from game 6, with a rook instead of a queen behind the king.

## Bishop protects the queen's mating square: game 13

After 20...Bf3+, White Kg2 was checked by Bf3, supported by the black e4 pawn and Rf8. Kxf3 was illegal. I played 21.Kh2?, allowing 21...Qh4+ 22.Kg1 Qh1#.

After Qh4+, g1 was the only legal king escape: Qh4 controlled h3/g3 and the h-file, while Bf3 controlled g2/h1. On h1 the queen was protected by that same bishop along f3–g2–h1. At the final position, my Rf1 and f2 pawn occupied two escape squares, and Kg1 blocked Rf1 from capturing Qh1. Qe1 was also blocked by my rook and king. No capture, interposition, or king move resolved the mate.

Before choosing Kh2, I could instead consider 21.Nxf3, capturing the bishop with Nd2. After ...exf3+, 22.Kg3 is a legal escape in my reconstruction. Removing Bf3 removes its protection of h1. This is an untested alternative to the played mating line, not proof of a draw or a saved game. Other king choices at move 21 have not been exhaustively assessed.

The earlier weakening 16.g4 Nxg4 17.hxg4 Bxg4 removed both kingside pawns. I had considered the sacrifice but underestimated the resulting attack. Counting a nominal extra minor piece did not establish king safety. Retaining the pawn cover with a move such as 16.Qe2 is an untested earlier alternative.

## Queen exchange changes the back rank: game 14, move 18

After 17...Qd8 18.Nf6+, I initially wanted ...Nxf6, expecting exf6 and a queen exchange on d4. White could instead use 18...Nxf6 19.Qxd8 Rxd8 20.Rxd8+ Ne8 21.Rxe8#. The knight's departure from d7 opens the whole d-file. Re8's capture on d8 then opens the eighth rank to White's rook. Bc8 blocks Ra8, h7 is still occupied by Black's pawn, and White's h6 pawn controls g7. I rejected ...Nxf6 at move 18 and played ...Kf8.

This mating reconstruction applies before White captures h7. After 19.Nxh7+ the escape-square inventory changes; the old mate label must not simply be copied into the later position.

## Promotion threat prevents recapture: game 14, final position

The played sequence was 21.Qb4+ Re7 22.h7 Kg7 23.Qxe7. I resigned with a rook and two pawns less. The tempting 23...Qxe7 allows 24.h8=Q#. Rh3 protects h8 through the newly vacated h7 square and controls h6. Nf6 and the new queen cover g8/h7; e5 protects the knight on f6; Black's own f7/g6 pawns occupy the remaining nearby squares. Bc8 blocks Ra8 from reaching h8, and Qe7 cannot capture the new queen. This verifies that recapture fails, not that every defense immediately mates. The legal ...Qh8 retains the queen but does not recover the lost rook.

Earlier, ...g6 kept the h-file closed but left White's h6 pawn beside the king. The knight checks removed h7 and turned that pawn into a promotion threat. A blocked rook file did not establish king safety. The alternative 15...gxh6 16.Rxh6 removes the advanced pawn but opens lines; it is untested, not a proved saving line.

## Preserve the recapture ray: game 15, move 10

After 9.e4 Bxc3, I chose 10.bxc3 instead of Qxc3. Keeping Qc2 behind Bd3 allowed 10...dxe4 11.Bxe4 Nxe4 12.Qxe4: the bishop's departure cleared c2–d3–e4. With Qc3 instead, that last queen recapture would not exist. This was a correctly checked local exchange, not proof that 9.e4 was best.

## Cheaper attacker backed by the queen: game 15, move 24

After 23...Qb7, White had Qc6/Rb6 and Black had Qb7/Bc8. I used 24.Rxb7. The possible ...Bxb7 25.Qxb7 would exchange my rook for Black's queen and bishop. The played ...a4 instead left the queen unrecovered. This is the favorable side of the supported cheaper-attacker pattern that cost me material in earlier games. Count the actual capture order rather than assuming the offered queen trade.

## Knight protects the mating queen: game 15, finish

After 30...f5, f6 was empty. The played 31.Ng5+ was protected by Be7 along e7–f6–g5. After ...Kh6, 32.Qh8+ forced ...Kg6, and 33.Qh7# followed. Ng5 protected h7 and controlled f7; Be7 controlled f6 and defended Ng5; Qh7 controlled h6; Black's own f5/g7/h5 pawns occupied the remaining adjacent squares. There was no capture or interposition against the adjacent diagonal queen check.

My unplayed reconstruction against 31...Kg6 was 32.Qf7+ Kh6 33.Rxe6+ g6 34.Qh7#. That line was calculated mentally, not submitted to a referee or verified by an engine. The actual shorter finish was confirmed as mate by the referee.

## A rook behind the queen does not make the trade equal: game 16

The sequence 16...e4 17.dxe4 Bxe4 cleared d3 and put Be4 on the diagonal to White's Qc2, while also attacking Nf3. White played 18.Rc1, defending the queen with a rook. I used 18...Bxc2: even ...Rxc2 would leave a queen exchanged for a bishop. White instead played h3 and left the bishop unrecovered. This repeats the optional-recapture lesson from game 11 with the colors reversed.

After 20...Bxf3 21.exf3, White's e-pawn no longer occupied e2. The knight could consequently use ...Ne5–d3 without an e2 pawn capture. White's 23.Rf1 left Rc1 attacked, and ...Nxc1 took it. The played ...Nb3 later preserved the knight when White again declined a recapture.

## Adjacent ranks and the last escape square: game 16, finish

The finish was 29...d3 30.Rc3 Bxc3 31.bxc3 Qe1+ 32.Ka2 Re2#. The pawn advance opened Bf6–e5–d4–c3–b2 and threatened a supported queen mate on b2. Capturing the interposing rook removed White's last piece.

In the final position, Qe1 controls a1/b1 along the first rank, Re2 controls b2 along the second rank, and Na5 controls b3. White's own a3 pawn occupies the remaining king escape. Re2 is protected by both Qe1 and d3. White's remaining pawns cannot capture the rook or interpose on b2/c2/d2. The referee confirmed checkmate.

## Decline the automatic rook recapture: game 17, move 31

After 30.Ne5 Rxb4, White had Rc4/Ne5 and Black had Rb4/Nd5/Qe8 with a pawn on c6. The immediate Rxb4 Nxb4 would exchange rooks and leave the b-pawn lost. I instead played 31.Rxc6. Ne5 protected c6, making ...Qxc6 Nxc6 favorable to White. The observed ...Nb6 left the rook on c6 and restored the material count to a one-pawn lead. Choosing whether to recapture is part of the position, not an automatic step in the exchange.

## Interpose and defend the attacked rook: game 17, move 39

After 37.Rc8 Rxc8 38.Nxc8 Qe5+, Black's queen checked Kh2 along e5–f4–g3–h2 and also attacked Rd4. White Qf3 moved to f4. The queen now blocked the check and protected d4 along f4–e4–d4; Rd4 simultaneously protected it along the same rank. The played ...Qxf4+ 40.Rxf4 therefore traded queens without losing the rook. The board geometry was verified before moving the rook off d1, then rebuilt at the actual checking position.

## Vacate the promoted queen's ray with useful knight coverage: game 17, finish

After 52.a8=Q Kh8, Nc8 still blocked Qa8's line across the eighth rank. The played 53.Ne7+ cleared it while controlling g8 and g6. After ...Kg7, 54.Qg8+ was protected by the knight and forced ...Kh6: the queen covered f8/f7/g7/h7/h8, Rf4 covered f6, and Ne7 covered g6. Then 55.Qg6# used the same knight to prevent Kxg6. The queen covered g5/g7/h7, and Black's own h5 pawn occupied h5. The referee confirmed mate.

## Recapturing with the king can restore a pawn pin: game 18

After 38...Rd6 39.Rxd6 Kxd6, White Ra6, Black c6 pawn, and Black Kd6 again lay on the sixth rank. White's 40.cxb5 could not be answered by ...cxb5: vacating c6 would expose the king. I recognized the illegality before submission, but the preceding exchange had already made the b5 pawn unavailable to that defender.

After ...Rc8, ...Kc5, and 42.bxc6 Rxc6, b5 was empty. White's 43.Ra5+ then opened a different ray: a5–b5–Kc5–d5–e5–f5. The played ...Kd4 removed the king from that ray, and Rxf5 took the pawn. Rebuild the rook's entire rank after the pawn capture and the king escape; the old blocker on b5 no longer exists.

## An unpinned bishop and the actual defender count: game 18, move 60

After 60.Kg4, the relevant position was White Kg4, Re6, Bf3, pawn d5; Black Kd2, Rd3, Bb3. The bishop on f3 was no longer pinned to a king on g3. Black nevertheless had two attackers on d5, Bb3 and Rd3, against the bishop's one defense. Re6 supported a possible advance to d6, not the pawn on d5 itself. The played ...Bxd5 Bxd5 Rxd5 therefore recovered the pawn and exchanged bishops without losing the rook.

## A pawn-protected rook check forces an adverse exchange: game 18, move 70

After 69...Ke5, White had Kh4, Rf6, and Pg4; Black had Ke5 and Rd5. White played Rf5+. The pawn on g4 protected f5, making Kxf5 illegal. Ke5 stood between Rd5 and the checking rook, so ...Rxf5 was also unavailable. There was no interposition against the adjacent rook check.

I played ...Ke6, keeping Rd5 defended, but White used Rxd5 Kxd5 to reach the pawn ending. The resulting position was White Kh4/Pg4, Black Kd5, White to move. A supported rook was still subject to an unfavorable exchange. Checking the legality of the last recapture is necessary but insufficient; rebuild and assess the ending before allowing the checking sequence. No claim is made that a particular earlier alternative was a proved draw.

## King support before promotion: game 18, final position

White Kh7/Pg6 faced Black Kf8 after 84.Kh7. Pg6 controlled f7; Kh7 controlled g7 and g8. Only ...Ke7 or ...Ke8 remained legal. White could then advance g7 and promote on g8 with the king's protection. I resigned. The illustrative ...Ke8 g7 ...Kf7 g8=Q+ is my unplayed reconstruction, not a referee-tested line or a claim that mate had already occurred.

## A defender can be exchanged before the pawn is taken: game 19

After 20.c4, White Rc1 and Nd2 defended c4 against Black Rc7 and Na5. Black played ...Bb4, attacking Nd2. The actual 21.a3 Bxd2 22.Bxd2 Nxc4+ removed the knight defender and won the pawn with check. Counting two defenders in the initial position did not establish that both would remain available. I have not proved that every alternative to 21.a3 lost the pawn.

Nd2 also blocked Rd1's file. After the earlier 17...Bxd5, Rxd5 was impossible because d2 was occupied by my knight; I used exd5. Recheck friendly blockers after moving a defender into position.

## Exchange the rooks before the knight recapture: game 19, move 24

After 23.Ka2 Nxd2, White had Rc1/Rd1 and Black Rc7/Nd2. Moving the d1 rook immediately to d2 would leave Rc1 unprotected against ...Rxc1. Instead, 24.Rxc7+ Kxc7 25.Rxd2 traded the c-file rooks first and then recovered the knight.

Ka2 mattered to this sequence: ...Nxd2 did not check that king, so White could use the rook exchange with check. In the unplayed alternative with the king on b3, ...Nxd2+ would require an immediate response to the knight check. These are local capture-order checks, not an evaluation of every king move.

## The king capture adds a defender: game 19, move 28

After 27.Rd3 e4 28.Re3, Black played ...Kxd5. The king's arrival on d5 defended e4 diagonally as well as capturing White's passed pawn. Rxe4 would therefore allow ...Kxe4; neither White Kb3 nor the white f2 pawn protected e4. The f2 pawn attacked e3/g3. Rebuild the king's eight adjacent squares after its move before calling the rook's pawn target available.

## A protected interposition ends the rear checks: game 19, finish

The played sequence 35.Rd8+ Ke3 36.Re8+ Kd2 37.Rd8+ Kc1 38.Re8 Rc2 39.Re3 Kd1 40.Rd3+ Rd2 put Black Kd1 behind Rd2, with the passed pawn on e2. Kd1 protected both the blocking rook on d2 and the promotion square e1. Rd2 also defended e2 horizontally.

I resigned. The unplayed illustrative 41.Rxd2+ Kxd2 leaves the pawn free to promote before Kb3 can stop it. The alternative 41.Re3 e1=Q 42.Rxe1+ Kxe1 removes White's rook while Black retains Rd2. Earlier forcing checks delayed promotion but did not establish a perpetual check; the rook's supported block changed the defense.

## A supported rook can still be driven into an exchange sacrifice: game 20

After 32.Nc4, I moved Ra3 to a6. Qc8 defended it through the now-vacant b7 square. White's 33.b5 attacked a6 with the pawn from b4 and also supported Bc6. I had checked queen support but omitted the pawn advance and the rook's subsequent escape squares. The actual ...Rxc6 34.dxc6 gave the exchange. This does not prove that all earlier alternatives lost, but establishes the failure of the intended safety argument. Before placing a major piece, check pawn pushes that attack its destination and a usable retreat after that push.

## A different knight landing square makes the fork: game 20

After 35.Nb6 Qc7, Black had Kg8, Qc7, and Be7. White played 36.Nd5. From d5 the knight attacked both c7 and e7. I had concentrated on Nd7 and failed to audit the other available destinations from b6. The played ...Qa5 37.Nxe7+ lost the bishop.

The unplayed ...Qc8 would not repair this fork: Nxe7+ would attack Kg8 and Qc8 simultaneously. This is a mental geometric illustration, not an engine-tested saving-line analysis. Scan every reachable landing square of the enemy knight before relying on a queen retreat.

## A promotion capture is an opponent choice: game 20, finish

After 37...Kf8 38.c7, Black had Kf8, Rb8, Nd8, and Ne4; White had Ne7 and the pawn on c7, with the original queen still on e2. The king's played ...Kxe7 legally took the undefended knight. It did not resolve the pawn's two capture promotions.

I concentrated on the unplayed cxd8=Q+ Rxd8. White instead played 39.cxb8=Q, taking the rook that the other line needed for a recapture. White now had two queens, and I resigned. Check the straight promotion and both capture promotions independently; a convenient checking promotion is not the opponent's only option. The actual final move was not checkmate.

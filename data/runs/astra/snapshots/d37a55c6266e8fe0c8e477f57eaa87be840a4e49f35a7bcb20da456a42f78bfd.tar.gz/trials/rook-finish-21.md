# Trial 21 — keep the rooks safe while finishing

Declared 2026-10-03 04:09 UTC after benchmark 150. Baseline 1540 [1420,1660], 54W/3D/93L in 150; 100 rated total/latest 50, 50 MAX excluded. Next fixed benchmark endpoint: games 151–156, regardless of drill results. The entire run stops at 200 scored games.

Trial 20 failed: 1W/0D/5L with repeated direct captures and missed mates. Earlier capture, defender, rook-activity and king-safety trials also failed. Narrow this learning period to a concrete conversion skill that failed spectacularly in 147: two rooks driving back a king without handing either rook to it. This deliberately uses a large material advantage, so wins are not Elo evidence or proof of broad tactical learning. Stop treating a remembered correct line, an intended check, or a connected pair of rooks before a move as proof that the resulting position is safe.

Own study principle to test: the checking rook's move can remove the other rook's only defender. Before the next checking move, use the resulting position to see whether the opposing king can capture either rook. A king near one rook may require relocating that rook along the protected rank before giving the next check with the other. Bring the king up when needed. This is a short practical task, not a new mandatory checklist, timing target or externally supplied solution.

Bounded learning: check exactly seven prewritten remembered/controlled branches below, plus validity of two self-composed drill setups. Then exactly two fresh maximum-strength opponent practices, White and Black, each ending naturally or stopped after 18 own moves with the final opponent reply included. Combined setup/study/practice/review deadline: 2026-10-03 04:34:29 UTC. No repetitions, replacements or extensions to improve the record. Starting material and intended mechanism are known; these are not blind positions or independently evaluated starting positions.

Supplied branches, predicted legal throughout (17 total supplied plies):
1. 147 after ply 47 (24.Bxg7+): g8g7. The king captures the checking bishop.
2. 147 after ply 68 (34...c3): f7f8, d8e7. The check removes Re7's defender and the king captures it.
3. Same 147 start, a controlled alternative, not a forced/best line: e7a7, d8e8, f7h7, e8f8, a7a8. Relocate both rooks away from the king before the final checking move. I expect the final move to give check; this supplied route does not predict the opponent's actual choices.
4. 149 after ply 89 (45.Rb1): a2b1q. The pawn captures diagonally and promotes.
5. 150 after ply 35 (18.Bc4): d5c4, d1d7. Vacating d5 exposes the queen on d7.
6. 150 after ply 57 (29.Kc1): f8d8, b3f7, g8h8, f7g7. Removing f7's defender allows the actual queen attack.
7. 148 after ply 97 (49.Rc8): e5e4, c8c5. Moving e5 opens the fifth-rank check.

Fresh composition A, White: `8/1p4p1/4k3/8/R6R/8/8/6K1 w - - 0 1` (Kg1/Ra4/Rh4 versus Ke6/b7/g7).
Fresh composition B, Black: `7k/8/8/1r3r2/8/2K5/P5P1/8 b - - 0 1` (Kh8/Rb5/Rf5 versus Kc3/a2/g2). Different placements, not a color-swapped replay. The opponent may find captures or evasions I missed.

Practice observation: finish without losing a rook, avoid illegal submissions, and distinguish a check from an actual referee-confirmed mate. A capped drill is unfinished, never an assumed win. For transfer, record every direct capture, loss of a defender, mating error and promotion oversight in the entire 151–156 block, including losses outside this narrow focus. Preserve ordinary development and all measurement settings. Stop or revise the method at the fixed assessment point if failures continue. All moves remain my own; no agents, engine analysis, automated search, scoring, attack maps or move menus.


## Trial 21 supplied study result
Seven remembered/controlled branches, 17 supplied plies: every legality prediction matched, and the specified final/checking moves gave check. Both new composition boards passed validity checks. The output labels nine records as branches because it includes two setup-only records; there are seven move branches and two setups, not nine tactical tests. No move generation/menu, attack-map enumeration, search, scoring, engine analysis or best-move claim was used. The alternative rook route is a legal controlled example with stipulated king replies, not an independently solved fresh position or a forced line. No mate search was performed by the script; actual recorded benchmark mates retain their referee results. Proceed to the two declared practices without adding cases.


## Practice 37 — composition A, converted with both rooks intact
Referee-confirmed 11.Rd1# at 2026-10-03 04:15:05 UTC: 11 own moves/21 plies, zero illegal submissions. Seq 1166; hash 84d4f9cc2c27c7838c976e4ccec4cb7a9abbd16edd3102ac1499fc23a7b6f843. Full practice PGN read. Actual line: 1.Rh5 g6 2.Rh7 b6 3.Ra6 Kd5 4.Rxb6 Kc5 5.Rxg6 Kd5 6.Rh5+ Kd4 7.Rg4+ Kd3 8.Rh3+ Kc2 9.Rg2+ Kc1 10.Rd3 Kb1 11.Rd1#.

The fresh replies mattered: ...g6 attacked Rh5, so I moved it; I also rejected Ra6+ while the pawn still stood on b7 because b7xa6 would capture that rook. After ...b6, Ra6 no longer lay on that pawn's capture square. Rxb6 was safe from Kd5; the actual ...Kc5 then approached the rook, and Rxg6 both moved it away and removed the other pawn. Successive rook checks drove the king down the board while the other rook blocked the higher rank, with both rooks beyond immediate king capture. At the first rank, my own Kg1 would block an imagined Rh1 check, so I used Rd3/Kb1/Rd1# instead. Both rooks survived.

This is a successful execution of the narrow, known-advantage task against fresh maximum-strength replies, not a benchmark win or independent strength gain. No extra practice is added after success; proceed to predeclared composition B.


## Practice 38 — composition B, both rooks lost
Resigned at 2026-10-03 04:18:05 UTC after 6.Kxb2: 5 own moves/10 plies, zero illegal submissions. Seq 1178; hash a0c27a06daae8d1b81a6c23c1e4b03e0e3c43066667a7a2f784bd02b2893fec3. Full practice PGN read. Actual line: 1...Rf4 2.Kd3 Rb3+ 3.axb3 Rg4 4.Kc3 Rxg2 5.b4 Rb2 6.Kxb2.

...Rb3+ considered the king on d3 but omitted the a2 pawn's capture on b3. I even considered a straight a-pawn move as a possible response without considering axb3; the actual capture removed the first rook. After ...Rg4/...Rxg2 captured the g-pawn, I chose ...Rb2 to go behind the remaining b-pawn and reasoned about the b-file's restrictions. I omitted Kc3xb2, a direct diagonal king capture of the second rook. Final Black Kh8 versus White Kb2/b4; practical resignation, not a proved starting-position or theoretical result. No replacement or extension was added. The 18-move cap was a maximum, not a requirement to play on after resignation.

## Trial 21 practice endpoint
Completed by 04:18:05, before the 04:34:29 ceiling. Seven remembered/controlled branches (17 supplied plies) matched predictions; both composition setups were valid. Fresh practices combined 16 own moves/31 plies, zero illegal submissions: an 11-move two-rook checkmate with both rooks preserved, followed by a five-move practical resignation after both rooks were captured. The second case repeats both pawn-destination and king-destination failures despite the first success and exact remembered examples. This does not establish improvement or reliable mastery even of the narrow task.

Return to the predeclared 151–156 fixed benchmark block now, without another drill or added mechanical case. Keep the short resulting-position focus as unproved and preserve every recurrence. Baseline remains 1540 [1420,1660], 54W/3D/93L after 150; practices do not affect it. The overall endpoint is 200 scored games regardless of Elo. No new valid token counter is available.


## Benchmark 151 — White MAX, loss
Resigned after 26...Kh7 at 2026-10-03 04:31:04 UTC: 26 own moves/52 plies, zero illegal submissions. Seq 12500; result hash 61b64f52ff93fa646b79f9bed5ef8ee9c510c7d9ec34697314ffcbf78dbdf928. Full PGN and trimmed status read. Cumulative 54W/3D/94L in 151; MAX 0W/2D/49L. Elo unchanged 1540 [1420,1660], 100 rated total/latest 50; 51 MAX excluded.

Castled move 5; remaining minors developed by 13, rooks activated 16/18. First 15 were not clean. After ...Bxf3/Qxf3 removed the knight that had defended d4, 8.exd4 Nxd4 lost the central pawn. More decisively, 10.Nc3 allowed ...d4 to fork Qe3/Nc3; Qg3/dxc3/bxc3 left me a knight down. ...Nh5 subsequently attacked Qg3/Bf4; Qg4 defended the bishop while escaping, and Black did not capture it. Later Qf3 correctly moved off the e-file before possible central exchanges. The c5 advance nevertheless lost a pawn to ...Rd5/...Rxc5. Bb3 kept the queen's horizontal defense of Bc3 open, and Bxa5/Rxa5 was an anticipated equal minor exchange. Final White Q/2R/B/5P versus Black Q/2R/B/N/6P, with no concrete compensating attack found. Practical resignation, not a mate or proof that the final position is theoretically lost. Neither rook was directly lost here, but the opening fork and pawn losses are adverse whole-game evidence; the narrow rook practice did not prevent them. Continue the declared block with 152.


## Benchmark 152 — Black MAX, loss
Resigned after 29.Ng3 at 2026-10-03 04:37:13 UTC: 28 own moves/57 plies, zero illegal submissions. Seq 12559; hash 6835da20a0972a0e8260b08e6cf6ad2ed3db0fc1b0bad6284c3cd1dd457f8083. Full PGN/status read. Cumulative 54W/3D/95L in 152; MAX 0W/2D/50L. Elo stays 1540 [1420,1660], 100 rated total/latest 50, 52 MAX excluded.

Castled 8, minors developed 9, rook activated 10. First 15 not clean when including White's 16th reply: 15...c4 16.b4 trapped Na5 because c4 and b7 were occupied by my pieces and c6 was attacked by d5. ...Nb3 axb3 cxb3 Bxb3 Qxc3 recovered two white pawns while losing my knight and c-pawn: a knight for one net pawn. The queen's apparent attacks on both rooks did not win material; Bd2 attacked her and connected the first-rank defense. ...a5 bxa5 lost another pawn: I correctly rejected ...Rxa5 when I noticed Bd2 protected a5. ...Bg7 defended Nf6; ...Nxg4 hxg4 was an anticipated equal knight exchange. The ...f5/gxf5/gxf5/exf5 break then left another pawn deficit. I initially imagined ...Qxf5 but rejected it before submission because Qf3 could take the undefended queen; moving Re8-f8 instead did not restore material. Final White Q/2R/2B/N/5P versus Black Q/2R/2B/4P. Practical resignation, not a theoretical result. No rook was lost directly, but confinement, pawn transactions and an initially mistaken recapture idea remain failures beyond the narrow study. Continue 153–156 as declared.


## Benchmark 153 — White skill 0, loss
Resigned after 37...Bxe3 at 2026-10-03 04:48:25 UTC: 37 own moves/74 plies, zero illegal submissions. Seq 12635; hash 40d9f80c61221030b2967d0bf27e6f9993ef10370c937b1dcd82ad340fdcfac7. Full PGN/status read. Cumulative 54W/3D/96L; skill 0 41W/1D/9L in 51. Elo 1530 [1410,1650], 101 rated total/latest 50, 52 MAX excluded.

Castled 5, minors developed 12, rook activated 15; first 15 clean, including the anticipated ...Nxe3/fxe3 exchange. Local correct applications: Qc2 protected b2 before Be3; e5 cleared the queen's diagonal so Bxh7 was protected, and after ...f5 the en-passant capture restored that protection. Bd3 returned before Ne4 could block its defender. After ...cxd4 opened Rc8 against Qc2, I moved the queen rather than blindly taking Rf6. Qxb5 was protected by Bd3; after ...Bxe4 I exchanged queens first (Qxb6/Nxb6) before Bxe4, avoiding removal of my queen's defender. These are actual local successes, not general mastery.

The endgame still failed. ...Nxb2 forked Rd1/Bd3; Rd2 saved the rook while retaining bishop defense, but later ...Bc3 attacked that overloaded rook. Before that, 30.Ng4 removed d4's defender and allowed ...Bxd4+. I chose Rxb2/axb2 as an anticipated exchange concession, then Bb1 blockaded the passer. The king reached e4 and attacked Bd4 successfully, but 37.Ne3—intended to route toward c2—walked onto Ba7's diagonal. ...Bxe3 captured the knight, protected by Ra3 along the third rank, so Kxe3 was unavailable. I had explicitly noticed both that bishop diagonal and rook rank earlier, then failed to apply them to the candidate. Final White B/3P versus Black R/B/3P. Practical resignation. A rook exchange loss, defender-removal pawn loss and direct knight capture outweigh the earlier correct line checks; the trial has not transferred reliably. Continue 154–156 without added study.


## Benchmark 154 — Black skill 0, win
Referee-confirmed 26...Rh1# at 2026-10-03 04:58:05 UTC: 26 own moves/52 plies, zero illegal submissions. Seq 12689; hash 72663665c67738d183a33231d06b586e16e2d7d7caa5c890e6f61c219e1f8dde. Full PGN/status read. Cumulative 55W/3D/96L in 154; skill 0 42W/1D/9L in 52. Elo 1510 [1390,1640], 102 rated total/latest 50, 52 MAX excluded. It fell from 1530 despite this win as the rolling rated window changed; do not infer deterioration from this one game's update alone.

First 15 clean by the no-material-oversight criterion. No castling: ...Kxf7 captured an undefended knight after ...Nxd5 had removed its bishop defender, then ...Kg8 answered Qf3+. Remaining minors developed by 11 and ...Rf8 activated a rook on 14. White's 12.Qg5 simply left its queen capturable by Qd8; this major opponent error chiefly explains the advantage, not demonstrated strength improvement. ...Be6 interrupted Qb3's diagonal and supported d5; ...Nf4 protected Be6 after leaving that diagonal, and ...Bd6 defended Nf4. When Nf3 also uncovered Bc1 against Qg5, I moved the queen rather than taking the knight and allowing Bxg5. Later apparent Qxg5 captures remained rejected because Bc1 protected Ng5. Pawn attacks were met by queen retreats.

The final attack was executed without a major material loss: ...Bxe5 was protected by Nc6; ...Bd5 escaped b3 and supported f3; ...Nf3+/Nxf3/Rxf3 was anticipated. ...Rxh3 threatened the first rank. White's Re4 then blocked Bd5's protection of h1; I noticed that immediate ...Rh1+ would permit Kxh1, and played ...Bxe4 first. After Bf4, ...Rh1# was protected by Be4 and confirmed by the referee. Both rooks survived. This is a concrete successful defender/king-capture application in a game dominated by opponent blunders, contrasted with the failures in 151–153. It does not by itself establish improvement. Continue 155–156, then assess the full declared block.

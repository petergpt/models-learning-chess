# Move check

Working protocol, based on my own recorded errors. No claim of tested improvement.

1. Reconstruct the current position, especially the king, queen, loose pieces, and recently vacated squares. Use the referee board if uncertain. State pawn attack directions correctly.
2. Identify the opponent's immediate checks and captures. A quiet move may have opened a defender behind another piece.
3. Choose a candidate for a concrete purpose. Test the cheapest enemy capture of any valuable exposed piece. Calculate exchanges through the last recapture, but treat each recapture as a choice: the opponent may stop trading or move the queen away. Do not call a target safe merely because a queen defends it.
4. Reconstruct the position after the candidate. Enumerate the opponent's checks before comparing material threats. For each enemy rook, inspect its reachable intersections with my king's rank and file; also inspect queen, bishop, knight, and pawn checks. Extend a checking ray through my king to any queen or rook behind it. Check paths and pins again, including whether my own king blocks a proposed defensive capture or interposition.
5. For king moves, inspect alignment with my queen and rooks. A king escape can expose a skewer. For a proposed king recapture, verify that the destination is not attacked after the capture. A king beside a piece does not defend it against an attacker supported by another enemy piece.
6. Prefer a verified material gain or sound development to an unverified sacrifice. With a large advantage, preserve coordination and check stalemate before quiet finishing moves.
7. For an exposed king, count actual escape squares after forcing checks, including squares occupied by my own pieces. When a move uncovers another line, check for double check: capturing one checking piece may leave the other check intact.
8. Before accepting a king escape, inspect queen checks on the new king's rank, file, and diagonals. A queen can switch from a diagonal to a file in one move. Reject immediate mate before comparing material threats.

Keep the final audit focused on the actual candidate and current board. Additional remote variations do not substitute for it.

The final audit has three questions: what checks are available after this exact move; can a cheaper attacker take a valuable piece and stop; and is my intended recapture legal? Apply them to the selected move, even if they were considered earlier in a variation. In game 12 I checked some rook checks but omitted Rc7+, which lost a rook; a partial check list did not suffice.

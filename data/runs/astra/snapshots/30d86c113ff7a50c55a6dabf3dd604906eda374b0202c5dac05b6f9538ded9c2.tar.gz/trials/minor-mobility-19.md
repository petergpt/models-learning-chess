# Trial 19 — minor-piece mobility and passed-pawn defense

Declared 2026-10-03 00:50 UTC after benchmark 138. Baseline 1560 [1440,1680], 52W/3D/83L, 92 rated games total/latest 50; each opponent has 46 scored games. Fixed next benchmark endpoint: games 139–144. Preserve rotation, settings, estimator and every record. The entire run ends at 200 scored games.

Trial 18 failed (1W/0D/5L). Trials 02, 12 and 13 already attempted explicit reconstruction, pawn origins and destination captures; their records show played failures despite implemented notes. Trial 10 already studied races with rooks. This is not a new general principle or a claim that another checklist will work. I am changing the material and practical task: recognize when a minor piece is being denied access to an opposing passer, before relying on distant king activity or pawn collection. In 138, the knight escaped h4 locally but the later bishop/king blockade of its routes defeated the h-pawn defense. The 137 sideways recapture and missed forcing check remain unresolved general weaknesses.

Bounded learning: a short mechanical check of five prewritten remembered/contrast branches below, then exactly two new self-composed nominal-1800 opponent practices, White then Black. Each practice ends naturally or explicitly unfinished after at most 16 own moves and the final opponent reply. Combined setup/study/practice/review ceiling: 2026-10-03 01:20:12 UTC. Add no repeats or replacement examples to improve the result. If the ceiling arrives, end an active drill and record any omitted work. Composed positions are not independently blind tests or certified equal positions; the mechanisms are known, and the opponent supplies fresh replies.

Practice A (White knight, Black bishop), FEN: `8/8/1p1k1b2/6p1/2K4p/P4NP1/5P2/8 w - - 0 1`.
White Kc4/Nf3/a3/f2/g3; Black Kd6/Bf6/b6/g5/h4. Both have a minor and three pawns. Decide how to handle the kingside pawn tension while preserving the knight's access; account for real captures rather than inventing a blockade result.

Practice B (Black knight, White bishop), FEN: `8/1p5p/2n2kp1/P7/1PB4P/4K3/8/8 b - - 0 1`.
Black Kf6/Nc6/b7/g6/h7; White Ke3/Bc4/a5/b4/h4. Both have a minor and three pawns. Deal with the advanced queenside pawn and bishop controls while retaining useful king/knight routes. This is a different composition, not a color-swapped copy of A.

Remembered/contrast predictions, recorded before mechanical checking (legality/check status only; no search, evaluation, attack map or move menu):
1. Game 137 after ply 104: h3g3 is illegal. The h3 pawn cannot recapture sideways after ...Rxg3. This is a remembered failure, not a fresh solution.
2. Game 138 after ply 73 (37.Kf2): h4f3 is a legal knight capture, and f2f3 is a legal king recapture. Thus Nxf3 is not a free pawn once the king has moved to f2.
3. Game 138 after ply 87 (44.Ke3): h4g2, e3f3, g2f4 are legal; Ng2 gives check. The proposed f3f4 king capture is illegal with the e5 and g5 pawn defenders surviving. This is the actual escape plus a supplied capture contrast.
4. Game 138 after ply 101 (51.Bf6): e5d7, h5h6, d7f8, h6h7, f8h7 are legal. The last knight capture gives check to Kg5. White cooperates in this deliberately supplied branch; it does not establish a hold against best play.
5. Game 138 after ply 103 (52.Bg7): d7f8 is still a legal knight move, but g7f8 is now a legal bishop capture. Legal mobility is not safe mobility; Bg7 changes the route used in branch 4.

Carry into practice and benchmarks: when an ending or exchange makes an enemy passed pawn urgent, identify the actual defender's route and the enemy king/bishop squares that bar it before choosing a distant pawn grab. Include the next capture and promotion response in that short line. Use ordinary development and ordinary capture/check reasoning; no special queen-trade preference, timing target, mandated move-note list or expanded general checklist. This targeted endgame cue is not a substitute for elementary legality or forcing-reply checks.

Assessment: record actual route obstructions, defender losses, legal recaptures, pawn promotions, successful stops, and all unrelated material/check errors. In capped practice an unresolved attack or race stays unresolved. A benchmark block with no relevant ending gives no direct transfer evidence. Compare the full fixed block and Elo interval at 144; do not claim a remembered legality match, a practice win or one benchmark win establishes learning. Revise again if the failures recur. All moves remain my own, without external chess advice, engines as analysts, automated move choice or delegation.


## Supplied-branch study result
Five branches / 14 supplied plies: 12 legal and two deliberately illegal; all predictions matched. The two predicted checking moves (Ng2 and Nxh7) were confirmed as checks. All starting positions were valid. The script checked only those prewritten moves using the vendored board module, with no engine, move menu, attack enumeration, scoring or search. Outputs: minor-mobility-19-legality.json. These are remembered/controlled contrasts; no fresh-solution accuracy or strength claim follows. The f8 branch explicitly demonstrates that move legality does not imply safe mobility. Proceed to the two predeclared new compositions only.


## Practice 33 — fresh composition A, unfinished
Stopped at the declared 16-own-move / 32-ply cap on 2026-10-03 01:01:52 UTC; zero illegal submissions. Result *, not a draw. Seq 1062; hash 5c345ed58b71c86e8a1c867279d7bfa573c75328403fbb35e9cb60a31d37b35a. Referee PGN read. Actual line: 1.Nd4 Ke5 2.Nf3+ Ke4 3.Nh2 Be5 4.f3+ Kf5 5.g4+ Kg6 6.Nf1 Kf6 7.Kd3 Bf4 8.Ke2 h3 9.Kf2 Ke5 10.Kg1 b5 11.Nh2 Kd5 12.Kh1 Kc4 13.Nf1 Kb3 14.Nh2 Kb2 15.Nf1 Kb3 16.Nh2 Kxa3.

After Ke5 I recognized that Bxd4 could no longer be answered safely by Kxd4 because the opposing king would guard d4. Nf3+ retained the knight, but allowed further king activity. f3+/g4+ moved the king back and kept the kingside pawns, yet vacating g3 opened Be5's line to Nh2; Nf1 escaped. I abandoned a knight-only blockade and brought the king through d3/e2/f2/g1/h1. The h3 pawn barred Kg2, so that route was not used. With Kg1 or Kh1 present, Nh2 had an actual king recapture after ...Bxh2; the h-pawn remained on h3. These are executed local defensive changes, not a proved hold.

Bf4 controlled the knight's alternatives d2/e3/g3/h2, while the king and knight were tied to the promotion corner. Black's king approached the other flank and captured a3 on the final reply. Final White Kh1/Nh2/f3/g4 against Black Ka3/Bf4/b5/g5/h3: one pawn down, no promotion or minor-piece loss, but the new b-pawn threat and restricted mobility remain unresolved. The starting composition was not objectively evaluated; no claim that these moves were best or that the position was initially drawable. No extra moves/repetition added; proceed to fresh composition B within the same deadline.


## Practice 34 — fresh composition B, draw after material errors
Ended naturally by insufficient material on 2026-10-03 01:09:44 UTC, 15 own moves / 29 plies, zero illegal submissions. Seq 1093; hash c22d6018447ba19c750ac45fe8b625e1ceb421cc2673934788839fe15f87f01f. Full referee PGN read. Actual line: 1...Nxb4 2.Kf4 h5 3.Be2 Nc6 4.Bc4 Nxa5 5.Bd3 Nc6 6.Be4 Ne5 7.Bxb7 Ke6 8.Kg3 Kf5 9.Ba6 Ke4 10.Bb5 Nf3 11.Be8 g5 12.Bxh5 Ne5 13.hxg5 Kf5 14.Bf7 Kxg5 15.Kh3 Nxf7 1/2-1/2.

The composition supplied an undefended b4 pawn, taken immediately. Nc6/Nxa5 also actually removed the advanced a-pawn when White left it undefended; this is an executed stop but an easy capture opportunity, not evidence of stronger defense against a well-supported passer. h5 fixed the other pawn. Then 6...Ne5 vacated c6 and opened Be4-d5-c6-b7: Bxb7 was an unanticipated pawn loss. I had noticed the attack on Nc6, but not the newly opened attack beyond it. The king/knight then reached Ke4/Nf3. Kxf3 by Kg3 was illegal while Ke4 guarded f3, but an immediate Nxh4 would still fail to the king on g3; that candidate was rejected.

11...g5 was intended to meet hxg5 with Nf3xg5. I omitted that vacating g6 both removed h5's defender and opened Be8-f7-g6-h5. White played Bxh5. The replacement 12...Ne5 then removed the knight's defense of g5, allowing 13.hxg5. All three original pawns were gone despite the earlier two-pawn gain. These are actual changed-line/defender failures, not a sound conversion. Kf5 approached the passer; White Bf7 left Pg5 undefended and the bishop itself attacked by Ne5. 14...Kxg5 was an actual legal king capture, and 15...Nxf7 removed the bishop. The referee drew with K+N against K. Opponent errors were decisive to this recovery; the draw does not erase the three pawn losses or demonstrate a forced defensive method.

## Trial 19 practice endpoint
Five remembered/controlled branches matched mechanical legality; two fresh composed practices then finished by 01:09:44, before the declared 01:20:12 ceiling. Combined 31 own moves / 61 plies, zero illegal submissions: one unfinished session one pawn down, one insufficient-material draw after surrendering a two-pawn advantage. No extra repetitions were added. A stopped the immediate h-pawn but tied down both pieces and conceded the other flank; B actually removed the a-pawn, then failed repeatedly on changed bishop lines and defenders before the opponent allowed simplification.

No practice evidence establishes improvement. Carry the predeclared minor-mobility/passers focus into fixed benchmarks 139–144, while retaining all capture, check and blocker errors. Do not expand the trial or treat the draw as a strength gain. Benchmark baseline remains 1560 [1440,1680], 52W/3D/83L in 138; practice does not enter Elo. No valid new cumulative token counter is available. All move choices and review were my own, with only the referee during active play and the declared limited mechanical checks between games.


## Benchmark 139 — 2026-10-03 01:24 UTC
White versus MAX; loss by resignation after 30...Rxa3. 30 own moves/60 plies, zero illegal submissions. Full PGN read. Result seq 11544; hash b670751a53bcfa942fe54cab2fa7cfd71e1290838c8512ebc17420637373c85a; snapshot 387312cd5f5f5a92c87a60a07b7b55546c831bf2c277b71adae5bcc6abd91f1b.

Castled on 6, minors developed by 8, rook activated on 11; first 15 moves material-clean. c3 retained a pawn defender of d4. Before Bf1 I rejected Bd3 because Nd2 would block Qd1's recapture after ...Bxd3; after Nf3 vacated d2, Bd3/Bxd3/Qxd3 was actually completed. Re5 could not retreat down the e-file with Be4 in the way; Rh5 preserved it when ...Nd7 attacked. Queens exchanged equally with ...bxc4, producing Black's queenside chain. Rb1 defended b2, while a speculative Rxf7 plan was invalid until Nf6 moved off the file; that blocker was noticed before an illegal submission. The rook activity did not yield a material gain.

After ...Rb3/...Ne4, I rejected Kf1 because ...Nd2+ would fork king and Rb1. However, 27.g3 allowed ...Nxc3, and 28.bxc3 was chosen while following ...Rxc3 in my own line. I omitted the decisive ...Rxb1+: vacating b2 opened the b-file from Rb3 to the rook behind it. Thus the apparent knight gain actually cost a rook and pawn, with check. This directly repeats the changed-blocker and incomplete-forcing-reply failures despite the practice period. Rf3 then protected c3 with Kg2 supporting the rook, but ...Rxa3 won another pawn; c3 blocked any Rf3-to-a3 recapture.

Final White Kg2/Rf3/Nc6/c3/d4/f2/g3/h3 against Black Kg8/Ra8/Ra3/a4/c4/d5/e6/f7/g7/h6. I resigned an exchange and two pawns down with an advanced supported a-pawn; legal continuations remained, and no forced-loss proof was used. No complete minor-piece-only ending or successful passed-pawn defense occurred, so there is no direct positive transfer evidence for trial 19. The older tactical weakness already recurred.

Cumulative 52W/3D/84L in 139. MAX 0W/2D/45L in 47; skill 0 39W/1D/6L and nominal 1800 13W/0D/33L, each 46. Elo stays 1560 [1440,1680], 92 rated total/latest 50; 47 MAX excluded. Storage 39,574,188 bytes. Trial 19 currently 0W/0D/1L; continue its fixed 139–144 block without extra practice. Sixty-one scored games remain to the 200-game endpoint.


## Benchmark 140 — 2026-10-03 01:34 UTC
Black versus MAX; loss by resignation after 23.Nxa1. 22 own moves/45 plies, zero illegal submissions. Referee PGN read. Result seq 11591; hash 42b9eb6e1f6851ea34492b935659048d5f2c5ee614efcfea0d2f89e59e60239f; snapshot 5fc4b03ed19e81069f079b6aa8c8cef2669cd895a403ed87b73bbdbae819cf91.

Castled on 7 and completed minor development on 9. The first 15 moves were not a material-clean opening: 13...c4 14.b4 restricted Na5. Nc6 was attacked by d5, b7 was occupied, and c4 held my own pawn. I chose 14...Nb3 15.Bxb3 cxb3 16.Qxb3, anticipating the pawn concession. The knight/bishop exchange was equal but the c-pawn was lost. Nd7 rerouted; I rejected Nc5 because b4 attacked it. After axb5/axb5 opened the a-file, Na3 temporarily blocked that file and attacked b5.

19...Qb6 defended b5 but 20.Be3 attacked the queen. 20...Qa6 retained that pawn defense while missing 21.Nc2: vacating a3 opened Ra1's attack on Qa6, and Nc2 also guarded a1. The queen obstructed my own Ra8. I found the queen's alternatives constrained by Be3, d5 and my own pieces, but did not prove a forced loss. The executed 21...Qxa1 22.Rxa1 Rxa1+ 23.Nxa1 traded my queen and one rook for both White rooks. It left a queen-for-rook deficit, not a favorable queen-for-two-rooks gain, because the knight recaptured the second rook.

Final Black Kg8/Rf8/Bb7/Be7/Nd7/b5/d6/e5/f7/g7/h6 versus White Kg1/Qb3/Be3/Na1/Nf3/b4/c3/d5/e4/f2/g2/h3. I resigned with the queen-for-rook deficit and one fewer pawn; legal continuations remained, and this was a practical decision without a forced-loss certificate. Both knight restriction and queen confinement were actual failures. There was no completed minor-piece ending or successful passer defense, and no positive transfer claim follows.

Cumulative 52W/3D/85L in 140. MAX 0W/2D/46L in 48; skill 0 39W/1D/6L and nominal 1800 13W/0D/33L, each 46. Elo 1560 [1440,1680], 92 rated total/latest 50; 48 MAX excluded. Storage 39,938,769 bytes. Trial 19 through 139–140: 0W/0D/2L, 52 own moves/105 plies, zero illegal submissions. Continue the fixed block through 144. Sixty scored games remain.


## Benchmark 141 — 2026-10-03 01:49 UTC
White versus skill 0; loss by resignation after 41...Kxg6. 41 own moves/82 plies, zero illegal submissions. Full PGN read. Result seq 11675; hash c5b74bd9609632708eea3f85b5104e50ad85d24001eff20c87b14273881bbfbf; snapshot 1d74d6e1b099f64af7a6226180a150ade5b4864a7a13b6bebadd5880963ff936.

Castled on 5, minors developed by 10, rook activated on 11; first 15 material-clean. Before Black castled, I rejected Bxh6/Bxh6/Qxh6 because Rh8 could then capture the queen. After castling moved that rook, 19.Bxh6 actually won the pawn; Bxg7/Kxg7 exchanged bishops equally. This local blocker recognition did not persist. 21.Qe3 put the queen on the e-file, and 22.Nd4 exd5 23.Nxd5 Bxd5 24.exd5 opened that file. I explicitly considered rook activity but omitted my own queen in the line: ...Rxe3 won it for a rook. 25.fxe3 retained a pawn defender of Nd4; Rxe3 would instead leave that knight vulnerable.

27.Nc6 attacked queen and rook, but ...Qxe3+ forced a king reply and ...Rf8 escaped. I had considered that checking interruption, so it was not an established material recovery. 29.Rce1 allowed the anticipated ...Ng3+/...Nxf1+ fork, losing another exchange before Rxf1. The d-pawn reached d6, but my own Rd7 obstructed its advance. Re7/Rxd7 did actually win Black's remaining knight. The queen checks briefly repeated; Black then broke the sequence with ...b4, so no draw occurred.

The final 41.Bxg6 correctly noticed that f7 was pinned to Kg7 by Rd7, but ignored the king itself: ...Kxg6 legally captured the undefended bishop. This is a direct recurrence of the defender/capture failure, despite the specific accurate pawn-pin note. Final White Kh2/Rd7/Nd4/a2/b2/d6/g2/h3 against Black Kg6/Qf1/Rh8/a6/b4/c4/f7. I resigned queen-versus-knight material down with one extra pawn; no forced-loss proof. No successful passed-pawn conversion or defense was completed. The errors, rather than the opening or isolated accurate pin observation, dominate this game's learning evidence.

Cumulative 52W/3D/86L in 141. MAX 0W/2D/46L in 48; skill 0 39W/1D/7L in 47; nominal 1800 13W/0D/33L in 46. Elo 1550 [1430,1670], 93 rated total/latest 50; 48 MAX excluded. Storage 40,318,387 bytes. Trial 19 currently 0W/0D/3L, 93 own moves/187 plies, zero illegal submissions. Continue unchanged fixed block through 144; 59 scored games remain to 200.


## Benchmark 142 — 2026-10-03 01:55 UTC
Black versus skill 0; win by 28...Rb1 checkmate. 28 own moves/56 plies, zero illegal submissions. Full PGN read. Result seq 11733; hash 86d96daf3a61a0b6867370b4c25f4c8939b3421b1af164898b7e0e18bef40992; snapshot b5fef939f17f3dcf88c172bb0c0994a7c79b121646a3cbdde21c011071264fc1.

Castled on 8, remaining minors developed by 9, rook activated on 10. 7...d6 blocked Qf4's added support of Nb5's c7 target. After the equal opening exchanges, 11...Nxd4 12.Qxf6 Qxf6 gave me White's queen for a knight. White then ignored ...Nxf3 and ...Nxd2, losing its remaining knight and a rook. These were major opponent errors. My 15...Qxb2+ was itself unsound: I considered other king responses but missed 16.Kxb2, which legally captured the undefended queen. The old Nd4 queen defender had long moved. The first-15 checkpoint is therefore not clean; the following reply exposes the loss. This is another direct king-capture/defender failure.

16...Nc4+ moved the knight with tempo, and 17...Re7 saved the rook attacked by Bb5. After ...c6 White left the bishop en prise; ...cxb5 actually won it. ...Nd2+ then forked king and the last rook, and ...Nxf1 won that rook. White had only pawns against both rooks, bishop and knight. I removed c4 and h6 pawns and finished an executed mating net: ...Rb4 cut off the b-file while vacating c4 opened Be6's line to a2; ...Nd2 defended b1; ...Rb1 was referee-confirmed mate. No promotion occurred. The huge opponent concessions, not a clean game or established intervention effect, explain the win. The successful final coordination does not cancel my queen loss.

Cumulative 53W/3D/86L in 142. MAX 0W/2D/46L in 48; skill 0 40W/1D/7L in 48; nominal 1800 13W/0D/33L in 46. Elo 1560 [1440,1680], 94 rated total/latest 50; 48 MAX excluded. Storage 40,665,398 bytes. Trial 19 currently 1W/0D/3L, 121 own moves/243 plies, zero illegal submissions. Complete 143–144 before assessment; 58 scored games remain.

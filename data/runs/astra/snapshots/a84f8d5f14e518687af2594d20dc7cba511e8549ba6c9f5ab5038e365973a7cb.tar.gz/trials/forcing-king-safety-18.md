# Trial 18 — forcing king safety and recapture contrasts

Declared 2026-10-02 22:07 UTC after game 132, with no active game. Baseline: 1580 [1460,1700], 51W/3D/78L in 132 scored games; MAX 0W/2D/42L, skill 0 38W/1D/5L, nominal 1800 13W/0D/31L (44 each). The user endpoint is exactly 200 scored games. This trial's fixed benchmark block is 133–138 in the unchanged paired-color rotation.

## Weakness and method

Trial 17 did not transfer reliably: the material calculation repeatedly stopped before a forcing check or treated a nearby king as a recapturer without retaining the opponent's surviving defender. Revisit this already-failed skill explicitly; this is not a novel checklist or a claim that recalling a diagram is improvement.

First make and mechanically check eight manually specified contrast cases from our own games 128, 130 and 132. Only board reconstruction and legality of the specified moves are allowed. No generated move menu, attack-map analysis, search, engine evaluation or external source. The remembered positions are training examples, not held-out tests.

Then play exactly two fresh self-composed opponent-practice positions at nominal 1800, White then Black, at most 20 own moves plus the reply in each. Unlike trial 17's sparse rook drills, both positions retain queens, rook, bishop, knight and six pawns per side, including constrained castled kings and diagonals that can open when blockers move. These are equal-material constructions, not certified equal evaluations.

Combined study/practice deadline: 2026-10-02 22:52:05 UTC, 45 minutes from the post-132 review clock. End any ongoing practice at its move cap or this deadline; record early results or unfinished sessions and add no replacement practice. Return to benchmarks after both sessions, even if the exercises fail.

Position A, White:
5rk1/p1pq1ppp/1b2p3/3n4/3N4/1B2P3/P1PQ1PPP/5RK1 w - - 0 1

Position B, Black:
6rk/pp2qppp/3bpn2/8/8/3BPN2/PP2QPPP/6RK b - - 0 1

## Predictions written before legality checks

1. Game 132 after ply 104 (...Bb6): Nxb6/Kxb6 is legal because the knight leaves c4 and Rd1 does not guard b6.
2. From that same position, Rd6+/Kc5/Rxb6 is legal, but Kxb6 is illegal: Nc4 survives and protects b6.
3. From that same position, Rd6+/Kc5/Nxb6 is legal, but Kxb6 is illegal: Rd6 now protects b6.
4. Immediately after Rd6+, Kxd6 is illegal because Nc4 protects d6.
5. Game 130 after ply 61 (Rc8+): Kh7 is illegal because h7 is occupied; Kf8 is illegal because the checking rook controls f8. Re8/Rxe8 are legal and the recorded result is mate.
6. Counterfactual to case 5 with only the black h7 pawn placed on h6: Kh7 is legal. This demonstrates an actual escape square, not a certified best earlier plan.
7. Game 128 after ply 35 (Qg8+): Kxg8 is illegal while Bb3 protects g8. Nxg8/Nf7 are legal; the recorded result is mate, so winning the queen did not make the capture safe.
8. Counterfactual to case 7 with Bb3 removed: Kxg8 is legal. This deliberately changes material and is only a geometry contrast.

## Evaluation and decision

The practice target is to preserve a usable king response through checking continuations and to reject false king recaptures in the actual final board. Track actual mating losses, newly opened pins, unsupported material losses and illegal submissions; retain all other errors as well. Success on remembered cases is diagnosis/retention only. Fresh practice is still training, not Elo evidence.

Use ordinary development in games. A short cue replaces trial 17's special rook focus: when a capture gives or permits check, resolve the king response before counting the gain; a king recapture must be legal with every surviving enemy defender still present. Do not expand the cue into an exhaustive move checklist or assume a king-adjacent piece is secure.

At game 138 report the whole block's W/D/L, per-opponent results, Elo and uncertainty, along with recurrence of the targeted errors. A recurrence rejects reliable execution and requires another revision. No single win, clean drill or transient rating rise establishes sustained progress. No opponent, estimator, decision-time target or token counter is changed.


## Contrast study completed — before opponent practice

Eight predeclared case groups were checked as eleven supplied branches, 21 specified plies: 15 legal continuations and six deliberately illegal king moves. Every starting board was valid and all predictions matched. Inputs, the supplied-move-only verifier, and results are saved in king-safety-18-inputs.json, king-safety-18-verify.py and king-safety-18-legality.json.

The check used only the existing vendored board module, with bytecode writes disabled and the shared t3-job wrapper. It reconstructed our recorded SAN moves and checked the explicitly supplied UCI moves. No engine interface, search, generated move menu, attack map or evaluation was used. The two mating outcomes are from the recorded referee results, not a new automated evaluation.

The 132 contrasts distinguish Nxb6 before Rd6 (king recapture legal), Rxb6 after Rd6 (Nc4 survives), and Nxb6 after Rd6 (Rd6 survives). Both later king recaptures are illegal. The 130 counterfactual makes h7 available only by actually vacating h7; merely naming it did not create an escape. The 128 contrast confirms Bb3's role in preventing Kxg8, while the recorded Nxg8/Nf7 sequence shows that a legal queen capture can still allow mate.

These were known failures with written predictions, so passing them is diagnosis/retention only. Proceed to the two declared fresh positions without extra examples or changed limits.


## Practice 31 — fresh White position A

Stopped at the declared cap on 2026-10-02 22:27:15 UTC: 20 own moves / 40 plies, zero illegal submissions, unfinished rather than a win or draw. Result seq 984, sha256 5654baa3c792f9e85a54a85bce6174723c175e7cc1858ad2bc0652ff8c982b70. PGN read back.

1.h3 Nf6 2.Rd1 c5 3.Nf3 Qb5 4.c4 Qc6 5.Qc2 Rb8 6.Nd2 Qc7 7.e4 Nd7 8.Nf3 Ne5 9.Nxe5 Qxe5 10.Rd7 Bc7 11.g3 Ba5 12.Kh2 h5 13.f4 Qf6 14.e5 Qh6 15.h4 g6 16.Rxa7 Bb6 17.Ra6 Qf8 18.a3 Qe8 19.Ba4 Qd8 20.Bb5 Ra8.

h3 created an initial h2 escape. Rd1 supplied a real queen defender before Nf3 opened the d-file; c4 stopped a pawn advance that would restrict Bb3 behind a2/c2. Nd2 added e4 support before the pawn advanced. After Qc7 and later Qxe5, I explicitly stopped treating h2 as safe. Bc7 created the queen-bishop battery; g3 blocked it with f2 support, and Kh2 was chosen only after checking the actual diagonal. f4/e5 gained queen tempi with pawn support, and h4 closed the pawn contact.

The knight exchange completed at equality. Rxa7 won the pawn only after its bishop defender left b6, and the planned Ra6 retreat was actually used after ...Bb6. I kept a4 clear by a3 rather than a4. Ba4 forced the queen off e8, then Bb5 restored the rook exit and put the bishop on a c4-supported square protecting Ra6.

Final board: White Kh2/Qc2/Ra6/Bb5/a3,c4,e5,f4,g3,h4 versus Black Kg8/Qd8/Ra8/Bb6/c5,e6,f7,g6,h5. White has one extra pawn. No unexpected material loss, mating loss or illegal move occurred within the cap. Black's final ...Ra8 attacks Ra6. The bishop-support geometry was planned, but no further rook exchange or recapture was played; do not report a completed defense, conversion or practice win. This is positive training execution, not measured Elo evidence.

## Trial 18 practice B and training endpoint — 2026-10-02 22:43 UTC

Practice 32, Black, nominal 1800, fresh self-composed FEN `6rk/pp2qppp/3bpn2/8/8/3BPN2/PP2QPPP/6RK b - - 0 1`, ended exactly at the declared 20 own moves plus final opponent reply (40 plies). Referee result is unfinished, not a win/draw/loss; zero illegal submissions. Result seq 1027, hash `1cfdca0761e4e96e4333a5db074df29aee2173b957c74864f9691116bd4afdef`, timestamp 22:43:06. PGN read back in full.

Actual moves:
1...Rf8 2.a3 e5 3.Bb1 e4 4.Nd4 Qe5 5.f4 exf3 6.Nxf3 Qh5 7.g3 Re8 8.b4 Ne4 9.Bxe4 Rxe4 10.Kg2 f5 11.Qd3 Be7 12.Rc1 h6 13.Kf2 g5 14.Qd7 g4 15.Rc8+ Kh7 16.Nh4 Qf7 17.Nxf5 Re5 18.Rc5 Rxc5 19.bxc5 Qa2+ 20.Kg1 Qb1+ 21.Kf2.

Observed useful execution:
- Rf8 opened g8 while Qe7 guarded f8; no assumed king recapture from h8 to f8.
- e4 blocked Bb1-h7. The actual f4/exf3 en-passant/Nxf3 sequence exchanged pawns and changed the queen attack and h2 defense; no pawn win was claimed.
- Bxe4/Rxe4 was an actual equal minor exchange. White Kg2 ended the earlier h-pawn pin.
- Once White Rc1 made Rc8+ concrete, h6 created h7. White's bishop had gone; later Qd7 was blocked by Be7. The actual Rc8+/Kh7 response was legal.
- Recognized the bishop pin on the seventh rank and inserted Qf7 as a second blocker.

Errors and limits retained:
- The claims that f5 was defended were materially incomplete. White Qd7 and Nh4 jointly attacked it, and 17.Nxf5 won the pawn. Qxf5+ would allow Qd7xf5+, so queen protection was not an adequate recapture. This repeats the effective-defender weakness.
- Rxc5/bxc5 was an equal rook trade. An immediate Bxc5 would open Qd7's attack on Qf7. Qa2+ moved the queen with check, but my initial planned bishop recovery still failed: Be7 was again the sole blocker between Qd7 and Kh7, so Bxc5 would be illegal. This was recognized before submission. The final Qb1+ bought another king response but did not solve the bishop problem.
- Final Black Kh7/Qb1/Be7 with a7,b7,g4,h6 versus White Kf2/Qd7/Nf5 with a3,c5,e3,g3,h2. One pawn down, bishop pinned and attacked, no resolved defense or conversion. No illegal move was submitted.

Both declared practices are now complete, both unfinished at 20 own moves and zero illegal attempts, before the shared 22:52:05 deadline. Practice A ended one pawn up with a final rook attack still unresolved; B ended one pawn down with an unresolved bishop pin. Eight remembered contrast groups passed their specified legality predictions, but that is retention, not transfer. Fresh B already reproduced an inadequate recapture assumption, so these drills do not establish reliable king-safety execution or improved playing strength.

No extra practice or selective extension. Proceed with the predeclared unchanged fixed benchmark block 133–138, assessing all six results at 138. Baseline remains 1580 [1460,1700], 51W/3D/78L after 132; training is excluded from ratings. The run stops at 200 scored benchmarks regardless of Elo. No valid new cumulative token counter is available. The tool goal still contains the obsolete win-based objective and old blocked status; the explicit user endpoint and current AGENTS/GOAL govern this continuation.

# Trial 10: endgame races and legal recaptures

Declared 2026-10-01 21:44 UTC after benchmark 84. Baseline 1700 [1580, 1820], overall 35W/2D/47L. No sustained improvement established. Trial 09 and its timing data are preserved; discontinue its 20-second target. Use ordinary ./play interfaces. Opponent, estimator, model and fair-play rules remain fixed.

Weakness: in game 84 I treated an advanced connected pawn pair as adequate compensation without completing the defender's rook-sacrifice line. A king's geometrical contact with a square was wrongly treated as a usable recapture despite the opposing king. Training will focus on a specific endgame skill, rather than another longer general checklist.

Before each race decision, mentally carry both sides' promotion or capture line through the next actual capture and check whether each king recapture is legal. Count moves for both sides, including checks and rook sacrifices; a promotion is not the end of the line. Record concrete errors after each session. These are my own calculations, not certified evaluations.

Bounded practice: three sessions, at nominal 1800 as Black, at most 25 learner moves each including the opponent reply. First and second start from benchmark 84 after ply 116 (58...Kxg2; White moves first), allowing one explicitly remembered repetition. Third uses the new constructed rook-ending FEN `r7/8/4k3/P4p1p/1P4p1/3K4/6PP/2R5 b - - 0 1`. The new position is an unvalidated exercise, not a known theoretical result. Combined ceiling 22:29 UTC on 2026-10-01, including setup/reviews; stop unfinished practice at the ceiling, preserve all sessions, and do not add repetitions to seek a win. Own board reasoning and referee only; no engine evaluation, move suggestions or automated chess analysis.

Next fixed evaluation: benchmark games 85–90 after this practice, regardless of practice outcome. Assess all six results and Elo uncertainty, actual endgame opportunities/errors, and recurrence of earlier tactical losses. A block with no relevant ending cannot establish endgame transfer; do not force favorable benchmark positions. Any rating rise remains provisional and requires repeated evaluation. Practice is excluded from Elo. Revise again if the approach fails.


## Practice 10 — first remembered-position session, loss

Completed 2026-10-01 21:46:31 UTC by practical resignation after 66.h6; 15 session plies, seven learner moves, zero illegal submissions. Result seq 401, hash `5d6a509b01545a5c37f0fed219e5fec51b89893f92a67cce0e232060a07c929a`. PGN read back. The supplied ply 116 is after 58...Kxg2, not after 58.Rxc8 as initially described. The referee therefore played White's 59.Rc1 before my first move. Corrected the description, retained the session unchanged; the second session will use that same specified ply.

Actual line: 59.Rc1 f3 60.Ke3 f2 61.Ke2 Kh2 62.h5 f1=Q+ 63.Rxf1 g2 64.Rb1 g1=Q 65.Rxg1 Kxg1 66.h6. I avoided the original illegal conceptual Kxf2 recapture by choosing ...Kh2, but did not escape the rook-sacrifice mechanism. Both black pawns promoted and both queens were captured. White gave its rook for the second pawn, drawing my king to g1 while its h-pawn remained unstoppable. This demonstrates why promotion alone is not a successful race endpoint. Some analogous rook-sacrifice lines were anticipated in my own reasoning, but I still chose a continuation that allowed the mechanism. No winning alternative or theoretical value of the starting position is established. Resignation is a practical conclusion, not a solver result. Practice remains excluded from Elo.

Seven own moves used, session finished below the 25-move cap. Two declared sessions remain; do not add extra repetitions or change the practice outcome into benchmark evidence. Next try a king route that addresses the h-pawn before pushing both pawns, while recognizing that the starting position may already be lost; this is an unverified candidate plan, not a supplied solution.


## Practice 11 — sole remembered repetition, loss by checkmate

Completed 2026-10-01 21:49:24 UTC, 13 session plies, six learner moves, zero illegal submissions. Result seq 416, hash `00d2eaf8c36ed49557a6254dd43fdd841e6502051b588fb44e9feac3ae3c20a2`. PGN read back. Same benchmark-84 ply-116 starting position; opponent chose Rd8 instead of Rc1.

Actual line: 59.Rd8 Kh3 60.Ke4 Kxh4 61.Rh8+ Kg4 62.Rb8 f3 63.Rg8+ Kh3 64.Kxf3 e5 65.Rh8#. The alternative king route removed the h-pawn, but ...f3 and the checking rook drove the king away from that pawn, letting Kxf3 capture it. I then considered an e-pawn advance to draw the white king away from the g-pawn, and missed the immediate mating threat. Rh8# confines Kh3 because White Kf3 controls g2/g3/g4 and my own g3 pawn blocks that square. This is an actual missed mate, referee-confirmed, and another example of a longer race idea displacing the immediate opponent reply. No claim that the earlier position was defensible or that ...e5 was the first losing move.

Both remembered drills lost. No extra repetition will be added; finish the declared third new-position session, then benchmark 85–90 regardless of its outcome. These six own moves finished below the cap. Practice remains excluded from Elo.


## Practice 12 — new constructed rook ending, draw; practice phase complete

Completed 2026-10-01 21:53:04 UTC by referee automatic threefold-repetition claim after 21...Ra6+, 41 session plies, 21 learner moves, zero illegal submissions. Result seq 459, hash `b8812c8df1920c209bdad33e6599634e1f6ced724c37e4d9f2908ab82a1da042`. PGN read back. The position was the declared constructed FEN, not an independently evaluated theoretical exercise.

After ...Ke5, Rc5+ drove the king away and Rxf5 took the f-pawn. ...h4/...g3 and ...Rh8 preserved the remaining pawns temporarily. White advanced b5/a6/a7; I used ...Kc5/...Kxb5 and ...Ra8/...Rxa7 to remove both passers without giving up the rook. Leaving h8 conceded h4 to Rxh4. ...Ra3+ defended g3 while checking; I brought the king through c5/d5/d4. White eventually used Rxg3 with Kf4 protecting that rook. I declined the rook exchange because the resulting pawn ending looked unfavorable, preserving my rook with ...Ra1. This is my own assessment, not a proved endgame value.

With rook against rook and g/h pawns, ...Ra5+/...Ra6+ kept checking the exposed white king from the side. White alternated among g6, f5 and e6 and the referee claimed repetition. The recorded draw does not prove a forced draw against every defense, and the earlier pawn losses are not erased. No direct unreciprocated major-piece loss, illegal move, or actual missed immediate mate was identified in this session.

Trial-10 practice total: 0W/1D/2L, 34 learner moves, 69 session plies, zero illegal submissions. All three finished below their 25-own-move caps and by 21:53:04, before the 22:29 combined ceiling. The two remembered drills retained the same starting position and every loss; the new exercise was not repeated. Practice 11's missed rook mate is a clear failure, while practice 12's side-check draw is one useful defensive result, not established transfer. No further practice is added before the declared fixed benchmark 85–90. Continue that block with the trial-10 endgame focus and ordinary referee commands; the trial-09 20-second target remains discontinued.

Elo remains the benchmark-84 value 1700 [1580, 1820], with 56 rated games total / latest 50 used. No sustained improvement is established. All moves and reviews were my own, without external chess advice, automated chess analysis, engine evaluation, or delegation. Actual observed cumulative whole-goal usage after these sessions: 16,173,564 tokens / 172,631 elapsed seconds.


## Benchmark 85 — White versus maximum strength, loss

Completed 2026-10-01 22:00:50 UTC by practical resignation after 26...Bxb7; 52 plies, 26 own moves, zero illegal submissions. Result seq 7087, hash `3440787a1b3e65dd2a8f4367691b251e9265fc6d1abf6e048900d9775261bded`, snapshot `a23ef28ba03d5e1a54afb2429f03f3c4152d5250de0477e0aaa37193e4d8ed35`. Saved PGN read back. No best-defense or first-losing-move certificate is claimed.

The queen-pawn opening exchanged the central pawns and then queens. ...Qd5 attacked Rh1; Nf3 blocked that diagonal and allowed Qxd1+/Kxd1. Black's subsequent bishop checks and rook development kept my king moving. ...Bb4 pinned c3, so Bd2 supplied a blocker before the knight exchange; ...Nxd4/cxd4/Rxd4/Bxb4/Rxb4 left me a pawn down. The recapture on b4 was understood, not a surprise piece loss. Black's active rook then took a2 and e2 while my rooks and king moved into exposed positions.

After ...Re5, 24.Rhb1 enabled ...Bc6+, skewering Kf3 and Bg2. I recognized the bishop loss once the check occurred, but had not accounted for it before Rhb1. Kg4/Bxg2 lost that bishop. The final 26.Rxb7+ was a separate direct rook blunder: I considered king replies and follow-up checking sequences but omitted the checking rook's capture by Bg2 along f3/e4/d5/c6/b7. Black played ...Bxb7. Rb1's protection did not rescue the tactic because Kb8 defended b7, so Rxb7+ would allow Kxb7. Resignation followed with R+3P against 2R+B+5P. A check being answerable by capture remains an actual recurring failure.

No pawn-promotion race occurred, so this game does not directly test the trial-10 race exercise. It does show another failed transfer of the broader immediate-capture discipline, with an actual major-piece loss. The result is preserved; no extra practice or altered benchmark opponent is introduced mid-block.

Through 85: overall 35W/2D/48L. Maximum strength 0W/2D/27L in 29 games; skill 0 26W/0D/2L and nominal 1800 9W/0D/19L, each in 28. Elo remains 1700 [1580, 1820], 56 rated total / latest 50 used, 29 maximum exclusions. Trial-10 benchmark currently one loss; finish 86–90 before its endpoint. No short-decision timing target applies. Observed cumulative whole-goal usage 16,298,116 tokens / 173,091 elapsed seconds. All decisions and review were my own; no external chess advice, automated chess analysis, engine evaluation or delegation was used.


## Benchmark 86 — Black versus maximum strength, loss

Completed 2026-10-01 22:09:44 UTC by practical resignation after 27.Qxa8+, 53 plies, 26 own moves, zero illegal submissions. Result seq 7143, hash `61e7175ba05b0409b11e5c062b254b2a231cbfc4c90b4210823a0d52081928e4`, snapshot `d1b0ff3a430dadbed97736ff21299a2347eee0b6e8818a6312be4f0d7ad44d14`. Saved PGN read back. No independent first-losing-move or optimal-defense claim.

The closed king-pawn opening reached ...c4/b4 and sent Na5 to b7. The ...a5/axb5/axb4 sequence opened the a-file, but White's b6 pawn attacked Qc7 and constrained my queen and knight. I moved Qc8 and recaptured Rxa8 with Qxa8; cxb4 left White an extra pawn. ...Qa2 attacked Bc2 but Qc1 defended it; Nc3 then attacked the queen. I chose ...Qa6 without foreseeing how Ra1 would confine it. After Qb2/f5/Ra1 I recognized that the direct queen retreat squares were occupied or attacked and chose ...Qxa1+/Qxa1 as a queen-for-rook concession. I considered interpositions but did not establish a sound saving line; this is not a claim that the concession was objectively forced.

The last move was an additional direct rook blunder, separate from the queen problem. After ...f4/Bc1 I played 26...Ra8 to attack Qa1, imagining queen retreats. I failed to apply the reciprocal attack along that same open file: the rook had no defender and White simply played 27.Qxa8+. This was not an intended exchange or a surprise remote tactic. I resigned with no major pieces against White's queen, in addition to the pawn deficit. Both the confined queen and the undefended rook are concrete failures preserved in the record.

White's advanced pawn mattered to the queen's confinement, but no promotion race or rook-only ending occurred. Thus the bounded endgame practice has not supplied positive transfer evidence in either maximum-strength game. The direct-capture failure recurred despite prior explicit notes; do not call the new trial effective.

Through 86: overall 35W/2D/49L. Maximum strength 0W/2D/28L in 30 games; skill 0 26W/0D/2L and nominal 1800 9W/0D/19L, each in 28. Elo unchanged at 1700 [1580, 1820], 56 rated total / latest 50 used and 30 maximum exclusions. Trial-10 benchmark currently 0W/0D/2L; finish 87–90 before the declared endpoint. Observed cumulative whole-goal usage: 16,475,357 tokens / 173,625 elapsed seconds. All chess decisions and review were my own; no external advice, automated chess analysis, engine evaluation or delegation.

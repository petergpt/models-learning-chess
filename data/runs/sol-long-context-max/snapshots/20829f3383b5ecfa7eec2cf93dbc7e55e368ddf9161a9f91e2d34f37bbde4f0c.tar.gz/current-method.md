# Current method, after 31 scored benchmarks

Own reminders from this experiment; no external analysis or imported learning material.

- Use the actual referee board and reply. Keep a quiet decision to one conventional candidate and its immediate forcing replies before distant plans. Enforcement has been poor; this is a chosen method, not a token budget. Imagined positions are not tests or proofs.
- Locate my queen and both rooks before a forcing exchange or king response. A king escape can leave a major piece undefended or expose a piece behind the king. Game 26's Kc6 exposed Rc8; game 30's Rh7+ skewered Ke7/Rb7 despite the retained guard of the other rook.
- Inspect enemy checks to empty squares and the king's usable flights. Game 22's Bf8 and game 29's Ng1 filled an escape square; guarding one destination did not prevent the next check.
- Check current pawn attacks and immediate en-passant replies before a two-square push. Game 23's new b5 pawn attacked Bc4. Game 30's b7-b5 allowed a5xb6 en passant even though b5 had pawn defenders.
- A departing pawn, guardian or captured queen can open a line to a major piece. Game 25's dxe6 removed the d5 blocker between Rd8 and Qd3; game 24's queen trade removed the final b7 recapture.
- Game 31's Nc6-d4 capture uncovered Rc8 against my undefended Nc3. Ba4 then defended b3 but allowed a bishop trap: own b3/d1 occupancy and Rc3's coverage of b3/c2 mattered after ...a6/...b5. Check the defender's own escapes against the actual reply.
- Use the cheapest usable defender and the opponent's next recapture. A queen or rook guardian can lose material to a cheaper third capture. For a king capture, include all other enemy attacks on the destination and any line uncovered when the checker leaves its origin.
- In an ending, inspect promotion distance before trading or activating the king. Game 24's c-pawn promoted after an exchange; game 30's en-passant reply created a defended sixth-rank passer and bound a rook.

Trial 22 has finished. Practice 23's h3/Kg1 allowed a different mating continuation and ended in a recorded loss after five own moves. Practice 24's proposed Re8 was blocked by Ke7 and never submitted; the adjusted Rf6/Rf8 continuation still lost Rb7 to the checking skewer, and was explicitly stopped after five own moves with result *. Neither local defense was repaired. Both records are retained, excluded from benchmark Elo. Return to fixed benchmarks 31–36 with no more opponent drills before the full evaluation at 36 scored games.

Current measurement: 4W/2D/25L, provisional engine-relative Elo 1250 with 95% credible interval 1010–1460, twenty calibrated games and eleven maximum-strength games excluded. Opponents: maximum 0W/0D/11L; skill 0 4W/1D/5L; 1800 setting 0W/1D/9L. White 3W/2D/11L, Black 1W/0D/14L. The block 25–30 scored 2W/0D/4L. The skill-0 wins relied heavily on opponent errors; sustained improvement or causal transfer remains unestablished. Bounded completion remains 200 scored games regardless of achieved Elo.

Trial 23 is brief study of game 31's c-file blocker and bishop-trap failures; Na3 at move 12 and b4 at move 21 are unplayed candidates. Continue fixed benchmarks 32–36 with no further opponent drill before the full review at 36. No repaired position or transfer is claimed.

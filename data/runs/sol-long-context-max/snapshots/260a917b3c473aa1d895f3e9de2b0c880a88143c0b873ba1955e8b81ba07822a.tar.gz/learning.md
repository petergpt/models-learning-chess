# Independent chess learning log

## Starting state

Read this experiment's AGENTS.md and GOAL.md. Referee status shows no started games and no Elo estimate. No outside chess material, other learner material, delegated advice, engine analysis, or move-selection code has been used. Actual token counters are unavailable; I will not invent usage numbers.

## Initial evaluation plan

Play the first six scored games as a paired-color baseline through the fixed rotation. Choose every move mentally. Use familiar development principles: contest the center, develop minor pieces, protect the king, and check the opponent's immediate checks, captures, and threats before committing a move. This is an initial approach, not evidence of improvement.

After this block, choose a focused learning trial from my own observed errors and return to benchmarks after a bounded study/practice period. Record observations after each game. The first transfer evaluation will be at 12 scored games; revise that point explicitly if a concrete weakness calls for a different interval.

## Evidence to track

- Official provisional engine-relative Elo and its 95% credible interval; maximum-strength games are separate evidence because they have no calibrated anchor.
- W/D/L by opponent and color.
- My own unverified diagnoses of avoidable material losses, missed threats, king exposure, and conversion errors; distinguish these from the referee's established result.
- Whether errors recur in new positions. Replaying a remembered position or winning easier practice alone will not establish transfer.

## Games and trials

### Benchmark 1: White versus maximum strength, loss by resignation

Result: 0-1 after 46 plies. One rejected illegal submission, 19.Qxf3 from d3 through my bishop on e3. The eventual queen loss after 22.Qe4 Rxe4 is established by the accepted moves; my diagnosis is a basic failure to trace occupied lines, not subtle opening theory. I resigned with queen-for-rook material loss and an exposed king. Maximum-strength games do not supply a calibrated Elo anchor.

### Trial 1: Make board geometry concrete

The first game already supplies a clear target, so revise the original uninterrupted six-game baseline: undertake a short learning period now, then resume the fixed rotation. Next benchmark review remains at six scored games, with a transfer review at twelve.

Study my own two mistakes mentally. Before a queen/rook move or a planned recapture, explicitly trace every intervening square and examine opponent rooks, bishops, and knights attacking the destination. On move 19 the e3 bishop blocks d3-f3. On move 22 the e8 rook has a clear e-file to e4. A queen-exchange intention did not make the other capturing piece disappear.

Try one recorded practice drill from benchmark 1 after ply 42, against skill 0, for at most eight of my moves. This is a remembered position, so success is only a local repair check. I will select a different queen square myself and attempt to keep both king and queen safe. End the drill explicitly if still active, then benchmark game 2. Observable transfer target: fewer illegal geometry attempts and no queen lost to an already visible slider in new benchmark positions. Keeping a longer checklist alone is not evidence of learning.

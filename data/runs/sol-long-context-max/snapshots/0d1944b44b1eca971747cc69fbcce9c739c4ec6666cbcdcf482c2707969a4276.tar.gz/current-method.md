# Current method, after 24 scored benchmarks

Own reminders from this experiment; no external analysis or imported learning material.

- Use the actual referee board and actual opponent reply. Imagined later positions are not tests or proofs.
- Inspect immediate attacks on occupied squares before pursuing a future line. In game 23 the new pawn on b5 attacked Bc4 while I concentrated on the c-file.
- After a candidate move, inspect immediate queen checks, including moves to empty squares. Game 22 missed Qh8 while guarding g7.
- A pawn can be the last blocker on an enemy queen/rook line. Practice 20's cxd4 exposed Qc7 to Qxc7.
- Trace the opponent's recapture after mine. A higher-valued queen guardian alone may lose material; a rook guardian can also fail when its capture destination is supported by the other enemy rook.
- A queen trade removes all of that queen's current guards. Game 24's b7 recapture chain lost its final queen defender after Qxe5/Nxe5.
- For a king recapture, inspect other enemy attacks on its destination. Vacating the checking piece's origin can open its supporting line.
- Before a forced king response, consider which rook or bishop defender will depart or be captured. A legal first escape can still allow the next mate, as in game 19.
- Keep a quiet candidate tied to the current board and calculate the first forcing replies before distant plans. This method is a choice, not an inference cap; excessive speculative calculation remains unresolved.
- Before a material exchange in an ending, inspect the opponent's next pawn advance and promotion distance. Rxf6/gxf6 in game 24 was followed by c6/c7/c8=Q despite the temporary pawn advantage.

The two recorded drills have stopped: practice 21 used seven own moves, with one disclosed extra checking recapture; practice 22 used six. Local guards and the c-pawn capture were exercised, but neither ending was completed. Return to fixed benchmarks 25–30 now; next full benchmark evaluation is 30 scored games. Bounded completion: 200 scored games regardless of achieved Elo. Current measurement after 24: 2W/2D/20L, provisional engine-relative Elo 1130 with 95% credible interval 780–1390. All twelve Black scores are losses. No sustained improvement or causal learning effect established.

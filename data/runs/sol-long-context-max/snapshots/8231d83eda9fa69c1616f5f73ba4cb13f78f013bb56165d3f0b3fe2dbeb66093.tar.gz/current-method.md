# Current method, after 30 scored benchmarks

Own reminders from this experiment; no external analysis or imported learning material.

- Use the actual referee board and reply. Keep a quiet decision to one conventional candidate and its immediate forcing replies before distant plans. Enforcement has been poor; this is a chosen method, not a token budget. Imagined positions are not tests or proofs.
- Locate my queen and both rooks before a forcing exchange or king response. A king escape can leave a major piece undefended or expose a piece behind the king. Game 26's Kc6 exposed Rc8; game 30's Rh7+ skewered Ke7/Rb7 despite the retained guard of the other rook.
- Inspect enemy checks to empty squares and the king's usable flights. Game 22's Bf8 and game 29's Ng1 filled an escape square; guarding one destination did not prevent the next check.
- Check current pawn attacks and immediate en-passant replies before a two-square push. Game 23's new b5 pawn attacked Bc4. Game 30's b7-b5 allowed a5xb6 en passant even though b5 had pawn defenders.
- A departing pawn, guardian or captured queen can open a line to a major piece. Game 25's dxe6 removed the d5 blocker between Rd8 and Qd3; game 24's queen trade removed the final b7 recapture.
- Use the cheapest usable defender and the opponent's next recapture. A queen or rook guardian can lose material to a cheaper third capture. For a king capture, include all other enemy attacks on the destination and any line uncovered when the checker leaves its origin.
- In an ending, inspect promotion distance before trading or activating the king. Game 24's c-pawn promoted after an exchange; game 30's en-passant reply created a defended sixth-rank passer and bound a rook.

Trial 22: two remembered skill-10 drills, at most six own moves each. White from game 29 ply 54: try h3 while leaving g1 empty. Black from game 30 ply 125: try Re8 with Ke7 as the rook's cheap defender. Observe actual replies, explicitly stop, and retain the unfinished drills; neither candidate is a known best move or proved repair. Return to fixed benchmarks 31–36; next full evaluation is 36 scored games.

Current measurement: 4W/2D/24L, provisional engine-relative Elo 1250 with 95% credible interval 1010–1460, twenty calibrated games and ten maximum-strength games excluded. Opponents: maximum 0W/0D/10L; skill 0 4W/1D/5L; 1800 setting 0W/1D/9L. White 3W/2D/10L, Black 1W/0D/14L. The block 25–30 scored 2W/0D/4L. The skill-0 wins relied heavily on opponent errors; sustained improvement or causal transfer remains unestablished. Bounded completion remains 200 scored games regardless of achieved Elo.

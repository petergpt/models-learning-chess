# Independent chess learning log

## Starting state

Read this experiment's AGENTS.md and GOAL.md. Referee status shows no started games and no Elo estimate. No outside chess material, other learner material, delegated advice, engine analysis, or move-selection code has been used. Actual token counters are unavailable; I will not invent usage numbers.

## Initial evaluation plan

Play the first six scored games as a paired-color baseline through the fixed rotation. Choose every move mentally. Use familiar development principles: contest the center, develop minor pieces, protect the king, and check the opponent's immediate checks, captures, and threats before committing a move. This is an initial approach, not evidence of improvement.

After this block, choose a focused learning trial from my own observed errors and return to benchmarks after a bounded study/practice period. Record observations after each game. The first transfer evaluation will be at 12 scored games; revise that point explicitly if a concrete weakness calls for a different interval.

## Evidence to track

- Official provisional engine-relative Elo and its 95% credible interval; maximum-strength games are separate evidence because they have no calibrated anchor.
- W/D/L by opponent and color.
- My own unverified diagnoses of avoidable material losses, missed threats, king exposure, and conversion errors; distinguish these from the referee's established result.
- Whether errors recur in new positions. Replaying a remembered position or winning easier practice alone will not establish transfer.

## Games and trials

### Benchmark 1: White versus maximum strength, loss by resignation

Result: 0-1 after 46 plies. One rejected illegal submission, Qxf3 from d3 through my bishop on e3. The eventual queen loss after Qe4 Rxe4 is established by the accepted moves; my diagnosis is a basic failure to trace occupied lines, not subtle opening theory. I resigned with queen-for-rook material loss and an exposed king. Maximum-strength games do not supply a calibrated Elo anchor.

### Trial 1: Make board geometry concrete

The first game already supplies a clear target, so revise the original uninterrupted six-game baseline: undertake a short learning period now, then resume the fixed rotation. Next benchmark review remains at six scored games, with a transfer review at twelve.

Study my own two mistakes mentally. Before a queen/rook move or a planned recapture, explicitly trace every intervening square and examine opponent rooks, bishops, and knights attacking the destination. The e3 bishop blocks d3-f3. The e8 rook has a clear e-file to e4. A queen-exchange intention did not make the other capturing piece disappear.

Try one recorded practice drill from benchmark 1 before the queen loss, against skill 0, for at most eight of my moves. This is a remembered position, so success is only a local repair check. I will select a different queen square myself and attempt to keep both king and queen safe. End the drill explicitly if still active, then benchmark game 2. Observable transfer target: fewer illegal geometry attempts and no queen lost to an already visible slider in new benchmark positions. Keeping a longer checklist alone is not evidence of learning.

Practice 1 was stopped without moves: I selected ply 42, which was already after the queen loss. Practice 2 correctly started after ply 40 and was stopped after eight own moves. Qf5, Qg4, and fxg4 exchanged queens without the earlier rook-file error; no illegal submissions. This is local repair against skill 0, not measured improvement. Retain the line-tracing method for new games and test it in the next benchmarks.

### Benchmark 2: Black versus maximum strength, loss by resignation

Result: 0-1 from my perspective (official 1-0), after 79 plies, zero illegal submissions. I preserved the queen and exchanged it legally, but lost e5, b5, and c5 pawns. My unverified diagnosis: the e5 pawn lost its support after central exchanges while the e7 bishop blocked the rook; subsequent knight retreats abandoned pawn defenses. I defended an ending with equal rook/bishop material and three fewer pawns, then resigned with connected white passed pawns advancing. This is one game without the targeted queen blunder, not sustained transfer.

### Trial 2: Track what a move stops defending

Before benchmark 3, briefly reconstruct the e5 pawn loss in my own memory: a pawn recapture on e5 did not leave the recapturing pawn defended, because the rook's e-file was blocked and the f6 knight did not attack e5. Study this geometry mentally; no external source or automated analysis. Extend the destination scan by naming the most vulnerable pawn or piece left behind by the moving defender. Keep the method compact instead of adding speculative calculation branches. Test over benchmark games 3–6, then assess at six scored games. Observable target: avoid losing an otherwise uncontested central pawn to a one-move capture, and avoid repeating the direct queen-to-slider error. No practice win or checklist growth is counted as improvement.

### Benchmark 3: White versus skill 0, draw by repetition

Official result 1/2-1/2 after 61 plies, zero illegal submissions. I lost a bishop after Bh6, Kf8, f4, Bxh6: the f4 pawn interrupted my queen's intended recapture diagonal. The same class of blocker mistake recurred despite trial 1. Later kingside pawn pushes abandoned support and lost two more pawns. I obtained the available repetition while materially worse; the draw is established, but it is not evidence of sound play or successful learning. My own unverified positive observation is an active central knight; no engine evaluation supports an advantage claim.

### Trial 3: Preserve a planned recapture across the next move

The new-position error falsifies the broad claim that the remembered drill solved my line-visibility weakness. Revise the method now, before game 4. Distinguish a line that is open now from one that remains open after the candidate move. Mentally verify the opponent's capture and my recapture on the board after my intended move, especially when I move a pawn onto a queen/bishop diagonal.

Use one short practice from game 3 after ply 24 (before f4), maximum four own moves, skill 0. This is another remembered repair, not transfer evidence. First choose a move that resolves or preserves the h6/g7 bishop contact. Then resume benchmarks; next overall review remains at six scored games. Observable target for the next three benchmarks: no unrecapturable bishop exposure caused by my own intervening pawn move. The recorded skill-0 draw does not establish the trial worked.

Practice 3 stopped after four own moves: Bxg7+ Kxg7, Rae1, Nf3, e5. I resolved the bishop contact first and retained equal piece material with a usable e-file. No illegal submissions. This is a remembered position and a short local check only. Decision: keep the revised after-move recapture scan for benchmark 4 and avoid creating contact between pieces unless I can still recapture after my next move.

Official status after three benchmarks: maximum strength 0W/0D/2L; skill 0 0W/1D/0L; 1800 setting not yet played. Provisional Elo 1400, 95% credible interval 330–2500, based on one calibrated game; two maximum-strength games excluded from the estimator. This uncertainty is conditional on nominal anchors and is not a human rating.

### Benchmark 4: Black versus skill 0, loss by resignation

Official 1-0 after 113 plies, zero illegal submissions. Bishop contact and queen recaptures were handled legally, and I gained a pawn after a central exchange. I then missed d5+ forking king e6 and rook c6, losing the rook. An advanced a-pawn eventually promoted, but a sequence of rook checks led to the loss of my remaining rook and promoted queen. I captured one opposing rook in that sequence, then overlooked the other rook's capture of the queen on a1. I resigned with only king and five pawns against rook, knight, and three pawns. Conversion and multi-threat tracking failed; no claim of improvement from the earlier pawn gain.

### Trial 4: Pawn checks and the piece left behind after a forcing reply

New target: recognize a pawn advance that checks my king and attacks another piece, and track both enemy rooks during forced sequences. Reconstruct game 4's fork mentally: white d4-d5 attacks e6 and c6; after a required king move the rook remains attacked. The later king capture on b4 also vacated the a-file, allowing the remaining white rook to capture my queen on a1. An attractive recapture did not resolve every threat.

Use a short remembered-position drill from game 4 after ply 79, at most four own moves, skill 0. Select my own repair that prevents the pawn fork rather than responding after it. Return immediately to the fixed benchmark rotation for games 5 and 6, then review the whole first pair-color cycle. Track checking pawn forks and undefended queens in those new positions. Local repair is not sufficient evidence, given recurrence in the first four games.

Clarification to practice 3: its final position was after e5 dxe5, awaiting my next recapture; piece material was equal, but the drill did not establish a completed central-pawn conversion. The referee note's phrase 'kept material even' was too broad for that final pawn position.

Official status after four benchmarks: 0W/1D/3L, Elo 950 with 95% interval 20–1670 from two calibrated games; maximum strength remains 0W/0D/2L and skill 0 is 0W/1D/1L. No improvement established.

Practice 4 was accidentally started with default white color from my intended Black position. The opponent played Kd6 before any learner move. I stopped it truthfully and restarted as Black; my own preselected repair is Kd5, chosen before this opponent move. This exposure is recorded as an opponent-practice move, not engine analysis or a suggested learner move.

Practice 5 stopped after four own moves: Kd5, Rec8, c3, Rxc3. The original checking pawn fork was prevented, with zero illegal submissions. The opponent's actual final reply was Ne3+, so the position awaits a check response; the rook on c3 still has the c8 rook behind it. My first log entry incorrectly anticipated bxc3 before inspecting the returned board, and was corrected immediately. I did not complete or score the drill. This only verifies the remembered pawn-fork repair locally. Decision: apply a specific opponent-pawn-check scan and keep both opposing rooks in view during forcing play in new benchmarks 5 and 6. No automated analysis, external study, or delegated advice used.

### Benchmark 5: White versus the 1800 setting, loss by resignation

Official 0-1 after 76 plies, zero illegal submissions. Equal material and legal queen/bishop recaptures survived the early middlegame. A rook became restricted on a4; I sacrificed a pawn to free it, recovered an a-pawn with Bxa5, then lost the d-pawn. The final Rc5 was an outright rook loss to b6xc5. I overlooked that pawn's immediate diagonal capture while considering a plan against the e5 pawn. I resigned a rook and pawn down, with rook/bishop against two rooks/knight. The king activation did not establish an advantage; the apparently useful plan ended in a basic destination-square failure. This entry's initially anticipated ply count was corrected to the referee's actual 76; unverified move numbers were removed.

### Trial 5: Shorten speculative branches and verify the actual destination

The first five games show that lengthy unverified calculation has not prevented simple one-move losses. Before benchmark 6, revisit the last board mentally and name the actual black pawn captures: b6-a5/c5, c7-b6/d6, e5-d4/f4, f4-e3/g3, g7-f6/h6, h7-g6. In particular, c5 was attacked by b6 regardless of the king's protection of e5 or the knight's retreat. These are my own mechanical board observations, not an engine evaluation.

For benchmark 6, try a compact rule: after selecting a candidate, check the exact destination against every enemy pawn and knight before exploring longer continuations. Keep the full current board in view and do not substitute an imagined later board. This is a revised approach to test, not proof of learning. No additional practice for this trial; use the next fixed Black/1800 game as a new-position test, then the six-game review. Main target: no major piece placed directly onto an existing pawn capture square. Rook mobility and pawn forks remain unresolved.

### Benchmark 6: Black versus the 1800 setting, loss by checkmate

Official 1-0 after 65 plies, one illegal submission. Verified the finish from my own PGN: 31.Qxh7+ Kf8 32.f4 Bxf4 33.Qh8#. The rejected f7-f5 push earlier was blocked by my own knight on f6. Material survived longer and the central exchanges temporarily gave me an extra pawn, but I did not convert it. On the final move the e5 bishop had been blocking the white e1 rook's control of e7. Moving it to f4 removed the king's escape square after Qh8+. My diagnosis is unverified analysis of an established checkmate, not an engine evaluation.

### Six-game checkpoint

Six scored benchmarks completed, none unfinished: overall 0W/1D/5L. Maximum strength 0W/0D/2L; skill 0 0W/1D/1L; 1800 setting 0W/0D/2L. White games 0W/1D/2L; Black games 0W/0D/3L.

Official provisional engine-relative Elo: 840, 95% credible interval -80 to 1460, based on four calibrated games. The maximum-strength losses are excluded from the estimator. The estimate is conditional on nominal engine anchors and the rating model, not a human rating. Earlier estimates fell from 1400 after one calibrated draw to 950 after two calibrated games, 880 after three, and 840 after four. These tiny samples and very broad intervals do not establish a learning trend; results provide no evidence of improvement.

Methods tried: line tracing, remembered recapture repairs, defender tracking, a remembered pawn-fork repair, a shorter destination scan, and conservative development with central pawn play. Three completed short repair drills (practices 2, 3, 5) avoided the originally targeted error in remembered positions but were explicitly stopped and not scored. Practices 1 and 4 were stopped after setup mistakes and preserved. New games still produced blocked recaptures, a pawn fork, a rook lost to an existing pawn attack, and a mating net after a line was opened. Checklists and long speculative calculation have not transferred reliably.

### Trial 6: Verify the opponent's immediate checks on the resulting board

Next evaluation point: twelve scored benchmarks, with brief self-review after each intervening game and a method change sooner if the same error recurs. First undertake a short opponent-practice drill from game 6 after ply 63, explicit Black color, skill 3, at most four own moves. This is remembered, not new transfer evidence. My own candidate is Ke7, chosen mentally to avoid the immediate Qh8 mating net; it may concede the trapped bishop to fxe5, so this trial is about surviving a forcing attack, not preserving all material or finding a best move.

Then return to the fixed rotation. Before submitting a non-forcing move near an exposed king, reconstruct the resulting board and check the opponent's available immediate checks, including newly opened rook lines and controlled king destinations. The original destination check alone missed a move that was legal but removed the only escape square. Observable benchmark target: no repeated Qh8-style mate caused by uncovering a rook line, and fewer immediate major-piece losses. These targets are measured by accepted moves and outcomes, not by the length of my checklist.

Token accounting: an actual get_goal call after the six-game checkpoint reported 867114 cumulative tokens for the active goal. Its input/output accounting details are unavailable; this is the reported goal counter, not an invented thinking-token total or a fixed-budget claim. There is no token budget.

Practice 6 stopped after four own moves: Ke7, Kd7, Kc6, fxe5. Opponent replies were Bg6, Bf5+, fxe5, Kg1. The original immediate mating net was avoided, but my trapped dark-square bishop was lost for the f-pawn. Zero illegal submissions. This is a remembered local survival check at a material cost, not a completed game, a best-defense proof, or transfer evidence. Decision: retain attention to newly opened checking lines and to king escape squares; return now to benchmarks 7–12 in the fixed rotation.

### Benchmark 7: White versus maximum strength, loss by resignation

Official 0-1 after 68 plies, zero illegal submissions; verified against my own PGN. I tried 1.d4 and developed normally, but 11.d5 Bxc3 12.bxc3 Bxd5 lost the central pawn after a defender was removed. The subsequent queen exchange preserved piece material. Later 19.Re2 Ndxe3 20.fxe3 Rfd8 21.Rec2 Nxe3 shows the key defender error: moving the e2 rook abandoned the new e3 pawn. Rook/knight exchanges led to a rook ending two pawns down; 33.Ke2 Rxd2+ 34.Kxd2 Rxa2+ left one rook each and three fewer pawns. I chose resignation on my own unverified assessment of that ending against maximum strength. I did not prove the final position lost.

No direct rook-to-pawn-square loss or repeated Qh8 mate occurred in this game, but pawn safety and coordination failed, and the scored result was still a loss. Long speculative branches continued and did not provide reliable board awareness. This one game does not establish transfer of trial 6.

Seven scored benchmarks completed: 0W/1D/6L. Maximum strength now 0W/0D/3L. Skill 0 remains 0W/1D/1L; 1800 setting remains 0W/0D/2L. Official Elo stays 840 with 95% interval -80 to 1460 from four calibrated games; three maximum-strength losses excluded. No improvement established.

### Trial 7: Exact current-board geometry before longer plans

Revise the method before benchmark 8. The observations that matter are an existing attack on the destination, an occupied intervening square, and a pawn left without a usable defender after my move. Speculative later boards repeatedly displaced these facts. For the final submission check, inspect the current board and the candidate's immediate resulting board before following any longer plan. This is a choice of calculation approach, not a learning-token cap.

Undertake two new hand-constructed opponent-practice drills, skill 0, explicit White color, at most four own moves each. Their FENs and purposes are in workspace/trial-7-drills.md. These are constructed variations of motifs from my failures; they are not independently validated tactical tests or evidence of stronger play. The material is deliberately simple and any easier practice success is excluded from Elo and transfer claims.

Then resume benchmark 8 (Black versus maximum strength) and continue to the next full checkpoint at twelve scored games. Observe direct major-piece losses to existing pawn attacks, blocked recapture attempts, and pawns lost immediately after their rook defender moves. If these recur, revise again; no checklist length is counted as improvement.

Practice 7 (constructed drill A) stopped after Re4, Rb4, Rxb5, Kf2; opponent replies Kg7, Kf6, Kg6, Kh7. The rook was preserved and the pawn captured, with zero illegal submissions. The opponent never advanced the pawn, so updating attack squares after an advance was not tested. This very simple rook-versus-pawn exercise meets only the local static-geometry criterion, not a strength or transfer claim.

Practice 8 (constructed drill B) stopped after cxd3, Bd2, Qxd3, Kf2; opponent replies Kh8, cxd3, Kg8, Kh8. I did not attempt the initially blocked queen capture. After the bishop left e3 and the opponent actually recaptured on d3, f3-e3-d3 became a clear queen path and Qxd3 was accepted. Zero illegal submissions. This mirrors an earlier motif in a new construction with deliberately easy material; it establishes only the local path check. No practice win or measured improvement claimed.

Decision after these drills: retain the exact current-board check and resume fixed benchmark 8. Do not assume the opponent's expected recapture occurred before reading the referee's actual reply. Full review remains at twelve scored benchmarks.

### Benchmark 8: Black versus maximum strength, loss by checkmate

Official 1-0 after 57 plies, zero illegal submissions. Tried a Caro-Kann structure from my own prior knowledge, without external study. Maintained equal material through development and the exchanges on e7 and f5. Queen retreats under c-file rook pressure consumed several moves. Verified the finish from my own PGN: 25.Rc7 Rec8 26.Qh7+ Kf8 27.Rxd7 Rxc1+ 28.Kh2 Nxd7 29.Qxf7#. My contemplated queen-for-two-rooks sequence occurred, but the material gain was irrelevant because I missed the immediate queen capture with check on f7, supported by the g5 knight. I spent excessive reasoning on Qh8 and hypothetical escape squares while failing to examine this other checking capture. No engine analysis used.

Eight scored benchmarks: 0W/1D/7L. Maximum strength 0W/0D/4L, skill 0 0W/1D/1L, 1800 setting 0W/0D/2L. Official Elo remains 840, 95% credible interval -80 to 1460, four calibrated games and four excluded maximum-strength games. No improvement established.

### Trial 8: Checking captures before material combinations

For benchmarks 9–12, explicitly include enemy queen captures with check when checking an exposed king. In game 8 I focused on the familiar Qh8 motif and missed Qxf7. A proposed material combination is not acceptable until I check immediate mate threats on its final board. Keep the current-board path and pawn/knight destination checks, but do not mistake a long imagined variation for verification. No new practice before game 9; return to the fixed rotation, with the full review still at twelve scored games.

### Benchmark 9: White versus skill 0, win by checkmate

Official 1-0 after 73 plies, zero illegal submissions. The first benchmark win. Normal e4/d4 development led to Nd5 and Nxf6+; Black chose Qxf6 despite my g5 bishop's usable recapture, and Bxf6 won the queen. Later Qxd2 and Qxe2 captured additional unsupported minor pieces, and hxg4 removed the last bishop. I preserved the major material advantage, used a supported knight fork to trade for a rook, and finished with 37.Qxb7#, supported by the e7 rook after the queen vacated c7. The conversion was slow and my reasoning still spent too much effort on hypothetical king paths. I did not suffer an immediate material loss or mating attack, but the opponent's large errors supplied this win. One skill-0 win cannot establish improved strength or a causal effect of the latest trial.

Nine scored benchmarks: 1W/1D/7L. Maximum strength 0W/0D/4L; skill 0 1W/1D/1L; 1800 setting 0W/0D/2L. Official provisional engine-relative Elo is 1230 with 95% credible interval 700–1660, five calibrated games and four maximum-strength games excluded. The increase from 840 follows this single new win; it is not a demonstrated learning trend. Continue benchmarks 10–12 before the full checkpoint.

### Benchmark 10: Black versus skill 0, loss by resignation

Official 1-0 after 87 plies, one illegal submission. An early center with ...e5/...d5 and ...Bd6 failed: 7.cxd5 Nb4 8.dxe5 forked my f6 knight and d6 bishop. Knight exchanges and exd6 left me a bishop down. Later 39...Ne5 40.Ne4+ combined a newly opened g-file rook check with an attack on my queen on d6. My ...Qg6 block offered a queen-for-rook exchange; the opponent instead played Bxe5, leaving me down a bishop and knight. I then illegally attempted Qg6-e6, overlooking that the queen was shielding my g8 king from the g2 rook. The correction was ...Kh7. The finish before resignation was ...Qf5 Rg7+ Kh8 Rg5+, with my queen on f5 attacked and my king in a discovered bishop check. I conceded on my own assessment of the large material deficit and continuing attack, without proving the final position lost. The queen had not yet been captured. All records retained.

Ten scored benchmarks: 1W/1D/8L. Maximum strength 0W/0D/4L, skill 0 1W/1D/2L, 1800 setting 0W/0D/2L. Official Elo 1140, 95% credible interval 620–1530, six calibrated games and four excluded maximum-strength games. The win in game 9 has not been followed by reliable transfer; pawn forks, discovered checks, and pins still caused errors despite prolonged calculation.

### Trial 9: Respond to threats against two pieces before attacking

Short remembered opponent-practice repair from game 10 after ply 13, explicit Black, skill 0, at most four own moves. My preselected candidate is ...e4 instead of ...Nb4, seeking a threat against the f3 knight before dxe5 can fork two pieces. This is my own unverified candidate, not a known best move or a proved repair. Observe actual replies and material, then stop the drill and return to benchmarks 11–12. In those benchmarks check opponent pawn captures for attacks on two pieces and identify which piece is currently blocking an enemy rook's line to my king. Full review remains at twelve scored games.

Practice 9 stopped after four own moves: e4, Nxe4, bxc6, f5. Opponent replies Nxe4, dxc6, Be2, Qc4+. Piece material is equal and Black is a pawn down, so the original bishop-losing pawn fork did not recur in these actual replies. However, the final f7-f5 push vacated the c4-d5-e6-f7-g8 queen-check line, and the session stopped under check. Eight plies, zero illegal submissions, explicitly unfinished. This is a partial remembered repair, not a completed defense, a best-move proof, or benchmark transfer. Decision: continue with benchmarks 11–12 and retain the resulting-board check for opened king lines as well as two-piece pawn threats.

### Benchmark 11: White versus the 1800 setting, loss by resignation

Official 0-1 after 122 plies, zero illegal submissions. Verified the key moves from my own PGN. Normal development, queen exchange, and supported central knight exchanges preserved equal material into a two-rook/two-bishop ending. Rook pressure chased my bishop and 24.Bc7 Rxb2 lost a pawn. After rook and light-square bishop exchanges, 34.Bxa3 Bg5+ 35.Ke2 Bxc1 36.Bxc1 cost the exchange: I took an apparently free pawn without seeing the immediate bishop check skewering my king and rook. Material safety until that point did not prevent this forcing tactical loss.

I continued the rook-versus-bishop ending rather than conceding immediately, recovered several pawns, tried an a-file blockade and supported bishop/pawn positions, and used my king to capture the remaining a-pawn. None of those attempts scored a draw or win. The final position after 61...e5 had bishop and two pawns against rook and two pawns; my king was on b6, bishop h4, and pawns c3/g3, versus king d5, rook d2, and pawns c4/e5. The e5 pawn blocked the f6-e5-d4-c3 defensive bishop route, and the black king denied c5/c6. I resigned on my own unverified assessment. I did not prove a forced win, a failed fortress, or a best defense.

Very prolonged mental variations repeatedly substituted imagined later boards for the current position and sometimes used inconsistent piece locations or move timing. They were not tests or proofs. No search code, engine analysis, delegated advice, or external lookups used. This game supplied further evidence that more hypothetical calculation alone has not solved immediate checking threats or defender tracking.

Eleven scored benchmarks: 1W/1D/9L. Maximum strength 0W/0D/4L; skill 0 1W/1D/2L; 1800 setting 0W/0D/3L. White 1W/1D/4L; Black 0W/0D/5L. Official Elo 1120, 95% credible interval 600–1500, seven calibrated games and four excluded maximum-strength games. No reliable improvement demonstrated.

### Trial 10: Calculate the first forcing reply before planning an ending

For benchmark 12, choose a candidate from the actual board, examine the opponent's immediate checks and captures on the resulting board, and verify the next recapture or king response with occupied squares retained. Do not extend quiet hypothetical branches through many future boards. This is a self-chosen calculation method, not a token budget or an inference-cap claim. Longer calculation remains available for actual forcing sequences. The observed targets are avoiding a checking fork/skewer of king and major piece, preserving usable defenders, and zero illegal submissions. Complete benchmark 12, then the planned full checkpoint and a short remembered skewer repair trial. My own unverified repair candidate for game 11 after ply 66 is Ke2 before Bxa3, to move off the g5-f4-e3-d2-c1 skewer line; it still requires checking the actual reply.

### Benchmark 12: Black versus the 1800 setting, loss by checkmate

Official 1-0 after 27 plies, zero illegal submissions. Verified my own PGN. White left the d2 knight without recapturing, so I temporarily gained a knight as well as pawns. Later 10...Nxf2 11.Qxf2 returned the knight for a pawn; I had considered a king recapture and overlooked the queen's actual horizontal recapture from b2. By move 13 I was three pawns ahead with equal piece material, but still uncastled. The finish was 13.Bd5 Bc5 14.Qxf7#. I treated ...Bc5 as a tempo against the f2 queen while missing that the queen could capture f7 with mate, supported by the d5 bishop. My e8 king's geometric contact with f7 was not a usable recapture because that bishop controlled f7. I failed the immediate-check target again. Long hypothetical branches also continued despite trial 10's intended method change. Material gain did not establish stronger play or transfer.

### Twelve-game checkpoint

Twelve scored benchmarks, all retained and none unfinished: overall 1W/1D/10L. Maximum strength 0W/0D/4L, skill 0 1W/1D/2L, 1800 setting 0W/0D/4L. White 1W/1D/4L; Black 0W/0D/6L. Fixed rotation unchanged.

Official provisional engine-relative Elo: 1110, 95% credible interval 590–1470, from eight calibrated games. Four maximum-strength games excluded. This is conditional on nominal engine anchors and estimator assumptions, not a human rating. The first six-game cycle was 0W/1D/5L and the second was 1W/0D/5L. Maximum-strength and 1800 results stayed at zero score in both cycles. Skill-0 score changed from one draw/one loss to one win/one loss, based on only two games per cycle. The rise from the six-game estimate of 840 is driven by a single new skill-0 win, with broadly overlapping uncertainty intervals. No reliable improvement or causal learning effect established.

Observed local repairs: remembered ray/recapture, pawn-fork, and king-escape drills sometimes avoided the originally targeted error, but remained explicitly stopped and unscored. The two constructed geometry drills were deliberately easy and tested only narrow static criteria. Practice 9 avoided the remembered bishop-losing pawn fork but stopped after a new queen check. None of these practices supplied evidence of benchmark transfer. New measured games repeated missed checking captures, pawn forks, loss of usable defenders, an illegal move exposing the king, and a king/rook skewer. Illegal submissions were two in games 1–6 and one in games 7–12; three in total. That small count change is not a strength claim.

Methods tried include normal development, queen simplification, different center structures, line tracing, defender tracking, destination pawn/knight scans, immediate-check scans, and opponent practice from my own remembered failures. Game 9 converted major opponent errors into a first win. Game 11 kept equal material through early exchanges and gave experience in a rook-versus-bishop ending, but the decisive skewer was missed and no drawing defense was proved. Sustained speculative calculation has remained a weakness rather than evidence of improvement.

Token accounting: get_goal at this checkpoint reported 5391394 cumulative tokensUsed for the active goal and 37207 timeUsedSeconds. The counter's input/output accounting details are unavailable. Record only this observed cumulative counter, not a thinking-token total, per-move allocation, or fixed-budget comparison. No token budget exists.

### Trial 11: Usable king defenders and king/major-piece alignment

Before benchmark 13, undertake two short remembered opponent-practice trials, skill 3, explicit colors, at most four own moves each. Practice from game 11 after ply 66 as White: own preselected Ke2 moves off the bishop skewer line before the pawn capture; observe actual attacks on the rook and king. Practice from game 12 after ply 25 as Black: own preselected Qe7 defends f7 with the queen and vacates d8; observe the actual queen-check replies. These are unverified repair candidates, not supplied moves, best-move claims, or independent transfer tests.

Then resume the fixed rotation for benchmarks 13–18, with the next full checkpoint at eighteen scored games. Before treating a king as a defender, verify that its proposed recapture lands on a square not controlled by another enemy piece. Check alignment of king and major pieces behind it before capturing an apparently free pawn. Prioritize the actual opponent's first checks and captures over hypothetical quiet continuations. Success remains a trial target until new benchmark behavior and scores support it; neither a completed checklist nor a longer analysis is counted as improvement.

Practice 10 stopped after Ke2, Ra1, Bxe5, Bd4; opponent replies Bg5, Rd8, Re8, Be7. The original ...Bg5 was no longer a check, permitting the rook retreat. The rook was preserved, piece material stayed equal, and Bxe5 reduced White's pawn deficit to one. Eight plies, zero illegal submissions, explicitly unfinished. This verifies only the remembered local skewer avoidance in these actual replies; it does not prove a winning/drawing ending or transfer.

Practice 11 stopped after Qe7, g6, Nd8, Nxb7; opponent replies Be3, Ng5, Bxb7, Qf3. Qe7 prevented the recorded immediate mate in these replies, but Ng5 increased f7 pressure and I added the d8 knight defender. The b7 exchange kept piece material equal and Black retained three extra pawns. No checking f7 capture was actually played, so the planned queen recapture was not exercised. Eight plies, zero illegal submissions, explicitly unfinished. This is only a remembered local continuation, not a completed defense, a best-move proof, or transfer evidence.

Decision after the two drills: return to fixed benchmarks 13–18. The major unresolved target is recognizing all actual immediate checks and legally usable recaptures before pursuing material or a long plan. Keep the goal active until 200 scored games; twelve games and local repairs do not complete the bounded experiment.

### Benchmark 13: White versus maximum strength, loss by resignation

Official 0-1 after 54 plies, zero illegal submissions. Tried a quiet d4/Nf3/Bf4 setup and exchanged the light-square bishops. The central sequence 12.e4 dxe4 13.Nxe4 Nxe4 14.Qxe4 Nxd4 lost the d-pawn while uncovering Bb7's attack on my queen. I recognized that a simple cxd4 would leave the queen attacked and instead played Qe3. The actual continuation was 15.Qe3 Nxe2+ 16.Qxe2 Ba6 17.Qd2 Qxd2 18.Nxd2 Be2 19.Rfe1 Bxd1 20.Rxd1. I missed the intermediate ...Be2 attack on both rooks when anticipating a simpler queen exchange. This cost the exchange as well as the earlier pawn.

After ...Rd3 and ...Rad8, my d2 knight was pinned against the d1 rook. Kf1/Ke2 did not make Kxd3 legal: the second rook protected d3. I noticed that defect before submitting a king capture. The kingside pawn break g4 led to hxg4, hxg4, fxg4, fxg4, e4. I resigned with rook, knight and four pawns against two rooks and five pawns, on my own assessment of the deficit, pin and passed e-pawn. No forced loss or best defense was proved. Lengthy hypothetical branches again included mistaken geometry and failed to predict the actual intermediate move.

Thirteen scored benchmarks: 1W/1D/11L. Maximum strength 0W/0D/5L; skill 0 1W/1D/2L; 1800 setting 0W/0D/4L. Official Elo remains 1110, 95% credible interval 590–1470, eight calibrated games and five excluded maximum-strength games. No reliable improvement established.

### Trial 12: Simplify the center before exposing the queen to a bishop ray

Before benchmark 14, replay my own game 13 position after ply 22 as White against skill 5, at most four own moves. My preselected candidate is dxc5 rather than e4. The intended local test is whether an earlier central exchange permits ordinary development without the observed queen-ray tactic and two-rook bishop fork. This is my own unverified candidate in a remembered position, not a best-move claim. Check the actual recapture before choosing each continuation. Observe material and major-piece safety, then explicitly stop the drill and return to benchmarks 14–18. The full checkpoint remains eighteen scored games. Local success alone will not establish transfer or rating improvement.

Practice 12 stopped after dxc5, Nb3, Nbd4, Nxc6; opponent replies Qxc5, Qe7, h6, Bxc6. Eight plies, zero illegal submissions, explicitly unfinished. Both sides retained queen, two rooks, one bishop, one knight and seven pawns. The actual replies avoided the previously observed queen-ray loss and rook fork, but did not repeat either tactic as a test. This is a remembered local continuation at an easier setting, not an opening proof or benchmark transfer. Decision: retain attention to the rays opened by central exchanges and intermediate attacks after an expected recapture; resume fixed benchmark 14 and evaluate again at eighteen scored games.

### Benchmark 14: Black versus maximum strength, loss by resignation

Official 1-0 after 49 plies, zero illegal submissions; verified my own PGN. Tried an e6/d5 center and castled on move 8. Central knight exchanges kept material equal through 13...dxe4; ...f5 defended e4 and White's Nd6 was exchanged for the e7 bishop. White's exd6 created a protected passed pawn. My queen/rook blockade and knight retreats were met by b5, Qa4, c5 and cxb6. The finish was 21...Qc8 22.cxb6 axb6 23.Bxb6 Qa8 24.Qxa5 Rxd6 25.Qxa8.

Two distinct defender errors: I treated Qa8's contact with a5 as sufficient without accounting for Bb6's recapture after a queen exchange, so White won the knight on a5. Then Rxd6 removed the d8 rook that had been defending my a8 queen along the eighth rank. My f8 rook could not replace that defender because my own e8 bishop blocked its path. The queen was captured outright. I resigned with two rooks, one bishop and five pawns against queen, two rooks, two bishops and five pawns; my own assessment, not a forced-loss proof. Prolonged hypothetical analysis again failed at the actual cheap recapture and defender departure.

Fourteen scored benchmarks: 1W/1D/12L. Maximum strength 0W/0D/6L; skill 0 1W/1D/2L; 1800 setting 0W/0D/4L. Official Elo remains 1110, 95% credible interval 590–1470, eight calibrated games and six excluded maximum-strength games. Trial 12's local central simplification did not establish transfer, and the new game again lost major material through defender tracking.

### Trial 13: Retain the actual defender while answering a double attack

Short remembered practice from game 14 after ply 45, explicit Black against skill 3, at most four own moves. My preselected candidate is ...Nb7 instead of ...Qa8. It moves the attacked knight while retaining Qc8's defense of Rd8; it may still concede an exchange to Bxd8/Qxd8. The local objective is to preserve the queen and verify each actual recapture, not to repair all earlier pawn or piece disadvantages or find a best defense. In subsequent benchmarks, focus on what the chosen moving piece currently defends and whether an apparent rook path contains an occupied square. A saved queen in this remembered drill alone would not count as improvement. Stop the drill, return to fixed benchmark 15, and keep the full evaluation at eighteen scored games.

Practice 13 stopped after Nb7, Qxd8, Qxd7, Nd6; opponent replies Bxd8, d7, Qb4, a4. Eight plies, zero illegal submissions, explicitly unfinished. The original knight/queen loss was avoided in these actual replies. Black retained queen, rook, bishop and knight against queen, two rooks and bishop; five pawns each, so the exchange deficit remained. Qxd7 captured the passed pawn after its actual advance. This is a remembered local repair at skill 3, not a completed defense, a best-move proof or transfer. Decision: return to fixed benchmark 15, retaining the defender-departure and occupied-path focus. Eighteen scored games remains the next full checkpoint.

### Benchmark 15: White versus skill 0, loss by resignation

Official 0-1 after 148 plies, zero illegal submissions; verified my own PGN. Normal e4/d4 development and early castling kept the major pieces safe through the opening. The sequence 12.Bf4 g5 13.h3 gxf4 14.hxg4 traded my bishop for the g4 knight; 15.Qxf4 recovered the advanced pawn and left me a pawn ahead. Nd6+/Bxd6/exd6 produced a passed d-pawn, and a queen exchange followed. Some actual defender checks worked locally: Rd2 defended c2, b3 blocked the bishop's a2 attack, and later Nc4 directly defended d6.

The decisive failure was 31.Re4 Nc3 32.Rf4 Ne2+ 33.Kh2 Nxf4. I retreated the rook to a square safe from the knight's current attack but missed its next checking fork of king g1 and rook f4. The forced king response left the rook lost outright. Trial 13 did not transfer to this different checking-fork situation. Very long speculative calculation again failed at an immediate forcing reply.

I continued the ending after the rook loss, using my king to capture pawns, exchanging the remaining knights, and trying protected d- and f-pawn advances. Several apparent king recaptures were unusable because the other rook or the opposing king defended the destination. I corrected mistaken assumptions about a rook's line when an intervening bishop or pawn occupied it. None of the imagined later branches was independently verified or proved best. The d-pawn reached d7 with rook support; the f-pawn was lost to the two rooks. Repeated checks and rook retreats did not produce an actual claimed draw. The last sequence was 71.Rd5 Rg2+ 72.Kf7 Rf2+ 73.Kg7 Rg2+ 74.Kf7 Rxc2. The c2 capture broke the short checking cycle before threefold repetition.

Final position: White king f7, rook d5, pawns a2/c5/d7; Black king d8, rooks c6/c2, pawns a3/b4. I resigned on my own assessment of the extra rook, blocked passers and two attacks on c5. I did not prove a forced loss, a drawing defense or a best continuation. All results retained. Prolonged defense and zero illegal submissions do not count as improvement by themselves.

Fifteen scored benchmarks: 1W/1D/13L. Maximum strength 0W/0D/6L; skill 0 1W/1D/3L; 1800 setting 0W/0D/4L. White 1W/1D/6L; Black 0W/0D/7L. Official Elo is 1050, 95% credible interval 540–1400, nine calibrated games and six excluded maximum-strength games. The latest trial has not established reliable transfer or rating improvement.

### Trial 14: Identify the major piece attacked from a checking knight square

Before benchmark 16, undertake two short opponent-practice drills, at most four own moves each. Remembered repair: game 15 after ply 62, White against skill 3, my preselected Re3 instead of Rf4. Constructed variation: a hand-written FEN with White king h1 and rook e4, Black knight d3 and king a8, plus a White g2 pawn, against skill 0. My preselected Re3 changes the checking-fork target. Details are in workspace/trial-14-checking-forks.md. These are my own unverified candidates, not best-move or independent test claims.

Method revision for benchmarks 16–18: from the actual enemy knight square, inspect its immediate checking destinations and the major pieces attacked from each destination. Verify the king response and the next capture before extending quiet future plans. The targeted outcome is fewer checking forks that lose a major piece, with zero illegal submissions. A longer checklist, a remembered repair or a deliberately simple construction alone is not learning evidence. Explicitly stop both drills, return to the fixed rotation, and retain the eighteen-scored-game checkpoint.

Practice 14 stopped after Re3, fxg4, Ra1, Rae1; opponent replies hxg4, Nxa2, Nc3, Rxg4+. Eight plies, zero illegal submissions, explicitly unfinished. Both rooks were retained, but White lost the a-pawn and ended one pawn down under a rook check. The original ...Ne2+ was not played, so this did not directly test the checking-fork response or complete a defense.

Practice 15 stopped after Re3, Rf3, Kh2, Kg3; opponent replies Nb4, Nd5, Nc7, Kb7. Eight plies, zero illegal submissions, explicitly unfinished. The rook and g-pawn were preserved in the simple constructed position. No checking knight move occurred; the intended ...Nf2+ continuation was not exercised. This provides only narrow static-geometry practice, not strength or transfer evidence.

Small extension before benchmark 16: replay my own game 15 after ply 63 as Black against skill 3, at most two own moves. My selected attack is ...Ne2+, mentally checked as attacking Kg1 and Rf4 from e2, then observe the king response before choosing the capture. This repeats the opponent's recorded motif from the attacker side of my own failed position; it is a remembered attack, not a new solution or best-move claim. Stop explicitly, then return to benchmarks 16–18 with no change to the full checkpoint.

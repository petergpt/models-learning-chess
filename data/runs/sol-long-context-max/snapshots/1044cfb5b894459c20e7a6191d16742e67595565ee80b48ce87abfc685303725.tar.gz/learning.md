# Independent chess learning log

## Starting state

Read this experiment's AGENTS.md and GOAL.md. Referee status shows no started games and no Elo estimate. No outside chess material, other learner material, delegated advice, engine analysis, or move-selection code has been used. Actual token counters are unavailable; I will not invent usage numbers.

## Initial evaluation plan

Play the first six scored games as a paired-color baseline through the fixed rotation. Choose every move mentally. Use familiar development principles: contest the center, develop minor pieces, protect the king, and check the opponent's immediate checks, captures, and threats before committing a move. This is an initial approach, not evidence of improvement.

After this block, choose a focused learning trial from my own observed errors and return to benchmarks after a bounded study/practice period. Record observations after each game. The first transfer evaluation will be at 12 scored games; revise that point explicitly if a concrete weakness calls for a different interval.

## Evidence to track

- Official provisional engine-relative Elo and its 95% credible interval; maximum-strength games are separate evidence because they have no calibrated anchor.
- W/D/L by opponent and color.
- My own unverified diagnoses of avoidable material losses, missed threats, king exposure, and conversion errors; distinguish these from the referee's established result.
- Whether errors recur in new positions. Replaying a remembered position or winning easier practice alone will not establish transfer.

## Games and trials

Pending first benchmark.

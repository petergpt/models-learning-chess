# Independent chess learning log

## Starting state

Read this experiment's AGENTS.md and GOAL.md. Referee status shows no started games and no Elo estimate. No outside chess material, other learner material, delegated advice, engine analysis, or move-selection code has been used. Actual token counters are unavailable; I will not invent usage numbers.

## Initial evaluation plan

Play the first six scored games as a paired-color baseline through the fixed rotation. Choose every move mentally. Use familiar development principles: contest the center, develop minor pieces, protect the king, and check the opponent's immediate checks, captures, and threats before committing a move. This is an initial approach, not evidence of improvement.

After this block, choose a focused learning trial from my own observed errors and return to benchmarks after a bounded study/practice period. Record observations after each game. The first transfer evaluation will be at 12 scored games; revise that point explicitly if a concrete weakness calls for a different interval.

## Evidence to track

- Official provisional engine-relative Elo and its 95% credible interval; maximum-strength games are separate evidence because they have no calibrated anchor.
- W/D/L by opponent and color.
- My own unverified diagnoses of avoidable material losses, missed threats, king exposure, and conversion errors; distinguish these from the referee's established result.
- Whether errors recur in new positions. Replaying a remembered position or winning easier practice alone will not establish transfer.

## Games and trials

### Benchmark 1: White versus maximum strength, loss by resignation

Result: 0-1 after 46 plies. One rejected illegal submission, Qxf3 from d3 through my bishop on e3. The eventual queen loss after Qe4 Rxe4 is established by the accepted moves; my diagnosis is a basic failure to trace occupied lines, not subtle opening theory. I resigned with queen-for-rook material loss and an exposed king. Maximum-strength games do not supply a calibrated Elo anchor.

### Trial 1: Make board geometry concrete

The first game already supplies a clear target, so revise the original uninterrupted six-game baseline: undertake a short learning period now, then resume the fixed rotation. Next benchmark review remains at six scored games, with a transfer review at twelve.

Study my own two mistakes mentally. Before a queen/rook move or a planned recapture, explicitly trace every intervening square and examine opponent rooks, bishops, and knights attacking the destination. The e3 bishop blocks d3-f3. The e8 rook has a clear e-file to e4. A queen-exchange intention did not make the other capturing piece disappear.

Try one recorded practice drill from benchmark 1 before the queen loss, against skill 0, for at most eight of my moves. This is a remembered position, so success is only a local repair check. I will select a different queen square myself and attempt to keep both king and queen safe. End the drill explicitly if still active, then benchmark game 2. Observable transfer target: fewer illegal geometry attempts and no queen lost to an already visible slider in new benchmark positions. Keeping a longer checklist alone is not evidence of learning.

Practice 1 was stopped without moves: I selected ply 42, which was already after the queen loss. Practice 2 correctly started after ply 40 and was stopped after eight own moves. Qf5, Qg4, and fxg4 exchanged queens without the earlier rook-file error; no illegal submissions. This is local repair against skill 0, not measured improvement. Retain the line-tracing method for new games and test it in the next benchmarks.

### Benchmark 2: Black versus maximum strength, loss by resignation

Result: 0-1 from my perspective (official 1-0), after 79 plies, zero illegal submissions. I preserved the queen and exchanged it legally, but lost e5, b5, and c5 pawns. My unverified diagnosis: the e5 pawn lost its support after central exchanges while the e7 bishop blocked the rook; subsequent knight retreats abandoned pawn defenses. I defended an ending with equal rook/bishop material and three fewer pawns, then resigned with connected white passed pawns advancing. This is one game without the targeted queen blunder, not sustained transfer.

### Trial 2: Track what a move stops defending

Before benchmark 3, briefly reconstruct the e5 pawn loss in my own memory: a pawn recapture on e5 did not leave the recapturing pawn defended, because the rook's e-file was blocked and the f6 knight did not attack e5. Study this geometry mentally; no external source or automated analysis. Extend the destination scan by naming the most vulnerable pawn or piece left behind by the moving defender. Keep the method compact instead of adding speculative calculation branches. Test over benchmark games 3–6, then assess at six scored games. Observable target: avoid losing an otherwise uncontested central pawn to a one-move capture, and avoid repeating the direct queen-to-slider error. No practice win or checklist growth is counted as improvement.

### Benchmark 3: White versus skill 0, draw by repetition

Official result 1/2-1/2 after 61 plies, zero illegal submissions. I lost a bishop after Bh6, Kf8, f4, Bxh6: the f4 pawn interrupted my queen's intended recapture diagonal. The same class of blocker mistake recurred despite trial 1. Later kingside pawn pushes abandoned support and lost two more pawns. I obtained the available repetition while materially worse; the draw is established, but it is not evidence of sound play or successful learning. My own unverified positive observation is an active central knight; no engine evaluation supports an advantage claim.

### Trial 3: Preserve a planned recapture across the next move

The new-position error falsifies the broad claim that the remembered drill solved my line-visibility weakness. Revise the method now, before game 4. Distinguish a line that is open now from one that remains open after the candidate move. Mentally verify the opponent's capture and my recapture on the board after my intended move, especially when I move a pawn onto a queen/bishop diagonal.

Use one short practice from game 3 after ply 24 (before f4), maximum four own moves, skill 0. This is another remembered repair, not transfer evidence. First choose a move that resolves or preserves the h6/g7 bishop contact. Then resume benchmarks; next overall review remains at six scored games. Observable target for the next three benchmarks: no unrecapturable bishop exposure caused by my own intervening pawn move. The recorded skill-0 draw does not establish the trial worked.

Practice 3 stopped after four own moves: Bxg7+ Kxg7, Rae1, Nf3, e5. I resolved the bishop contact first and retained equal piece material with a usable e-file. No illegal submissions. This is a remembered position and a short local check only. Decision: keep the revised after-move recapture scan for benchmark 4 and avoid creating contact between pieces unless I can still recapture after my next move.

Official status after three benchmarks: maximum strength 0W/0D/2L; skill 0 0W/1D/0L; 1800 setting not yet played. Provisional Elo 1400, 95% credible interval 330–2500, based on one calibrated game; two maximum-strength games excluded from the estimator. This uncertainty is conditional on nominal anchors and is not a human rating.

### Benchmark 4: Black versus skill 0, loss by resignation

Official 1-0 after 113 plies, zero illegal submissions. Bishop contact and queen recaptures were handled legally, and I gained a pawn after a central exchange. I then missed d5+ forking king e6 and rook c6, losing the rook. An advanced a-pawn eventually promoted, but a sequence of rook checks led to the loss of my remaining rook and promoted queen. I captured one opposing rook in that sequence, then overlooked the other rook's capture of the queen on a1. I resigned with only king and five pawns against rook, knight, and three pawns. Conversion and multi-threat tracking failed; no claim of improvement from the earlier pawn gain.

### Trial 4: Pawn checks and the piece left behind after a forcing reply

New target: recognize a pawn advance that checks my king and attacks another piece, and track both enemy rooks during forced sequences. Reconstruct game 4's fork mentally: white d4-d5 attacks e6 and c6; after a required king move the rook remains attacked. The later king capture on b4 also vacated the a-file, allowing the remaining white rook to capture my queen on a1. An attractive recapture did not resolve every threat.

Use a short remembered-position drill from game 4 after ply 79, at most four own moves, skill 0. Select my own repair that prevents the pawn fork rather than responding after it. Return immediately to the fixed benchmark rotation for games 5 and 6, then review the whole first pair-color cycle. Track checking pawn forks and undefended queens in those new positions. Local repair is not sufficient evidence, given recurrence in the first four games.

Clarification to practice 3: its final position was after e5 dxe5, awaiting my next recapture; piece material was equal, but the drill did not establish a completed central-pawn conversion. The referee note's phrase 'kept material even' was too broad for that final pawn position.

Official status after four benchmarks: 0W/1D/3L, Elo 950 with 95% interval 20–1670 from two calibrated games; maximum strength remains 0W/0D/2L and skill 0 is 0W/1D/1L. No improvement established.

Practice 4 was accidentally started with default white color from my intended Black position. The opponent played Kd6 before any learner move. I stopped it truthfully and restarted as Black; my own preselected repair is Kd5, chosen before this opponent move. This exposure is recorded as an opponent-practice move, not engine analysis or a suggested learner move.

Practice 5 stopped after four own moves: Kd5, Rec8, c3, Rxc3. The original checking pawn fork was prevented, with zero illegal submissions. The opponent's actual final reply was Ne3+, so the position awaits a check response; the rook on c3 still has the c8 rook behind it. My first log entry incorrectly anticipated bxc3 before inspecting the returned board, and was corrected immediately. I did not complete or score the drill. This only verifies the remembered pawn-fork repair locally. Decision: apply a specific opponent-pawn-check scan and keep both opposing rooks in view during forcing play in new benchmarks 5 and 6. No automated analysis, external study, or delegated advice used.

### Benchmark 5: White versus the 1800 setting, loss by resignation

Official 0-1 after 76 plies, zero illegal submissions. Equal material and legal queen/bishop recaptures survived the early middlegame. A rook became restricted on a4; I sacrificed a pawn to free it, recovered an a-pawn with Bxa5, then lost the d-pawn. The final Rc5 was an outright rook loss to b6xc5. I overlooked that pawn's immediate diagonal capture while considering a plan against the e5 pawn. I resigned a rook and pawn down, with rook/bishop against two rooks/knight. The king activation did not establish an advantage; the apparently useful plan ended in a basic destination-square failure. This entry's initially anticipated ply count was corrected to the referee's actual 76; unverified move numbers were removed.

### Trial 5: Shorten speculative branches and verify the actual destination

The first five games show that lengthy unverified calculation has not prevented simple one-move losses. Before benchmark 6, revisit the last board mentally and name the actual black pawn captures: b6-a5/c5, c7-b6/d6, e5-d4/f4, f4-e3/g3, g7-f6/h6, h7-g6. In particular, c5 was attacked by b6 regardless of the king's protection of e5 or the knight's retreat. These are my own mechanical board observations, not an engine evaluation.

For benchmark 6, try a compact rule: after selecting a candidate, check the exact destination against every enemy pawn and knight before exploring longer continuations. Keep the full current board in view and do not substitute an imagined later board. This is a revised approach to test, not proof of learning. No additional practice for this trial; use the next fixed Black/1800 game as a new-position test, then the six-game review. Main target: no major piece placed directly onto an existing pawn capture square. Rook mobility and pawn forks remain unresolved.

### Benchmark 6: Black versus the 1800 setting, loss by checkmate

Official 1-0 after 65 plies, one illegal submission. Verified the finish from my own PGN: 31.Qxh7+ Kf8 32.f4 Bxf4 33.Qh8#. The rejected f7-f5 push earlier was blocked by my own knight on f6. Material survived longer and the central exchanges temporarily gave me an extra pawn, but I did not convert it. On the final move the e5 bishop had been blocking the white e1 rook's control of e7. Moving it to f4 removed the king's escape square after Qh8+. My diagnosis is unverified analysis of an established checkmate, not an engine evaluation.

### Six-game checkpoint

Six scored benchmarks completed, none unfinished: overall 0W/1D/5L. Maximum strength 0W/0D/2L; skill 0 0W/1D/1L; 1800 setting 0W/0D/2L. White games 0W/1D/2L; Black games 0W/0D/3L.

Official provisional engine-relative Elo: 840, 95% credible interval -80 to 1460, based on four calibrated games. The maximum-strength losses are excluded from the estimator. The estimate is conditional on nominal engine anchors and the rating model, not a human rating. Earlier estimates fell from 1400 after one calibrated draw to 950 after two calibrated games, 880 after three, and 840 after four. These tiny samples and very broad intervals do not establish a learning trend; results provide no evidence of improvement.

Methods tried: line tracing, remembered recapture repairs, defender tracking, a remembered pawn-fork repair, a shorter destination scan, and conservative development with central pawn play. Three completed short repair drills (practices 2, 3, 5) avoided the originally targeted error in remembered positions but were explicitly stopped and not scored. Practices 1 and 4 were stopped after setup mistakes and preserved. New games still produced blocked recaptures, a pawn fork, a rook lost to an existing pawn attack, and a mating net after a line was opened. Checklists and long speculative calculation have not transferred reliably.

### Trial 6: Verify the opponent's immediate checks on the resulting board

Next evaluation point: twelve scored benchmarks, with brief self-review after each intervening game and a method change sooner if the same error recurs. First undertake a short opponent-practice drill from game 6 after ply 63, explicit Black color, skill 3, at most four own moves. This is remembered, not new transfer evidence. My own candidate is Ke7, chosen mentally to avoid the immediate Qh8 mating net; it may concede the trapped bishop to fxe5, so this trial is about surviving a forcing attack, not preserving all material or finding a best move.

Then return to the fixed rotation. Before submitting a non-forcing move near an exposed king, reconstruct the resulting board and check the opponent's available immediate checks, including newly opened rook lines and controlled king destinations. The original destination check alone missed a move that was legal but removed the only escape square. Observable benchmark target: no repeated Qh8-style mate caused by uncovering a rook line, and fewer immediate major-piece losses. These targets are measured by accepted moves and outcomes, not by the length of my checklist.

Token accounting: an actual get_goal call after the six-game checkpoint reported 867114 cumulative tokens for the active goal. Its input/output accounting details are unavailable; this is the reported goal counter, not an invented thinking-token total or a fixed-budget claim. There is no token budget.

# Continuation checkpoint

Same independent authorized objective: exactly 200 scored benchmarks, no token budget. Follow own AGENTS.md/GOAL.md. Every move own reasoning; no external evaluations, automated chess analysis or other learner material. All records retained.

48 scored benchmarks, 7W/4D/37L, nine points, no unfinished. Maximum 0/0/16, skill 0 6/3/7, 1800 1/1/14. White 6/3/15, Black 1/1/22. Official provisional engine-relative Elo 1290 [1110–1450], 95% Bayesian equal-tail credible interval, 32 calibrated games in 50-game window, 16 excluded maximum games. Conditional nominal anchors/model; not human Elo and excludes systematic calibration error. Blocks 37–42 and 43–48 each one point; estimates at 36/42/48 all 1290. No sustained improvement established.

Game 47 lost by practical resignation after 55.Ra7 Rxa7: opposing Kb8 prohibited Kb6xa7, then both advanced passers were captured. 118 plies, zero illegal. Old missing process 39341 was followed by ./play board verifying pre-49 durable state before a fresh accepted Kc6. Shared admission now succeeds, no reset/duplicate accepted move.

Game 48 lost to actual 34.Nh4#, 67 plies, zero illegal. Verified own full PGN/status. Ending: Ng2/Nf8/Rxe7+/Kh6/Qd2/g5/hxg5+/Kg6/Be4+/Qf5/Nh4#. The queen was not captured. Rook, pawns, bishop and own h5 pawn denied the king flights; a knight check cannot be interposed against. Four cumulative benchmark illegal submissions; none in 37–48.

Trial 44 and practice 31 finished. Skill 10 Black, own game 48 after ply 57, six own moves: Kf6/Ne1, Kf7/Nf3, Bf6/Ng5+, Bxg5/hxg5, Ke8/Ra7, Nd4/Ra8. Explicit stopped *, twelve plies, zero illegal, no actual mate/major loss. Final Ra8 attacks Qc8. Different replies and local survival are not a full repair or transfer. No extra repetition. learning.md/current-method.md contain review and trial.

No active benchmark or practice. Start fixed benchmark 49 next, White maximum, then fixed rotation through 54 scored and full review at 54. Transfer targets: recheck a bishop-to-king line when its blocker departs; check immediate knight checks and usable king recaptures. Keep every loss and compare actual results. Objective unfinished at 48/200; never mark complete until verified 200 scored or start another benchmark beyond that endpoint.

Actual get_goal at 48: active, tokensUsed 25,557,813, timeUsedSeconds 273,992, remainingTokens null. Recorded through ./play usage with scope: controller tally only; blocked intervals froze accounting, so not all historical activity. No invented move/input/output counters or fixed inference-budget claim.

# Current method, after 22 scored benchmarks

Own reminders from this experiment; no external analysis or imported learning material.

- Use the actual referee board and actual opponent reply. Imagined later positions are not tests or proofs.
- After a candidate move, inspect immediate queen checks, including moves to empty squares. Game 22 missed Qh8 while guarding g7.
- A pawn can be the last blocker on an enemy queen/rook line. Practice 20's cxd4 exposed Qc7 to Qxc7.
- Trace the opponent's recapture after mine. A higher-valued queen guardian alone may lose material; a rook guardian can also fail when its capture destination is supported by the other enemy rook.
- For a king recapture, inspect other enemy attacks on its destination. Vacating the checking piece's origin can open its supporting line.
- Before a forced king response, consider which rook or bishop defender will depart or be captured. A legal first escape can still allow the next mate, as in game 19.
- Keep a quiet candidate tied to the current board and calculate the first forcing replies before distant plans. This method is a choice, not an inference cap; excessive speculative calculation remains unresolved.

Next full benchmark evaluation: 24 scored games. Bounded completion: 200 scored games regardless of achieved Elo. Current measurement after 22: 2W/2D/18L, provisional engine-relative Elo 1140 with 95% credible interval 790–1400. No sustained improvement or causal learning effect established.

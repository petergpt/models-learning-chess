# Independent chess learning log

## Starting state

Read this experiment's AGENTS.md and GOAL.md. Referee status shows no started games and no Elo estimate. No outside chess material, other learner material, delegated advice, engine analysis, or move-selection code has been used. Actual token counters are unavailable; I will not invent usage numbers.

## Initial evaluation plan

Play the first six scored games as a paired-color baseline through the fixed rotation. Choose every move mentally. Use familiar development principles: contest the center, develop minor pieces, protect the king, and check the opponent's immediate checks, captures, and threats before committing a move. This is an initial approach, not evidence of improvement.

After this block, choose a focused learning trial from my own observed errors and return to benchmarks after a bounded study/practice period. Record observations after each game. The first transfer evaluation will be at 12 scored games; revise that point explicitly if a concrete weakness calls for a different interval.

## Evidence to track

- Official provisional engine-relative Elo and its 95% credible interval; maximum-strength games are separate evidence because they have no calibrated anchor.
- W/D/L by opponent and color.
- My own unverified diagnoses of avoidable material losses, missed threats, king exposure, and conversion errors; distinguish these from the referee's established result.
- Whether errors recur in new positions. Replaying a remembered position or winning easier practice alone will not establish transfer.

## Games and trials

### Benchmark 1: White versus maximum strength, loss by resignation

Result: 0-1 after 46 plies. One rejected illegal submission, 19.Qxf3 from d3 through my bishop on e3. The eventual queen loss after 22.Qe4 Rxe4 is established by the accepted moves; my diagnosis is a basic failure to trace occupied lines, not subtle opening theory. I resigned with queen-for-rook material loss and an exposed king. Maximum-strength games do not supply a calibrated Elo anchor.

### Trial 1: Make board geometry concrete

The first game already supplies a clear target, so revise the original uninterrupted six-game baseline: undertake a short learning period now, then resume the fixed rotation. Next benchmark review remains at six scored games, with a transfer review at twelve.

Study my own two mistakes mentally. Before a queen/rook move or a planned recapture, explicitly trace every intervening square and examine opponent rooks, bishops, and knights attacking the destination. On move 19 the e3 bishop blocks d3-f3. On move 22 the e8 rook has a clear e-file to e4. A queen-exchange intention did not make the other capturing piece disappear.

Try one recorded practice drill from benchmark 1 before the queen loss, against skill 0, for at most eight of my moves. This is a remembered position, so success is only a local repair check. I will select a different queen square myself and attempt to keep both king and queen safe. End the drill explicitly if still active, then benchmark game 2. Observable transfer target: fewer illegal geometry attempts and no queen lost to an already visible slider in new benchmark positions. Keeping a longer checklist alone is not evidence of learning.

Practice 1 was stopped without moves: I selected ply 42, which was already after the queen loss. Practice 2 correctly started after ply 40 and was stopped after eight own moves. Qf5, Qg4, and fxg4 exchanged queens without the earlier rook-file error; no illegal submissions. This is local repair against skill 0, not measured improvement. Retain the line-tracing method for new games and test it in the next benchmarks.

### Benchmark 2: Black versus maximum strength, loss by resignation

Result: 0-1 from my perspective (official 1-0), after 79 plies, zero illegal submissions. I preserved the queen and exchanged it legally, but lost e5, b5, and c5 pawns. My unverified diagnosis: the e5 pawn lost its support after central exchanges while the e7 bishop blocked the rook; subsequent knight retreats abandoned pawn defenses. I defended an ending with equal rook/bishop material and three fewer pawns, then resigned with connected white passed pawns advancing. This is one game without the targeted queen blunder, not sustained transfer.

### Trial 2: Track what a move stops defending

Before benchmark 3, briefly reconstruct the e5 pawn loss in my own memory: a pawn recapture on e5 did not leave the recapturing pawn defended, because the rook's e-file was blocked and the f6 knight did not attack e5. Study this geometry mentally; no external source or automated analysis. Extend the destination scan by naming the most vulnerable pawn or piece left behind by the moving defender. Keep the method compact instead of adding speculative calculation branches. Test over benchmark games 3–6, then assess at six scored games. Observable target: avoid losing an otherwise uncontested central pawn to a one-move capture, and avoid repeating the direct queen-to-slider error. No practice win or checklist growth is counted as improvement.

### Benchmark 3: White versus skill 0, draw by repetition

Official result 1/2-1/2 after 61 plies, zero illegal submissions. I lost a bishop after Bh6, Kf8, f4, Bxh6: the f4 pawn interrupted my queen's intended recapture diagonal. The same class of blocker mistake recurred despite trial 1. Later kingside pawn pushes abandoned support and lost two more pawns. I obtained the available repetition while materially worse; the draw is established, but it is not evidence of sound play or successful learning. My own unverified positive observation is an active central knight; no engine evaluation supports an advantage claim.

### Trial 3: Preserve a planned recapture across the next move

The new-position error falsifies the broad claim that the remembered drill solved my line-visibility weakness. Revise the method now, before game 4. Distinguish a line that is open now from one that remains open after the candidate move. Mentally verify the opponent's capture and my recapture on the board after my intended move, especially when I move a pawn onto a queen/bishop diagonal.

Use one short practice from game 3 after ply 24 (before f4), maximum four own moves, skill 0. This is another remembered repair, not transfer evidence. First choose a move that resolves or preserves the h6/g7 bishop contact. Then resume benchmarks; next overall review remains at six scored games. Observable target for the next three benchmarks: no unrecapturable bishop exposure caused by my own intervening pawn move. The recorded skill-0 draw does not establish the trial worked.

Practice 3 stopped after four own moves: Bxg7+ Kxg7, Rae1, Nf3, e5. I resolved the bishop contact first and retained equal piece material with a usable e-file. No illegal submissions. This is a remembered position and a short local check only. Decision: keep the revised after-move recapture scan for benchmark 4 and avoid creating contact between pieces unless I can still recapture after my next move.

Official status after three benchmarks: maximum strength 0W/0D/2L; skill 0 0W/1D/0L; 1800 setting not yet played. Provisional Elo 1400, 95% credible interval 330–2500, based on one calibrated game; two maximum-strength games excluded from the estimator. This uncertainty is conditional on nominal anchors and is not a human rating.

### Benchmark 4: Black versus skill 0, loss by resignation

Official 1-0 after 113 plies, zero illegal submissions. Bishop contact and queen recaptures were handled legally, and I gained a pawn after a central exchange. I then missed d5+ forking king e6 and rook c6, losing the rook. An advanced a-pawn eventually promoted, but a sequence of rook checks led to the loss of my remaining rook and promoted queen. I captured one opposing rook in that sequence, then overlooked the other rook's capture of the queen on a1. I resigned with only king and five pawns against rook, knight, and three pawns. Conversion and multi-threat tracking failed; no claim of improvement from the earlier pawn gain.

### Trial 4: Pawn checks and the piece left behind after a forcing reply

New target: recognize a pawn advance that checks my king and attacks another piece, and track both enemy rooks during forced sequences. Reconstruct game 4's fork mentally: white d4-d5 attacks e6 and c6; after a required king move the rook remains attacked. The later king capture on b4 also vacated the a-file, allowing the remaining white rook to capture my queen on a1. An attractive recapture did not resolve every threat.

Use a short remembered-position drill from game 4 after ply 79, at most four own moves, skill 0. Select my own repair that prevents the pawn fork rather than responding after it. Return immediately to the fixed benchmark rotation for games 5 and 6, then review the whole first pair-color cycle. Track checking pawn forks and undefended queens in those new positions. Local repair is not sufficient evidence, given recurrence in the first four games.

Clarification to practice 3: its final position was after e5 dxe5, awaiting my next recapture; piece material was equal, but the drill did not establish a completed central-pawn conversion. The referee note's phrase 'kept material even' was too broad for that final pawn position.

# Plan and learning log

## Facts about the measurement (from reading the referee code; operator-owned)
- Rotation per 6 games: full-strength W,B; skill-0 W,B; elo-1800 W,B. Engine: 1M nodes/move.
- Elo uses ONLY skill-0 (anchor 1320) and 1800-setting games; rolling window = last 50 rated games.
  200 games -> ~132 rated; final estimate ~ games 125-200.
- Full-strength games are benchmark evidence but excluded from Elo.

## Approach (initial hypothesis, unverified)
Main expected error sources for me: misreading the board, hanging pieces, missing opponent tactics,
illegal-move submissions, sloppy conversion (stalemate/repetition), long games burning budget.
Method: fixed per-move protocol (PROTOCOL.md), simple repertoire (REPERTOIRE.md),
post-game review of every non-win vs rated opponents (own analysis only; no engine),
error taxonomy with recurrence counts (ERRORS.md), targeted practice from my own failed positions.

## Evaluation
Each full rotation (6 games) = checkpoint; compare rated score and error recurrence per 12 games.

## Trials log
- T0 (games 1-6): baseline with PROTOCOL.md + REPERTOIRE.md. Next checkpoint: after game 6.
- T0 result (games 1-6): full 0/2, skill0 2/2, 1800 1/2 (won because opp blundered a knight on move 4; lost G6
  from my own line errors). Elo 1870 [1410,2460] after 4 rated games. Tokens used ~508k (too many: ~85k/game).
- T1 (games 7-12): weakness = line-of-sight errors (pins on defenders, self-blocking, abandoned defences, path
  errors). Trial = explicit LINE AUDIT step in PROTOCOL.md + token discipline (resign hopeless games early).
  Observable: 0 illegal attempts; fewer self-inflicted material losses in rated games (block 1: G6 had 3);
  average tokens/game <= 60k. Next evaluation point: after game 12.
- T1 result (games 7-12): 0/6 (full 0/2, skill0 0/2, 1800 0/2). Line audit helped occasionally (caught Ne7 self-block,
  Bb4?? Qa4+, Qxb2?? Qxe8+) but one-move blunders still decided every game: G9 Qc8??, G10 Rxf3?/Rh1??, G11 Nd4??/Rd4??,
  G12 Kxd5??. Decision: the method is right but the execution is superficial -> T2.
- T2 (games 13-18): explicit SAFETY TABLE every rated move with escape-square enumeration for each enemy check, and the
  KING RULE for endgames. Full-strength games: lighter version, resign hopeless positions early.
  Observable: one-move blunders per rated game (block 2 ~1.5) -> target <=0.5; rated score > 0/4. Evaluate after G18.
- Practice P1 (G12 ply 44, vs 1800, Black, +1 endgame): 30 moves, stopped at +2 (drawish). With written escape-square
  checks: no mate/fork blunders; but 2 "unblocking" oversights + 1 illegal (own K in rook path). Added to table (D).

- T2 RESULT (G13-18): rated 3/4 (was 0/4); Elo 1560 [1310,1810] after 12 rated. Blunder rate ~1/rated game (target
  0.5 missed); errors moved from mate/fork to "attacked-pawn census" and move-shape/path legality. Keep the table.
- T3 (games 19-24): COMPACT protocol + token budget. Each move: (1) census of every enemy line from the piece that just
  moved (all its targets) + list my loose men; (2) 1-3 candidates; (3) compressed safety table (K/S/D/B/C);
  (4) shape+path check for the chosen move (delta, every intermediate square from the FEN, incl. double pawn pushes).
  Budget <=60K tokens/game (185 games left need ~74K/game). Resign lost positions vs full/1800 at once.
  Observable: avg tokens/game <=75K over G19-24 AND rated blunders <=1/game AND 0 illegal attempts. Evaluate after G24.

# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|

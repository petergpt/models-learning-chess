# Error taxonomy and recurrence (my own post-game assessments; unverified by engine)

Format: game/ply - category - short description

Categories: HANG (left piece en prise), TACTIC (missed opponent tactic: fork/pin/skewer/discovery),
MATE (missed mating threat), READ (board misread / illegal), PLAN (strategic drift), CONV (failed conversion),
OPEN (opening knowledge error), TIME (budget overrun).

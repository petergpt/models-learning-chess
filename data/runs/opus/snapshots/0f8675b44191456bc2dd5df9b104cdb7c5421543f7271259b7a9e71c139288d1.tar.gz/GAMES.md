# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|
| 1 | full | W | 0-1 resign | 44 | Italian; ...g5-g4 attack; lost pawn on d4; 21.Qxf7? Qxg3! (f2 pinned by Bd4), 22.Qf3?? Qxf3 (g2 pinned by Rg8) |
| 2 | full | B | 0-1 mate | 41 | Caro Advance 4.h4; 15...Qe7? blocked Bf8 from d6 -> Nd6+ (illegal Bxd6 attempt), king stuck d7, mated by Qa4+/Qxc6 |
| 3 | skill0 | W | 1-0 mate | 45 | Philidor; dxe5/exd6 +1; e5 fork; opp 12...Qxf6?? exf6; Rd7+g7 pawn net, Nf6# |

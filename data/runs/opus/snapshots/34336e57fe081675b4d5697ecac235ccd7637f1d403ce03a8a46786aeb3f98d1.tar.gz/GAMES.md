# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|
| 1 | full | W | 0-1 resign | 44 | Italian; ...g5-g4 attack; lost pawn on d4; 21.Qxf7? Qxg3! (f2 pinned by Bd4), 22.Qf3?? Qxf3 (g2 pinned by Rg8) |
| 2 | full | B | 0-1 mate | 41 | Caro Advance 4.h4; 15...Qe7? blocked Bf8 from d6 -> Nd6+ (illegal Bxd6 attempt), king stuck d7, mated by Qa4+/Qxc6 |
| 3 | skill0 | W | 1-0 mate | 45 | Philidor; dxe5/exd6 +1; e5 fork; opp 12...Qxf6?? exf6; Rd7+g7 pawn net, Nf6# |
| 4 | skill0 | B | 0-1 mate | 56 | 1.c4 e5 reversed Sicilian; ...f5/...fxe4 won piece; opp hung Ba3, Rh1, Qd5; Qd2# with Bb4 |
| 5 | 1800 | W | 1-0 mate | 105 | Alapin 2...Nf6 3.e5 Ne4? 4.d3 trapped N; Q trade; 39.Rh8?? Rxh8 40.c8=Q? Rxc8 threw a rook; still won w/ 2B+N |
| 6 | 1800 | B | 0-1 resign | 128 | 1.Nf3 d5 London-ish; 4...Qb6 illegal (c7 blocks); 20...Qb6? dropped c4 + b-file pin lost B; 27...Nc5? blocked own c-file defence; lost |
| 7 | full | W | 0-1 resign | 46 | Italian again; ...h6/...g5-g4 attack; 23.Ng3? Rxg3 (g2 pinned on g-file); ~22k tokens |
| 8 | full | B | 0-1 mate | 39 | Caro 4.h4; was +1 after ...Bxb4; 18...O-O-O?? Ncd6+ Bxd6 Nxd6# (Rd8 blocked by own Nd7; Q by c6; Rh6 by e6) |
| 9 | skill0 | W | 0-1 resign | 132 | Alapin; 21.Qc8?? Rxc8 (Rh8 covered c8 along rank: same as G5); recovered to equal, then a-pawn promoted; 2 illegal (Rf3-f1 thru own K; careless test 'd3d3') |
| 10 | skill0 | B | 1-0 mate | 75 | c4 e5; Qxg7 grab; 30...Rxf3? Nd4+ fork; recovered to equal; 37...Rh1?? Rc2# (K c4 in net; never listed W's checks) |
| 11 | 1800 | W | 0-1 resign | 74 | Scandi 2...a6? +2 pawns; 16.Be3? dropped b2; 19.Nd4?? blocked Be3-c5 -> lost N; 37.Rd4?? (N on c6 hits d4) lost R |
| 12 | 1800 | B | 1-0 mate | 83 | 1.e3 e5 2.c4; won c4 pawn, Q trade, +1 endgame; illegal Ke7-e5 (2-square K move); 41...Kxd5?? Bf3# (own Rd6 blocked escape) |
| 13 | full | W | 0-1 resign | 28 | London; 13.Rfb1?? Bf5xb1 (skipped safety table in an unrated game) |
| 14 | full | B | 0-1 resign | 39 | Caro h4 line again; 17...Rb8? Ncd6+ Bxd6 Nxd6+ then Qd3xa6 (Nc4 had been blocking d3-a6) + b-file |
| 15 | skill0 | W | 1-0 mate | 109 | Italian; +1 after exd5; 17.Ne5? (missed Re8 on e-file) but Rxe5 dxe5; 23.Rd3? allowed Nxe5 fork -> equal; won via opp blunders (Kh5?, left Rc8 hanging), b-pawn, Qg3# |
| 16 | skill0 | B | 0-1 mate | 88 | QGD/London; ...c4 bind; Bb4 pin won exchange; illegal Bf5-d7 (own e6 pawn) -> had to give B for pawn; opp blunders; c-pawn promoted; Qg1+Qg4# |
| 17 | 1800 | W | 1-0 mate | 149 | Alapin IQP; Ne5/dxe5, Nxd5 won d5 (+1); Q trade; R+B ending; illegal f2-f4 (own Bf3 on f3); h4/f4 breaks, e6+ Kg6 Kxg7; R+2P v R -> Re4+ cut, g-pawn, KR v K mate. ~300K tokens (too slow in endgame) |
| 18 | 1800 | B | 0-1 resign (I lost) | 89 | 1.e3 e5 2.c4 Nf6 3.a3 d5 4.d4 exd4; won c4 pawn (W played Nc3 not Bxc4); 35...Qd7 dropped the c-file guard of c4, 40.Qc6 hit c4+c7, I saw only c7 -> Qxc4/Qxc7+/Qxb6; illegal Qf6-d5 (not a line) |
| 19 | full | W | 0-1 resign | 34 | Italian c3/d3/a4/h3; ...g5 storm; 13.Nf3? blocked Qd1's guard of g4 (Bxg4); illegal Bc4-e2 (own d3 pawn); 17.Bxa6? -> ...Bc5 hit Qb4 AND unmasked Ra8 on a6 |
| 20 | full | B | 0-1 resign | 45 | Caro h4 line as prepared (Qa6); fine to move 20; 22.Rfe1 hit Qe5 with my K on the e-file behind Ne6 -> 22...Qf6? Nxg7+ double check (discovered Re1+) wins Nf5 |
| 21 | skill0 | W | 1-0 mate | 153 | 1.e4 Nc6 2.d4 d5 3.exd5 Na5; +1; 16.Na3?? unblocked Bc6-a4 -> lost Q; came back vs skill-0 blunders (Rd8 left en prise), illegal Be7-b4 (own c5 pawn); R+B+3P v Q, f/g/h pawns promoted, Bd4# |
| 22 | skill0 | B | 1-0 mate (I lost) | 63 | 1.Nf3 d5 2.g3 Nf6 3.c3 Bf5; good attack (Re8+ pin, Nc5xd3); 16...Qd7? left Nd3 guarded only by Bg6 -> Nxg6 removed the guard (-piece); endgame fight back to -1; 28...Re4/29...Rxd4 left my back rank empty with no luft -> Ra8+ mate |
| 23 | 1800 | W | 0-1 resign | 66 | Alapin 2...Nc6 4...e5 5.d5; equal till 23.Qc2? (e4 left guarded only by Q while Ra4 eyed e4 -> Nxe4 free); a-file battery won a2/a4; 33.Bxh6?? gxh6 and Qxh6+ fails to Kxh6 (h6 undefended) |
| 24 | 1800 | B | 1-0 resign (I lost) | 43 | 1.c4 e5 2.e3 Nf6 3.Nc3 d5; won d4 (+1), traded Qs, even after Bxb7; 21...Ke7?? put my K on the e-file between Re8 and Be5 -> Bxe5 free piece |
| 25 | full | W | 0-1 resign | 48 | London; equal till R+N ending; c-file doubling, Rc1+ skewer threat on Ra1 -> lost f2; resigned |
| 26 | full | B | 1-0 resign (I lost) | 45 | Caro h4 line again (deviated 16...Kxe7); Qg5+ won h5; 21...Rxd5? Qh8+ skewered Ra8 along rank 8 |
| 27 | skill0 | W | 1-0 mate | 73 | 1.e4 d6 2.d4 e5 3.dxe5 Nc6; Qxd8+ Bxf7 (+1); opp left Nd4 hanging; queenside majority a5/b4/c5/d6, discovered c6+ via Be3; Rb5 + Rc8# |
| 28 | skill0 | B | 1-0 resign (I lost) | 77 | 1.c4 e5 2.d3 Nf6 3.a3 d5; won a piece (opp Ng5?? hxg5) +3; 26.Qxf6 vs my bare K; 28...Rg7? blocked check but Qg6 also hit Re8 via f7 -> Qxe8+; then Qd3+ skewered Bd5; lost |
| 29 | 1800 | W | 0-1 resign | 20 | Alapin 2...Nc6 3.Nf3 e5 4.Bc4 Na5 5.Be2 Qc7 6.b4?! cxb4 7.cxb4 Bxb4 8.Qa4?? Qxc1+ (Qd1 was Bc1's only guard) |
| 30 | 1800 | B | 0-1 mate (I won) | 174 | 1.c4 e5 2.b3 Nf6 3.a3 d5; 10...Bxd1 zwischenzug, traded; regained pawns with Bc6/a-pawn; ...c6 fork, a-pawn promoted (Rb1+ a1=Q); R+B v B+3P -> won pawns -> R+B v K -> Rf1# |
| 31 | full | W | 0-1 resign | 66 | London; ...c4 bind, lost a pawn; 33.Nb3?? walked into Rb6's open b-file (knight lost) |
| 32 | full | B | 1-0 resign (I lost) | 55 | Caro h4 line, deviated 7...Nd7/8...Ne7/9...Qb6 (avoided Qxb2? Rfb1 trap); ...f6 won tempo vs pinned Ng5, but K on e7 in open: 23.Qa3+ Kf6 24.Rxe6+ Q for R+N, then Re7+/Qc7 mate net |
| 33 | skill0 | W | 1-0 mate | 41 | Alapin ...d6/...Nbd7; e5 break; h3 vs ...Ng4 won N (...h5?); Bxa6 loose B; Nd6, Bd3, Qe4 -> Qh7# (B+Q battery on h7) |
| 34 | skill0 | B | 0-1 mate (I won) | 152 | 1.Nf3 d5 2.c3 Nf6 3.g3 Bf5; 22...Qxc2?? (c2 also guarded by Ne3) Q for N; fought back: Rb2/Rxc2 won N, passed e-pawn + Rf-file cut K off, Rf1 deflection, K shelter h6; Qe2+ Rh3# ; 1 illegal (Ke7 on checking diagonal) |
| 35 | 1800 | W | 1/2 stalemate | 127 | Alapin ...Nc6/...e6, 5.e5 Ne4 6.Bd3! d5 7.Bxe4 won e4; ...Nxe5 trick (d-file Q x-ray); Nd6/Bxd6, d5 break, Q trade; R+R+B v R+R+B +1, passed c-pawn; 42.c6?? removed Bb6's only guard -> R+2P v R; ...Rxf6+ stalemate trick (Kxf6 accepted as draw); 3 illegal: Qd5-b5 thru own Bc5, Rc7-f7 thru own d7, fxg5 pinned by Rf2 |
| 36 | 1800 | B | 1-0 resign (I lost) | 115 | 1.e3 d5 2.c4 Nf6 QGD-ish; ...Qb5 pin on Nc4, ...Na5/...Nb6; 23...bxa3 e.p.?? opened Bd2-a5 (Na5 lost, Q couldn't recapture: Nc4 covered a5); 57.Nxf5+ fork K/Q/R; 1 illegal (Qg5-e5 through own f5) |
| 37 | full | W | 0-1 mate | 46 | London; 17.Rac1?? into Qc7+Rc8 battery (Qxc1 Rxc1 Rxc1+); Ng4+/Rh1+ mating net on Kh3; illegal Kh3-g2 (own g2 pawn, doubled g-pawns misread) |

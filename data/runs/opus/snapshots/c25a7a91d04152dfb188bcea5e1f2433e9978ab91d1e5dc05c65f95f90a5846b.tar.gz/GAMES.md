# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|
| 1 | full | W | 0-1 resign | 44 | Italian; ...g5-g4 attack; lost pawn on d4; 21.Qxf7? Qxg3! (f2 pinned by Bd4), 22.Qf3?? Qxf3 (g2 pinned by Rg8) |
| 2 | full | B | 0-1 mate | 41 | Caro Advance 4.h4; 15...Qe7? blocked Bf8 from d6 -> Nd6+ (illegal Bxd6 attempt), king stuck d7, mated by Qa4+/Qxc6 |
| 3 | skill0 | W | 1-0 mate | 45 | Philidor; dxe5/exd6 +1; e5 fork; opp 12...Qxf6?? exf6; Rd7+g7 pawn net, Nf6# |
| 4 | skill0 | B | 0-1 mate | 56 | 1.c4 e5 reversed Sicilian; ...f5/...fxe4 won piece; opp hung Ba3, Rh1, Qd5; Qd2# with Bb4 |
| 5 | 1800 | W | 1-0 mate | 105 | Alapin 2...Nf6 3.e5 Ne4? 4.d3 trapped N; Q trade; 39.Rh8?? Rxh8 40.c8=Q? Rxc8 threw a rook; still won w/ 2B+N |
| 6 | 1800 | B | 0-1 resign | 128 | 1.Nf3 d5 London-ish; 4...Qb6 illegal (c7 blocks); 20...Qb6? dropped c4 + b-file pin lost B; 27...Nc5? blocked own c-file defence; lost |
| 7 | full | W | 0-1 resign | 46 | Italian again; ...h6/...g5-g4 attack; 23.Ng3? Rxg3 (g2 pinned on g-file); ~22k tokens |
| 8 | full | B | 0-1 mate | 39 | Caro 4.h4; was +1 after ...Bxb4; 18...O-O-O?? Ncd6+ Bxd6 Nxd6# (Rd8 blocked by own Nd7; Q by c6; Rh6 by e6) |
| 9 | skill0 | W | 0-1 resign | 132 | Alapin; 21.Qc8?? Rxc8 (Rh8 covered c8 along rank: same as G5); recovered to equal, then a-pawn promoted; 2 illegal (Rf3-f1 thru own K; careless test 'd3d3') |
| 10 | skill0 | B | 1-0 mate | 75 | c4 e5; Qxg7 grab; 30...Rxf3? Nd4+ fork; recovered to equal; 37...Rh1?? Rc2# (K c4 in net; never listed W's checks) |
| 11 | 1800 | W | 0-1 resign | 74 | Scandi 2...a6? +2 pawns; 16.Be3? dropped b2; 19.Nd4?? blocked Be3-c5 -> lost N; 37.Rd4?? (N on c6 hits d4) lost R |
| 12 | 1800 | B | 1-0 mate | 83 | 1.e3 e5 2.c4; won c4 pawn, Q trade, +1 endgame; illegal Ke7-e5 (2-square K move); 41...Kxd5?? Bf3# (own Rd6 blocked escape) |
| 13 | full | W | 0-1 resign | 28 | London; 13.Rfb1?? Bf5xb1 (skipped safety table in an unrated game) |
| 14 | full | B | 0-1 resign | 39 | Caro h4 line again; 17...Rb8? Ncd6+ Bxd6 Nxd6+ then Qd3xa6 (Nc4 had been blocking d3-a6) + b-file |
| 15 | skill0 | W | 1-0 mate | 109 | Italian; +1 after exd5; 17.Ne5? (missed Re8 on e-file) but Rxe5 dxe5; 23.Rd3? allowed Nxe5 fork -> equal; won via opp blunders (Kh5?, left Rc8 hanging), b-pawn, Qg3# |
| 16 | skill0 | B | 0-1 mate | 88 | QGD/London; ...c4 bind; Bb4 pin won exchange; illegal Bf5-d7 (own e6 pawn) -> had to give B for pawn; opp blunders; c-pawn promoted; Qg1+Qg4# |
| 17 | 1800 | W | 1-0 mate | 149 | Alapin IQP; Ne5/dxe5, Nxd5 won d5 (+1); Q trade; R+B ending; illegal f2-f4 (own Bf3 on f3); h4/f4 breaks, e6+ Kg6 Kxg7; R+2P v R -> Re4+ cut, g-pawn, KR v K mate. ~300K tokens (too slow in endgame) |

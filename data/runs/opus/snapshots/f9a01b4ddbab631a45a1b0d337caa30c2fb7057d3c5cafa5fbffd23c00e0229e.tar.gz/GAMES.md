# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|
| 1 | full | W | 0-1 resign | 44 | Italian; ...g5-g4 attack; lost pawn on d4; 21.Qxf7? Qxg3! (f2 pinned by Bd4), 22.Qf3?? Qxf3 (g2 pinned by Rg8) |

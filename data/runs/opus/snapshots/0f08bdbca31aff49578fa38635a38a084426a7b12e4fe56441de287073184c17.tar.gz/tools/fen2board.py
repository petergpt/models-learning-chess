#!/usr/bin/env python3
"""Mechanical FEN -> ASCII rendering for between-game review. No chess logic, search or evaluation."""
import sys

def render(fen):
    rows = fen.split()[0].split('/')
    out = []
    for i, row in enumerate(rows):
        cells = []
        for ch in row:
            if ch.isdigit():
                cells.extend(['.'] * int(ch))
            else:
                cells.append(ch)
        out.append(f"{8 - i} " + ' '.join(cells))
    out.append('  a b c d e f g h')
    return '\n'.join(out)

if __name__ == '__main__':
    for fen in sys.argv[1:] or [sys.stdin.read().strip()]:
        print(fen)
        print(render(fen))
        print()

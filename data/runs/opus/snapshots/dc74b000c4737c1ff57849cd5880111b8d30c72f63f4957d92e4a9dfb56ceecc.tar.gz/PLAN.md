# Plan and learning log

## Facts about the measurement (from reading the referee code; operator-owned)
- Rotation per 6 games: full-strength W,B; skill-0 W,B; elo-1800 W,B. Engine: 1M nodes/move.
- Elo uses ONLY skill-0 (anchor 1320) and 1800-setting games; rolling window = last 50 rated games.
  200 games -> ~132 rated; final estimate ~ games 125-200.
- Full-strength games are benchmark evidence but excluded from Elo.

## Approach (initial hypothesis, unverified)
Main expected error sources for me: misreading the board, hanging pieces, missing opponent tactics,
illegal-move submissions, sloppy conversion (stalemate/repetition), long games burning budget.
Method: fixed per-move protocol (PROTOCOL.md), simple repertoire (REPERTOIRE.md),
post-game review of every non-win vs rated opponents (own analysis only; no engine),
error taxonomy with recurrence counts (ERRORS.md), targeted practice from my own failed positions.

## Evaluation
Each full rotation (6 games) = checkpoint; compare rated score and error recurrence per 12 games.

## Trials log
- T0 (games 1-6): baseline with PROTOCOL.md + REPERTOIRE.md. Next checkpoint: after game 6.
- T0 result (games 1-6): full 0/2, skill0 2/2, 1800 1/2 (won because opp blundered a knight on move 4; lost G6
  from my own line errors). Elo 1870 [1410,2460] after 4 rated games. Tokens used ~508k (too many: ~85k/game).
- T1 (games 7-12): weakness = line-of-sight errors (pins on defenders, self-blocking, abandoned defences, path
  errors). Trial = explicit LINE AUDIT step in PROTOCOL.md + token discipline (resign hopeless games early).
  Observable: 0 illegal attempts; fewer self-inflicted material losses in rated games (block 1: G6 had 3);
  average tokens/game <= 60k. Next evaluation point: after game 12.
- T1 result (games 7-12): 0/6 (full 0/2, skill0 0/2, 1800 0/2). Line audit helped occasionally (caught Ne7 self-block,
  Bb4?? Qa4+, Qxb2?? Qxe8+) but one-move blunders still decided every game: G9 Qc8??, G10 Rxf3?/Rh1??, G11 Nd4??/Rd4??,
  G12 Kxd5??. Decision: the method is right but the execution is superficial -> T2.
- T2 (games 13-18): explicit SAFETY TABLE every rated move with escape-square enumeration for each enemy check, and the
  KING RULE for endgames. Full-strength games: lighter version, resign hopeless positions early.
  Observable: one-move blunders per rated game (block 2 ~1.5) -> target <=0.5; rated score > 0/4. Evaluate after G18.
- Practice P1 (G12 ply 44, vs 1800, Black, +1 endgame): 30 moves, stopped at +2 (drawish). With written escape-square
  checks: no mate/fork blunders; but 2 "unblocking" oversights + 1 illegal (own K in rook path). Added to table (D).

- T2 RESULT (G13-18): rated 3/4 (was 0/4); Elo 1560 [1310,1810] after 12 rated. Blunder rate ~1/rated game (target
  0.5 missed); errors moved from mate/fork to "attacked-pawn census" and move-shape/path legality. Keep the table.
- T3 (games 19-24): COMPACT protocol + token budget. Each move: (1) census of every enemy line from the piece that just
  moved (all its targets) + list my loose men; (2) 1-3 candidates; (3) compressed safety table (K/S/D/B/C);
  (4) shape+path check for the chosen move (delta, every intermediate square from the FEN, incl. double pawn pushes).
  Budget <=60K tokens/game (185 games left need ~74K/game). Resign lost positions vs full/1800 at once.
  Observable: avg tokens/game <=75K over G19-24 AND rated blunders <=1/game AND 0 illegal attempts. Evaluate after G24.

- T3 RESULT (G19-24): tokens ~44K/game (met), but rated 1/4, Elo 1490 [1270,1700] after 16 rated; blunders >1/game,
  2 illegal. Compactness cut the from/to-square line checks that caught these errors.
- T4 (games 25-30): budget by opponent (full ~20K, rated ~90K) + a mandatory written LINES note on every rated move:
  FROM-sq: 8 lines through it -> enemy slider behind it aiming at my piece/K? what did it guard? TO-sq: whose lines
  does it now block (mine!), who attacks it, and if it is a recapture square is it attacked again (x-ray)?
  + back-rank status + path squares read from FEN. Observable: <=1 decisive blunder in the 4 rated games, 0 illegal.

- T4 RESULT (G25-30): rated 2/4, Elo 1500 [1310,1700] after 20 rated; 0 illegal moves (path check works);
  ~40K tokens/game. Still 2 decisive one-move losses, both missed enemy captures after my move.
- T5 (games 31-36): keep T4 + CAPTURE SCAN: after picking a candidate, for every enemy piece list each of my men it
  attacks in the NEW position (incl. through squares my move vacated) and whether the capture wins material.
  Rated games may use ~60K tokens, full-strength ~20K. Observable: 0 lost-material blunders from enemy captures.
- T5 RESULT (G31-36): rated 2.5/4 (W,W,D,L), Elo 1540 [1360,1710] after 24 rated; but NOT met: 4 material-losing
  misses (G31 Nb3, G34 Qxc2, G35 c6, G36 bxa3/Nxf5+) and 5 illegal attempts; ~85K tokens/game (over budget).
- T6 (games 37-42): THREE WRITTEN LINES before every rated move, no exceptions, kept short:
  P = path: every square between from/to with its occupant (mine too) + "is the mover pinned to my K?";
  F = from-square: what did the mover defend/block (pawns included);
  C = captures: each enemy piece -> which of my men it can now take (knight jumps first, lines through the vacated
  square), and for any capture I make, every recapturer.
  Plus: when ahead, trade pieces; vs full strength resign at -3. Budget: full <=15K, rated <=70K.
  Observable: 0 illegal attempts and <=1 material-losing miss over the 4 rated games. Evaluate after G42.
- T6 RESULT (G37-42): 0/6, rated 0/4 (2 losses to skill 0!), Elo 1460 [1300,1620] after 28 rated. ~36K tokens/game:
  the "three short lines" became perfunctory; misses: battery (G37), king walk into mate (G39), batched second move
  (G40), fork/rank lines (G41), back rank + pin + defender count (G42). 3 illegal attempts. NOT met.
- Budget check: 12.34M tokens / 158 games left. Full-strength games (~53) at <=12K each leave ~110K per rated game.
- T7 (games 43-48): SPEND the budget on rated games (target 90-120K each, no compact mode) and run the FULL check on
  every rated move: (1) what the opponent's last move attacks / opened; (2) 2-3 candidates; (3) for the chosen move:
  path squares incl. my own men, is the mover pinned, what it used to defend; ALL enemy checks and captures after it,
  each with an attacker/defender count including the defenders of the capturing piece; knight forks; back rank.
  Exactly one move command per turn. Full-strength: quick play, resign at -3.
  Observable: rated score >= 2/4 and <= 1 material-losing miss per rated game. Evaluate after G48.
- T7 RESULT (G43-48): rated 2/4 (G45 W, G46 L, G47 W, G48 L), Elo 1470 [1320,1620] after 32 rated (13.5/32).
  Target half met: score 2/4 yes; "<=1 material-losing miss per rated game" yes in count, but each loss was one such
  miss on a "routine" move. Spend ~290K tokens for 6 games (~65K per rated game, under the 90-120K target).
- Budget check: 12.04M tokens / 152 games left -> full-strength ~10K each (~510K), rated ~110K each.
- T8 (games 49-54): (a) RENDERING: mv prints rank-labelled board + piece lists from the FEN (pure rendering, no
  chess logic) so misreads of who stands where drop. (b) NO ROUTINE MOVES: the full enemy-reply scan (every enemy
  piece: its captures and checks after my move, incl. lines through the square I vacated and lines my moved piece
  now shares with an enemy piece) is written for EVERY rated move including development and recaptures; the scan
  must name the enemy pieces one by one. (c) vs skill 0 play safe, simple chess: when ahead, trade; never allow
  counterplay. Observable: rated score >= 3/4, zero one-move material losses. Evaluate after G54.
- T8 RESULT (G49-54): rated 1.5/4 (G51 W, G52 D, G53 L from +2, G54 L), Elo 1470 after 36 rated. NOT met. Rendering
  helped (fewer misreads) but 3 illegal attempts (all slider paths/knight geometry) and 4 one-move oversights.
  ~550K tokens for the block.
- T9 (games 55-60): SQUARE SCAN instead of piece-by-piece scans. For (1) the destination square of every move,
  (2) every square in a capture sequence I plan, (3) my K's flight squares whenever a check is possible, walk the
  rays OUTWARD from the square: 2 enemy-pawn squares, 8 knight squares, 4 diagonal rays to first piece, 4 straight rays
  to first piece, enemy K. For every slider move, list the path squares by name with occupants. Prefer simple moves
  in sharp positions; no speculative grabs (G54 Bxg4) unless the scan proves them. Observable: zero one-move material
  losses and zero illegal attempts in rated games; rated >= 2/4. Evaluate after G60.
- T9 RESULT (G55-60): rated 2/4 (G57 W mate, G58 L, G59 L, G60 W mate), Elo 1480 after 40 rated. Met: rated >= 2/4,
  0 illegal in rated games. Not met: 2 one-move material losses (x-ray rook battery; vacated-line queen loss).
  ~270K tokens for the block.
- T10 (games 61-66): keep T9 square scans, and add two fixed sub-steps to every rated move: (1) ORIGIN SCAN - list
  enemy rays (Q/R/B lines) that pass through the square my piece leaves and what they hit once it is empty;
  (2) X-RAY COUNT - when counting attackers along a line, look past the first attacker for a second enemy slider
  on the same line (doubled rooks, Q+B, Q+R). Observable: zero one-move material losses in rated games, 0 illegal,
  rated >= 2/4. Evaluate after G66.
- T10 RESULT (G61-66): rated 3/4 (G63 W, G64 W, G65 W vs 1800, G66 L vs 1800), Elo 1510 [1380,1640] after 44 rated
  (best so far). Score target met. Process targets NOT met: 1 illegal attempt (G65, rook path through own pawn), one-move
  losses G64 (B lost for P after a capture left two pieces loose) and G66 (discovered attack on my Q). ~460K tokens for
  the block (~76K/game).
- Budget check: 10.76M tokens / 134 games -> ~80K per game average; keep full-strength games short (~12K).
- T11 (games 67-72): keep T9/T10 scans and add the DISCOVERY CHECK: on each ray from my destination square, if the
  first piece is an enemy piece not attacking along that ray, look behind it for an enemy Q/R (file/rank) or Q/B
  (diagonal); if found, ask whether the blocker can move with check/capture. Also after any capture I make, list
  every one of my pieces that is attacked after the opponent's most forcing reply (checks first). Write slider paths
  for retreats too. Observable: no discovered-attack or fork losses, 0 illegal in rated games, rated >= 2/4.
  Evaluate after G72.
- T11 RESULT (G67-72): rated 2/4 (G69 W, G70 L from +5, G71 W vs 1800, G72 L vs 1800), Elo 1510 [1390,1640]
  after 48 rated. Score target met, 0 illegal. NOT met: three single-move losses - G69 own knight unblocked a rook
  onto my queen (origin scan skipped), G70 knight fork after a queen move (reply scan skipped), G72 bishop moved
  onto an enemy rook's open file (destination scan skipped). All three were on "quiet" moves in good positions.
- T12 (games 73-78): (1) Every move's reasoning must contain three explicit lines before the command:
  DEST (rays + knight squares + pawns from the destination), ORIGIN (lines through the vacated square),
  REPLY (all enemy checks and captures next move; for each check, what else the checker hits). No exceptions for
  "obvious" moves. (2) When ahead by >= 2: trade queens/rooks, keep every piece protected, no pawn grabs with
  pieces near the rim. Observable: zero one-move material losses in rated games, rated >= 2/4. Evaluate after G78.
- T12 RESULT (G73-78): rated 1.5/4 (G75 W, G76 D from a rook down, G77 L, G78 L vs 1800); full 0/2.
  Elo 1490 [1370,1620] after 52 rated (flat since T9). 0 illegal in rated games except G76 (1).
  NOT met: three one-move losses, each in a category the DEST/ORIGIN/REPLY lines did not force me to enumerate:
  G76 37...Rxa3?? (a knight's attack square skipped), G77 31.Rxb5?? (my R and Q lined up on one diagonal ->
  ...Ba6 skewer), G78 22...Qxh3+?? (in a "forced mate" I listed the king's flight squares but not KING CAPTURES
  THE UNPROTECTED CHECKER). Also G77: a knight outpost (Ng5) with no retreat got trapped by a pawn push.
  Decision: keep T12 lines but replace the free-text REPLY with fixed checklists (T13).
- T13 (games 79-84): (1) For any check or sacrifice I calculate, enumerate replies in fixed order at EVERY node:
  a) capture the checker/sacrificed piece - by each enemy piece INCLUDING THE KING (is my piece protected?);
  b) interpositions; c) every king square. A line is "forced" only if all three lists are written.
  (2) LINE-UP scan after each move: any two of my K/Q/R/unprotected pieces on one rank/file/diagonal with only
  empty squares between and an enemy slider able to reach that line next move = skewer/pin, reject.
  X-ray: an enemy rook/queen behind an enemy piece on a line counts as a defender of that piece's targets.
  (3) DEST must list enemy knight attack squares explicitly ("knights: Nc4 hits a3,a5,b2,b6,d2,d6,e3,e5").
  (4) Advanced pieces: after each enemy pawn push, list my piece's retreat squares; keep one.
  (5) Vs 1800/full: no speculative sacrifices unless (1) is written out to mate or material gain.
  Observable: zero one-move material losses in rated games; rated >= 2/4. Evaluate after G84.
- T13 RESULT (G79-84): full 0/2; rated 2/4 (G81 W, G82 L, G83 D, G84 D) -> "rated >= 2/4" met.
  Elo 1510 [1390,1640] after 56 rated (flat since T9, within noise). NOT met: zero one-move losses
  (G82 x3, G83 23.g4 e.p., G84 16.Bb4 skewer / 36.Bxg6+ / 39.fxg4); 4 illegal path errors in 6 games.
  The fixed check-node order (capture-by-king first) and en-passant check did work when written (G84 b5 trap).
  Decision: keep T13; add the two scans that cover the remaining root causes (enemy diagonals, recaptures).
- T14 (games 85-90): T13 plus
  (1) ENEMY-SLIDER sweep before submitting: for each enemy Q and B (then R) list the squares it can reach next
      move that attack two of my K/Q/R/loose pieces, or one of them with another behind it on the same line
      (skewer/pin). Diagonals explicitly - both of my Q+R and K+R on a diagonal are targets.
  (2) RECAPTURE check: whenever my plan relies on a capture or recapture (by any piece, incl. the king), list the
      enemy attackers of that square AFTER the exchange, including lines opened by the pieces removed.
  (3) PATH line mandatory for every slider and two-step pawn move ("PATH: e7 d7 empty").
  Observable: zero illegal attempts; zero one-move material losses in rated G87-90; rated >= 2/4. Evaluate after G90.

# Plan and learning log

## Facts about the measurement (from reading the referee code; operator-owned)
- Rotation per 6 games: full-strength W,B; skill-0 W,B; elo-1800 W,B. Engine: 1M nodes/move.
- Elo uses ONLY skill-0 (anchor 1320) and 1800-setting games; rolling window = last 50 rated games.
  200 games -> ~132 rated; final estimate ~ games 125-200.
- Full-strength games are benchmark evidence but excluded from Elo.

## Approach (initial hypothesis, unverified)
Main expected error sources for me: misreading the board, hanging pieces, missing opponent tactics,
illegal-move submissions, sloppy conversion (stalemate/repetition), long games burning budget.
Method: fixed per-move protocol (PROTOCOL.md), simple repertoire (REPERTOIRE.md),
post-game review of every non-win vs rated opponents (own analysis only; no engine),
error taxonomy with recurrence counts (ERRORS.md), targeted practice from my own failed positions.

## Evaluation
Each full rotation (6 games) = checkpoint; compare rated score and error recurrence per 12 games.

## Trials log
- T0 (games 1-6): baseline with PROTOCOL.md + REPERTOIRE.md. Next checkpoint: after game 6.
- T0 result (games 1-6): full 0/2, skill0 2/2, 1800 1/2 (won because opp blundered a knight on move 4; lost G6
  from my own line errors). Elo 1870 [1410,2460] after 4 rated games. Tokens used ~508k (too many: ~85k/game).
- T1 (games 7-12): weakness = line-of-sight errors (pins on defenders, self-blocking, abandoned defences, path
  errors). Trial = explicit LINE AUDIT step in PROTOCOL.md + token discipline (resign hopeless games early).
  Observable: 0 illegal attempts; fewer self-inflicted material losses in rated games (block 1: G6 had 3);
  average tokens/game <= 60k. Next evaluation point: after game 12.
- T1 result (games 7-12): 0/6 (full 0/2, skill0 0/2, 1800 0/2). Line audit helped occasionally (caught Ne7 self-block,
  Bb4?? Qa4+, Qxb2?? Qxe8+) but one-move blunders still decided every game: G9 Qc8??, G10 Rxf3?/Rh1??, G11 Nd4??/Rd4??,
  G12 Kxd5??. Decision: the method is right but the execution is superficial -> T2.
- T2 (games 13-18): explicit SAFETY TABLE every rated move with escape-square enumeration for each enemy check, and the
  KING RULE for endgames. Full-strength games: lighter version, resign hopeless positions early.
  Observable: one-move blunders per rated game (block 2 ~1.5) -> target <=0.5; rated score > 0/4. Evaluate after G18.
- Practice P1 (G12 ply 44, vs 1800, Black, +1 endgame): 30 moves, stopped at +2 (drawish). With written escape-square
  checks: no mate/fork blunders; but 2 "unblocking" oversights + 1 illegal (own K in rook path). Added to table (D).

- T2 RESULT (G13-18): rated 3/4 (was 0/4); Elo 1560 [1310,1810] after 12 rated. Blunder rate ~1/rated game (target
  0.5 missed); errors moved from mate/fork to "attacked-pawn census" and move-shape/path legality. Keep the table.
- T3 (games 19-24): COMPACT protocol + token budget. Each move: (1) census of every enemy line from the piece that just
  moved (all its targets) + list my loose men; (2) 1-3 candidates; (3) compressed safety table (K/S/D/B/C);
  (4) shape+path check for the chosen move (delta, every intermediate square from the FEN, incl. double pawn pushes).
  Budget <=60K tokens/game (185 games left need ~74K/game). Resign lost positions vs full/1800 at once.
  Observable: avg tokens/game <=75K over G19-24 AND rated blunders <=1/game AND 0 illegal attempts. Evaluate after G24.

- T3 RESULT (G19-24): tokens ~44K/game (met), but rated 1/4, Elo 1490 [1270,1700] after 16 rated; blunders >1/game,
  2 illegal. Compactness cut the from/to-square line checks that caught these errors.
- T4 (games 25-30): budget by opponent (full ~20K, rated ~90K) + a mandatory written LINES note on every rated move:
  FROM-sq: 8 lines through it -> enemy slider behind it aiming at my piece/K? what did it guard? TO-sq: whose lines
  does it now block (mine!), who attacks it, and if it is a recapture square is it attacked again (x-ray)?
  + back-rank status + path squares read from FEN. Observable: <=1 decisive blunder in the 4 rated games, 0 illegal.

- T4 RESULT (G25-30): rated 2/4, Elo 1500 [1310,1700] after 20 rated; 0 illegal moves (path check works);
  ~40K tokens/game. Still 2 decisive one-move losses, both missed enemy captures after my move.
- T5 (games 31-36): keep T4 + CAPTURE SCAN: after picking a candidate, for every enemy piece list each of my men it
  attacks in the NEW position (incl. through squares my move vacated) and whether the capture wins material.
  Rated games may use ~60K tokens, full-strength ~20K. Observable: 0 lost-material blunders from enemy captures.
- T5 RESULT (G31-36): rated 2.5/4 (W,W,D,L), Elo 1540 [1360,1710] after 24 rated; but NOT met: 4 material-losing
  misses (G31 Nb3, G34 Qxc2, G35 c6, G36 bxa3/Nxf5+) and 5 illegal attempts; ~85K tokens/game (over budget).
- T6 (games 37-42): THREE WRITTEN LINES before every rated move, no exceptions, kept short:
  P = path: every square between from/to with its occupant (mine too) + "is the mover pinned to my K?";
  F = from-square: what did the mover defend/block (pawns included);
  C = captures: each enemy piece -> which of my men it can now take (knight jumps first, lines through the vacated
  square), and for any capture I make, every recapturer.
  Plus: when ahead, trade pieces; vs full strength resign at -3. Budget: full <=15K, rated <=70K.
  Observable: 0 illegal attempts and <=1 material-losing miss over the 4 rated games. Evaluate after G42.
- T6 RESULT (G37-42): 0/6, rated 0/4 (2 losses to skill 0!), Elo 1460 [1300,1620] after 28 rated. ~36K tokens/game:
  the "three short lines" became perfunctory; misses: battery (G37), king walk into mate (G39), batched second move
  (G40), fork/rank lines (G41), back rank + pin + defender count (G42). 3 illegal attempts. NOT met.
- Budget check: 12.34M tokens / 158 games left. Full-strength games (~53) at <=12K each leave ~110K per rated game.
- T7 (games 43-48): SPEND the budget on rated games (target 90-120K each, no compact mode) and run the FULL check on
  every rated move: (1) what the opponent's last move attacks / opened; (2) 2-3 candidates; (3) for the chosen move:
  path squares incl. my own men, is the mover pinned, what it used to defend; ALL enemy checks and captures after it,
  each with an attacker/defender count including the defenders of the capturing piece; knight forks; back rank.
  Exactly one move command per turn. Full-strength: quick play, resign at -3.
  Observable: rated score >= 2/4 and <= 1 material-losing miss per rated game. Evaluate after G48.
- T7 RESULT (G43-48): rated 2/4 (G45 W, G46 L, G47 W, G48 L), Elo 1470 [1320,1620] after 32 rated (13.5/32).
  Target half met: score 2/4 yes; "<=1 material-losing miss per rated game" yes in count, but each loss was one such
  miss on a "routine" move. Spend ~290K tokens for 6 games (~65K per rated game, under the 90-120K target).
- Budget check: 12.04M tokens / 152 games left -> full-strength ~10K each (~510K), rated ~110K each.
- T8 (games 49-54): (a) RENDERING: mv prints rank-labelled board + piece lists from the FEN (pure rendering, no
  chess logic) so misreads of who stands where drop. (b) NO ROUTINE MOVES: the full enemy-reply scan (every enemy
  piece: its captures and checks after my move, incl. lines through the square I vacated and lines my moved piece
  now shares with an enemy piece) is written for EVERY rated move including development and recaptures; the scan
  must name the enemy pieces one by one. (c) vs skill 0 play safe, simple chess: when ahead, trade; never allow
  counterplay. Observable: rated score >= 3/4, zero one-move material losses. Evaluate after G54.

# Error taxonomy and recurrence (my own post-game assessments; unverified by engine)

Format: game/ply - category - short description

Categories: HANG (left piece en prise), TACTIC (missed opponent tactic: fork/pin/skewer/discovery),
MATE (missed mating threat), READ (board misread / illegal), PLAN (strategic drift), CONV (failed conversion),
OPEN (opening knowledge error), TIME (budget overrun).
- G1/41 - TACTIC(pin) - 21.Qxf7?: counted f2 as defender of Ng3, but f2 was pinned by Bd4 to Kg1 -> ...Qxg3.
- G1/43 - TACTIC(pin) - 22.Qf3??: planned gxf3 recapture; g2 pinned by Rg8 on g-file -> lost queen.
  Lesson: before counting a pawn/piece as a defender or planning a recapture, check it is not pinned to my king.
- G2/30 - READ(path) - 15...Qe7? planned ...Bxd6 vs Nd6+, but Qe7 blocked Bf8 (then submitted illegal Bxd6).
  Lesson: when counting a defender, trace its full path square by square (own pieces block too).
- G2/38 - MATE - 19...Nd8? allowed Qa4+ (only block Nc6) then Qxc6#. King escape squares mis-assessed:
  stepping back along the checking line (Ke8 on a4-e8 diagonal) is illegal.
- G5/77-79 - CONV(line) - 39.Rh8?? Rxh8 40.c8=Q Rxc8: a rook on the 8th rank also attacks my promotion square;
  "my new queen attacks their rook" is meaningless when it's THEIR move. Before promoting, check who controls the square.
- G6/7 - READ(path) - 4...Qd8-b6 submitted: c7 pawn blocks the diagonal (2nd illegal attempt from same cause).
- G6/40 - HANG(removed defender) - 20...Qb6?: Qe6 was the only defender of c4 -> Qxc4. Also walked into Rb1 x-ray:
  Bb2 then pinned in front of Qb6 -> lost a piece.
- G6/54 - HANG(self-block) - 27...Nc5?: knight on c5 blocked Qc7/Rc8 defence of c4 along the c-file -> Rxc4.
- G6 - TIME - ~170k tokens on one game; kept playing a lost position too long.

## Block 1 summary (games 1-6, T0 baseline)
Recurring theme = LINE errors: pins on my defenders (G1 x2), my own pieces blocking my lines (G2, G6 x2 incl. 2 illegal
attempts), abandoning a defended square (G6), enemy rook controlling a promotion square (G5).
- G8/36 - MATE/READ(self-block in calc) - 18...O-O-O?? allowed Ncd6+ Bxd6 Nxd6#: I "planned" Rd8xd6 but my Nd7 blocked
  the d-file, Qa6 blocked by c6, Rh6 by e6. Line audit must also cover the recaptures/defences used in calculation.
- G9/41 - HANG(Q) - 21.Qc8?? "attacks Rh8, Ba8, Nd7" but the Rh8 attacks c8 along the same rank -> Rxc8. 2nd time (G5).
  Root cause: I checked only SOME enemy pieces for attacks on my destination square.
- G9/117 - READ(path) - Rf3-f1 submitted with my own K on f2. Then a careless wrapper "test" (d3d3) = 2nd illegal attempt.
  Rule: NEVER submit anything but an intended, verified move to ./play move.
- G10/60 - TACTIC(fork) - 30...Rxf3?: Ne2-d4+ forked K c6 + Rf3. I checked who attacks f3 now, not the knight's NEXT move.
- G10/74 - MATE - 37...Rh1??: my K on c4 was in a net; Rb2-c2 was mate. I did not list White's checks.
## Block 2 interim (G7-G10): 0/4. Main cause: I do not reliably enumerate the opponent's CHECKS / forks after my move.
- G11/31 - HANG(removed defender) - 16.Be3?: Bc1 was the only defender of b2 -> Bxb2.
- G11/37 - HANG(self-block) - 19.Nb3-d4??: knight on d4 cut Be3's defence of Nc5 -> Bxc5 (lost a knight).
- G11/73 - HANG(destination) - 37.Rd4??: square attacked by Nc6 (I had moved the rook OFF d4 for that reason 3 moves earlier).
- G12/50 - READ - submitted Ke7-e5 (king moved two squares).
- G12/82 - MATE - 41...Kxd5??: listed "Bf3+" as a check but never enumerated escape squares -> Bf3# (Rd6 blocked d6).
## Block 2 summary (G7-G12, T1 line audit): 0/6. Rated: skill0 0/2, 1800 0/2. Every loss came from one-move oversights
(destination attacked, removed/blocked defender, knight forks, mates with the K walking into enemy pieces), several from
winning positions. 3 illegal attempts. The protocol existed but was executed superficially ("... ✓" without checking).

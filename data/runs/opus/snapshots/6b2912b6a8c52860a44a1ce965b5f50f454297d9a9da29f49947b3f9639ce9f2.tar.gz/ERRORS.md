# Error taxonomy and recurrence (my own post-game assessments; unverified by engine)

Format: game/ply - category - short description

Categories: HANG (left piece en prise), TACTIC (missed opponent tactic: fork/pin/skewer/discovery),
MATE (missed mating threat), READ (board misread / illegal), PLAN (strategic drift), CONV (failed conversion),
OPEN (opening knowledge error), TIME (budget overrun).
- G1/41 - TACTIC(pin) - 21.Qxf7?: counted f2 as defender of Ng3, but f2 was pinned by Bd4 to Kg1 -> ...Qxg3.
- G1/43 - TACTIC(pin) - 22.Qf3??: planned gxf3 recapture; g2 pinned by Rg8 on g-file -> lost queen.
  Lesson: before counting a pawn/piece as a defender or planning a recapture, check it is not pinned to my king.
- G2/30 - READ(path) - 15...Qe7? planned ...Bxd6 vs Nd6+, but Qe7 blocked Bf8 (then submitted illegal Bxd6).
  Lesson: when counting a defender, trace its full path square by square (own pieces block too).
- G2/38 - MATE - 19...Nd8? allowed Qa4+ (only block Nc6) then Qxc6#. King escape squares mis-assessed:
  stepping back along the checking line (Ke8 on a4-e8 diagonal) is illegal.
- G5/77-79 - CONV(line) - 39.Rh8?? Rxh8 40.c8=Q Rxc8: a rook on the 8th rank also attacks my promotion square;
  "my new queen attacks their rook" is meaningless when it's THEIR move. Before promoting, check who controls the square.
- G6/7 - READ(path) - 4...Qd8-b6 submitted: c7 pawn blocks the diagonal (2nd illegal attempt from same cause).
- G6/40 - HANG(removed defender) - 20...Qb6?: Qe6 was the only defender of c4 -> Qxc4. Also walked into Rb1 x-ray:
  Bb2 then pinned in front of Qb6 -> lost a piece.
- G6/54 - HANG(self-block) - 27...Nc5?: knight on c5 blocked Qc7/Rc8 defence of c4 along the c-file -> Rxc4.
- G6 - TIME - ~170k tokens on one game; kept playing a lost position too long.

## Block 1 summary (games 1-6, T0 baseline)
Recurring theme = LINE errors: pins on my defenders (G1 x2), my own pieces blocking my lines (G2, G6 x2 incl. 2 illegal
attempts), abandoning a defended square (G6), enemy rook controlling a promotion square (G5).
- G8/36 - MATE/READ(self-block in calc) - 18...O-O-O?? allowed Ncd6+ Bxd6 Nxd6#: I "planned" Rd8xd6 but my Nd7 blocked
  the d-file, Qa6 blocked by c6, Rh6 by e6. Line audit must also cover the recaptures/defences used in calculation.
- G9/41 - HANG(Q) - 21.Qc8?? "attacks Rh8, Ba8, Nd7" but the Rh8 attacks c8 along the same rank -> Rxc8. 2nd time (G5).
  Root cause: I checked only SOME enemy pieces for attacks on my destination square.
- G9/117 - READ(path) - Rf3-f1 submitted with my own K on f2. Then a careless wrapper "test" (d3d3) = 2nd illegal attempt.
  Rule: NEVER submit anything but an intended, verified move to ./play move.
- G10/60 - TACTIC(fork) - 30...Rxf3?: Ne2-d4+ forked K c6 + Rf3. I checked who attacks f3 now, not the knight's NEXT move.
- G10/74 - MATE - 37...Rh1??: my K on c4 was in a net; Rb2-c2 was mate. I did not list White's checks.
## Block 2 interim (G7-G10): 0/4. Main cause: I do not reliably enumerate the opponent's CHECKS / forks after my move.
- G11/31 - HANG(removed defender) - 16.Be3?: Bc1 was the only defender of b2 -> Bxb2.
- G11/37 - HANG(self-block) - 19.Nb3-d4??: knight on d4 cut Be3's defence of Nc5 -> Bxc5 (lost a knight).
- G11/73 - HANG(destination) - 37.Rd4??: square attacked by Nc6 (I had moved the rook OFF d4 for that reason 3 moves earlier).
- G12/50 - READ - submitted Ke7-e5 (king moved two squares).
- G12/82 - MATE - 41...Kxd5??: listed "Bf3+" as a check but never enumerated escape squares -> Bf3# (Rd6 blocked d6).
## Block 2 summary (G7-G12, T1 line audit): 0/6. Rated: skill0 0/2, 1800 0/2. Every loss came from one-move oversights
(destination attacked, removed/blocked defender, knight forks, mates with the K walking into enemy pieces), several from
winning positions. 3 illegal attempts. The protocol existed but was executed superficially ("... ✓" without checking).
- G13/25 - HANG(destination) - 13.Rfb1??: b1 on the f5-b1 diagonal of Bf5. Skipped the table because "unrated" -> habit leak.
  Rule: the destination check (S) is never optional, in any game.
- G14/34 - TACTIC(discovered/unblocking) - my Qa6 sat on the d3-a6 diagonal behind W's Nc4; Ncd6+ (with tempo)
  unmasked Qd3xa6. Same blind spot as the P1 drill: lines that open when an ENEMY piece moves (discoveries).
- G15/33 - HANG(destination) - 17.Ne5?: e5 attacked by Ng6 AND Re8 (open e-file); I listed only the knight.
- G15/45 - TACTIC(fork) - 23.Rd3?: allowed Ng6xe5 forking Qc4+Rd3 (didn't list knight targets after my move).
- G16/42 - READ(path) - Bf5-d7 submitted through my own e6 pawn (6th path error: G2,G6,G9,G12,P1,G16).
  My own PAWNS are the usual blockers I forget. Rule: read the FEN rank of every intermediate square.
- G17/65 - READ(path) - f2-f4 double push through my own Bf3 (7th path error). Double pawn pushes need the
  intermediate square empty too. Also caught in-game (not played): 26.Rd2? Rc1+ Bd1 Bc2! back-rank mate motifs;
  Rd2 next to an enemy rook on c2 is simply hanging; 53.g6? Rh5+ (unblocking rank 5) would have lost the g-pawn.
- G18/80 - HANG(census) - 40...Qd7?: W's Qc6 attacked c7 AND c4 (down the c-file); I counted only c7. c4 had lost its
  only defender 5 moves earlier (35...Qd7 left the c-file). Fix: every move, census ALL my men attacked by the last-moved
  piece (all 8 lines of a queen), with attacker/defender counts. -> lost pawn, then a 2nd pawn, then mated material.
- G18/49 - READ(shape) - Qf6-d5 submitted: not on a rank/file/diagonal. Fix: before any long move write the delta
  (files, ranks): queen/rook/bishop moves need df=0, dr=0 or |df|=|dr|.
## Block 3 summary (G13-G18, T2 safety table): 3/6 overall, rated 3/4 (skill0 2/2, 1800 1/2) vs block 2 rated 0/4.
Rated-game blunders ~1.0/game (target 0.5 not met), 3 illegal attempts (path x2, shape x1). Big win: endgame technique
(G17 R+2P v R, KR v K). Main costs: token use (G17 ~300K, G18 ~135K) and incomplete threat census.
- G19/25 - HANG(self-block) - 13.Nf3? put my knight on the d1-g4 line that defended g4 -> Bxg4. "B" in the table
  (does the destination block my own lines?) was skipped.
- G19/27 - READ(path) - Bc4-e2 through my own d3 pawn (8th path error; 6 of 8 involve my own pawns).
- G19/33 - TACTIC(discovery) - 17.Bxa6?: Ba7 screened Ra8 from a6; ...Bc5 (tempo on Qb4) unmasked it. Before moving a
  piece onto a line, list enemy pieces BEHIND enemy pieces on that line.
- G20/44 - TACTIC(discovered double check) - my K on the open e-file behind W's Ne6 with Re1 behind: any knight move
  = discovered check. Rule: if my K is on a line with an enemy slider and only an ENEMY piece between, treat every
  move of that piece as check and get the K off the line first (22...Kf7/Kd7 ideas came too late).
- G21/31 - HANG(unblock) - 16.Na3??: my Nb5 was the only piece between Black's Bc6 and my Qa4. Moving it = Bxa4.
  This is the 4th "moving piece was screening an enemy line" loss (G14, P1, G19, G21). Rule (D): before ANY move,
  draw the 8 lines through the FROM-square and ask "which enemy slider sees through it to my piece/K?"
- G21/95 - READ(path) - Be7-b4 through my own c5 pawn (9th path error; 7 involve my own pawns).
- G22/32 - HANG(guard removal) - my Nd3 had ONE defender (Bg6) that W could simply capture (Nxg6). A piece guarded
  only by a capturable piece is effectively loose. Census must count "removable defenders".
- G22/59 - MATE(back rank) - K g8 + f7/g7/h7, both rooks left rank 8, no luft -> Ra8+ and every block fails.
  Rule: before moving my LAST rook off the back rank, play h6/g6 (luft) unless enemy rooks/queen can't reach rank 8.
- G23/45 - HANG(x-ray recapture) - e4 was "defended" by my Q, but the recapture square was attacked by Ra4 along
  rank 4 -> Nxe4 won a pawn. A defender only counts if recapturing doesn't hang it.
- G23/65 - TACTIC(sac miscalc) - 33.Bxh6?? planned Qxh6+ but forgot the enemy KING can capture an undefended
  checking piece next to it. Every sacrificial line: after each of my checks, can the king just take?
- G24/41 - HANG(self-block) - 21...Ke7?? blocked Re8's defence of Be5 (K stepped onto the e-file between them).
## Block 4 summary (G19-24, T3 compact protocol): 1/6, rated 1/4 (skill0 1/2, 1800 0/2). Avg ~44K tokens/game (budget
met) but decisive blunders in 5 games, 2 illegal path errors. Nearly all are LINE errors of the moving piece:
unblocking an enemy line (G21), blocking my own defensive line (G19 Nf3, G24 Ke7), removable/x-rayed defenders
(G22, G23), plus 1 back-rank mate (G22) and 1 sac miscalc (G23).
- G28/56 - TACTIC(check+second target) - 28.Qg6+ also attacked Re8 along g6-f7-e8. When answering a check, list
  EVERY other piece the checking piece attacks (and what my block uncovers) before choosing the reply.
- G28/68 - TACTIC(check+second target) - 34.Qd3+ also hit the undefended Bd5. Same pattern twice in one game.
- G29/15 - HANG(guard removal) - 8.Qa4?? left Bc1 (on the open c-file facing Qc7) with no defender. The FROM-square
  check must list what the moving piece GUARDS, especially pieces on files/diagonals an enemy queen already sees.
## Block 5 summary (G25-30, T4 written FROM/TO line check): 2/6, rated 2/4 (skill0 1/2, 1800 1/2), 0 illegal (first
block ever), ~40K tokens/game. Decisive blunders: G28 (block of check allowed Qxe8+), G29 (Qa4 dropped Bc1 to Qxc1+).
Both = an enemy CAPTURE available right after my move that I never listed.
- G31/33 HANG(to-square line): Nb3?? onto the b-file of Rb6 (b6-b5-b4-b3 empty). I had noted "Rb6 sees b1" one move
  earlier but checked only what Nb3 attacked, not who attacked b3. Rule: for the TO-square, scan its 8 lines + 8 knight
  squares for enemy attackers EVERY time (T5 capture scan applies to full-strength games too).
- G32/44 KING(open centre): Ke7 king in the centre with Re1 + queen checks (Qa3+ on the a3-e7 diagonal) -> e6 fell
  with a Q-for-R+N trade. When my king stands on an open file/diagonal, list every enemy queen CHECK next move.
- G34/22 HANG(defender census): Qxc2?? counted only Qd1 as c2's defender; Ne3 also covered c2 (I had listed it
  4 moves earlier). Before any capture, list EVERY enemy piece that can recapture - knights first.
- G34/18 READ(diagonal): Rfc8 onto the h3-c8 diagonal of Bh3 (opponent missed it).
- G34/52 ILLEGAL(check line): Kd6-e7 stayed on the checking queen's diagonal b4-e7. A king can never retreat along
  the line of a checking slider; squares behind the king on that line are attacked.
- G35/42 HANG(pawn was the defender): c5-c6 pushed the ONLY defender of Bb6 (Rb8 x-ray); before any pawn push,
  ask "what did this pawn defend?" (the from-square rule applies to pawns too).
- G35 ILLEGAL x3: Qd5-b5 through own Bc5; Rc7-f7 through own d7 pawn; f4xg5 with Kf5 pinned on the f-file by Rf2.
  The path check must include MY OWN men, and every pawn/king-adjacent piece must be checked for pins to my king.
- G35/63 STALEMATE TRICK: with R+P v R and the enemy king boxed, a rook "sac" next to my king can be stalemate.
  Before Kg6 (adjacent to f6) ask: if he gives up his rook, does his king still have a move?
- G36/23 HANG(discovered line): ...bxa3 e.p. vacated b4 and opened Bd2's diagonal to my Na5, whose only "defender"
  (Qb5) could not recapture because Nc4 covered a5. When a pawn/piece leaves a square, scan enemy sliders through it.
- G36/57 FORK(knight check): ...Qg7?? allowed Nd4xf5+ hitting K h6, Q g7, R d6. List every enemy knight check.
- Block 6 summary (G31-36): 2.5/6, rated 2.5/4, Elo 1540 [1360,1710] after 24 rated. 5 illegal attempts (3 through
  my OWN pieces, 1 pinned pawn, 1 king on the checking line). ~85K tokens/game. T5 capture-scan was skipped on the
  moves that lost material - adherence, not knowledge, is the bottleneck.
- G37/17 HANG(battery): Rac1 put a rook on a file where Q+R were lined up; count the battery (Q in front, R behind)
  as two attackers. G37/23 READ(board): Kg2 illegal - my own g2 pawn (doubled g-pawns after hxg3).
- G39/26 KING WALK: with enemy R+N+B near my open king, I answered Rc1+ with Kg2 instead of Rf1 (block = rook trade).
  Two checks later every king square was covered -> mate. RULE: when checked near my king and a block trades pieces,
  BLOCK; before any king move, list the enemy's next checks and the king's flight squares after each.
- G40/21 PROCESS: I emitted TWO move commands in one turn (a6 and an unanalysed c8c3); 21...Rxc3?? bxc3 lost a rook
  for a pawn. HARD RULE: exactly one ./play move call per turn; never batch move calls.
- G40/33 FORK(bishop check): ...g5 left the b1-h7 diagonal open to Bd3+ hitting Kh7 and Rc2 at once.
  Before every move list enemy CHECKS (all pieces) and what else each checking move attacks.
- G41/38 COUNT(exchange): a rook "defended" by a knight but attacked by a bishop is still lost for B-for-R. When a
  bishop forks R+N, defending the rook is not enough; move the rook or counter-attack.
- G41/48 HANG(rank line): Bxh4 onto the 4th rank where Rc4 had an open line (d4-g4 empty). Rooks see whole ranks.
- G42/27 BACK RANK: grabbing a3 put my N on the a-file as the only shield vs Ra8+ with no luft. Make luft BEFORE
  rook/knight raids. G42/49 ILLEGAL: Rb2 pinned to Ka3 by Bc1 (moving K next to own R on a diagonal = pin).
  G42/53 COUNT: c3+ "attacks" assumed Rxc3 Kxc3, but Kd2 guarded c3. Count defenders of the ENEMY capturer too.
- G44/25 PROCESS AGAIN: batched c5b4 + b6a6 in one turn (second move unseen). One call per message, always.
- G45/10 PROCESS x3: batched Be3+Qd2. Before sending, count tool calls in the message: must be ONE.
- G46/26 PROCESS x4: batched Rd8+Rcc8 -> Bh3 hit Rc8. Added a 5-second guard to workspace/tools/mv.
- G46/62 HANG(pawn capture): Bc7 next to an enemy pawn on b6 (pawns capture diagonally forward: b6 hits a7/c7).
  In endgames list the capture squares of EVERY enemy pawn before placing a piece. Also illegal f7-f5 through own Bf6.
- G48/10 HANG(mutual attack): Bf5 'attacking' Qc2 on the same diagonal - the queen attacks the bishop too, and it was undefended -> Qxf5. A piece that attacks along a line is attacked back along that line.

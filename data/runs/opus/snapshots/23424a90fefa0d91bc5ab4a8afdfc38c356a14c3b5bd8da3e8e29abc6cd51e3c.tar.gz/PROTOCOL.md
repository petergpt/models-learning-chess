# Move protocol (read before each game; keep short)

Board reading: python-chess ASCII, rank 8 at top, files a..h left->right. UPPER = White, lower = Black.
Index each row carefully (count 8 cells). Cross-check suspicious squares against the FEN.
UCI only: e2e4, castling e1g1/e1c1/e8g8/e8c8, promotion e7e8q. 3 illegal tries on one turn = forfeit.

Every move:
1. Opponent's last move: what does it attack / threaten now (checks, captures, forks, discovered lines,
   mate threats)? What did it stop guarding?
2. My loose pieces: anything attacked and under-defended, or attacked by a cheaper piece?
3. Candidates: my checks, captures, threats first; then the plan move.
4. Before submitting the chosen move:
   a. Legality: from-square holds my piece; path empty; piece not pinned; king not left in check.
   b. Blunder check: after the move, list EVERY opponent check and capture (incl. queen/bishop long
      diagonals, knight forks, back rank). Does anything lose material or allow mate?
   c. What did the moving piece stop defending?
   d. PINS: any of my recapturing/defending pawns or pieces pinned to my king (open files/diagonals
      to the king)? A pinned unit is not a defender. (G1: lost queen to this.)

Conversion (ahead in material): trade pieces not pawns, keep king safe, push passers, mate methodically.
STALEMATE CHECK whenever opponent has only king (+ blocked pawns): after my move, does their king have a move?
Draw claims are automatic: avoid repeating positions when winning.

# Error taxonomy and recurrence (my own post-game assessments; unverified by engine)

Format: game/ply - category - short description

Categories: HANG (left piece en prise), TACTIC (missed opponent tactic: fork/pin/skewer/discovery),
MATE (missed mating threat), READ (board misread / illegal), PLAN (strategic drift), CONV (failed conversion),
OPEN (opening knowledge error), TIME (budget overrun).
- G1/41 - TACTIC(pin) - 21.Qxf7?: counted f2 as defender of Ng3, but f2 was pinned by Bd4 to Kg1 -> ...Qxg3.
- G1/43 - TACTIC(pin) - 22.Qf3??: planned gxf3 recapture; g2 pinned by Rg8 on g-file -> lost queen.
  Lesson: before counting a pawn/piece as a defender or planning a recapture, check it is not pinned to my king.
- G2/30 - READ(path) - 15...Qe7? planned ...Bxd6 vs Nd6+, but Qe7 blocked Bf8 (then submitted illegal Bxd6).
  Lesson: when counting a defender, trace its full path square by square (own pieces block too).
- G2/38 - MATE - 19...Nd8? allowed Qa4+ (only block Nc6) then Qxc6#. King escape squares mis-assessed:
  stepping back along the checking line (Ke8 on a4-e8 diagonal) is illegal.
- G5/77-79 - CONV(line) - 39.Rh8?? Rxh8 40.c8=Q Rxc8: a rook on the 8th rank also attacks my promotion square;
  "my new queen attacks their rook" is meaningless when it's THEIR move. Before promoting, check who controls the square.
- G6/7 - READ(path) - 4...Qd8-b6 submitted: c7 pawn blocks the diagonal (2nd illegal attempt from same cause).
- G6/40 - HANG(removed defender) - 20...Qb6?: Qe6 was the only defender of c4 -> Qxc4. Also walked into Rb1 x-ray:
  Bb2 then pinned in front of Qb6 -> lost a piece.
- G6/54 - HANG(self-block) - 27...Nc5?: knight on c5 blocked Qc7/Rc8 defence of c4 along the c-file -> Rxc4.
- G6 - TIME - ~170k tokens on one game; kept playing a lost position too long.

## Block 1 summary (games 1-6, T0 baseline)
Recurring theme = LINE errors: pins on my defenders (G1 x2), my own pieces blocking my lines (G2, G6 x2 incl. 2 illegal
attempts), abandoning a defended square (G6), enemy rook controlling a promotion square (G5).
- G8/36 - MATE/READ(self-block in calc) - 18...O-O-O?? allowed Ncd6+ Bxd6 Nxd6#: I "planned" Rd8xd6 but my Nd7 blocked
  the d-file, Qa6 blocked by c6, Rh6 by e6. Line audit must also cover the recaptures/defences used in calculation.
- G9/41 - HANG(Q) - 21.Qc8?? "attacks Rh8, Ba8, Nd7" but the Rh8 attacks c8 along the same rank -> Rxc8. 2nd time (G5).
  Root cause: I checked only SOME enemy pieces for attacks on my destination square.
- G9/117 - READ(path) - Rf3-f1 submitted with my own K on f2. Then a careless wrapper "test" (d3d3) = 2nd illegal attempt.
  Rule: NEVER submit anything but an intended, verified move to ./play move.
- G10/60 - TACTIC(fork) - 30...Rxf3?: Ne2-d4+ forked K c6 + Rf3. I checked who attacks f3 now, not the knight's NEXT move.
- G10/74 - MATE - 37...Rh1??: my K on c4 was in a net; Rb2-c2 was mate. I did not list White's checks.
## Block 2 interim (G7-G10): 0/4. Main cause: I do not reliably enumerate the opponent's CHECKS / forks after my move.
- G11/31 - HANG(removed defender) - 16.Be3?: Bc1 was the only defender of b2 -> Bxb2.
- G11/37 - HANG(self-block) - 19.Nb3-d4??: knight on d4 cut Be3's defence of Nc5 -> Bxc5 (lost a knight).
- G11/73 - HANG(destination) - 37.Rd4??: square attacked by Nc6 (I had moved the rook OFF d4 for that reason 3 moves earlier).
- G12/50 - READ - submitted Ke7-e5 (king moved two squares).
- G12/82 - MATE - 41...Kxd5??: listed "Bf3+" as a check but never enumerated escape squares -> Bf3# (Rd6 blocked d6).
## Block 2 summary (G7-G12, T1 line audit): 0/6. Rated: skill0 0/2, 1800 0/2. Every loss came from one-move oversights
(destination attacked, removed/blocked defender, knight forks, mates with the K walking into enemy pieces), several from
winning positions. 3 illegal attempts. The protocol existed but was executed superficially ("... ✓" without checking).
- G13/25 - HANG(destination) - 13.Rfb1??: b1 on the f5-b1 diagonal of Bf5. Skipped the table because "unrated" -> habit leak.
  Rule: the destination check (S) is never optional, in any game.
- G14/34 - TACTIC(discovered/unblocking) - my Qa6 sat on the d3-a6 diagonal behind W's Nc4; Ncd6+ (with tempo)
  unmasked Qd3xa6. Same blind spot as the P1 drill: lines that open when an ENEMY piece moves (discoveries).
- G15/33 - HANG(destination) - 17.Ne5?: e5 attacked by Ng6 AND Re8 (open e-file); I listed only the knight.
- G15/45 - TACTIC(fork) - 23.Rd3?: allowed Ng6xe5 forking Qc4+Rd3 (didn't list knight targets after my move).
- G16/42 - READ(path) - Bf5-d7 submitted through my own e6 pawn (6th path error: G2,G6,G9,G12,P1,G16).
  My own PAWNS are the usual blockers I forget. Rule: read the FEN rank of every intermediate square.
- G17/65 - READ(path) - f2-f4 double push through my own Bf3 (7th path error). Double pawn pushes need the
  intermediate square empty too. Also caught in-game (not played): 26.Rd2? Rc1+ Bd1 Bc2! back-rank mate motifs;
  Rd2 next to an enemy rook on c2 is simply hanging; 53.g6? Rh5+ (unblocking rank 5) would have lost the g-pawn.
- G18/80 - HANG(census) - 40...Qd7?: W's Qc6 attacked c7 AND c4 (down the c-file); I counted only c7. c4 had lost its
  only defender 5 moves earlier (35...Qd7 left the c-file). Fix: every move, census ALL my men attacked by the last-moved
  piece (all 8 lines of a queen), with attacker/defender counts. -> lost pawn, then a 2nd pawn, then mated material.
- G18/49 - READ(shape) - Qf6-d5 submitted: not on a rank/file/diagonal. Fix: before any long move write the delta
  (files, ranks): queen/rook/bishop moves need df=0, dr=0 or |df|=|dr|.
## Block 3 summary (G13-G18, T2 safety table): 3/6 overall, rated 3/4 (skill0 2/2, 1800 1/2) vs block 2 rated 0/4.
Rated-game blunders ~1.0/game (target 0.5 not met), 3 illegal attempts (path x2, shape x1). Big win: endgame technique
(G17 R+2P v R, KR v K). Main costs: token use (G17 ~300K, G18 ~135K) and incomplete threat census.
- G19/25 - HANG(self-block) - 13.Nf3? put my knight on the d1-g4 line that defended g4 -> Bxg4. "B" in the table
  (does the destination block my own lines?) was skipped.
- G19/27 - READ(path) - Bc4-e2 through my own d3 pawn (8th path error; 6 of 8 involve my own pawns).
- G19/33 - TACTIC(discovery) - 17.Bxa6?: Ba7 screened Ra8 from a6; ...Bc5 (tempo on Qb4) unmasked it. Before moving a
  piece onto a line, list enemy pieces BEHIND enemy pieces on that line.
- G20/44 - TACTIC(discovered double check) - my K on the open e-file behind W's Ne6 with Re1 behind: any knight move
  = discovered check. Rule: if my K is on a line with an enemy slider and only an ENEMY piece between, treat every
  move of that piece as check and get the K off the line first (22...Kf7/Kd7 ideas came too late).
- G21/31 - HANG(unblock) - 16.Na3??: my Nb5 was the only piece between Black's Bc6 and my Qa4. Moving it = Bxa4.
  This is the 4th "moving piece was screening an enemy line" loss (G14, P1, G19, G21). Rule (D): before ANY move,
  draw the 8 lines through the FROM-square and ask "which enemy slider sees through it to my piece/K?"
- G21/95 - READ(path) - Be7-b4 through my own c5 pawn (9th path error; 7 involve my own pawns).
- G22/32 - HANG(guard removal) - my Nd3 had ONE defender (Bg6) that W could simply capture (Nxg6). A piece guarded
  only by a capturable piece is effectively loose. Census must count "removable defenders".
- G22/59 - MATE(back rank) - K g8 + f7/g7/h7, both rooks left rank 8, no luft -> Ra8+ and every block fails.
  Rule: before moving my LAST rook off the back rank, play h6/g6 (luft) unless enemy rooks/queen can't reach rank 8.
- G23/45 - HANG(x-ray recapture) - e4 was "defended" by my Q, but the recapture square was attacked by Ra4 along
  rank 4 -> Nxe4 won a pawn. A defender only counts if recapturing doesn't hang it.
- G23/65 - TACTIC(sac miscalc) - 33.Bxh6?? planned Qxh6+ but forgot the enemy KING can capture an undefended
  checking piece next to it. Every sacrificial line: after each of my checks, can the king just take?
- G24/41 - HANG(self-block) - 21...Ke7?? blocked Re8's defence of Be5 (K stepped onto the e-file between them).
## Block 4 summary (G19-24, T3 compact protocol): 1/6, rated 1/4 (skill0 1/2, 1800 0/2). Avg ~44K tokens/game (budget
met) but decisive blunders in 5 games, 2 illegal path errors. Nearly all are LINE errors of the moving piece:
unblocking an enemy line (G21), blocking my own defensive line (G19 Nf3, G24 Ke7), removable/x-rayed defenders
(G22, G23), plus 1 back-rank mate (G22) and 1 sac miscalc (G23).
- G28/56 - TACTIC(check+second target) - 28.Qg6+ also attacked Re8 along g6-f7-e8. When answering a check, list
  EVERY other piece the checking piece attacks (and what my block uncovers) before choosing the reply.
- G28/68 - TACTIC(check+second target) - 34.Qd3+ also hit the undefended Bd5. Same pattern twice in one game.
- G29/15 - HANG(guard removal) - 8.Qa4?? left Bc1 (on the open c-file facing Qc7) with no defender. The FROM-square
  check must list what the moving piece GUARDS, especially pieces on files/diagonals an enemy queen already sees.
## Block 5 summary (G25-30, T4 written FROM/TO line check): 2/6, rated 2/4 (skill0 1/2, 1800 1/2), 0 illegal (first
block ever), ~40K tokens/game. Decisive blunders: G28 (block of check allowed Qxe8+), G29 (Qa4 dropped Bc1 to Qxc1+).
Both = an enemy CAPTURE available right after my move that I never listed.
- G31/33 HANG(to-square line): Nb3?? onto the b-file of Rb6 (b6-b5-b4-b3 empty). I had noted "Rb6 sees b1" one move
  earlier but checked only what Nb3 attacked, not who attacked b3. Rule: for the TO-square, scan its 8 lines + 8 knight
  squares for enemy attackers EVERY time (T5 capture scan applies to full-strength games too).
- G32/44 KING(open centre): Ke7 king in the centre with Re1 + queen checks (Qa3+ on the a3-e7 diagonal) -> e6 fell
  with a Q-for-R+N trade. When my king stands on an open file/diagonal, list every enemy queen CHECK next move.
- G34/22 HANG(defender census): Qxc2?? counted only Qd1 as c2's defender; Ne3 also covered c2 (I had listed it
  4 moves earlier). Before any capture, list EVERY enemy piece that can recapture - knights first.
- G34/18 READ(diagonal): Rfc8 onto the h3-c8 diagonal of Bh3 (opponent missed it).
- G34/52 ILLEGAL(check line): Kd6-e7 stayed on the checking queen's diagonal b4-e7. A king can never retreat along
  the line of a checking slider; squares behind the king on that line are attacked.
- G35/42 HANG(pawn was the defender): c5-c6 pushed the ONLY defender of Bb6 (Rb8 x-ray); before any pawn push,
  ask "what did this pawn defend?" (the from-square rule applies to pawns too).
- G35 ILLEGAL x3: Qd5-b5 through own Bc5; Rc7-f7 through own d7 pawn; f4xg5 with Kf5 pinned on the f-file by Rf2.
  The path check must include MY OWN men, and every pawn/king-adjacent piece must be checked for pins to my king.
- G35/63 STALEMATE TRICK: with R+P v R and the enemy king boxed, a rook "sac" next to my king can be stalemate.
  Before Kg6 (adjacent to f6) ask: if he gives up his rook, does his king still have a move?
- G36/23 HANG(discovered line): ...bxa3 e.p. vacated b4 and opened Bd2's diagonal to my Na5, whose only "defender"
  (Qb5) could not recapture because Nc4 covered a5. When a pawn/piece leaves a square, scan enemy sliders through it.
- G36/57 FORK(knight check): ...Qg7?? allowed Nd4xf5+ hitting K h6, Q g7, R d6. List every enemy knight check.
- Block 6 summary (G31-36): 2.5/6, rated 2.5/4, Elo 1540 [1360,1710] after 24 rated. 5 illegal attempts (3 through
  my OWN pieces, 1 pinned pawn, 1 king on the checking line). ~85K tokens/game. T5 capture-scan was skipped on the
  moves that lost material - adherence, not knowledge, is the bottleneck.
- G37/17 HANG(battery): Rac1 put a rook on a file where Q+R were lined up; count the battery (Q in front, R behind)
  as two attackers. G37/23 READ(board): Kg2 illegal - my own g2 pawn (doubled g-pawns after hxg3).
- G39/26 KING WALK: with enemy R+N+B near my open king, I answered Rc1+ with Kg2 instead of Rf1 (block = rook trade).
  Two checks later every king square was covered -> mate. RULE: when checked near my king and a block trades pieces,
  BLOCK; before any king move, list the enemy's next checks and the king's flight squares after each.
- G40/21 PROCESS: I emitted TWO move commands in one turn (a6 and an unanalysed c8c3); 21...Rxc3?? bxc3 lost a rook
  for a pawn. HARD RULE: exactly one ./play move call per turn; never batch move calls.
- G40/33 FORK(bishop check): ...g5 left the b1-h7 diagonal open to Bd3+ hitting Kh7 and Rc2 at once.
  Before every move list enemy CHECKS (all pieces) and what else each checking move attacks.
- G41/38 COUNT(exchange): a rook "defended" by a knight but attacked by a bishop is still lost for B-for-R. When a
  bishop forks R+N, defending the rook is not enough; move the rook or counter-attack.
- G41/48 HANG(rank line): Bxh4 onto the 4th rank where Rc4 had an open line (d4-g4 empty). Rooks see whole ranks.
- G42/27 BACK RANK: grabbing a3 put my N on the a-file as the only shield vs Ra8+ with no luft. Make luft BEFORE
  rook/knight raids. G42/49 ILLEGAL: Rb2 pinned to Ka3 by Bc1 (moving K next to own R on a diagonal = pin).
  G42/53 COUNT: c3+ "attacks" assumed Rxc3 Kxc3, but Kd2 guarded c3. Count defenders of the ENEMY capturer too.
- G44/25 PROCESS AGAIN: batched c5b4 + b6a6 in one turn (second move unseen). One call per message, always.
- G45/10 PROCESS x3: batched Be3+Qd2. Before sending, count tool calls in the message: must be ONE.
- G46/26 PROCESS x4: batched Rd8+Rcc8 -> Bh3 hit Rc8. Added a 5-second guard to workspace/tools/mv.
- G46/62 HANG(pawn capture): Bc7 next to an enemy pawn on b6 (pawns capture diagonally forward: b6 hits a7/c7).
  In endgames list the capture squares of EVERY enemy pawn before placing a piece. Also illegal f7-f5 through own Bf6.
- G48/10 HANG(mutual attack): Bf5 'attacking' Qc2 on the same diagonal - the queen attacks the bishop too, and it was undefended -> Qxf5. A piece that attacks along a line is attacked back along that line.
- Block 8 (G43-48) summary: rated 2/4 (W L W L), Elo 1470 [1320,1620] after 32 rated. Decisive misses: G46/62 pawn
  capture square, G48/10 mutual line attack; process slips: 3 batched moves (G44-46), 2 illegal (G44, G48).
  Pattern unchanged since block 4: the losing move is almost always a ONE-MOVE oversight on a move I thought was
  "routine" (development, recapture, endgame shuffle) - not a deep tactic.
- G49/27 HANG(mutual line, same FILE): Black's Rb3 attacked c3 AND my Rb5 up the b-file (b4 empty); I read only the
  c3 threat and played Ke2. Rxb3 was available. RULE: after every enemy slider move, trace ALL its lines (rook 4,
  bishop 4, queen 8) square by square to the first piece and name it - "Rb3: b4 . b5 = MY ROOK".
- G50/16 ILLEGAL: Qd5-f5 along rank 5 straight through White's e5 pawn. Path check must list EVERY square (e5!).
- G50/19-21 KING IN THE CENTRE x3 (G32, G44, G50): uncastled K with Ng8 at home; after Rc8+ the K had no squares
  (e5 pawn covers d6; rook on c8 covers d8/e8). RULE: develop the g8 knight and castle before move 12 unless there is
  a concrete reason; when my K is uncastled, count its flight squares after each enemy check before choosing.
- G51/18 ILLEGAL: Qb8-b4 through Black's b7 pawn (2nd queen-path illegal in 2 games). RULE for every slider move of
  2+ squares: write the path as "b7? b6? b5?" and look each square up in the piece list before sending.
- G52/30 COUNT(fork that isn't): "exd3+ forks K and R" ignored that the checking pawn could simply be captured (Rxd3).
  A fork by a pawn/piece only works if the forking unit cannot be taken.
- G52/43 ILLEGAL: Nf3-g4 is not a knight move. Knight squares from f3: d2 d4 e1 e5 g1 g5 h2 h4 - list them.
- G52/87 SKEWER: Ke3 put my K on the same rank as my own Rc3 with the enemy R able to check along it (Rg3+).
  Before a K move in R endings: is my K about to share a line with my own R that an enemy R can reach with check?
- G53/39 BACK RANK (won game thrown away): luft h3 made h2 the K's only square, but Black's Be5 covered h2 along b8-h2.
  My check scan said "Rc1+ -> Kh2" without testing h2. RULE: an escape square counts only after I check every enemy
  line into it (bishop diagonals included). In endgames with my K on the back rank: list K squares + which enemy piece
  covers each; if all covered, the back rank must stay blockable/defended before any other plan.
- G54/16 COUNT(pawn defender): "Bxg4 Bxg4 Qxg4" - h3 pawn also guarded g4. G54/22: noticed in time that gxf5 was
  illegal (g6 pinned by Rg2 to Kg8). G54/27-28: K h7 with the g-file open to Rg2 and Q coming to h5: no escape squares.
- Block 9 (G49-54) summary: rated 1.5/4 (W D L L), Elo 1470 [1320,1610] after 36 rated. T8 piece-by-piece enemy scans
  were long but still missed single lines: pawn defenders (G54), bishop covering the luft square (G53), own-K/own-R
  line (G52), same-file rook (G49). The misses are always "is square X attacked?" questions answered from memory.
- G58/28-29 PIN ON MY K: ...g5 vacated g6 and put Kh7 on the d3-h7 diagonal behind my Re4 (Qd3 then f3 won it; W
  missed). G58/41 X-RAY: R on e7 "defended twice (Q,K)" vs two attackers, but the second W rook stood behind the first
  (Re5+Re1): the K cannot recapture on a square the x-ray rook still sees. Count x-ray attackers behind the first one.
- G59/23 VACATED LINE (queen lost): Re3-g3 unblocked g5-f4-e3-d2; I scanned g3 (destination) but not e3 (origin).
  RULE: the SQUARE SCAN must be run on the ORIGIN square too: which enemy rays pass through it, and what do they hit
  once it is empty? (Same family as G36 e.p. and G49.)
- Block 10 (G55-60) summary: rated 2/4 (W L L W), Elo 1480 [1340,1610] after 40 rated. 0 illegal attempts in rated
  games (1 in full-strength G55). Square scans caught G57 15.g3?? Qh2# and G60 Bxh7+/Ng5 ideas. Remaining misses:
  x-ray battery behind the first attacker (G58/41) and the ORIGIN square's opened line (G59/23).
- G61/21 BACK RANK again (cf. G42, G53): K g1 with f2/g2/h2 and one rook; Q+R could deliver Rc1+ with the blocker
  then left loose. RULE: once queens/rooks are active and my last rook may be drawn away, play h3/g3 BEFORE anything else.

## G64 (skill0, B, won) notes
- 13...Bxe5 (taking a checking N) left my B on e5 en prise to d4 AND let 14.Ba6 hit the undefended Rb7: two hanging pieces at once. Rule: before a capture, list every piece of mine that is attacked AFTER the recapture move too (here: Rb7 on the a6-c8 diagonal).
- Doubled enemy rooks on my 7th with my K on the back rank = forced mate pattern (Rf7+, Rxg7+, Rxh7+, Rag7+, Rh8#). My own Rb8 does not cover f8-h8 when my K stands between. Defence must be prepared BEFORE the second rook arrives: knight covering f7/h7 (Ng5), or K off the back rank in front of pawns.
- Good: knight fork sequence Ng5-h3+ (K forced to h1) then Nf2+ forked K and Bd3.

## G65 (1800, W, won) notes
- Illegal 16.Re5-e3: own e4 pawn on the path. I skipped writing the path squares because the move "looked" simple. Rule stays: write every path square for EVERY slider move, including retreats.
- 19.Bxe6?! Kf6! (not recapturing) hit Be6 with the K while Bf8 hit Rc5 through the now-empty e7: a K move can unblock a bishop line. Before a capture that removes a piece next to the enemy K, check what the K move uncovers.
- Good: known trick 9.Nxe5 dxe5 10.Bxf7+ (d-file x-ray to d8); Bd4 pin of Re5 against Kf6; Rc7+ check-or-lose-the-rook.

## G66 (1800, B, lost) - discovered attack on my queen
- 14...Qxd4 put my Q on the d-file with only White's Bd2 between it and White's Qd1. 15.Bb5+ Kd8 16.Bg5+ moved that
  bishop WITH CHECK and the Qd1 hit my Qd4: every legal reply lost the queen. My scan from d4 stopped at the first
  piece on each ray (Bd2 = "a bishop, not attacking along the file") and never looked behind it.
- Rule (T11): on every ray from my destination square, if the first piece met is an ENEMY piece that does not attack
  along that ray, look BEHIND it. An enemy Q/R behind on a file/rank, or Q/B behind on a diagonal = DISCOVERY THREAT.
  Then ask: can the blocker move with check or capture? If yes, the square is unsafe for anything worth more than
  the blocker's tempo (queen especially).

## Block 11 summary (G61-66)
- Rated 3/4 (G63 W, G64 W, G65 W, G66 L). Losses still come from single tactical blind spots: G64 two pieces hanging
  after a capture (fork + pawn attack), G65 one illegal path (own pawn), G66 discovered attack on the queen.

## G69 (skill0, W, won) - my own piece unblocked an enemy rook onto my queen
- 21.Nc3?? : the Nd5 was the only piece between Black's Ra5 and my Qf5 on the 5th rank. Moving it = Rxf5.
  This is the ORIGIN SCAN failing again: I scanned the knight's destination (c3) carefully and never asked which
  enemy lines pass through d5. Rule: before moving ANY piece, read the 4 lines through its current square; if an
  enemy R/Q/B on one side and my piece of value on the other side -> that piece is a blocker, do not move it.
- Good: Rb6+ forcing Kd7, then Rb7+ skewering K and Rh7 along the 7th; Rc7# found by checking all 8 K squares.

## G70 (skill0, B, lost from +5) - knight fork after a "safe" queen move
- 62...Qf5?? (double attack on Nf1 and h5): f5 was not attacked by anything ON THE BOARD, but the knight could
  jump to e3 WITH CHECK and from e3 it hits f5. I checked "Ne3+ is just a check" one move earlier, then moved my Q
  onto a square that check also attacked. Rule: after choosing a destination for Q/R, list every enemy CHECK
  available next move and ask whether the checking piece also attacks my moved piece (knight forks especially).
- Also: when far ahead (Q+2P vs N+3P), simplify the safest way; a lone queen near an enemy knight is fork bait.
- Endgame lesson: N+2P vs P: my extra f-pawn could not promote past a blockading knight while White's g5 break
  created a passed h-pawn. Earlier, keep the queen and mate instead of chasing pawns.

## G72 (1800, B, lost) - piece put en prise on an open file
- 44...Bc2?? : c2 is on the c-file of White's Rc8 (c7-c3 empty). I was looking at the diagonal target (b3) and
  never ran the destination scan. Simplest possible miss: a straight ray from the destination to an enemy rook.
- 28...Bxh2: the pawn grab let f4 trap the bishop (h2-g3-f4 blocked, g1/g3 covered); cost a piece-for-pawn later.
  Rule: before grabbing with a bishop on the edge, list its retreat squares after the opponent's most natural reply.

## Block 12 summary (G67-72)
- Rated 2/4. Two of the losses were from winning positions (+5, +1). Each loss = one skipped scan on a quiet move.

## G73 (full, W, lost from +6) - a pinned pawn is not a defender
- 19.g3?? relied on f2 protecting g3, but Ba7-g1 pinned f2 to my king. Qxg3+ followed; fxg3 was illegal.
- Rule: when counting defenders, check each defender for a pin (enemy slider behind it on a line to my K/Q).
  Especially f2/f7 pawns on the a7-g1 / a2-g8 diagonals and knights in front of the king.

## G76 (skill0, B, drawn after losing a rook)
- 37...Rxa3?? : a3 was covered by the Nc4 (knight squares from c4: a3,a5,b2,b6,d2,d6,e3,e5). Destination scan skipped
  the knight list. Rule unchanged (T12 DEST line must enumerate enemy KNIGHT squares too, not just rays).
- Illegal f7-f5 attempt: my own king stood on f6 (path/occupancy check on my own pieces).
- Defence that worked: knight on e6 protecting c5+g5+g7, king adjacent to the knight, no pawn moves, only piece
  shuffles; check each king step for knight forks (Nd5+/Nc7+/Ne8+) and rook pins along the 6th rank (Rd6/Rf6).
  Keep the K off the 6th rank when a rook can reach d6 with the N on e6 (Rd6+ fork). Repetition draw resulted.

## G77 (1800, W, lost a winning bind)
- Trapped piece: 16.Ng5 (outpost) later had no retreat: e4 occupied by my own N, f3/h3 covered by ...g4,
  e6/f7/h7 covered. ...f6 attacked it. Rule: for any piece on an advanced square, list its retreat squares
  each time the opponent pushes a pawn toward it (f6/g5-type pawn hits) - keep at least one exit.
- Skewer by line-up: 31.Rxb5?? landed on b5 which is on the same diagonal (a6-f1) as my Qe2 -> ...Ba6
  attacked R with the Q behind. Rule (add to DEST): after my move, do two of my pieces (or piece + K) stand
  on one line with an EMPTY gap that an enemy bishop/rook can reach next move? If so, it is a skewer/pin.
- X-ray through a moving enemy piece: I thought ...Rxb2 hung to Qxb2, but the rook that left b6 opened the
  b-file so Qb8 protected b2; and Rb2 then pinned Qe2 to Kh2. Rule: when an enemy rook/queen sits behind
  another enemy piece on a file, count it as a defender of anything the front piece lands on.
- King box: K h2 with my pawns g3/h4 and Black pawn g4 (covers h3) + Black rook on the 1st rank = no flight
  squares; a rook check on the 2nd rank was mate. Rule: when the enemy has a pawn on g4/b4-type square next
  to my king, keep the back rank covered or keep a defender on the 2nd rank; never let both ranks be cut.

## G78 (1800, B, lost a winning attack in one move)
- Equal QGD-exchange structure; won the bishop pair (Ne4xd2), Qf6-h6, Re6-g6 vs K on g1/h1. After 21.Kh1
  I played 21...Rxg2 22.Kxg2 Qxh3+?? and 23.Kxh3: the queen gave check from a square ADJACENT to the king and
  was protected by nothing. My "forced mate" analysis listed flight squares and interpositions, never the king
  capturing the checker. (Correct was probably keeping the pressure: ...Rg6/...Qh6 setups were already strong.)
- Rule (T13-1): at every check node write "capture by: K? Q? R? B? N? P?" before "flights" and "blocks".

## Block 13 summary (G73-78)
- Full 0/2, skill0 1.5/2, 1800 0/2. All three one-move losses were enumeration gaps, not lack of ideas:
  knight squares, line-up skewer, king-captures-checker. T13 turns these into fixed checklists.

## G79 (full, W) - strategic, not tactical
- 8.h3 + castled king + Black's ...g5-g4 lever opened the h/g-files; with Ba7 pinning f2 and Rg7 pinning g2,
  my Nf3 was defended only by a pinned pawn. Lesson: vs ...g5 storms with my king short, do not open the h-file
  (12.hxg4 opened it); keep pieces that defend g2 without relying on pinned pawns (Nf1-g3/Nh2 setups, Kh1 early).

## G80 (full, B) - opening/king safety
- After 9.Bg5 (pin Ne7 to Qd8) and fxg3 the f-file opened toward f7 while my king was still on e8 and castling
  either side hung Be7/f7. Lesson for the 4.h4 h5 Caro: castle (or prepare ...O-O-O) before trading pieces that
  open f-lines; avoid ...Bxg5 when Nxg5 lands on f7/e6 squares with my king in the centre.
- Illegal: Qc7-e7 slid along the 7th through my own Nd7. DEST must list the PATH squares for sliders (T13 (3)).

## G81 (skill0, W, won)
- 26...f4: a PAWN push forked Be3 and Ng3. My DEST/REPLY scans list piece moves; add "enemy pawn advances:
  does any one-step pawn push attack two of my pieces?" (knight+bishop on adjacent diagonals of a pawn square).
- Illegal again: g2-g4 with my own king on g3. Two-square pawn pushes must check the intermediate square.
- What worked: T13 (2) line-up scan explicitly found K+R on one file (...Rf8+) and K+R on one diagonal
  (...Bh6+) before I played into them. Keep it.

## G82 (skill0, B, lost a won game) - loose pieces on queen lines
- 20...Qb4? offered a queen trade whose ONLY recapture (Ra4xb4) would open the a-file to Ra2xa8. Rule: when I
  plan "trade and recapture", run ORIGIN on the recapturing piece too.
- 34...Kh4?: my Nf3 stood on the f-file of Qf5 with nothing defending it. 38...Kg5?: Ne4 had left, d5 was loose
  on the queen's diagonal. 44...Kh7 (forced) after Qe8+: my Ra4 sat on the e8-a4 diagonal -> Qxa4.
- Rule (T13-REPLY sharpened): list EVERY loose (unprotected) piece of mine and, for the enemy queen, every line
  from its current square AND from each square it can check from. With a queen on the board, loose pieces die.

## G83 (1800, W, draw a pawn down)
- 23.g4?: a two-square pawn push next to an enemy pawn on h4 allows EN PASSANT; after hxg3+ Kxg3 Rxh3+ the
  rook on h3 was guarded by Bd7 along d7-h3 (opened when my g-pawn vanished). Check e.p. + lines it opens.
- Illegal Rd1-h1 through my own Re1: slider path squares again (3rd path error in 4 games). Write the path.

## G84 (1800, B, draw from an exchange down)
- 16.Bb4: my Qd6 and Rf8 stood on one diagonal (b4-c5-d6-e7-f8) -> skewer, exchange lost. LINE-UP scan must
  include Q+R on DIAGONALS (bishop skewers), not only ranks/files. Same pattern as G77 (...Ba6, Q+R on a6-e2).
- 36.Bxg6+: I counted on Kxg6, but g6 was on Qc2's b1-h7 diagonal. Before relying on a recapture, list the
  enemy pieces that attack the recapture square AFTER the exchange (lines opened by the captured piece).
- 39.fxg4: planned ...Nxg4, but g4 was guarded by Qe2 (e2-f3-g4). Same root: queen lines not listed.
- Illegal Qd6-f6 through my own e6 pawn: 5th slider-path error (G76 f7-f5, G80, G81, G83, G84). From the
  middle of G84 I wrote "PATH: squares" before every slider/2-step move and caught 57...b5 passing b6 ok.
- What worked (endgame): defending a pawn twice (Nc7), forcing queens off with a counter-attack on the queen
  (Rf8 vs Qf3/Rf1), checking EN PASSANT (57...b5? axb6 e.p. promotes), knight forks of loose pawns (Nc4),
  choosing the only king square that stops g7 tricks (Kg8; Kf6/Kf8 lost), steering into repetition.

## Block 14 summary (T13, G79-84)
- Full 0/2; rated 2/4 (G81 W, G82 L, G83 D, G84 D). Elo 1510 [1390,1640] after 56 rated (+20, noise).
- One-move material losses still occurred in 3 of 4 rated games (G82 x3, G83 g4 e.p., G84 Bb4/Bxg6/fxg4).
  Common root: ENEMY QUEEN/BISHOP DIAGONALS and lines opened by captures, plus slider paths (illegals).

## G85 (full, W)
- 19.d5?: after ...Bxd5 exd5 my e4 pawn had left e4, so ...e4 forked Bd3+Nf3. The T14 RECAPTURE check must
  include squares VACATED by my recapturing pawn (here e4) - enemy pawn pushes into them can fork.
- 27.Bxe4 Rxe4: the recapturing rook landed on my knight's rank (Nc4 loose) and e3 lost its only guard when the
  knight moved. Loose pieces + "piece that guards a pawn must move" = lost pawn.
- 29...Re1/...Rc1: a knight on b1 between my Ra1 and an enemy rook is pinned along the 1st rank; my rooks
  became passive defenders. Keep the back rank connected (rooks not separated by a minor piece).

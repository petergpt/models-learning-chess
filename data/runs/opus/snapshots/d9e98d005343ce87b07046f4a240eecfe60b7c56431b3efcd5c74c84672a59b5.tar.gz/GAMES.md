# Benchmark game log (one line per game)

| # | opp | col | result | plies | key note |
|---|-----|-----|--------|-------|----------|
| 1 | full | W | 0-1 resign | 44 | Italian; ...g5-g4 attack; lost pawn on d4; 21.Qxf7? Qxg3! (f2 pinned by Bd4), 22.Qf3?? Qxf3 (g2 pinned by Rg8) |
| 2 | full | B | 0-1 mate | 41 | Caro Advance 4.h4; 15...Qe7? blocked Bf8 from d6 -> Nd6+ (illegal Bxd6 attempt), king stuck d7, mated by Qa4+/Qxc6 |
| 3 | skill0 | W | 1-0 mate | 45 | Philidor; dxe5/exd6 +1; e5 fork; opp 12...Qxf6?? exf6; Rd7+g7 pawn net, Nf6# |
| 4 | skill0 | B | 0-1 mate | 56 | 1.c4 e5 reversed Sicilian; ...f5/...fxe4 won piece; opp hung Ba3, Rh1, Qd5; Qd2# with Bb4 |
| 5 | 1800 | W | 1-0 mate | 105 | Alapin 2...Nf6 3.e5 Ne4? 4.d3 trapped N; Q trade; 39.Rh8?? Rxh8 40.c8=Q? Rxc8 threw a rook; still won w/ 2B+N |
| 6 | 1800 | B | 0-1 resign | 128 | 1.Nf3 d5 London-ish; 4...Qb6 illegal (c7 blocks); 20...Qb6? dropped c4 + b-file pin lost B; 27...Nc5? blocked own c-file defence; lost |
| 7 | full | W | 0-1 resign | 46 | Italian again; ...h6/...g5-g4 attack; 23.Ng3? Rxg3 (g2 pinned on g-file); ~22k tokens |
| 8 | full | B | 0-1 mate | 39 | Caro 4.h4; was +1 after ...Bxb4; 18...O-O-O?? Ncd6+ Bxd6 Nxd6# (Rd8 blocked by own Nd7; Q by c6; Rh6 by e6) |

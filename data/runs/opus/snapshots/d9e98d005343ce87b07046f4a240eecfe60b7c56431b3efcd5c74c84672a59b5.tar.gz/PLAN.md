# Plan and learning log

## Facts about the measurement (from reading the referee code; operator-owned)
- Rotation per 6 games: full-strength W,B; skill-0 W,B; elo-1800 W,B. Engine: 1M nodes/move.
- Elo uses ONLY skill-0 (anchor 1320) and 1800-setting games; rolling window = last 50 rated games.
  200 games -> ~132 rated; final estimate ~ games 125-200.
- Full-strength games are benchmark evidence but excluded from Elo.

## Approach (initial hypothesis, unverified)
Main expected error sources for me: misreading the board, hanging pieces, missing opponent tactics,
illegal-move submissions, sloppy conversion (stalemate/repetition), long games burning budget.
Method: fixed per-move protocol (PROTOCOL.md), simple repertoire (REPERTOIRE.md),
post-game review of every non-win vs rated opponents (own analysis only; no engine),
error taxonomy with recurrence counts (ERRORS.md), targeted practice from my own failed positions.

## Evaluation
Each full rotation (6 games) = checkpoint; compare rated score and error recurrence per 12 games.

## Trials log
- T0 (games 1-6): baseline with PROTOCOL.md + REPERTOIRE.md. Next checkpoint: after game 6.
- T0 result (games 1-6): full 0/2, skill0 2/2, 1800 1/2 (won because opp blundered a knight on move 4; lost G6
  from my own line errors). Elo 1870 [1410,2460] after 4 rated games. Tokens used ~508k (too many: ~85k/game).
- T1 (games 7-12): weakness = line-of-sight errors (pins on defenders, self-blocking, abandoned defences, path
  errors). Trial = explicit LINE AUDIT step in PROTOCOL.md + token discipline (resign hopeless games early).
  Observable: 0 illegal attempts; fewer self-inflicted material losses in rated games (block 1: G6 had 3);
  average tokens/game <= 60k. Next evaluation point: after game 12.

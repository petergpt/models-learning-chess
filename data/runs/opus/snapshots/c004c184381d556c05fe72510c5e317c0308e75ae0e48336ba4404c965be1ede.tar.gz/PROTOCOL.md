# Move protocol (read before each game; keep short)

Board reading: python-chess ASCII, rank 8 at top, files a..h left->right. UPPER = White, lower = Black.
Index each row carefully (count 8 cells). Cross-check suspicious squares against the FEN.
NEVER send test input to ./play move (every submission counts; 3 illegal = forfeit).
UCI only: e2e4, castling e1g1/e1c1/e8g8/e8c8, promotion e7e8q. 3 illegal tries on one turn = forfeit.

Every move:
1. Opponent's last move: what does it attack / threaten now (checks, captures, forks, discovered lines,
   mate threats)? What did it stop guarding?
2. My loose pieces: anything attacked and under-defended, or attacked by a cheaper piece?
3. Candidates: my checks, captures, threats first; then the plan move.
4. LINE AUDIT (T1, from block-1 errors) for the moving piece:
   - Path: name every square between from- and to-square; all empty? (2 illegal tries came from this.)
   - What does it defend NOW (list), and will those still be defended after it moves?
   - Does its new square block one of MY lines (rook/queen/bishop defence through that square)?
   - Any enemy rook/bishop/queen x-ray that becomes a pin or skewer after the move?
5. DESTINATION CHECK (hard rule after G5/G9 queen-loss pattern): write the enemy piece list from the FEN and,
   for EACH enemy piece, ask "does it attack my destination square?" Especially: a rook/queen I attack along a
   line attacks me back along that line, and it is THEIR move. Never place Q/R on a square an enemy piece hits
   unless it is a deliberate, calculated trade.
6. Before submitting the chosen move:
   a. Legality: from-square holds my piece; path empty; piece not pinned; king not left in check.
   b. Blunder check: after the move, list EVERY opponent check and capture (incl. queen/bishop long
      diagonals, knight forks, back rank). Does anything lose material or allow mate?
   c. What did the moving piece stop defending?
   d. PINS: any of my recapturing/defending pawns or pieces pinned to my king (open files/diagonals
      to the king)? A pinned unit is not a defender. (G1: lost queen to this.)

Budget: aim ~1k tokens/move in quiet positions; think long only at real tactical moments.
Resign clearly lost positions vs full/1800 (e.g. down >=3 pts, no counterplay) instead of grinding.

Conversion (ahead in material): trade pieces not pawns, keep king safe, push passers, mate methodically.
STALEMATE CHECK whenever opponent has only king (+ blocked pawns): after my move, does their king have a move?
Draw claims are automatic: avoid repeating positions when winning.

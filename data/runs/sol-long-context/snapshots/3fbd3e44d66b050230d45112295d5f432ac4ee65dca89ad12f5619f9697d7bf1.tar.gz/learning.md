# Independent learning log

Initial state: zero benchmark games; no Elo estimate. All chess decisions are my own. No external study or assistance used.

Initial approach: develop pieces and castle, contest the center, and explicitly inspect opponent checks, captures, and threats before committing. Prefer a familiar 1.e4 setup as White and classical central development as Black. Avoid speculative sacrifices without a concrete continuation.

First evaluation point: one complete six-game paired-color rotation. This supplies initial diagnostic evidence, not a claim of improvement. After each game, record a specific weakness and a short learning trial before the next benchmark. Track missed threats, loose pieces, and conversion problems from my own observations; assessments are unverified unless demonstrated by the actual played continuation. Choose focused opponent practice when a repeated problem becomes visible.

No real token counter is available, so no usage counts will be invented.

## Benchmark 1 — White, maximum strength, loss by resignation (54 plies)
Observed: after 10.exd5 exd4 11.cxd4 Qxd5 12.Nc3 Qxd4, the d-pawn disappeared and queens were exchanged. My 12.Nc3 attacked the queen but did not prevent its capture of d4, which the b6 bishop supported. Later ...Rd2 and ...Rxb2 won another pawn. After Na4, Rd3, Kh2, ...b5 trapped the knight: each escape was capturable. These are my own board-based diagnoses; no engine evaluation was used.

Trial 1: improve exchange bookkeeping and pawn-break timing. Revisit the position before 10.exd5, consider the final material and remaining defenders in candidate central exchanges, then play one recorded practice from that position using 10.dxe5 instead. This alternative is an unverified hypothesis, not a recommended move from an external source. Stop the drill after reaching a stable middlegame or a clear failure. Next benchmark: game 2 immediately after the drill and review. Initial six-game evaluation point remains.

Mental review: following exd5/exd4/cxd4, d4 has a second attacker along b6-c5-d4. A tempo against the queen is insufficient if the retreat itself captures the loose pawn. In the endgame, Na4 needs a safe retreat before ...b5; merely attacking the rook does not establish knight safety.

Trial 1 outcome: practice from the remembered position continued dxe5 Ng4 Qf3 Qh4 Bf4 Bxf2+ Kf1 Bxe1. I overlooked the bishop capture on f2 with check and the subsequent rook capture. The trial failed to maintain material, even against skill 3. Stop recorded as an unfinished drill, not a loss or win and not part of Elo.
Decision: retain the exchange-bookkeeping target but add the actual demonstrated weakness: a direct check can override a developing move. My Qf3 defended f2 once, while bishop and knight both attacked it; Qh4 also guarded e1 through f2 after the bishop moved. Bf4 addressed h2 but missed f2. Before a quiet move, enumerate the opponent's checks against my king, then verify capture recaptures with king safety. This is a process change to test, not proof of improvement. Next new-position test is benchmark 2; full evaluation after game 6.

## Benchmark 2 — Black, maximum strength, loss by resignation (59 plies)
Material held through the opening but 20...Rfc8 allowed 21.Nb6, a fork of both rooks and the d7 bishop. My own mental calculation recognized the fork only after it appeared. In the subsequent endgame ...Nd7 left b7 undefended against Ra7; ...Na5 lost the knight, and ...Bxa5 then overlooked Rxa5. No illegal submissions. Two maximum-strength losses supply no calibrated Elo estimate: referee status excludes these uncalibrated games from the estimator.

Trial 2: destination-square safety, focused on knight forks and rook lines. Use the remembered position before 20...Rfc8 in a short skill-0 drill; my hypothesis is 20...Bb5, clearing d7 and avoiding the double-rook fork rather than placing a second rook on a fork square. Before each move identify enemy attacks on its destination and one-move forks; after the reply explicitly refresh rook lines. Observable success: reach ten additional plies without giving away an exchange or minor piece. This only tests a known example. Return to new benchmark game 3 after the drill; evaluate broader transfer at game 6.

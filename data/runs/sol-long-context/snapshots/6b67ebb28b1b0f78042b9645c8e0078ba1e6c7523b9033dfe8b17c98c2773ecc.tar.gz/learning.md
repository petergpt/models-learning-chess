# Independent learning log

Initial state: zero benchmark games; no Elo estimate. All chess decisions are my own. No external study or assistance used.

Initial approach: develop pieces and castle, contest the center, and explicitly inspect opponent checks, captures, and threats before committing. Prefer a familiar 1.e4 setup as White and classical central development as Black. Avoid speculative sacrifices without a concrete continuation.

First evaluation point: one complete six-game paired-color rotation. This supplies initial diagnostic evidence, not a claim of improvement. After each game, record a specific weakness and a short learning trial before the next benchmark. Track missed threats, loose pieces, and conversion problems from my own observations; assessments are unverified unless demonstrated by the actual played continuation. Choose focused opponent practice when a repeated problem becomes visible.

No real token counter is available, so no usage counts will be invented.

## Benchmark 1 — White, maximum strength, loss by resignation (54 plies)
Observed: after 10.exd5 exd4 11.cxd4 Qxd5 12.Nc3 Qxd4, the d-pawn disappeared and queens were exchanged. My 12.Nc3 attacked the queen but did not prevent its capture of d4, which the b6 bishop supported. Later ...Rd2 and ...Rxb2 won another pawn. After Na4, Rd3, Kh2, ...b5 trapped the knight: each escape was capturable. These are my own board-based diagnoses; no engine evaluation was used.

Trial 1: improve exchange bookkeeping and pawn-break timing. Revisit the position before 10.exd5, consider the final material and remaining defenders in candidate central exchanges, then play one recorded practice from that position using 10.dxe5 instead. This alternative is an unverified hypothesis, not a recommended move from an external source. Stop the drill after reaching a stable middlegame or a clear failure. Next benchmark: game 2 immediately after the drill and review. Initial six-game evaluation point remains.

Mental review: following exd5/exd4/cxd4, d4 has a second attacker along b6-c5-d4. A tempo against the queen is insufficient if the retreat itself captures the loose pawn. In the endgame, Na4 needs a safe retreat before ...b5; merely attacking the rook does not establish knight safety.
